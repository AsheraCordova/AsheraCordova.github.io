/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/babel-polyfill/lib/index.js":
/*!**************************************************!*\
  !*** ./node_modules/babel-polyfill/lib/index.js ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


__webpack_require__(/*! core-js/shim */ "./node_modules/core-js/shim.js");
__webpack_require__(/*! regenerator-runtime/runtime */ "./node_modules/regenerator-runtime/runtime.js");
__webpack_require__(/*! core-js/fn/regexp/escape */ "./node_modules/core-js/fn/regexp/escape.js");
if (__webpack_require__.g._babelPolyfill) {
  throw new Error("only one instance of babel-polyfill is allowed");
}
__webpack_require__.g._babelPolyfill = true;
var DEFINE_PROPERTY = "defineProperty";
function define(O, key, value) {
  O[key] || Object[DEFINE_PROPERTY](O, key, {
    writable: true,
    configurable: true,
    value: value
  });
}
define(String.prototype, "padLeft", "".padStart);
define(String.prototype, "padRight", "".padEnd);
"pop,reverse,shift,keys,values,entries,indexOf,every,some,forEach,map,filter,find,findIndex,includes,join,slice,concat,push,splice,unshift,sort,lastIndexOf,reduce,reduceRight,copyWithin,fill".split(",").forEach(function (key) {
  [][key] && define(Array, key, Function.call.bind([][key]));
});

/***/ }),

/***/ "./node_modules/class-transformer/esm5/ClassTransformer.js":
/*!*****************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/ClassTransformer.js ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClassTransformer: function() { return /* binding */ ClassTransformer; }
/* harmony export */ });
/* harmony import */ var _TransformOperationExecutor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TransformOperationExecutor */ "./node_modules/class-transformer/esm5/TransformOperationExecutor.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./enums */ "./node_modules/class-transformer/esm5/enums/transformation-type.enum.js");
/* harmony import */ var _constants_default_options_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./constants/default-options.constant */ "./node_modules/class-transformer/esm5/constants/default-options.constant.js");
var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};



var ClassTransformer = /** @class */function () {
  function ClassTransformer() {}
  ClassTransformer.prototype.instanceToPlain = function (object, options) {
    var executor = new _TransformOperationExecutor__WEBPACK_IMPORTED_MODULE_0__.TransformOperationExecutor(_enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_PLAIN, __assign(__assign({}, _constants_default_options_constant__WEBPACK_IMPORTED_MODULE_2__.defaultOptions), options));
    return executor.transform(undefined, object, undefined, undefined, undefined, undefined);
  };
  ClassTransformer.prototype.classToPlainFromExist = function (object, plainObject, options) {
    var executor = new _TransformOperationExecutor__WEBPACK_IMPORTED_MODULE_0__.TransformOperationExecutor(_enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_PLAIN, __assign(__assign({}, _constants_default_options_constant__WEBPACK_IMPORTED_MODULE_2__.defaultOptions), options));
    return executor.transform(plainObject, object, undefined, undefined, undefined, undefined);
  };
  ClassTransformer.prototype.plainToInstance = function (cls, plain, options) {
    var executor = new _TransformOperationExecutor__WEBPACK_IMPORTED_MODULE_0__.TransformOperationExecutor(_enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.PLAIN_TO_CLASS, __assign(__assign({}, _constants_default_options_constant__WEBPACK_IMPORTED_MODULE_2__.defaultOptions), options));
    return executor.transform(undefined, plain, cls, undefined, undefined, undefined);
  };
  ClassTransformer.prototype.plainToClassFromExist = function (clsObject, plain, options) {
    var executor = new _TransformOperationExecutor__WEBPACK_IMPORTED_MODULE_0__.TransformOperationExecutor(_enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.PLAIN_TO_CLASS, __assign(__assign({}, _constants_default_options_constant__WEBPACK_IMPORTED_MODULE_2__.defaultOptions), options));
    return executor.transform(clsObject, plain, undefined, undefined, undefined, undefined);
  };
  ClassTransformer.prototype.instanceToInstance = function (object, options) {
    var executor = new _TransformOperationExecutor__WEBPACK_IMPORTED_MODULE_0__.TransformOperationExecutor(_enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_CLASS, __assign(__assign({}, _constants_default_options_constant__WEBPACK_IMPORTED_MODULE_2__.defaultOptions), options));
    return executor.transform(undefined, object, undefined, undefined, undefined, undefined);
  };
  ClassTransformer.prototype.classToClassFromExist = function (object, fromObject, options) {
    var executor = new _TransformOperationExecutor__WEBPACK_IMPORTED_MODULE_0__.TransformOperationExecutor(_enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_CLASS, __assign(__assign({}, _constants_default_options_constant__WEBPACK_IMPORTED_MODULE_2__.defaultOptions), options));
    return executor.transform(fromObject, object, undefined, undefined, undefined, undefined);
  };
  ClassTransformer.prototype.serialize = function (object, options) {
    return JSON.stringify(this.instanceToPlain(object, options));
  };
  /**
   * Deserializes given JSON string to a object of the given class.
   */
  ClassTransformer.prototype.deserialize = function (cls, json, options) {
    var jsonObject = JSON.parse(json);
    return this.plainToInstance(cls, jsonObject, options);
  };
  /**
   * Deserializes given JSON string to an array of objects of the given class.
   */
  ClassTransformer.prototype.deserializeArray = function (cls, json, options) {
    var jsonObject = JSON.parse(json);
    return this.plainToInstance(cls, jsonObject, options);
  };
  return ClassTransformer;
}();


/***/ }),

/***/ "./node_modules/class-transformer/esm5/MetadataStorage.js":
/*!****************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/MetadataStorage.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MetadataStorage: function() { return /* binding */ MetadataStorage; }
/* harmony export */ });
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./enums */ "./node_modules/class-transformer/esm5/enums/transformation-type.enum.js");

/**
 * Storage all library metadata.
 */
var MetadataStorage = /** @class */function () {
  function MetadataStorage() {
    // -------------------------------------------------------------------------
    // Properties
    // -------------------------------------------------------------------------
    this._typeMetadatas = new Map();
    this._transformMetadatas = new Map();
    this._exposeMetadatas = new Map();
    this._excludeMetadatas = new Map();
    this._ancestorsMap = new Map();
  }
  // -------------------------------------------------------------------------
  // Adder Methods
  // -------------------------------------------------------------------------
  MetadataStorage.prototype.addTypeMetadata = function (metadata) {
    if (!this._typeMetadatas.has(metadata.target)) {
      this._typeMetadatas.set(metadata.target, new Map());
    }
    this._typeMetadatas.get(metadata.target).set(metadata.propertyName, metadata);
  };
  MetadataStorage.prototype.addTransformMetadata = function (metadata) {
    if (!this._transformMetadatas.has(metadata.target)) {
      this._transformMetadatas.set(metadata.target, new Map());
    }
    if (!this._transformMetadatas.get(metadata.target).has(metadata.propertyName)) {
      this._transformMetadatas.get(metadata.target).set(metadata.propertyName, []);
    }
    this._transformMetadatas.get(metadata.target).get(metadata.propertyName).push(metadata);
  };
  MetadataStorage.prototype.addExposeMetadata = function (metadata) {
    if (!this._exposeMetadatas.has(metadata.target)) {
      this._exposeMetadatas.set(metadata.target, new Map());
    }
    this._exposeMetadatas.get(metadata.target).set(metadata.propertyName, metadata);
  };
  MetadataStorage.prototype.addExcludeMetadata = function (metadata) {
    if (!this._excludeMetadatas.has(metadata.target)) {
      this._excludeMetadatas.set(metadata.target, new Map());
    }
    this._excludeMetadatas.get(metadata.target).set(metadata.propertyName, metadata);
  };
  // -------------------------------------------------------------------------
  // Public Methods
  // -------------------------------------------------------------------------
  MetadataStorage.prototype.findTransformMetadatas = function (target, propertyName, transformationType) {
    return this.findMetadatas(this._transformMetadatas, target, propertyName).filter(function (metadata) {
      if (!metadata.options) return true;
      if (metadata.options.toClassOnly === true && metadata.options.toPlainOnly === true) return true;
      if (metadata.options.toClassOnly === true) {
        return transformationType === _enums__WEBPACK_IMPORTED_MODULE_0__.TransformationType.CLASS_TO_CLASS || transformationType === _enums__WEBPACK_IMPORTED_MODULE_0__.TransformationType.PLAIN_TO_CLASS;
      }
      if (metadata.options.toPlainOnly === true) {
        return transformationType === _enums__WEBPACK_IMPORTED_MODULE_0__.TransformationType.CLASS_TO_PLAIN;
      }
      return true;
    });
  };
  MetadataStorage.prototype.findExcludeMetadata = function (target, propertyName) {
    return this.findMetadata(this._excludeMetadatas, target, propertyName);
  };
  MetadataStorage.prototype.findExposeMetadata = function (target, propertyName) {
    return this.findMetadata(this._exposeMetadatas, target, propertyName);
  };
  MetadataStorage.prototype.findExposeMetadataByCustomName = function (target, name) {
    return this.getExposedMetadatas(target).find(function (metadata) {
      return metadata.options && metadata.options.name === name;
    });
  };
  MetadataStorage.prototype.findTypeMetadata = function (target, propertyName) {
    return this.findMetadata(this._typeMetadatas, target, propertyName);
  };
  MetadataStorage.prototype.getStrategy = function (target) {
    var excludeMap = this._excludeMetadatas.get(target);
    var exclude = excludeMap && excludeMap.get(undefined);
    var exposeMap = this._exposeMetadatas.get(target);
    var expose = exposeMap && exposeMap.get(undefined);
    if (exclude && expose || !exclude && !expose) return 'none';
    return exclude ? 'excludeAll' : 'exposeAll';
  };
  MetadataStorage.prototype.getExposedMetadatas = function (target) {
    return this.getMetadata(this._exposeMetadatas, target);
  };
  MetadataStorage.prototype.getExcludedMetadatas = function (target) {
    return this.getMetadata(this._excludeMetadatas, target);
  };
  MetadataStorage.prototype.getExposedProperties = function (target, transformationType) {
    return this.getExposedMetadatas(target).filter(function (metadata) {
      if (!metadata.options) return true;
      if (metadata.options.toClassOnly === true && metadata.options.toPlainOnly === true) return true;
      if (metadata.options.toClassOnly === true) {
        return transformationType === _enums__WEBPACK_IMPORTED_MODULE_0__.TransformationType.CLASS_TO_CLASS || transformationType === _enums__WEBPACK_IMPORTED_MODULE_0__.TransformationType.PLAIN_TO_CLASS;
      }
      if (metadata.options.toPlainOnly === true) {
        return transformationType === _enums__WEBPACK_IMPORTED_MODULE_0__.TransformationType.CLASS_TO_PLAIN;
      }
      return true;
    }).map(function (metadata) {
      return metadata.propertyName;
    });
  };
  MetadataStorage.prototype.getExcludedProperties = function (target, transformationType) {
    return this.getExcludedMetadatas(target).filter(function (metadata) {
      if (!metadata.options) return true;
      if (metadata.options.toClassOnly === true && metadata.options.toPlainOnly === true) return true;
      if (metadata.options.toClassOnly === true) {
        return transformationType === _enums__WEBPACK_IMPORTED_MODULE_0__.TransformationType.CLASS_TO_CLASS || transformationType === _enums__WEBPACK_IMPORTED_MODULE_0__.TransformationType.PLAIN_TO_CLASS;
      }
      if (metadata.options.toPlainOnly === true) {
        return transformationType === _enums__WEBPACK_IMPORTED_MODULE_0__.TransformationType.CLASS_TO_PLAIN;
      }
      return true;
    }).map(function (metadata) {
      return metadata.propertyName;
    });
  };
  MetadataStorage.prototype.clear = function () {
    this._typeMetadatas.clear();
    this._exposeMetadatas.clear();
    this._excludeMetadatas.clear();
    this._ancestorsMap.clear();
  };
  // -------------------------------------------------------------------------
  // Private Methods
  // -------------------------------------------------------------------------
  MetadataStorage.prototype.getMetadata = function (metadatas, target) {
    var metadataFromTargetMap = metadatas.get(target);
    var metadataFromTarget;
    if (metadataFromTargetMap) {
      metadataFromTarget = Array.from(metadataFromTargetMap.values()).filter(function (meta) {
        return meta.propertyName !== undefined;
      });
    }
    var metadataFromAncestors = [];
    for (var _i = 0, _a = this.getAncestors(target); _i < _a.length; _i++) {
      var ancestor = _a[_i];
      var ancestorMetadataMap = metadatas.get(ancestor);
      if (ancestorMetadataMap) {
        var metadataFromAncestor = Array.from(ancestorMetadataMap.values()).filter(function (meta) {
          return meta.propertyName !== undefined;
        });
        metadataFromAncestors.push.apply(metadataFromAncestors, metadataFromAncestor);
      }
    }
    return metadataFromAncestors.concat(metadataFromTarget || []);
  };
  MetadataStorage.prototype.findMetadata = function (metadatas, target, propertyName) {
    var metadataFromTargetMap = metadatas.get(target);
    if (metadataFromTargetMap) {
      var metadataFromTarget = metadataFromTargetMap.get(propertyName);
      if (metadataFromTarget) {
        return metadataFromTarget;
      }
    }
    for (var _i = 0, _a = this.getAncestors(target); _i < _a.length; _i++) {
      var ancestor = _a[_i];
      var ancestorMetadataMap = metadatas.get(ancestor);
      if (ancestorMetadataMap) {
        var ancestorResult = ancestorMetadataMap.get(propertyName);
        if (ancestorResult) {
          return ancestorResult;
        }
      }
    }
    return undefined;
  };
  MetadataStorage.prototype.findMetadatas = function (metadatas, target, propertyName) {
    var metadataFromTargetMap = metadatas.get(target);
    var metadataFromTarget;
    if (metadataFromTargetMap) {
      metadataFromTarget = metadataFromTargetMap.get(propertyName);
    }
    var metadataFromAncestorsTarget = [];
    for (var _i = 0, _a = this.getAncestors(target); _i < _a.length; _i++) {
      var ancestor = _a[_i];
      var ancestorMetadataMap = metadatas.get(ancestor);
      if (ancestorMetadataMap) {
        if (ancestorMetadataMap.has(propertyName)) {
          metadataFromAncestorsTarget.push.apply(metadataFromAncestorsTarget, ancestorMetadataMap.get(propertyName));
        }
      }
    }
    return metadataFromAncestorsTarget.slice().reverse().concat((metadataFromTarget || []).slice().reverse());
  };
  MetadataStorage.prototype.getAncestors = function (target) {
    if (!target) return [];
    if (!this._ancestorsMap.has(target)) {
      var ancestors = [];
      for (var baseClass = Object.getPrototypeOf(target.prototype.constructor); typeof baseClass.prototype !== 'undefined'; baseClass = Object.getPrototypeOf(baseClass.prototype.constructor)) {
        ancestors.push(baseClass);
      }
      this._ancestorsMap.set(target, ancestors);
    }
    return this._ancestorsMap.get(target);
  };
  return MetadataStorage;
}();


/***/ }),

/***/ "./node_modules/class-transformer/esm5/TransformOperationExecutor.js":
/*!***************************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/TransformOperationExecutor.js ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TransformOperationExecutor: function() { return /* binding */ TransformOperationExecutor; }
/* harmony export */ });
/* harmony import */ var _storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./storage */ "./node_modules/class-transformer/esm5/storage.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./enums */ "./node_modules/class-transformer/esm5/enums/transformation-type.enum.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils */ "./node_modules/class-transformer/esm5/utils/get-global.util.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils */ "./node_modules/class-transformer/esm5/utils/is-promise.util.js");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var __spreadArray = undefined && undefined.__spreadArray || function (to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};



function instantiateArrayType(arrayType) {
  var array = new arrayType();
  if (!(array instanceof Set) && !('push' in array)) {
    return [];
  }
  return array;
}
var TransformOperationExecutor = /** @class */function () {
  // -------------------------------------------------------------------------
  // Constructor
  // -------------------------------------------------------------------------
  function TransformOperationExecutor(transformationType, options) {
    this.transformationType = transformationType;
    this.options = options;
    // -------------------------------------------------------------------------
    // Private Properties
    // -------------------------------------------------------------------------
    this.recursionStack = new Set();
  }
  // -------------------------------------------------------------------------
  // Public Methods
  // -------------------------------------------------------------------------
  TransformOperationExecutor.prototype.transform = function (source, value, targetType, arrayType, isMap, level) {
    var _this = this;
    if (level === void 0) {
      level = 0;
    }
    if (Array.isArray(value) || value instanceof Set) {
      var newValue_1 = arrayType && this.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.PLAIN_TO_CLASS ? instantiateArrayType(arrayType) : [];
      value.forEach(function (subValue, index) {
        var subSource = source ? source[index] : undefined;
        if (!_this.options.enableCircularCheck || !_this.isCircular(subValue)) {
          var realTargetType = void 0;
          if (typeof targetType !== 'function' && targetType && targetType.options && targetType.options.discriminator && targetType.options.discriminator.property && targetType.options.discriminator.subTypes) {
            if (_this.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.PLAIN_TO_CLASS) {
              realTargetType = targetType.options.discriminator.subTypes.find(function (subType) {
                return subType.name === subValue[targetType.options.discriminator.property];
              });
              var options = {
                newObject: newValue_1,
                object: subValue,
                property: undefined
              };
              var newType = targetType.typeFunction(options);
              realTargetType === undefined ? realTargetType = newType : realTargetType = realTargetType.value;
              if (!targetType.options.keepDiscriminatorProperty) delete subValue[targetType.options.discriminator.property];
            }
            if (_this.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_CLASS) {
              realTargetType = subValue.constructor;
            }
            if (_this.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_PLAIN) {
              subValue[targetType.options.discriminator.property] = targetType.options.discriminator.subTypes.find(function (subType) {
                return subType.value === subValue.constructor;
              }).name;
            }
          } else {
            realTargetType = targetType;
          }
          var value_1 = _this.transform(subSource, subValue, realTargetType, undefined, subValue instanceof Map, level + 1);
          if (newValue_1 instanceof Set) {
            newValue_1.add(value_1);
          } else {
            newValue_1.push(value_1);
          }
        } else if (_this.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_CLASS) {
          if (newValue_1 instanceof Set) {
            newValue_1.add(subValue);
          } else {
            newValue_1.push(subValue);
          }
        }
      });
      return newValue_1;
    } else if (targetType === String && !isMap) {
      if (value === null || value === undefined) return value;
      return String(value);
    } else if (targetType === Number && !isMap) {
      if (value === null || value === undefined) return value;
      return Number(value);
    } else if (targetType === Boolean && !isMap) {
      if (value === null || value === undefined) return value;
      return Boolean(value);
    } else if ((targetType === Date || value instanceof Date) && !isMap) {
      if (value instanceof Date) {
        return new Date(value.valueOf());
      }
      if (value === null || value === undefined) return value;
      return new Date(value);
    } else if (!!(0,_utils__WEBPACK_IMPORTED_MODULE_2__.getGlobal)().Buffer && (targetType === Buffer || value instanceof Buffer) && !isMap) {
      if (value === null || value === undefined) return value;
      return Buffer.from(value);
    } else if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__.isPromise)(value) && !isMap) {
      return new Promise(function (resolve, reject) {
        value.then(function (data) {
          return resolve(_this.transform(undefined, data, targetType, undefined, undefined, level + 1));
        }, reject);
      });
    } else if (!isMap && value !== null && _typeof(value) === 'object' && typeof value.then === 'function') {
      // Note: We should not enter this, as promise has been handled above
      // This option simply returns the Promise preventing a JS error from happening and should be an inaccessible path.
      return value; // skip promise transformation
    } else if (_typeof(value) === 'object' && value !== null) {
      // try to guess the type
      if (!targetType && value.constructor !== Object /* && TransformationType === TransformationType.CLASS_TO_PLAIN*/) if (!Array.isArray(value) && value.constructor === Array) {
        // Somebody attempts to convert special Array like object to Array, eg:
        // const evilObject = { '100000000': '100000000', __proto__: [] };
        // This could be used to cause Denial-of-service attack so we don't allow it.
        // See prevent-array-bomb.spec.ts for more details.
      } else {
        // We are good we can use the built-in constructor
        targetType = value.constructor;
      }
      if (!targetType && source) targetType = source.constructor;
      if (this.options.enableCircularCheck) {
        // add transformed type to prevent circular references
        this.recursionStack.add(value);
      }
      var keys = this.getKeys(targetType, value, isMap);
      var newValue = source ? source : {};
      if (!source && (this.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.PLAIN_TO_CLASS || this.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_CLASS)) {
        if (isMap) {
          newValue = new Map();
        } else if (targetType) {
          newValue = new targetType();
        } else {
          newValue = {};
        }
      }
      var _loop_1 = function _loop_1(key) {
        if (key === '__proto__' || key === 'constructor') {
          return "continue";
        }
        var valueKey = key;
        var newValueKey = key,
          propertyName = key;
        if (!this_1.options.ignoreDecorators && targetType) {
          if (this_1.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.PLAIN_TO_CLASS) {
            var exposeMetadata = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.findExposeMetadataByCustomName(targetType, key);
            if (exposeMetadata) {
              propertyName = exposeMetadata.propertyName;
              newValueKey = exposeMetadata.propertyName;
            }
          } else if (this_1.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_PLAIN || this_1.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_CLASS) {
            var exposeMetadata = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.findExposeMetadata(targetType, key);
            if (exposeMetadata && exposeMetadata.options && exposeMetadata.options.name) {
              newValueKey = exposeMetadata.options.name;
            }
          }
        }
        // get a subvalue
        var subValue = undefined;
        if (this_1.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.PLAIN_TO_CLASS) {
          /**
           * This section is added for the following report:
           * https://github.com/typestack/class-transformer/issues/596
           *
           * We should not call functions or constructors when transforming to class.
           */
          subValue = value[valueKey];
        } else {
          if (value instanceof Map) {
            subValue = value.get(valueKey);
          } else if (value[valueKey] instanceof Function) {
            subValue = value[valueKey]();
          } else {
            subValue = value[valueKey];
          }
        }
        // determine a type
        var type = undefined,
          isSubValueMap = subValue instanceof Map;
        if (targetType && isMap) {
          type = targetType;
        } else if (targetType) {
          var metadata_1 = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.findTypeMetadata(targetType, propertyName);
          if (metadata_1) {
            var options = {
              newObject: newValue,
              object: value,
              property: propertyName
            };
            var newType = metadata_1.typeFunction ? metadata_1.typeFunction(options) : metadata_1.reflectedType;
            if (metadata_1.options && metadata_1.options.discriminator && metadata_1.options.discriminator.property && metadata_1.options.discriminator.subTypes) {
              if (!(value[valueKey] instanceof Array)) {
                if (this_1.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.PLAIN_TO_CLASS) {
                  type = metadata_1.options.discriminator.subTypes.find(function (subType) {
                    if (subValue && subValue instanceof Object && metadata_1.options.discriminator.property in subValue) {
                      return subType.name === subValue[metadata_1.options.discriminator.property];
                    }
                  });
                  type === undefined ? type = newType : type = type.value;
                  if (!metadata_1.options.keepDiscriminatorProperty) {
                    if (subValue && subValue instanceof Object && metadata_1.options.discriminator.property in subValue) {
                      delete subValue[metadata_1.options.discriminator.property];
                    }
                  }
                }
                if (this_1.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_CLASS) {
                  type = subValue.constructor;
                }
                if (this_1.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_PLAIN) {
                  if (subValue) {
                    subValue[metadata_1.options.discriminator.property] = metadata_1.options.discriminator.subTypes.find(function (subType) {
                      return subType.value === subValue.constructor;
                    }).name;
                  }
                }
              } else {
                type = metadata_1;
              }
            } else {
              type = newType;
            }
            isSubValueMap = isSubValueMap || metadata_1.reflectedType === Map;
          } else if (this_1.options.targetMaps) {
            // try to find a type in target maps
            this_1.options.targetMaps.filter(function (map) {
              return map.target === targetType && !!map.properties[propertyName];
            }).forEach(function (map) {
              return type = map.properties[propertyName];
            });
          } else if (this_1.options.enableImplicitConversion && this_1.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.PLAIN_TO_CLASS) {
            // if we have no registererd type via the @Type() decorator then we check if we have any
            // type declarations in reflect-metadata (type declaration is emited only if some decorator is added to the property.)
            var reflectedType = Reflect.getMetadata('design:type', targetType.prototype, propertyName);
            if (reflectedType) {
              type = reflectedType;
            }
          }
        }
        // if value is an array try to get its custom array type
        var arrayType_1 = Array.isArray(value[valueKey]) ? this_1.getReflectedType(targetType, propertyName) : undefined;
        // const subValueKey = TransformationType === TransformationType.PLAIN_TO_CLASS && newKeyName ? newKeyName : key;
        var subSource = source ? source[valueKey] : undefined;
        // if its deserialization then type if required
        // if we uncomment this types like string[] will not work
        // if (this.transformationType === TransformationType.PLAIN_TO_CLASS && !type && subValue instanceof Object && !(subValue instanceof Date))
        //     throw new Error(`Cannot determine type for ${(targetType as any).name }.${propertyName}, did you forget to specify a @Type?`);
        // if newValue is a source object that has method that match newKeyName then skip it
        if (newValue.constructor.prototype) {
          var descriptor = Object.getOwnPropertyDescriptor(newValue.constructor.prototype, newValueKey);
          if ((this_1.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.PLAIN_TO_CLASS || this_1.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_CLASS) && (
          // eslint-disable-next-line @typescript-eslint/unbound-method
          descriptor && !descriptor.set || newValue[newValueKey] instanceof Function)) return "continue";
        }
        if (!this_1.options.enableCircularCheck || !this_1.isCircular(subValue)) {
          var transformKey = this_1.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.PLAIN_TO_CLASS ? newValueKey : key;
          var finalValue = void 0;
          if (this_1.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_PLAIN) {
            // Get original value
            finalValue = value[transformKey];
            // Apply custom transformation
            finalValue = this_1.applyCustomTransformations(finalValue, targetType, transformKey, value, this_1.transformationType);
            // If nothing change, it means no custom transformation was applied, so use the subValue.
            finalValue = value[transformKey] === finalValue ? subValue : finalValue;
            // Apply the default transformation
            finalValue = this_1.transform(subSource, finalValue, type, arrayType_1, isSubValueMap, level + 1);
          } else {
            if (subValue === undefined && this_1.options.exposeDefaultValues) {
              // Set default value if nothing provided
              finalValue = newValue[newValueKey];
            } else {
              finalValue = this_1.transform(subSource, subValue, type, arrayType_1, isSubValueMap, level + 1);
              finalValue = this_1.applyCustomTransformations(finalValue, targetType, transformKey, value, this_1.transformationType);
            }
          }
          if (finalValue !== undefined || this_1.options.exposeUnsetFields) {
            if (newValue instanceof Map) {
              newValue.set(newValueKey, finalValue);
            } else {
              newValue[newValueKey] = finalValue;
            }
          }
        } else if (this_1.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.CLASS_TO_CLASS) {
          var finalValue = subValue;
          finalValue = this_1.applyCustomTransformations(finalValue, targetType, key, value, this_1.transformationType);
          if (finalValue !== undefined || this_1.options.exposeUnsetFields) {
            if (newValue instanceof Map) {
              newValue.set(newValueKey, finalValue);
            } else {
              newValue[newValueKey] = finalValue;
            }
          }
        }
      };
      var this_1 = this;
      // traverse over keys
      for (var _i = 0, keys_1 = keys; _i < keys_1.length; _i++) {
        var key = keys_1[_i];
        _loop_1(key);
      }
      if (this.options.enableCircularCheck) {
        this.recursionStack.delete(value);
      }
      return newValue;
    } else {
      return value;
    }
  };
  TransformOperationExecutor.prototype.applyCustomTransformations = function (value, target, key, obj, transformationType) {
    var _this = this;
    var metadatas = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.findTransformMetadatas(target, key, this.transformationType);
    // apply versioning options
    if (this.options.version !== undefined) {
      metadatas = metadatas.filter(function (metadata) {
        if (!metadata.options) return true;
        return _this.checkVersion(metadata.options.since, metadata.options.until);
      });
    }
    // apply grouping options
    if (this.options.groups && this.options.groups.length) {
      metadatas = metadatas.filter(function (metadata) {
        if (!metadata.options) return true;
        return _this.checkGroups(metadata.options.groups);
      });
    } else {
      metadatas = metadatas.filter(function (metadata) {
        return !metadata.options || !metadata.options.groups || !metadata.options.groups.length;
      });
    }
    metadatas.forEach(function (metadata) {
      value = metadata.transformFn({
        value: value,
        key: key,
        obj: obj,
        type: transformationType,
        options: _this.options
      });
    });
    return value;
  };
  // preventing circular references
  TransformOperationExecutor.prototype.isCircular = function (object) {
    return this.recursionStack.has(object);
  };
  TransformOperationExecutor.prototype.getReflectedType = function (target, propertyName) {
    if (!target) return undefined;
    var meta = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.findTypeMetadata(target, propertyName);
    return meta ? meta.reflectedType : undefined;
  };
  TransformOperationExecutor.prototype.getKeys = function (target, object, isMap) {
    var _this = this;
    // determine exclusion strategy
    var strategy = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.getStrategy(target);
    if (strategy === 'none') strategy = this.options.strategy || 'exposeAll'; // exposeAll is default strategy
    // get all keys that need to expose
    var keys = [];
    if (strategy === 'exposeAll' || isMap) {
      if (object instanceof Map) {
        keys = Array.from(object.keys());
      } else {
        keys = Object.keys(object);
      }
    }
    if (isMap) {
      // expose & exclude do not apply for map keys only to fields
      return keys;
    }
    /**
     * If decorators are ignored but we don't want the extraneous values, then we use the
     * metadata to decide which property is needed, but doesn't apply the decorator effect.
     */
    if (this.options.ignoreDecorators && this.options.excludeExtraneousValues && target) {
      var exposedProperties = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.getExposedProperties(target, this.transformationType);
      var excludedProperties = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.getExcludedProperties(target, this.transformationType);
      keys = __spreadArray(__spreadArray([], exposedProperties, true), excludedProperties, true);
    }
    if (!this.options.ignoreDecorators && target) {
      // add all exposed to list of keys
      var exposedProperties = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.getExposedProperties(target, this.transformationType);
      if (this.transformationType === _enums__WEBPACK_IMPORTED_MODULE_1__.TransformationType.PLAIN_TO_CLASS) {
        exposedProperties = exposedProperties.map(function (key) {
          var exposeMetadata = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.findExposeMetadata(target, key);
          if (exposeMetadata && exposeMetadata.options && exposeMetadata.options.name) {
            return exposeMetadata.options.name;
          }
          return key;
        });
      }
      if (this.options.excludeExtraneousValues) {
        keys = exposedProperties;
      } else {
        keys = keys.concat(exposedProperties);
      }
      // exclude excluded properties
      var excludedProperties_1 = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.getExcludedProperties(target, this.transformationType);
      if (excludedProperties_1.length > 0) {
        keys = keys.filter(function (key) {
          return !excludedProperties_1.includes(key);
        });
      }
      // apply versioning options
      if (this.options.version !== undefined) {
        keys = keys.filter(function (key) {
          var exposeMetadata = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.findExposeMetadata(target, key);
          if (!exposeMetadata || !exposeMetadata.options) return true;
          return _this.checkVersion(exposeMetadata.options.since, exposeMetadata.options.until);
        });
      }
      // apply grouping options
      if (this.options.groups && this.options.groups.length) {
        keys = keys.filter(function (key) {
          var exposeMetadata = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.findExposeMetadata(target, key);
          if (!exposeMetadata || !exposeMetadata.options) return true;
          return _this.checkGroups(exposeMetadata.options.groups);
        });
      } else {
        keys = keys.filter(function (key) {
          var exposeMetadata = _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.findExposeMetadata(target, key);
          return !exposeMetadata || !exposeMetadata.options || !exposeMetadata.options.groups || !exposeMetadata.options.groups.length;
        });
      }
    }
    // exclude prefixed properties
    if (this.options.excludePrefixes && this.options.excludePrefixes.length) {
      keys = keys.filter(function (key) {
        return _this.options.excludePrefixes.every(function (prefix) {
          return key.substr(0, prefix.length) !== prefix;
        });
      });
    }
    // make sure we have unique keys
    keys = keys.filter(function (key, index, self) {
      return self.indexOf(key) === index;
    });
    return keys;
  };
  TransformOperationExecutor.prototype.checkVersion = function (since, until) {
    var decision = true;
    if (decision && since) decision = this.options.version >= since;
    if (decision && until) decision = this.options.version < until;
    return decision;
  };
  TransformOperationExecutor.prototype.checkGroups = function (groups) {
    if (!groups) return true;
    return this.options.groups.some(function (optionGroup) {
      return groups.includes(optionGroup);
    });
  };
  return TransformOperationExecutor;
}();


/***/ }),

/***/ "./node_modules/class-transformer/esm5/constants/default-options.constant.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/constants/default-options.constant.js ***!
  \***********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   defaultOptions: function() { return /* binding */ defaultOptions; }
/* harmony export */ });
/**
 * These are the default options used by any transformation operation.
 */
var defaultOptions = {
  enableCircularCheck: false,
  enableImplicitConversion: false,
  excludeExtraneousValues: false,
  excludePrefixes: undefined,
  exposeDefaultValues: false,
  exposeUnsetFields: true,
  groups: undefined,
  ignoreDecorators: false,
  strategy: undefined,
  targetMaps: undefined,
  version: undefined
};

/***/ }),

/***/ "./node_modules/class-transformer/esm5/decorators/exclude.decorator.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/decorators/exclude.decorator.js ***!
  \*****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Exclude: function() { return /* binding */ Exclude; }
/* harmony export */ });
/* harmony import */ var _storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../storage */ "./node_modules/class-transformer/esm5/storage.js");

/**
 * Marks the given class or property as excluded. By default the property is excluded in both
 * constructorToPlain and plainToConstructor transformations. It can be limited to only one direction
 * via using the `toPlainOnly` or `toClassOnly` option.
 *
 * Can be applied to class definitions and properties.
 */
function Exclude(options) {
  if (options === void 0) {
    options = {};
  }
  /**
   * NOTE: The `propertyName` property must be marked as optional because
   * this decorator used both as a class and a property decorator and the
   * Typescript compiler will freak out if we make it mandatory as a class
   * decorator only receives one parameter.
   */
  return function (object, propertyName) {
    _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.addExcludeMetadata({
      target: object instanceof Function ? object : object.constructor,
      propertyName: propertyName,
      options: options
    });
  };
}

/***/ }),

/***/ "./node_modules/class-transformer/esm5/decorators/expose.decorator.js":
/*!****************************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/decorators/expose.decorator.js ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Expose: function() { return /* binding */ Expose; }
/* harmony export */ });
/* harmony import */ var _storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../storage */ "./node_modules/class-transformer/esm5/storage.js");

/**
 * Marks the given class or property as included. By default the property is included in both
 * constructorToPlain and plainToConstructor transformations. It can be limited to only one direction
 * via using the `toPlainOnly` or `toClassOnly` option.
 *
 * Can be applied to class definitions and properties.
 */
function Expose(options) {
  if (options === void 0) {
    options = {};
  }
  /**
   * NOTE: The `propertyName` property must be marked as optional because
   * this decorator used both as a class and a property decorator and the
   * Typescript compiler will freak out if we make it mandatory as a class
   * decorator only receives one parameter.
   */
  return function (object, propertyName) {
    _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.addExposeMetadata({
      target: object instanceof Function ? object : object.constructor,
      propertyName: propertyName,
      options: options
    });
  };
}

/***/ }),

/***/ "./node_modules/class-transformer/esm5/decorators/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/decorators/index.js ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Exclude: function() { return /* reexport safe */ _exclude_decorator__WEBPACK_IMPORTED_MODULE_0__.Exclude; },
/* harmony export */   Expose: function() { return /* reexport safe */ _expose_decorator__WEBPACK_IMPORTED_MODULE_1__.Expose; },
/* harmony export */   Transform: function() { return /* reexport safe */ _transform_decorator__WEBPACK_IMPORTED_MODULE_5__.Transform; },
/* harmony export */   TransformInstanceToInstance: function() { return /* reexport safe */ _transform_instance_to_instance_decorator__WEBPACK_IMPORTED_MODULE_2__.TransformInstanceToInstance; },
/* harmony export */   TransformInstanceToPlain: function() { return /* reexport safe */ _transform_instance_to_plain_decorator__WEBPACK_IMPORTED_MODULE_3__.TransformInstanceToPlain; },
/* harmony export */   TransformPlainToInstance: function() { return /* reexport safe */ _transform_plain_to_instance_decorator__WEBPACK_IMPORTED_MODULE_4__.TransformPlainToInstance; },
/* harmony export */   Type: function() { return /* reexport safe */ _type_decorator__WEBPACK_IMPORTED_MODULE_6__.Type; }
/* harmony export */ });
/* harmony import */ var _exclude_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./exclude.decorator */ "./node_modules/class-transformer/esm5/decorators/exclude.decorator.js");
/* harmony import */ var _expose_decorator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./expose.decorator */ "./node_modules/class-transformer/esm5/decorators/expose.decorator.js");
/* harmony import */ var _transform_instance_to_instance_decorator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./transform-instance-to-instance.decorator */ "./node_modules/class-transformer/esm5/decorators/transform-instance-to-instance.decorator.js");
/* harmony import */ var _transform_instance_to_plain_decorator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./transform-instance-to-plain.decorator */ "./node_modules/class-transformer/esm5/decorators/transform-instance-to-plain.decorator.js");
/* harmony import */ var _transform_plain_to_instance_decorator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./transform-plain-to-instance.decorator */ "./node_modules/class-transformer/esm5/decorators/transform-plain-to-instance.decorator.js");
/* harmony import */ var _transform_decorator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./transform.decorator */ "./node_modules/class-transformer/esm5/decorators/transform.decorator.js");
/* harmony import */ var _type_decorator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./type.decorator */ "./node_modules/class-transformer/esm5/decorators/type.decorator.js");








/***/ }),

/***/ "./node_modules/class-transformer/esm5/decorators/transform-instance-to-instance.decorator.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/decorators/transform-instance-to-instance.decorator.js ***!
  \****************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TransformInstanceToInstance: function() { return /* binding */ TransformInstanceToInstance; }
/* harmony export */ });
/* harmony import */ var _ClassTransformer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../ClassTransformer */ "./node_modules/class-transformer/esm5/ClassTransformer.js");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }

/**
 * Return the class instance only with the exposed properties.
 *
 * Can be applied to functions and getters/setters only.
 */
function TransformInstanceToInstance(params) {
  return function (target, propertyKey, descriptor) {
    var classTransformer = new _ClassTransformer__WEBPACK_IMPORTED_MODULE_0__.ClassTransformer();
    var originalMethod = descriptor.value;
    descriptor.value = function () {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      var result = originalMethod.apply(this, args);
      var isPromise = !!result && (_typeof(result) === 'object' || typeof result === 'function') && typeof result.then === 'function';
      return isPromise ? result.then(function (data) {
        return classTransformer.instanceToInstance(data, params);
      }) : classTransformer.instanceToInstance(result, params);
    };
  };
}

/***/ }),

/***/ "./node_modules/class-transformer/esm5/decorators/transform-instance-to-plain.decorator.js":
/*!*************************************************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/decorators/transform-instance-to-plain.decorator.js ***!
  \*************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TransformInstanceToPlain: function() { return /* binding */ TransformInstanceToPlain; }
/* harmony export */ });
/* harmony import */ var _ClassTransformer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../ClassTransformer */ "./node_modules/class-transformer/esm5/ClassTransformer.js");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }

/**
 * Transform the object from class to plain object and return only with the exposed properties.
 *
 * Can be applied to functions and getters/setters only.
 */
function TransformInstanceToPlain(params) {
  return function (target, propertyKey, descriptor) {
    var classTransformer = new _ClassTransformer__WEBPACK_IMPORTED_MODULE_0__.ClassTransformer();
    var originalMethod = descriptor.value;
    descriptor.value = function () {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      var result = originalMethod.apply(this, args);
      var isPromise = !!result && (_typeof(result) === 'object' || typeof result === 'function') && typeof result.then === 'function';
      return isPromise ? result.then(function (data) {
        return classTransformer.instanceToPlain(data, params);
      }) : classTransformer.instanceToPlain(result, params);
    };
  };
}

/***/ }),

/***/ "./node_modules/class-transformer/esm5/decorators/transform-plain-to-instance.decorator.js":
/*!*************************************************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/decorators/transform-plain-to-instance.decorator.js ***!
  \*************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TransformPlainToInstance: function() { return /* binding */ TransformPlainToInstance; }
/* harmony export */ });
/* harmony import */ var _ClassTransformer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../ClassTransformer */ "./node_modules/class-transformer/esm5/ClassTransformer.js");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }

/**
 * Return the class instance only with the exposed properties.
 *
 * Can be applied to functions and getters/setters only.
 */
function TransformPlainToInstance(classType, params) {
  return function (target, propertyKey, descriptor) {
    var classTransformer = new _ClassTransformer__WEBPACK_IMPORTED_MODULE_0__.ClassTransformer();
    var originalMethod = descriptor.value;
    descriptor.value = function () {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      var result = originalMethod.apply(this, args);
      var isPromise = !!result && (_typeof(result) === 'object' || typeof result === 'function') && typeof result.then === 'function';
      return isPromise ? result.then(function (data) {
        return classTransformer.plainToInstance(classType, data, params);
      }) : classTransformer.plainToInstance(classType, result, params);
    };
  };
}

/***/ }),

/***/ "./node_modules/class-transformer/esm5/decorators/transform.decorator.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/decorators/transform.decorator.js ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Transform: function() { return /* binding */ Transform; }
/* harmony export */ });
/* harmony import */ var _storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../storage */ "./node_modules/class-transformer/esm5/storage.js");

/**
 * Defines a custom logic for value transformation.
 *
 * Can be applied to properties only.
 */
function Transform(transformFn, options) {
  if (options === void 0) {
    options = {};
  }
  return function (target, propertyName) {
    _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.addTransformMetadata({
      target: target.constructor,
      propertyName: propertyName,
      transformFn: transformFn,
      options: options
    });
  };
}

/***/ }),

/***/ "./node_modules/class-transformer/esm5/decorators/type.decorator.js":
/*!**************************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/decorators/type.decorator.js ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Type: function() { return /* binding */ Type; }
/* harmony export */ });
/* harmony import */ var _storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../storage */ "./node_modules/class-transformer/esm5/storage.js");

/**
 * Specifies a type of the property.
 * The given TypeFunction can return a constructor. A discriminator can be given in the options.
 *
 * Can be applied to properties only.
 */
function Type(typeFunction, options) {
  if (options === void 0) {
    options = {};
  }
  return function (target, propertyName) {
    var reflectedType = Reflect.getMetadata('design:type', target, propertyName);
    _storage__WEBPACK_IMPORTED_MODULE_0__.defaultMetadataStorage.addTypeMetadata({
      target: target.constructor,
      propertyName: propertyName,
      reflectedType: reflectedType,
      typeFunction: typeFunction,
      options: options
    });
  };
}

/***/ }),

/***/ "./node_modules/class-transformer/esm5/enums/index.js":
/*!************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/enums/index.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TransformationType: function() { return /* reexport safe */ _transformation_type_enum__WEBPACK_IMPORTED_MODULE_0__.TransformationType; }
/* harmony export */ });
/* harmony import */ var _transformation_type_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transformation-type.enum */ "./node_modules/class-transformer/esm5/enums/transformation-type.enum.js");


/***/ }),

/***/ "./node_modules/class-transformer/esm5/enums/transformation-type.enum.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/enums/transformation-type.enum.js ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TransformationType: function() { return /* binding */ TransformationType; }
/* harmony export */ });
var TransformationType;
(function (TransformationType) {
  TransformationType[TransformationType["PLAIN_TO_CLASS"] = 0] = "PLAIN_TO_CLASS";
  TransformationType[TransformationType["CLASS_TO_PLAIN"] = 1] = "CLASS_TO_PLAIN";
  TransformationType[TransformationType["CLASS_TO_CLASS"] = 2] = "CLASS_TO_CLASS";
})(TransformationType || (TransformationType = {}));

/***/ }),

/***/ "./node_modules/class-transformer/esm5/index.js":
/*!******************************************************!*\
  !*** ./node_modules/class-transformer/esm5/index.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClassTransformer: function() { return /* reexport safe */ _ClassTransformer__WEBPACK_IMPORTED_MODULE_0__.ClassTransformer; },
/* harmony export */   Exclude: function() { return /* reexport safe */ _decorators__WEBPACK_IMPORTED_MODULE_1__.Exclude; },
/* harmony export */   Expose: function() { return /* reexport safe */ _decorators__WEBPACK_IMPORTED_MODULE_1__.Expose; },
/* harmony export */   Transform: function() { return /* reexport safe */ _decorators__WEBPACK_IMPORTED_MODULE_1__.Transform; },
/* harmony export */   TransformInstanceToInstance: function() { return /* reexport safe */ _decorators__WEBPACK_IMPORTED_MODULE_1__.TransformInstanceToInstance; },
/* harmony export */   TransformInstanceToPlain: function() { return /* reexport safe */ _decorators__WEBPACK_IMPORTED_MODULE_1__.TransformInstanceToPlain; },
/* harmony export */   TransformPlainToInstance: function() { return /* reexport safe */ _decorators__WEBPACK_IMPORTED_MODULE_1__.TransformPlainToInstance; },
/* harmony export */   TransformationType: function() { return /* reexport safe */ _enums__WEBPACK_IMPORTED_MODULE_2__.TransformationType; },
/* harmony export */   Type: function() { return /* reexport safe */ _decorators__WEBPACK_IMPORTED_MODULE_1__.Type; },
/* harmony export */   classToClassFromExist: function() { return /* binding */ classToClassFromExist; },
/* harmony export */   classToPlain: function() { return /* binding */ classToPlain; },
/* harmony export */   classToPlainFromExist: function() { return /* binding */ classToPlainFromExist; },
/* harmony export */   deserialize: function() { return /* binding */ deserialize; },
/* harmony export */   deserializeArray: function() { return /* binding */ deserializeArray; },
/* harmony export */   instanceToInstance: function() { return /* binding */ instanceToInstance; },
/* harmony export */   instanceToPlain: function() { return /* binding */ instanceToPlain; },
/* harmony export */   plainToClass: function() { return /* binding */ plainToClass; },
/* harmony export */   plainToClassFromExist: function() { return /* binding */ plainToClassFromExist; },
/* harmony export */   plainToInstance: function() { return /* binding */ plainToInstance; },
/* harmony export */   serialize: function() { return /* binding */ serialize; }
/* harmony export */ });
/* harmony import */ var _ClassTransformer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ClassTransformer */ "./node_modules/class-transformer/esm5/ClassTransformer.js");
/* harmony import */ var _decorators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./decorators */ "./node_modules/class-transformer/esm5/decorators/index.js");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./enums */ "./node_modules/class-transformer/esm5/enums/index.js");





var classTransformer = new _ClassTransformer__WEBPACK_IMPORTED_MODULE_0__.ClassTransformer();
function classToPlain(object, options) {
  return classTransformer.instanceToPlain(object, options);
}
function instanceToPlain(object, options) {
  return classTransformer.instanceToPlain(object, options);
}
function classToPlainFromExist(object, plainObject, options) {
  return classTransformer.classToPlainFromExist(object, plainObject, options);
}
function plainToClass(cls, plain, options) {
  return classTransformer.plainToInstance(cls, plain, options);
}
function plainToInstance(cls, plain, options) {
  return classTransformer.plainToInstance(cls, plain, options);
}
function plainToClassFromExist(clsObject, plain, options) {
  return classTransformer.plainToClassFromExist(clsObject, plain, options);
}
function instanceToInstance(object, options) {
  return classTransformer.instanceToInstance(object, options);
}
function classToClassFromExist(object, fromObject, options) {
  return classTransformer.classToClassFromExist(object, fromObject, options);
}
function serialize(object, options) {
  return classTransformer.serialize(object, options);
}
/**
 * Deserializes given JSON string to a object of the given class.
 *
 * @deprecated This function is being removed. Please use the following instead:
 * ```
 * instanceToClass(cls, JSON.parse(json), options)
 * ```
 */
function deserialize(cls, json, options) {
  return classTransformer.deserialize(cls, json, options);
}
/**
 * Deserializes given JSON string to an array of objects of the given class.
 *
 * @deprecated This function is being removed. Please use the following instead:
 * ```
 * JSON.parse(json).map(value => instanceToClass(cls, value, options))
 * ```
 *
 */
function deserializeArray(cls, json, options) {
  return classTransformer.deserializeArray(cls, json, options);
}

/***/ }),

/***/ "./node_modules/class-transformer/esm5/storage.js":
/*!********************************************************!*\
  !*** ./node_modules/class-transformer/esm5/storage.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   defaultMetadataStorage: function() { return /* binding */ defaultMetadataStorage; }
/* harmony export */ });
/* harmony import */ var _MetadataStorage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MetadataStorage */ "./node_modules/class-transformer/esm5/MetadataStorage.js");

/**
 * Default metadata storage is used as singleton and can be used to storage all metadatas.
 */
var defaultMetadataStorage = new _MetadataStorage__WEBPACK_IMPORTED_MODULE_0__.MetadataStorage();

/***/ }),

/***/ "./node_modules/class-transformer/esm5/utils/get-global.util.js":
/*!**********************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/utils/get-global.util.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getGlobal: function() { return /* binding */ getGlobal; }
/* harmony export */ });
/**
 * This function returns the global object across Node and browsers.
 *
 * Note: `globalThis` is the standardized approach however it has been added to
 * Node.js in version 12. We need to include this snippet until Node 12 EOL.
 */
function getGlobal() {
  if (typeof globalThis !== 'undefined') {
    return globalThis;
  }
  if (typeof __webpack_require__.g !== 'undefined') {
    return __webpack_require__.g;
  }
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore: Cannot find name 'window'.
  if (typeof window !== 'undefined') {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore: Cannot find name 'window'.
    return window;
  }
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore: Cannot find name 'self'.
  if (typeof self !== 'undefined') {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore: Cannot find name 'self'.
    return self;
  }
}

/***/ }),

/***/ "./node_modules/class-transformer/esm5/utils/is-promise.util.js":
/*!**********************************************************************!*\
  !*** ./node_modules/class-transformer/esm5/utils/is-promise.util.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isPromise: function() { return /* binding */ isPromise; }
/* harmony export */ });
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function isPromise(p) {
  return p !== null && _typeof(p) === 'object' && typeof p.then === 'function';
}

/***/ }),

/***/ "./node_modules/core-js/fn/regexp/escape.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/fn/regexp/escape.js ***!
  \**************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ../../modules/core.regexp.escape */ "./node_modules/core-js/modules/core.regexp.escape.js");
module.exports = __webpack_require__(/*! ../../modules/_core */ "./node_modules/core-js/modules/_core.js").RegExp.escape;

/***/ }),

/***/ "./node_modules/core-js/modules/_a-function.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_a-function.js ***!
  \*****************************************************/
/***/ (function(module) {

module.exports = function (it) {
  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
  return it;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_a-number-value.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/_a-number-value.js ***!
  \*********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
module.exports = function (it, msg) {
  if (typeof it != 'number' && cof(it) != 'Number') throw TypeError(msg);
  return +it;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_add-to-unscopables.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/_add-to-unscopables.js ***!
  \*************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 22.1.3.31 Array.prototype[@@unscopables]
var UNSCOPABLES = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('unscopables');
var ArrayProto = Array.prototype;
if (ArrayProto[UNSCOPABLES] == undefined) __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js")(ArrayProto, UNSCOPABLES, {});
module.exports = function (key) {
  ArrayProto[UNSCOPABLES][key] = true;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_advance-string-index.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/_advance-string-index.js ***!
  \***************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var at = __webpack_require__(/*! ./_string-at */ "./node_modules/core-js/modules/_string-at.js")(true);

// `AdvanceStringIndex` abstract operation
// https://tc39.github.io/ecma262/#sec-advancestringindex
module.exports = function (S, index, unicode) {
  return index + (unicode ? at(S, index).length : 1);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_an-instance.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_an-instance.js ***!
  \******************************************************/
/***/ (function(module) {

module.exports = function (it, Constructor, name, forbiddenField) {
  if (!(it instanceof Constructor) || forbiddenField !== undefined && forbiddenField in it) {
    throw TypeError(name + ': incorrect invocation!');
  }
  return it;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_an-object.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_an-object.js ***!
  \****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
module.exports = function (it) {
  if (!isObject(it)) throw TypeError(it + ' is not an object!');
  return it;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_array-copy-within.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/_array-copy-within.js ***!
  \************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";
// 22.1.3.3 Array.prototype.copyWithin(target, start, end = this.length)


var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toAbsoluteIndex = __webpack_require__(/*! ./_to-absolute-index */ "./node_modules/core-js/modules/_to-absolute-index.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
module.exports = [].copyWithin || function copyWithin(target /* = 0 */, start /* = 0, end = @length */) {
  var O = toObject(this);
  var len = toLength(O.length);
  var to = toAbsoluteIndex(target, len);
  var from = toAbsoluteIndex(start, len);
  var end = arguments.length > 2 ? arguments[2] : undefined;
  var count = Math.min((end === undefined ? len : toAbsoluteIndex(end, len)) - from, len - to);
  var inc = 1;
  if (from < to && to < from + count) {
    inc = -1;
    from += count - 1;
    to += count - 1;
  }
  while (count-- > 0) {
    if (from in O) O[to] = O[from];else delete O[to];
    to += inc;
    from += inc;
  }
  return O;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_array-fill.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_array-fill.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";
// 22.1.3.6 Array.prototype.fill(value, start = 0, end = this.length)


var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toAbsoluteIndex = __webpack_require__(/*! ./_to-absolute-index */ "./node_modules/core-js/modules/_to-absolute-index.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
module.exports = function fill(value /* , start = 0, end = @length */) {
  var O = toObject(this);
  var length = toLength(O.length);
  var aLen = arguments.length;
  var index = toAbsoluteIndex(aLen > 1 ? arguments[1] : undefined, length);
  var end = aLen > 2 ? arguments[2] : undefined;
  var endPos = end === undefined ? length : toAbsoluteIndex(end, length);
  while (endPos > index) O[index++] = value;
  return O;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_array-from-iterable.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/_array-from-iterable.js ***!
  \**************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var forOf = __webpack_require__(/*! ./_for-of */ "./node_modules/core-js/modules/_for-of.js");
module.exports = function (iter, ITERATOR) {
  var result = [];
  forOf(iter, false, result.push, result, ITERATOR);
  return result;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_array-includes.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/_array-includes.js ***!
  \*********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// false -> Array#indexOf
// true  -> Array#includes
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var toAbsoluteIndex = __webpack_require__(/*! ./_to-absolute-index */ "./node_modules/core-js/modules/_to-absolute-index.js");
module.exports = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIObject($this);
    var length = toLength(O.length);
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare
    if (IS_INCLUDES && el != el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare
      if (value != value) return true;
      // Array#indexOf ignores holes, Array#includes - not
    } else for (; length > index; index++) if (IS_INCLUDES || index in O) {
      if (O[index] === el) return IS_INCLUDES || index || 0;
    }
    return !IS_INCLUDES && -1;
  };
};

/***/ }),

/***/ "./node_modules/core-js/modules/_array-methods.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_array-methods.js ***!
  \********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 0 -> Array#forEach
// 1 -> Array#map
// 2 -> Array#filter
// 3 -> Array#some
// 4 -> Array#every
// 5 -> Array#find
// 6 -> Array#findIndex
var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var IObject = __webpack_require__(/*! ./_iobject */ "./node_modules/core-js/modules/_iobject.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var asc = __webpack_require__(/*! ./_array-species-create */ "./node_modules/core-js/modules/_array-species-create.js");
module.exports = function (TYPE, $create) {
  var IS_MAP = TYPE == 1;
  var IS_FILTER = TYPE == 2;
  var IS_SOME = TYPE == 3;
  var IS_EVERY = TYPE == 4;
  var IS_FIND_INDEX = TYPE == 6;
  var NO_HOLES = TYPE == 5 || IS_FIND_INDEX;
  var create = $create || asc;
  return function ($this, callbackfn, that) {
    var O = toObject($this);
    var self = IObject(O);
    var f = ctx(callbackfn, that, 3);
    var length = toLength(self.length);
    var index = 0;
    var result = IS_MAP ? create($this, length) : IS_FILTER ? create($this, 0) : undefined;
    var val, res;
    for (; length > index; index++) if (NO_HOLES || index in self) {
      val = self[index];
      res = f(val, index, O);
      if (TYPE) {
        if (IS_MAP) result[index] = res; // map
        else if (res) switch (TYPE) {
          case 3:
            return true;
          // some
          case 5:
            return val;
          // find
          case 6:
            return index;
          // findIndex
          case 2:
            result.push(val);
          // filter
        } else if (IS_EVERY) return false; // every
      }
    }
    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : result;
  };
};

/***/ }),

/***/ "./node_modules/core-js/modules/_array-reduce.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/_array-reduce.js ***!
  \*******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var IObject = __webpack_require__(/*! ./_iobject */ "./node_modules/core-js/modules/_iobject.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
module.exports = function (that, callbackfn, aLen, memo, isRight) {
  aFunction(callbackfn);
  var O = toObject(that);
  var self = IObject(O);
  var length = toLength(O.length);
  var index = isRight ? length - 1 : 0;
  var i = isRight ? -1 : 1;
  if (aLen < 2) for (;;) {
    if (index in self) {
      memo = self[index];
      index += i;
      break;
    }
    index += i;
    if (isRight ? index < 0 : length <= index) {
      throw TypeError('Reduce of empty array with no initial value');
    }
  }
  for (; isRight ? index >= 0 : length > index; index += i) if (index in self) {
    memo = callbackfn(memo, self[index], index, O);
  }
  return memo;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_array-species-constructor.js":
/*!********************************************************************!*\
  !*** ./node_modules/core-js/modules/_array-species-constructor.js ***!
  \********************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var isArray = __webpack_require__(/*! ./_is-array */ "./node_modules/core-js/modules/_is-array.js");
var SPECIES = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('species');
module.exports = function (original) {
  var C;
  if (isArray(original)) {
    C = original.constructor;
    // cross-realm fallback
    if (typeof C == 'function' && (C === Array || isArray(C.prototype))) C = undefined;
    if (isObject(C)) {
      C = C[SPECIES];
      if (C === null) C = undefined;
    }
  }
  return C === undefined ? Array : C;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_array-species-create.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/_array-species-create.js ***!
  \***************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 9.4.2.3 ArraySpeciesCreate(originalArray, length)
var speciesConstructor = __webpack_require__(/*! ./_array-species-constructor */ "./node_modules/core-js/modules/_array-species-constructor.js");
module.exports = function (original, length) {
  return new (speciesConstructor(original))(length);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_bind.js":
/*!***********************************************!*\
  !*** ./node_modules/core-js/modules/_bind.js ***!
  \***********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var invoke = __webpack_require__(/*! ./_invoke */ "./node_modules/core-js/modules/_invoke.js");
var arraySlice = [].slice;
var factories = {};
var construct = function construct(F, len, args) {
  if (!(len in factories)) {
    for (var n = [], i = 0; i < len; i++) n[i] = 'a[' + i + ']';
    // eslint-disable-next-line no-new-func
    factories[len] = Function('F,a', 'return new F(' + n.join(',') + ')');
  }
  return factories[len](F, args);
};
module.exports = Function.bind || function bind(that /* , ...args */) {
  var fn = aFunction(this);
  var partArgs = arraySlice.call(arguments, 1);
  var _bound = function bound(/* args... */
  ) {
    var args = partArgs.concat(arraySlice.call(arguments));
    return this instanceof _bound ? construct(fn, args.length, args) : invoke(fn, args, that);
  };
  if (isObject(fn.prototype)) _bound.prototype = fn.prototype;
  return _bound;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_classof.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/modules/_classof.js ***!
  \**************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// getting tag from 19.1.3.6 Object.prototype.toString()
var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
var TAG = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('toStringTag');
// ES3 wrong here
var ARG = cof(function () {
  return arguments;
}()) == 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function tryGet(it, key) {
  try {
    return it[key];
  } catch (e) {/* empty */}
};
module.exports = function (it) {
  var O, T, B;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
  // @@toStringTag case
  : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
  // builtinTag case
  : ARG ? cof(O)
  // ES3 arguments fallback
  : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_cof.js":
/*!**********************************************!*\
  !*** ./node_modules/core-js/modules/_cof.js ***!
  \**********************************************/
/***/ (function(module) {

var toString = {}.toString;
module.exports = function (it) {
  return toString.call(it).slice(8, -1);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_collection-strong.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/_collection-strong.js ***!
  \************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var dP = (__webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f);
var create = __webpack_require__(/*! ./_object-create */ "./node_modules/core-js/modules/_object-create.js");
var redefineAll = __webpack_require__(/*! ./_redefine-all */ "./node_modules/core-js/modules/_redefine-all.js");
var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var anInstance = __webpack_require__(/*! ./_an-instance */ "./node_modules/core-js/modules/_an-instance.js");
var forOf = __webpack_require__(/*! ./_for-of */ "./node_modules/core-js/modules/_for-of.js");
var $iterDefine = __webpack_require__(/*! ./_iter-define */ "./node_modules/core-js/modules/_iter-define.js");
var step = __webpack_require__(/*! ./_iter-step */ "./node_modules/core-js/modules/_iter-step.js");
var setSpecies = __webpack_require__(/*! ./_set-species */ "./node_modules/core-js/modules/_set-species.js");
var DESCRIPTORS = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js");
var fastKey = (__webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js").fastKey);
var validate = __webpack_require__(/*! ./_validate-collection */ "./node_modules/core-js/modules/_validate-collection.js");
var SIZE = DESCRIPTORS ? '_s' : 'size';
var getEntry = function getEntry(that, key) {
  // fast case
  var index = fastKey(key);
  var entry;
  if (index !== 'F') return that._i[index];
  // frozen object case
  for (entry = that._f; entry; entry = entry.n) {
    if (entry.k == key) return entry;
  }
};
module.exports = {
  getConstructor: function getConstructor(wrapper, NAME, IS_MAP, ADDER) {
    var C = wrapper(function (that, iterable) {
      anInstance(that, C, NAME, '_i');
      that._t = NAME; // collection type
      that._i = create(null); // index
      that._f = undefined; // first entry
      that._l = undefined; // last entry
      that[SIZE] = 0; // size
      if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
    });
    redefineAll(C.prototype, {
      // 23.1.3.1 Map.prototype.clear()
      // 23.2.3.2 Set.prototype.clear()
      clear: function clear() {
        for (var that = validate(this, NAME), data = that._i, entry = that._f; entry; entry = entry.n) {
          entry.r = true;
          if (entry.p) entry.p = entry.p.n = undefined;
          delete data[entry.i];
        }
        that._f = that._l = undefined;
        that[SIZE] = 0;
      },
      // 23.1.3.3 Map.prototype.delete(key)
      // 23.2.3.4 Set.prototype.delete(value)
      'delete': function _delete(key) {
        var that = validate(this, NAME);
        var entry = getEntry(that, key);
        if (entry) {
          var next = entry.n;
          var prev = entry.p;
          delete that._i[entry.i];
          entry.r = true;
          if (prev) prev.n = next;
          if (next) next.p = prev;
          if (that._f == entry) that._f = next;
          if (that._l == entry) that._l = prev;
          that[SIZE]--;
        }
        return !!entry;
      },
      // 23.2.3.6 Set.prototype.forEach(callbackfn, thisArg = undefined)
      // 23.1.3.5 Map.prototype.forEach(callbackfn, thisArg = undefined)
      forEach: function forEach(callbackfn /* , that = undefined */) {
        validate(this, NAME);
        var f = ctx(callbackfn, arguments.length > 1 ? arguments[1] : undefined, 3);
        var entry;
        while (entry = entry ? entry.n : this._f) {
          f(entry.v, entry.k, this);
          // revert to the last existing entry
          while (entry && entry.r) entry = entry.p;
        }
      },
      // 23.1.3.7 Map.prototype.has(key)
      // 23.2.3.7 Set.prototype.has(value)
      has: function has(key) {
        return !!getEntry(validate(this, NAME), key);
      }
    });
    if (DESCRIPTORS) dP(C.prototype, 'size', {
      get: function get() {
        return validate(this, NAME)[SIZE];
      }
    });
    return C;
  },
  def: function def(that, key, value) {
    var entry = getEntry(that, key);
    var prev, index;
    // change existing entry
    if (entry) {
      entry.v = value;
      // create new entry
    } else {
      that._l = entry = {
        i: index = fastKey(key, true),
        // <- index
        k: key,
        // <- key
        v: value,
        // <- value
        p: prev = that._l,
        // <- previous entry
        n: undefined,
        // <- next entry
        r: false // <- removed
      };
      if (!that._f) that._f = entry;
      if (prev) prev.n = entry;
      that[SIZE]++;
      // add to index
      if (index !== 'F') that._i[index] = entry;
    }
    return that;
  },
  getEntry: getEntry,
  setStrong: function setStrong(C, NAME, IS_MAP) {
    // add .keys, .values, .entries, [@@iterator]
    // 23.1.3.4, 23.1.3.8, 23.1.3.11, 23.1.3.12, 23.2.3.5, 23.2.3.8, 23.2.3.10, 23.2.3.11
    $iterDefine(C, NAME, function (iterated, kind) {
      this._t = validate(iterated, NAME); // target
      this._k = kind; // kind
      this._l = undefined; // previous
    }, function () {
      var that = this;
      var kind = that._k;
      var entry = that._l;
      // revert to the last existing entry
      while (entry && entry.r) entry = entry.p;
      // get next entry
      if (!that._t || !(that._l = entry = entry ? entry.n : that._t._f)) {
        // or finish the iteration
        that._t = undefined;
        return step(1);
      }
      // return step by kind
      if (kind == 'keys') return step(0, entry.k);
      if (kind == 'values') return step(0, entry.v);
      return step(0, [entry.k, entry.v]);
    }, IS_MAP ? 'entries' : 'values', !IS_MAP, true);

    // add [@@species], 23.1.2.2, 23.2.2.2
    setSpecies(NAME);
  }
};

/***/ }),

/***/ "./node_modules/core-js/modules/_collection-to-json.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/_collection-to-json.js ***!
  \*************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var classof = __webpack_require__(/*! ./_classof */ "./node_modules/core-js/modules/_classof.js");
var from = __webpack_require__(/*! ./_array-from-iterable */ "./node_modules/core-js/modules/_array-from-iterable.js");
module.exports = function (NAME) {
  return function toJSON() {
    if (classof(this) != NAME) throw TypeError(NAME + "#toJSON isn't generic");
    return from(this);
  };
};

/***/ }),

/***/ "./node_modules/core-js/modules/_collection-weak.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/_collection-weak.js ***!
  \**********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var redefineAll = __webpack_require__(/*! ./_redefine-all */ "./node_modules/core-js/modules/_redefine-all.js");
var getWeak = (__webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js").getWeak);
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var anInstance = __webpack_require__(/*! ./_an-instance */ "./node_modules/core-js/modules/_an-instance.js");
var forOf = __webpack_require__(/*! ./_for-of */ "./node_modules/core-js/modules/_for-of.js");
var createArrayMethod = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js");
var $has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var validate = __webpack_require__(/*! ./_validate-collection */ "./node_modules/core-js/modules/_validate-collection.js");
var arrayFind = createArrayMethod(5);
var arrayFindIndex = createArrayMethod(6);
var id = 0;

// fallback for uncaught frozen keys
var uncaughtFrozenStore = function uncaughtFrozenStore(that) {
  return that._l || (that._l = new UncaughtFrozenStore());
};
var UncaughtFrozenStore = function UncaughtFrozenStore() {
  this.a = [];
};
var findUncaughtFrozen = function findUncaughtFrozen(store, key) {
  return arrayFind(store.a, function (it) {
    return it[0] === key;
  });
};
UncaughtFrozenStore.prototype = {
  get: function get(key) {
    var entry = findUncaughtFrozen(this, key);
    if (entry) return entry[1];
  },
  has: function has(key) {
    return !!findUncaughtFrozen(this, key);
  },
  set: function set(key, value) {
    var entry = findUncaughtFrozen(this, key);
    if (entry) entry[1] = value;else this.a.push([key, value]);
  },
  'delete': function _delete(key) {
    var index = arrayFindIndex(this.a, function (it) {
      return it[0] === key;
    });
    if (~index) this.a.splice(index, 1);
    return !!~index;
  }
};
module.exports = {
  getConstructor: function getConstructor(wrapper, NAME, IS_MAP, ADDER) {
    var C = wrapper(function (that, iterable) {
      anInstance(that, C, NAME, '_i');
      that._t = NAME; // collection type
      that._i = id++; // collection id
      that._l = undefined; // leak store for uncaught frozen objects
      if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
    });
    redefineAll(C.prototype, {
      // 23.3.3.2 WeakMap.prototype.delete(key)
      // 23.4.3.3 WeakSet.prototype.delete(value)
      'delete': function _delete(key) {
        if (!isObject(key)) return false;
        var data = getWeak(key);
        if (data === true) return uncaughtFrozenStore(validate(this, NAME))['delete'](key);
        return data && $has(data, this._i) && delete data[this._i];
      },
      // 23.3.3.4 WeakMap.prototype.has(key)
      // 23.4.3.4 WeakSet.prototype.has(value)
      has: function has(key) {
        if (!isObject(key)) return false;
        var data = getWeak(key);
        if (data === true) return uncaughtFrozenStore(validate(this, NAME)).has(key);
        return data && $has(data, this._i);
      }
    });
    return C;
  },
  def: function def(that, key, value) {
    var data = getWeak(anObject(key), true);
    if (data === true) uncaughtFrozenStore(that).set(key, value);else data[that._i] = value;
    return that;
  },
  ufstore: uncaughtFrozenStore
};

/***/ }),

/***/ "./node_modules/core-js/modules/_collection.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_collection.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var redefineAll = __webpack_require__(/*! ./_redefine-all */ "./node_modules/core-js/modules/_redefine-all.js");
var meta = __webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js");
var forOf = __webpack_require__(/*! ./_for-of */ "./node_modules/core-js/modules/_for-of.js");
var anInstance = __webpack_require__(/*! ./_an-instance */ "./node_modules/core-js/modules/_an-instance.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var $iterDetect = __webpack_require__(/*! ./_iter-detect */ "./node_modules/core-js/modules/_iter-detect.js");
var setToStringTag = __webpack_require__(/*! ./_set-to-string-tag */ "./node_modules/core-js/modules/_set-to-string-tag.js");
var inheritIfRequired = __webpack_require__(/*! ./_inherit-if-required */ "./node_modules/core-js/modules/_inherit-if-required.js");
module.exports = function (NAME, wrapper, methods, common, IS_MAP, IS_WEAK) {
  var Base = global[NAME];
  var C = Base;
  var ADDER = IS_MAP ? 'set' : 'add';
  var proto = C && C.prototype;
  var O = {};
  var fixMethod = function fixMethod(KEY) {
    var fn = proto[KEY];
    redefine(proto, KEY, KEY == 'delete' ? function (a) {
      return IS_WEAK && !isObject(a) ? false : fn.call(this, a === 0 ? 0 : a);
    } : KEY == 'has' ? function has(a) {
      return IS_WEAK && !isObject(a) ? false : fn.call(this, a === 0 ? 0 : a);
    } : KEY == 'get' ? function get(a) {
      return IS_WEAK && !isObject(a) ? undefined : fn.call(this, a === 0 ? 0 : a);
    } : KEY == 'add' ? function add(a) {
      fn.call(this, a === 0 ? 0 : a);
      return this;
    } : function set(a, b) {
      fn.call(this, a === 0 ? 0 : a, b);
      return this;
    });
  };
  if (typeof C != 'function' || !(IS_WEAK || proto.forEach && !fails(function () {
    new C().entries().next();
  }))) {
    // create collection constructor
    C = common.getConstructor(wrapper, NAME, IS_MAP, ADDER);
    redefineAll(C.prototype, methods);
    meta.NEED = true;
  } else {
    var instance = new C();
    // early implementations not supports chaining
    var HASNT_CHAINING = instance[ADDER](IS_WEAK ? {} : -0, 1) != instance;
    // V8 ~  Chromium 40- weak-collections throws on primitives, but should return false
    var THROWS_ON_PRIMITIVES = fails(function () {
      instance.has(1);
    });
    // most early implementations doesn't supports iterables, most modern - not close it correctly
    var ACCEPT_ITERABLES = $iterDetect(function (iter) {
      new C(iter);
    }); // eslint-disable-line no-new
    // for early implementations -0 and +0 not the same
    var BUGGY_ZERO = !IS_WEAK && fails(function () {
      // V8 ~ Chromium 42- fails only with 5+ elements
      var $instance = new C();
      var index = 5;
      while (index--) $instance[ADDER](index, index);
      return !$instance.has(-0);
    });
    if (!ACCEPT_ITERABLES) {
      C = wrapper(function (target, iterable) {
        anInstance(target, C, NAME);
        var that = inheritIfRequired(new Base(), target, C);
        if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
        return that;
      });
      C.prototype = proto;
      proto.constructor = C;
    }
    if (THROWS_ON_PRIMITIVES || BUGGY_ZERO) {
      fixMethod('delete');
      fixMethod('has');
      IS_MAP && fixMethod('get');
    }
    if (BUGGY_ZERO || HASNT_CHAINING) fixMethod(ADDER);
    // weak collections should not contains .clear method
    if (IS_WEAK && proto.clear) delete proto.clear;
  }
  setToStringTag(C, NAME);
  O[NAME] = C;
  $export($export.G + $export.W + $export.F * (C != Base), O);
  if (!IS_WEAK) common.setStrong(C, NAME, IS_MAP);
  return C;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_core.js":
/*!***********************************************!*\
  !*** ./node_modules/core-js/modules/_core.js ***!
  \***********************************************/
/***/ (function(module) {

var core = module.exports = {
  version: '2.6.12'
};
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef

/***/ }),

/***/ "./node_modules/core-js/modules/_create-property.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/_create-property.js ***!
  \**********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $defineProperty = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var createDesc = __webpack_require__(/*! ./_property-desc */ "./node_modules/core-js/modules/_property-desc.js");
module.exports = function (object, index, value) {
  if (index in object) $defineProperty.f(object, index, createDesc(0, value));else object[index] = value;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_ctx.js":
/*!**********************************************!*\
  !*** ./node_modules/core-js/modules/_ctx.js ***!
  \**********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// optional / simple context binding
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
module.exports = function (fn, that, length) {
  aFunction(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 1:
      return function (a) {
        return fn.call(that, a);
      };
    case 2:
      return function (a, b) {
        return fn.call(that, a, b);
      };
    case 3:
      return function (a, b, c) {
        return fn.call(that, a, b, c);
      };
  }
  return function /* ...args */
  () {
    return fn.apply(that, arguments);
  };
};

/***/ }),

/***/ "./node_modules/core-js/modules/_date-to-iso-string.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/_date-to-iso-string.js ***!
  \*************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// 20.3.4.36 / 15.9.5.43 Date.prototype.toISOString()
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var getTime = Date.prototype.getTime;
var $toISOString = Date.prototype.toISOString;
var lz = function lz(num) {
  return num > 9 ? num : '0' + num;
};

// PhantomJS / old WebKit has a broken implementations
module.exports = fails(function () {
  return $toISOString.call(new Date(-5e13 - 1)) != '0385-07-25T07:06:39.999Z';
}) || !fails(function () {
  $toISOString.call(new Date(NaN));
}) ? function toISOString() {
  if (!isFinite(getTime.call(this))) throw RangeError('Invalid time value');
  var d = this;
  var y = d.getUTCFullYear();
  var m = d.getUTCMilliseconds();
  var s = y < 0 ? '-' : y > 9999 ? '+' : '';
  return s + ('00000' + Math.abs(y)).slice(s ? -6 : -4) + '-' + lz(d.getUTCMonth() + 1) + '-' + lz(d.getUTCDate()) + 'T' + lz(d.getUTCHours()) + ':' + lz(d.getUTCMinutes()) + ':' + lz(d.getUTCSeconds()) + '.' + (m > 99 ? m : '0' + lz(m)) + 'Z';
} : $toISOString;

/***/ }),

/***/ "./node_modules/core-js/modules/_date-to-primitive.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/_date-to-primitive.js ***!
  \************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
var NUMBER = 'number';
module.exports = function (hint) {
  if (hint !== 'string' && hint !== NUMBER && hint !== 'default') throw TypeError('Incorrect hint');
  return toPrimitive(anObject(this), hint != NUMBER);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_defined.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/modules/_defined.js ***!
  \**************************************************/
/***/ (function(module) {

// 7.2.1 RequireObjectCoercible(argument)
module.exports = function (it) {
  if (it == undefined) throw TypeError("Can't call method on  " + it);
  return it;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_descriptors.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_descriptors.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// Thank's IE8 for his funny defineProperty
module.exports = !__webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return Object.defineProperty({}, 'a', {
    get: function get() {
      return 7;
    }
  }).a != 7;
});

/***/ }),

/***/ "./node_modules/core-js/modules/_dom-create.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_dom-create.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var document = (__webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").document);
// typeof document.createElement is 'object' in old IE
var is = isObject(document) && isObject(document.createElement);
module.exports = function (it) {
  return is ? document.createElement(it) : {};
};

/***/ }),

/***/ "./node_modules/core-js/modules/_enum-bug-keys.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_enum-bug-keys.js ***!
  \********************************************************/
/***/ (function(module) {

// IE 8- don't enum bug keys
module.exports = 'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'.split(',');

/***/ }),

/***/ "./node_modules/core-js/modules/_enum-keys.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_enum-keys.js ***!
  \****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// all enumerable object keys, includes symbols
var getKeys = __webpack_require__(/*! ./_object-keys */ "./node_modules/core-js/modules/_object-keys.js");
var gOPS = __webpack_require__(/*! ./_object-gops */ "./node_modules/core-js/modules/_object-gops.js");
var pIE = __webpack_require__(/*! ./_object-pie */ "./node_modules/core-js/modules/_object-pie.js");
module.exports = function (it) {
  var result = getKeys(it);
  var getSymbols = gOPS.f;
  if (getSymbols) {
    var symbols = getSymbols(it);
    var isEnum = pIE.f;
    var i = 0;
    var key;
    while (symbols.length > i) if (isEnum.call(it, key = symbols[i++])) result.push(key);
  }
  return result;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_export.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/_export.js ***!
  \*************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var core = __webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js");
var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var PROTOTYPE = 'prototype';
var _$export = function $export(type, name, source) {
  var IS_FORCED = type & _$export.F;
  var IS_GLOBAL = type & _$export.G;
  var IS_STATIC = type & _$export.S;
  var IS_PROTO = type & _$export.P;
  var IS_BIND = type & _$export.B;
  var target = IS_GLOBAL ? global : IS_STATIC ? global[name] || (global[name] = {}) : (global[name] || {})[PROTOTYPE];
  var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
  var expProto = exports[PROTOTYPE] || (exports[PROTOTYPE] = {});
  var key, own, out, exp;
  if (IS_GLOBAL) source = name;
  for (key in source) {
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    // export native or passed
    out = (own ? target : source)[key];
    // bind timers to global for call from export context
    exp = IS_BIND && own ? ctx(out, global) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
    // extend global
    if (target) redefine(target, key, out, type & _$export.U);
    // export
    if (exports[key] != out) hide(exports, key, exp);
    if (IS_PROTO && expProto[key] != out) expProto[key] = out;
  }
};
global.core = core;
// type bitmap
_$export.F = 1; // forced
_$export.G = 2; // global
_$export.S = 4; // static
_$export.P = 8; // proto
_$export.B = 16; // bind
_$export.W = 32; // wrap
_$export.U = 64; // safe
_$export.R = 128; // real proto method for `library`
module.exports = _$export;

/***/ }),

/***/ "./node_modules/core-js/modules/_fails-is-regexp.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/_fails-is-regexp.js ***!
  \**********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var MATCH = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('match');
module.exports = function (KEY) {
  var re = /./;
  try {
    '/./'[KEY](re);
  } catch (e) {
    try {
      re[MATCH] = false;
      return !'/./'[KEY](re);
    } catch (f) {/* empty */}
  }
  return true;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_fails.js":
/*!************************************************!*\
  !*** ./node_modules/core-js/modules/_fails.js ***!
  \************************************************/
/***/ (function(module) {

module.exports = function (exec) {
  try {
    return !!exec();
  } catch (e) {
    return true;
  }
};

/***/ }),

/***/ "./node_modules/core-js/modules/_fix-re-wks.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_fix-re-wks.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


__webpack_require__(/*! ./es6.regexp.exec */ "./node_modules/core-js/modules/es6.regexp.exec.js");
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
var wks = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js");
var regexpExec = __webpack_require__(/*! ./_regexp-exec */ "./node_modules/core-js/modules/_regexp-exec.js");
var SPECIES = wks('species');
var REPLACE_SUPPORTS_NAMED_GROUPS = !fails(function () {
  // #replace needs built-in support for named groups.
  // #match works fine because it just return the exec results, even if it has
  // a "grops" property.
  var re = /./;
  re.exec = function () {
    var result = [];
    result.groups = {
      a: '7'
    };
    return result;
  };
  return ''.replace(re, '$<a>') !== '7';
});
var SPLIT_WORKS_WITH_OVERWRITTEN_EXEC = function () {
  // Chrome 51 has a buggy "split" implementation when RegExp#exec !== nativeExec
  var re = /(?:)/;
  var originalExec = re.exec;
  re.exec = function () {
    return originalExec.apply(this, arguments);
  };
  var result = 'ab'.split(re);
  return result.length === 2 && result[0] === 'a' && result[1] === 'b';
}();
module.exports = function (KEY, length, exec) {
  var SYMBOL = wks(KEY);
  var DELEGATES_TO_SYMBOL = !fails(function () {
    // String methods call symbol-named RegEp methods
    var O = {};
    O[SYMBOL] = function () {
      return 7;
    };
    return ''[KEY](O) != 7;
  });
  var DELEGATES_TO_EXEC = DELEGATES_TO_SYMBOL ? !fails(function () {
    // Symbol-named RegExp methods call .exec
    var execCalled = false;
    var re = /a/;
    re.exec = function () {
      execCalled = true;
      return null;
    };
    if (KEY === 'split') {
      // RegExp[@@split] doesn't call the regex's exec method, but first creates
      // a new one. We need to return the patched regex when creating the new one.
      re.constructor = {};
      re.constructor[SPECIES] = function () {
        return re;
      };
    }
    re[SYMBOL]('');
    return !execCalled;
  }) : undefined;
  if (!DELEGATES_TO_SYMBOL || !DELEGATES_TO_EXEC || KEY === 'replace' && !REPLACE_SUPPORTS_NAMED_GROUPS || KEY === 'split' && !SPLIT_WORKS_WITH_OVERWRITTEN_EXEC) {
    var nativeRegExpMethod = /./[SYMBOL];
    var fns = exec(defined, SYMBOL, ''[KEY], function maybeCallNative(nativeMethod, regexp, str, arg2, forceStringMethod) {
      if (regexp.exec === regexpExec) {
        if (DELEGATES_TO_SYMBOL && !forceStringMethod) {
          // The native String method already delegates to @@method (this
          // polyfilled function), leasing to infinite recursion.
          // We avoid it by directly calling the native @@method method.
          return {
            done: true,
            value: nativeRegExpMethod.call(regexp, str, arg2)
          };
        }
        return {
          done: true,
          value: nativeMethod.call(str, regexp, arg2)
        };
      }
      return {
        done: false
      };
    });
    var strfn = fns[0];
    var rxfn = fns[1];
    redefine(String.prototype, KEY, strfn);
    hide(RegExp.prototype, SYMBOL, length == 2
    // 21.2.5.8 RegExp.prototype[@@replace](string, replaceValue)
    // 21.2.5.11 RegExp.prototype[@@split](string, limit)
    ? function (string, arg) {
      return rxfn.call(string, this, arg);
    }
    // 21.2.5.6 RegExp.prototype[@@match](string)
    // 21.2.5.9 RegExp.prototype[@@search](string)
    : function (string) {
      return rxfn.call(string, this);
    });
  }
};

/***/ }),

/***/ "./node_modules/core-js/modules/_flags.js":
/*!************************************************!*\
  !*** ./node_modules/core-js/modules/_flags.js ***!
  \************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// 21.2.5.3 get RegExp.prototype.flags
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
module.exports = function () {
  var that = anObject(this);
  var result = '';
  if (that.global) result += 'g';
  if (that.ignoreCase) result += 'i';
  if (that.multiline) result += 'm';
  if (that.unicode) result += 'u';
  if (that.sticky) result += 'y';
  return result;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_flatten-into-array.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/_flatten-into-array.js ***!
  \*************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://tc39.github.io/proposal-flatMap/#sec-FlattenIntoArray
var isArray = __webpack_require__(/*! ./_is-array */ "./node_modules/core-js/modules/_is-array.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var IS_CONCAT_SPREADABLE = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('isConcatSpreadable');
function flattenIntoArray(target, original, source, sourceLen, start, depth, mapper, thisArg) {
  var targetIndex = start;
  var sourceIndex = 0;
  var mapFn = mapper ? ctx(mapper, thisArg, 3) : false;
  var element, spreadable;
  while (sourceIndex < sourceLen) {
    if (sourceIndex in source) {
      element = mapFn ? mapFn(source[sourceIndex], sourceIndex, original) : source[sourceIndex];
      spreadable = false;
      if (isObject(element)) {
        spreadable = element[IS_CONCAT_SPREADABLE];
        spreadable = spreadable !== undefined ? !!spreadable : isArray(element);
      }
      if (spreadable && depth > 0) {
        targetIndex = flattenIntoArray(target, original, element, toLength(element.length), targetIndex, depth - 1) - 1;
      } else {
        if (targetIndex >= 0x1fffffffffffff) throw TypeError();
        target[targetIndex] = element;
      }
      targetIndex++;
    }
    sourceIndex++;
  }
  return targetIndex;
}
module.exports = flattenIntoArray;

/***/ }),

/***/ "./node_modules/core-js/modules/_for-of.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/_for-of.js ***!
  \*************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var call = __webpack_require__(/*! ./_iter-call */ "./node_modules/core-js/modules/_iter-call.js");
var isArrayIter = __webpack_require__(/*! ./_is-array-iter */ "./node_modules/core-js/modules/_is-array-iter.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var getIterFn = __webpack_require__(/*! ./core.get-iterator-method */ "./node_modules/core-js/modules/core.get-iterator-method.js");
var BREAK = {};
var RETURN = {};
var exports = module.exports = function (iterable, entries, fn, that, ITERATOR) {
  var iterFn = ITERATOR ? function () {
    return iterable;
  } : getIterFn(iterable);
  var f = ctx(fn, that, entries ? 2 : 1);
  var index = 0;
  var length, step, iterator, result;
  if (typeof iterFn != 'function') throw TypeError(iterable + ' is not iterable!');
  // fast case for arrays with default iterator
  if (isArrayIter(iterFn)) for (length = toLength(iterable.length); length > index; index++) {
    result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
    if (result === BREAK || result === RETURN) return result;
  } else for (iterator = iterFn.call(iterable); !(step = iterator.next()).done;) {
    result = call(iterator, f, step.value, entries);
    if (result === BREAK || result === RETURN) return result;
  }
};
exports.BREAK = BREAK;
exports.RETURN = RETURN;

/***/ }),

/***/ "./node_modules/core-js/modules/_function-to-string.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/_function-to-string.js ***!
  \*************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./_shared */ "./node_modules/core-js/modules/_shared.js")('native-function-to-string', Function.toString);

/***/ }),

/***/ "./node_modules/core-js/modules/_global.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/_global.js ***!
  \*************************************************/
/***/ (function(module) {

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math ? window : typeof self != 'undefined' && self.Math == Math ? self
// eslint-disable-next-line no-new-func
: Function('return this')();
if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef

/***/ }),

/***/ "./node_modules/core-js/modules/_has.js":
/*!**********************************************!*\
  !*** ./node_modules/core-js/modules/_has.js ***!
  \**********************************************/
/***/ (function(module) {

var hasOwnProperty = {}.hasOwnProperty;
module.exports = function (it, key) {
  return hasOwnProperty.call(it, key);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_hide.js":
/*!***********************************************!*\
  !*** ./node_modules/core-js/modules/_hide.js ***!
  \***********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var createDesc = __webpack_require__(/*! ./_property-desc */ "./node_modules/core-js/modules/_property-desc.js");
module.exports = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") ? function (object, key, value) {
  return dP.f(object, key, createDesc(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_html.js":
/*!***********************************************!*\
  !*** ./node_modules/core-js/modules/_html.js ***!
  \***********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var document = (__webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").document);
module.exports = document && document.documentElement;

/***/ }),

/***/ "./node_modules/core-js/modules/_ie8-dom-define.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/_ie8-dom-define.js ***!
  \*********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = !__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") && !__webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return Object.defineProperty(__webpack_require__(/*! ./_dom-create */ "./node_modules/core-js/modules/_dom-create.js")('div'), 'a', {
    get: function get() {
      return 7;
    }
  }).a != 7;
});

/***/ }),

/***/ "./node_modules/core-js/modules/_inherit-if-required.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/_inherit-if-required.js ***!
  \**************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var setPrototypeOf = (__webpack_require__(/*! ./_set-proto */ "./node_modules/core-js/modules/_set-proto.js").set);
module.exports = function (that, target, C) {
  var S = target.constructor;
  var P;
  if (S !== C && typeof S == 'function' && (P = S.prototype) !== C.prototype && isObject(P) && setPrototypeOf) {
    setPrototypeOf(that, P);
  }
  return that;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_invoke.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/_invoke.js ***!
  \*************************************************/
/***/ (function(module) {

// fast apply, http://jsperf.lnkit.com/fast-apply/5
module.exports = function (fn, args, that) {
  var un = that === undefined;
  switch (args.length) {
    case 0:
      return un ? fn() : fn.call(that);
    case 1:
      return un ? fn(args[0]) : fn.call(that, args[0]);
    case 2:
      return un ? fn(args[0], args[1]) : fn.call(that, args[0], args[1]);
    case 3:
      return un ? fn(args[0], args[1], args[2]) : fn.call(that, args[0], args[1], args[2]);
    case 4:
      return un ? fn(args[0], args[1], args[2], args[3]) : fn.call(that, args[0], args[1], args[2], args[3]);
  }
  return fn.apply(that, args);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_iobject.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/modules/_iobject.js ***!
  \**************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// fallback for non-array-like ES3 and non-enumerable old V8 strings
var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
// eslint-disable-next-line no-prototype-builtins
module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
  return cof(it) == 'String' ? it.split('') : Object(it);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_is-array-iter.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_is-array-iter.js ***!
  \********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// check on default Array iterator
var Iterators = __webpack_require__(/*! ./_iterators */ "./node_modules/core-js/modules/_iterators.js");
var ITERATOR = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('iterator');
var ArrayProto = Array.prototype;
module.exports = function (it) {
  return it !== undefined && (Iterators.Array === it || ArrayProto[ITERATOR] === it);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_is-array.js":
/*!***************************************************!*\
  !*** ./node_modules/core-js/modules/_is-array.js ***!
  \***************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 7.2.2 IsArray(argument)
var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
module.exports = Array.isArray || function isArray(arg) {
  return cof(arg) == 'Array';
};

/***/ }),

/***/ "./node_modules/core-js/modules/_is-integer.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_is-integer.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 20.1.2.3 Number.isInteger(number)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var floor = Math.floor;
module.exports = function isInteger(it) {
  return !isObject(it) && isFinite(it) && floor(it) === it;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_is-object.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_is-object.js ***!
  \****************************************************/
/***/ (function(module) {

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
module.exports = function (it) {
  return _typeof(it) === 'object' ? it !== null : typeof it === 'function';
};

/***/ }),

/***/ "./node_modules/core-js/modules/_is-regexp.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_is-regexp.js ***!
  \****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 7.2.8 IsRegExp(argument)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
var MATCH = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('match');
module.exports = function (it) {
  var isRegExp;
  return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : cof(it) == 'RegExp');
};

/***/ }),

/***/ "./node_modules/core-js/modules/_iter-call.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_iter-call.js ***!
  \****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// call something on iterator step with safe closing on error
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
module.exports = function (iterator, fn, value, entries) {
  try {
    return entries ? fn(anObject(value)[0], value[1]) : fn(value);
    // 7.4.6 IteratorClose(iterator, completion)
  } catch (e) {
    var ret = iterator['return'];
    if (ret !== undefined) anObject(ret.call(iterator));
    throw e;
  }
};

/***/ }),

/***/ "./node_modules/core-js/modules/_iter-create.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_iter-create.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var create = __webpack_require__(/*! ./_object-create */ "./node_modules/core-js/modules/_object-create.js");
var descriptor = __webpack_require__(/*! ./_property-desc */ "./node_modules/core-js/modules/_property-desc.js");
var setToStringTag = __webpack_require__(/*! ./_set-to-string-tag */ "./node_modules/core-js/modules/_set-to-string-tag.js");
var IteratorPrototype = {};

// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
__webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js")(IteratorPrototype, __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('iterator'), function () {
  return this;
});
module.exports = function (Constructor, NAME, next) {
  Constructor.prototype = create(IteratorPrototype, {
    next: descriptor(1, next)
  });
  setToStringTag(Constructor, NAME + ' Iterator');
};

/***/ }),

/***/ "./node_modules/core-js/modules/_iter-define.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_iter-define.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var LIBRARY = __webpack_require__(/*! ./_library */ "./node_modules/core-js/modules/_library.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
var Iterators = __webpack_require__(/*! ./_iterators */ "./node_modules/core-js/modules/_iterators.js");
var $iterCreate = __webpack_require__(/*! ./_iter-create */ "./node_modules/core-js/modules/_iter-create.js");
var setToStringTag = __webpack_require__(/*! ./_set-to-string-tag */ "./node_modules/core-js/modules/_set-to-string-tag.js");
var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var ITERATOR = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('iterator');
var BUGGY = !([].keys && 'next' in [].keys()); // Safari has buggy iterators w/o `next`
var FF_ITERATOR = '@@iterator';
var KEYS = 'keys';
var VALUES = 'values';
var returnThis = function returnThis() {
  return this;
};
module.exports = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
  $iterCreate(Constructor, NAME, next);
  var getMethod = function getMethod(kind) {
    if (!BUGGY && kind in proto) return proto[kind];
    switch (kind) {
      case KEYS:
        return function keys() {
          return new Constructor(this, kind);
        };
      case VALUES:
        return function values() {
          return new Constructor(this, kind);
        };
    }
    return function entries() {
      return new Constructor(this, kind);
    };
  };
  var TAG = NAME + ' Iterator';
  var DEF_VALUES = DEFAULT == VALUES;
  var VALUES_BUG = false;
  var proto = Base.prototype;
  var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
  var $default = $native || getMethod(DEFAULT);
  var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined;
  var $anyNative = NAME == 'Array' ? proto.entries || $native : $native;
  var methods, key, IteratorPrototype;
  // Fix native
  if ($anyNative) {
    IteratorPrototype = getPrototypeOf($anyNative.call(new Base()));
    if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
      // Set @@toStringTag to native iterators
      setToStringTag(IteratorPrototype, TAG, true);
      // fix for some old engines
      if (!LIBRARY && typeof IteratorPrototype[ITERATOR] != 'function') hide(IteratorPrototype, ITERATOR, returnThis);
    }
  }
  // fix Array#{values, @@iterator}.name in V8 / FF
  if (DEF_VALUES && $native && $native.name !== VALUES) {
    VALUES_BUG = true;
    $default = function values() {
      return $native.call(this);
    };
  }
  // Define iterator
  if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
    hide(proto, ITERATOR, $default);
  }
  // Plug for library
  Iterators[NAME] = $default;
  Iterators[TAG] = returnThis;
  if (DEFAULT) {
    methods = {
      values: DEF_VALUES ? $default : getMethod(VALUES),
      keys: IS_SET ? $default : getMethod(KEYS),
      entries: $entries
    };
    if (FORCED) for (key in methods) {
      if (!(key in proto)) redefine(proto, key, methods[key]);
    } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
  }
  return methods;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_iter-detect.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_iter-detect.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var ITERATOR = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('iterator');
var SAFE_CLOSING = false;
try {
  var riter = [7][ITERATOR]();
  riter['return'] = function () {
    SAFE_CLOSING = true;
  };
  // eslint-disable-next-line no-throw-literal
  Array.from(riter, function () {
    throw 2;
  });
} catch (e) {/* empty */}
module.exports = function (exec, skipClosing) {
  if (!skipClosing && !SAFE_CLOSING) return false;
  var safe = false;
  try {
    var arr = [7];
    var iter = arr[ITERATOR]();
    iter.next = function () {
      return {
        done: safe = true
      };
    };
    arr[ITERATOR] = function () {
      return iter;
    };
    exec(arr);
  } catch (e) {/* empty */}
  return safe;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_iter-step.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_iter-step.js ***!
  \****************************************************/
/***/ (function(module) {

module.exports = function (done, value) {
  return {
    value: value,
    done: !!done
  };
};

/***/ }),

/***/ "./node_modules/core-js/modules/_iterators.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_iterators.js ***!
  \****************************************************/
/***/ (function(module) {

module.exports = {};

/***/ }),

/***/ "./node_modules/core-js/modules/_library.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/modules/_library.js ***!
  \**************************************************/
/***/ (function(module) {

module.exports = false;

/***/ }),

/***/ "./node_modules/core-js/modules/_math-expm1.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_math-expm1.js ***!
  \*****************************************************/
/***/ (function(module) {

// 20.2.2.14 Math.expm1(x)
var $expm1 = Math.expm1;
module.exports = !$expm1
// Old FF bug
|| $expm1(10) > 22025.465794806719 || $expm1(10) < 22025.4657948067165168
// Tor Browser bug
|| $expm1(-2e-17) != -2e-17 ? function expm1(x) {
  return (x = +x) == 0 ? x : x > -1e-6 && x < 1e-6 ? x + x * x / 2 : Math.exp(x) - 1;
} : $expm1;

/***/ }),

/***/ "./node_modules/core-js/modules/_math-fround.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_math-fround.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.16 Math.fround(x)
var sign = __webpack_require__(/*! ./_math-sign */ "./node_modules/core-js/modules/_math-sign.js");
var pow = Math.pow;
var EPSILON = pow(2, -52);
var EPSILON32 = pow(2, -23);
var MAX32 = pow(2, 127) * (2 - EPSILON32);
var MIN32 = pow(2, -126);
var roundTiesToEven = function roundTiesToEven(n) {
  return n + 1 / EPSILON - 1 / EPSILON;
};
module.exports = Math.fround || function fround(x) {
  var $abs = Math.abs(x);
  var $sign = sign(x);
  var a, result;
  if ($abs < MIN32) return $sign * roundTiesToEven($abs / MIN32 / EPSILON32) * MIN32 * EPSILON32;
  a = (1 + EPSILON32 / EPSILON) * $abs;
  result = a - (a - $abs);
  // eslint-disable-next-line no-self-compare
  if (result > MAX32 || result != result) return $sign * Infinity;
  return $sign * result;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_math-log1p.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_math-log1p.js ***!
  \*****************************************************/
/***/ (function(module) {

// 20.2.2.20 Math.log1p(x)
module.exports = Math.log1p || function log1p(x) {
  return (x = +x) > -1e-8 && x < 1e-8 ? x - x * x / 2 : Math.log(1 + x);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_math-scale.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_math-scale.js ***!
  \*****************************************************/
/***/ (function(module) {

// https://rwaldron.github.io/proposal-math-extensions/
module.exports = Math.scale || function scale(x, inLow, inHigh, outLow, outHigh) {
  if (arguments.length === 0
  // eslint-disable-next-line no-self-compare
  || x != x
  // eslint-disable-next-line no-self-compare
  || inLow != inLow
  // eslint-disable-next-line no-self-compare
  || inHigh != inHigh
  // eslint-disable-next-line no-self-compare
  || outLow != outLow
  // eslint-disable-next-line no-self-compare
  || outHigh != outHigh) return NaN;
  if (x === Infinity || x === -Infinity) return x;
  return (x - inLow) * (outHigh - outLow) / (inHigh - inLow) + outLow;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_math-sign.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_math-sign.js ***!
  \****************************************************/
/***/ (function(module) {

// 20.2.2.28 Math.sign(x)
module.exports = Math.sign || function sign(x) {
  // eslint-disable-next-line no-self-compare
  return (x = +x) == 0 || x != x ? x : x < 0 ? -1 : 1;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_meta.js":
/*!***********************************************!*\
  !*** ./node_modules/core-js/modules/_meta.js ***!
  \***********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var META = __webpack_require__(/*! ./_uid */ "./node_modules/core-js/modules/_uid.js")('meta');
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var setDesc = (__webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f);
var id = 0;
var isExtensible = Object.isExtensible || function () {
  return true;
};
var FREEZE = !__webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return isExtensible(Object.preventExtensions({}));
});
var setMeta = function setMeta(it) {
  setDesc(it, META, {
    value: {
      i: 'O' + ++id,
      // object ID
      w: {} // weak collections IDs
    }
  });
};
var fastKey = function fastKey(it, create) {
  // return primitive with prefix
  if (!isObject(it)) return _typeof(it) == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return 'F';
    // not necessary to add metadata
    if (!create) return 'E';
    // add missing metadata
    setMeta(it);
    // return object ID
  }
  return it[META].i;
};
var getWeak = function getWeak(it, create) {
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return true;
    // not necessary to add metadata
    if (!create) return false;
    // add missing metadata
    setMeta(it);
    // return hash weak collections IDs
  }
  return it[META].w;
};
// add metadata on freeze-family methods calling
var onFreeze = function onFreeze(it) {
  if (FREEZE && meta.NEED && isExtensible(it) && !has(it, META)) setMeta(it);
  return it;
};
var meta = module.exports = {
  KEY: META,
  NEED: false,
  fastKey: fastKey,
  getWeak: getWeak,
  onFreeze: onFreeze
};

/***/ }),

/***/ "./node_modules/core-js/modules/_metadata.js":
/*!***************************************************!*\
  !*** ./node_modules/core-js/modules/_metadata.js ***!
  \***************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var Map = __webpack_require__(/*! ./es6.map */ "./node_modules/core-js/modules/es6.map.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var shared = __webpack_require__(/*! ./_shared */ "./node_modules/core-js/modules/_shared.js")('metadata');
var store = shared.store || (shared.store = new (__webpack_require__(/*! ./es6.weak-map */ "./node_modules/core-js/modules/es6.weak-map.js"))());
var getOrCreateMetadataMap = function getOrCreateMetadataMap(target, targetKey, create) {
  var targetMetadata = store.get(target);
  if (!targetMetadata) {
    if (!create) return undefined;
    store.set(target, targetMetadata = new Map());
  }
  var keyMetadata = targetMetadata.get(targetKey);
  if (!keyMetadata) {
    if (!create) return undefined;
    targetMetadata.set(targetKey, keyMetadata = new Map());
  }
  return keyMetadata;
};
var ordinaryHasOwnMetadata = function ordinaryHasOwnMetadata(MetadataKey, O, P) {
  var metadataMap = getOrCreateMetadataMap(O, P, false);
  return metadataMap === undefined ? false : metadataMap.has(MetadataKey);
};
var ordinaryGetOwnMetadata = function ordinaryGetOwnMetadata(MetadataKey, O, P) {
  var metadataMap = getOrCreateMetadataMap(O, P, false);
  return metadataMap === undefined ? undefined : metadataMap.get(MetadataKey);
};
var ordinaryDefineOwnMetadata = function ordinaryDefineOwnMetadata(MetadataKey, MetadataValue, O, P) {
  getOrCreateMetadataMap(O, P, true).set(MetadataKey, MetadataValue);
};
var ordinaryOwnMetadataKeys = function ordinaryOwnMetadataKeys(target, targetKey) {
  var metadataMap = getOrCreateMetadataMap(target, targetKey, false);
  var keys = [];
  if (metadataMap) metadataMap.forEach(function (_, key) {
    keys.push(key);
  });
  return keys;
};
var toMetaKey = function toMetaKey(it) {
  return it === undefined || _typeof(it) == 'symbol' ? it : String(it);
};
var exp = function exp(O) {
  $export($export.S, 'Reflect', O);
};
module.exports = {
  store: store,
  map: getOrCreateMetadataMap,
  has: ordinaryHasOwnMetadata,
  get: ordinaryGetOwnMetadata,
  set: ordinaryDefineOwnMetadata,
  keys: ordinaryOwnMetadataKeys,
  key: toMetaKey,
  exp: exp
};

/***/ }),

/***/ "./node_modules/core-js/modules/_microtask.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_microtask.js ***!
  \****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var macrotask = (__webpack_require__(/*! ./_task */ "./node_modules/core-js/modules/_task.js").set);
var Observer = global.MutationObserver || global.WebKitMutationObserver;
var process = global.process;
var Promise = global.Promise;
var isNode = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js")(process) == 'process';
module.exports = function () {
  var head, last, notify;
  var flush = function flush() {
    var parent, fn;
    if (isNode && (parent = process.domain)) parent.exit();
    while (head) {
      fn = head.fn;
      head = head.next;
      try {
        fn();
      } catch (e) {
        if (head) notify();else last = undefined;
        throw e;
      }
    }
    last = undefined;
    if (parent) parent.enter();
  };

  // Node.js
  if (isNode) {
    notify = function notify() {
      process.nextTick(flush);
    };
    // browsers with MutationObserver, except iOS Safari - https://github.com/zloirock/core-js/issues/339
  } else if (Observer && !(global.navigator && global.navigator.standalone)) {
    var toggle = true;
    var node = document.createTextNode('');
    new Observer(flush).observe(node, {
      characterData: true
    }); // eslint-disable-line no-new
    notify = function notify() {
      node.data = toggle = !toggle;
    };
    // environments with maybe non-completely correct, but existent Promise
  } else if (Promise && Promise.resolve) {
    // Promise.resolve without an argument throws an error in LG WebOS 2
    var promise = Promise.resolve(undefined);
    notify = function notify() {
      promise.then(flush);
    };
    // for other environments - macrotask based on:
    // - setImmediate
    // - MessageChannel
    // - window.postMessag
    // - onreadystatechange
    // - setTimeout
  } else {
    notify = function notify() {
      // strange IE + webpack dev server bug - use .call(global)
      macrotask.call(global, flush);
    };
  }
  return function (fn) {
    var task = {
      fn: fn,
      next: undefined
    };
    if (last) last.next = task;
    if (!head) {
      head = task;
      notify();
    }
    last = task;
  };
};

/***/ }),

/***/ "./node_modules/core-js/modules/_new-promise-capability.js":
/*!*****************************************************************!*\
  !*** ./node_modules/core-js/modules/_new-promise-capability.js ***!
  \*****************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// 25.4.1.5 NewPromiseCapability(C)
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
function PromiseCapability(C) {
  var resolve, reject;
  this.promise = new C(function ($$resolve, $$reject) {
    if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
    resolve = $$resolve;
    reject = $$reject;
  });
  this.resolve = aFunction(resolve);
  this.reject = aFunction(reject);
}
module.exports.f = function (C) {
  return new PromiseCapability(C);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_object-assign.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_object-assign.js ***!
  \********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// 19.1.2.1 Object.assign(target, source, ...)
var DESCRIPTORS = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js");
var getKeys = __webpack_require__(/*! ./_object-keys */ "./node_modules/core-js/modules/_object-keys.js");
var gOPS = __webpack_require__(/*! ./_object-gops */ "./node_modules/core-js/modules/_object-gops.js");
var pIE = __webpack_require__(/*! ./_object-pie */ "./node_modules/core-js/modules/_object-pie.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var IObject = __webpack_require__(/*! ./_iobject */ "./node_modules/core-js/modules/_iobject.js");
var $assign = Object.assign;

// should work with symbols and should have deterministic property order (V8 bug)
module.exports = !$assign || __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  var A = {};
  var B = {};
  // eslint-disable-next-line no-undef
  var S = Symbol();
  var K = 'abcdefghijklmnopqrst';
  A[S] = 7;
  K.split('').forEach(function (k) {
    B[k] = k;
  });
  return $assign({}, A)[S] != 7 || Object.keys($assign({}, B)).join('') != K;
}) ? function assign(target, source) {
  // eslint-disable-line no-unused-vars
  var T = toObject(target);
  var aLen = arguments.length;
  var index = 1;
  var getSymbols = gOPS.f;
  var isEnum = pIE.f;
  while (aLen > index) {
    var S = IObject(arguments[index++]);
    var keys = getSymbols ? getKeys(S).concat(getSymbols(S)) : getKeys(S);
    var length = keys.length;
    var j = 0;
    var key;
    while (length > j) {
      key = keys[j++];
      if (!DESCRIPTORS || isEnum.call(S, key)) T[key] = S[key];
    }
  }
  return T;
} : $assign;

/***/ }),

/***/ "./node_modules/core-js/modules/_object-create.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_object-create.js ***!
  \********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var dPs = __webpack_require__(/*! ./_object-dps */ "./node_modules/core-js/modules/_object-dps.js");
var enumBugKeys = __webpack_require__(/*! ./_enum-bug-keys */ "./node_modules/core-js/modules/_enum-bug-keys.js");
var IE_PROTO = __webpack_require__(/*! ./_shared-key */ "./node_modules/core-js/modules/_shared-key.js")('IE_PROTO');
var Empty = function Empty() {/* empty */};
var PROTOTYPE = 'prototype';

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var _createDict = function createDict() {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = __webpack_require__(/*! ./_dom-create */ "./node_modules/core-js/modules/_dom-create.js")('iframe');
  var i = enumBugKeys.length;
  var lt = '<';
  var gt = '>';
  var iframeDocument;
  iframe.style.display = 'none';
  (__webpack_require__(/*! ./_html */ "./node_modules/core-js/modules/_html.js").appendChild)(iframe);
  iframe.src = 'javascript:'; // eslint-disable-line no-script-url
  // createDict = iframe.contentWindow.Object;
  // html.removeChild(iframe);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
  iframeDocument.close();
  _createDict = iframeDocument.F;
  while (i--) delete _createDict[PROTOTYPE][enumBugKeys[i]];
  return _createDict();
};
module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    Empty[PROTOTYPE] = anObject(O);
    result = new Empty();
    Empty[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = _createDict();
  return Properties === undefined ? result : dPs(result, Properties);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_object-dp.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_object-dp.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var IE8_DOM_DEFINE = __webpack_require__(/*! ./_ie8-dom-define */ "./node_modules/core-js/modules/_ie8-dom-define.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
var dP = Object.defineProperty;
exports.f = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") ? Object.defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return dP(O, P, Attributes);
  } catch (e) {/* empty */}
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_object-dps.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_object-dps.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var getKeys = __webpack_require__(/*! ./_object-keys */ "./node_modules/core-js/modules/_object-keys.js");
module.exports = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var keys = getKeys(Properties);
  var length = keys.length;
  var i = 0;
  var P;
  while (length > i) dP.f(O, P = keys[i++], Properties[P]);
  return O;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_object-forced-pam.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/_object-forced-pam.js ***!
  \************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// Forced replacement prototype accessors methods
module.exports = __webpack_require__(/*! ./_library */ "./node_modules/core-js/modules/_library.js") || !__webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  var K = Math.random();
  // In FF throws only define methods
  // eslint-disable-next-line no-undef, no-useless-call
  __defineSetter__.call(null, K, function () {/* empty */});
  delete __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js")[K];
});

/***/ }),

/***/ "./node_modules/core-js/modules/_object-gopd.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_object-gopd.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

var pIE = __webpack_require__(/*! ./_object-pie */ "./node_modules/core-js/modules/_object-pie.js");
var createDesc = __webpack_require__(/*! ./_property-desc */ "./node_modules/core-js/modules/_property-desc.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var IE8_DOM_DEFINE = __webpack_require__(/*! ./_ie8-dom-define */ "./node_modules/core-js/modules/_ie8-dom-define.js");
var gOPD = Object.getOwnPropertyDescriptor;
exports.f = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") ? gOPD : function getOwnPropertyDescriptor(O, P) {
  O = toIObject(O);
  P = toPrimitive(P, true);
  if (IE8_DOM_DEFINE) try {
    return gOPD(O, P);
  } catch (e) {/* empty */}
  if (has(O, P)) return createDesc(!pIE.f.call(O, P), O[P]);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_object-gopn-ext.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/_object-gopn-ext.js ***!
  \**********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
// fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var gOPN = (__webpack_require__(/*! ./_object-gopn */ "./node_modules/core-js/modules/_object-gopn.js").f);
var toString = {}.toString;
var windowNames = (typeof window === "undefined" ? "undefined" : _typeof(window)) == 'object' && window && Object.getOwnPropertyNames ? Object.getOwnPropertyNames(window) : [];
var getWindowNames = function getWindowNames(it) {
  try {
    return gOPN(it);
  } catch (e) {
    return windowNames.slice();
  }
};
module.exports.f = function getOwnPropertyNames(it) {
  return windowNames && toString.call(it) == '[object Window]' ? getWindowNames(it) : gOPN(toIObject(it));
};

/***/ }),

/***/ "./node_modules/core-js/modules/_object-gopn.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_object-gopn.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

// 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)
var $keys = __webpack_require__(/*! ./_object-keys-internal */ "./node_modules/core-js/modules/_object-keys-internal.js");
var hiddenKeys = (__webpack_require__(/*! ./_enum-bug-keys */ "./node_modules/core-js/modules/_enum-bug-keys.js").concat)('length', 'prototype');
exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return $keys(O, hiddenKeys);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_object-gops.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_object-gops.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, exports) {

exports.f = Object.getOwnPropertySymbols;

/***/ }),

/***/ "./node_modules/core-js/modules/_object-gpo.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_object-gpo.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var IE_PROTO = __webpack_require__(/*! ./_shared-key */ "./node_modules/core-js/modules/_shared-key.js")('IE_PROTO');
var ObjectProto = Object.prototype;
module.exports = Object.getPrototypeOf || function (O) {
  O = toObject(O);
  if (has(O, IE_PROTO)) return O[IE_PROTO];
  if (typeof O.constructor == 'function' && O instanceof O.constructor) {
    return O.constructor.prototype;
  }
  return O instanceof Object ? ObjectProto : null;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_object-keys-internal.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/_object-keys-internal.js ***!
  \***************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var arrayIndexOf = __webpack_require__(/*! ./_array-includes */ "./node_modules/core-js/modules/_array-includes.js")(false);
var IE_PROTO = __webpack_require__(/*! ./_shared-key */ "./node_modules/core-js/modules/_shared-key.js")('IE_PROTO');
module.exports = function (object, names) {
  var O = toIObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) if (key != IE_PROTO) has(O, key) && result.push(key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (has(O, key = names[i++])) {
    ~arrayIndexOf(result, key) || result.push(key);
  }
  return result;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_object-keys.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_object-keys.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 19.1.2.14 / 15.2.3.14 Object.keys(O)
var $keys = __webpack_require__(/*! ./_object-keys-internal */ "./node_modules/core-js/modules/_object-keys-internal.js");
var enumBugKeys = __webpack_require__(/*! ./_enum-bug-keys */ "./node_modules/core-js/modules/_enum-bug-keys.js");
module.exports = Object.keys || function keys(O) {
  return $keys(O, enumBugKeys);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_object-pie.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_object-pie.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, exports) {

exports.f = {}.propertyIsEnumerable;

/***/ }),

/***/ "./node_modules/core-js/modules/_object-sap.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_object-sap.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// most Object methods by ES6 should accept primitives
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var core = __webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
module.exports = function (KEY, exec) {
  var fn = (core.Object || {})[KEY] || Object[KEY];
  var exp = {};
  exp[KEY] = exec(fn);
  $export($export.S + $export.F * fails(function () {
    fn(1);
  }), 'Object', exp);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_object-to-array.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/_object-to-array.js ***!
  \**********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var DESCRIPTORS = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js");
var getKeys = __webpack_require__(/*! ./_object-keys */ "./node_modules/core-js/modules/_object-keys.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var isEnum = (__webpack_require__(/*! ./_object-pie */ "./node_modules/core-js/modules/_object-pie.js").f);
module.exports = function (isEntries) {
  return function (it) {
    var O = toIObject(it);
    var keys = getKeys(O);
    var length = keys.length;
    var i = 0;
    var result = [];
    var key;
    while (length > i) {
      key = keys[i++];
      if (!DESCRIPTORS || isEnum.call(O, key)) {
        result.push(isEntries ? [key, O[key]] : O[key]);
      }
    }
    return result;
  };
};

/***/ }),

/***/ "./node_modules/core-js/modules/_own-keys.js":
/*!***************************************************!*\
  !*** ./node_modules/core-js/modules/_own-keys.js ***!
  \***************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// all object keys, includes non-enumerable and symbols
var gOPN = __webpack_require__(/*! ./_object-gopn */ "./node_modules/core-js/modules/_object-gopn.js");
var gOPS = __webpack_require__(/*! ./_object-gops */ "./node_modules/core-js/modules/_object-gops.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var Reflect = (__webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").Reflect);
module.exports = Reflect && Reflect.ownKeys || function ownKeys(it) {
  var keys = gOPN.f(anObject(it));
  var getSymbols = gOPS.f;
  return getSymbols ? keys.concat(getSymbols(it)) : keys;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_parse-float.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_parse-float.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var $parseFloat = (__webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").parseFloat);
var $trim = (__webpack_require__(/*! ./_string-trim */ "./node_modules/core-js/modules/_string-trim.js").trim);
module.exports = 1 / $parseFloat(__webpack_require__(/*! ./_string-ws */ "./node_modules/core-js/modules/_string-ws.js") + '-0') !== -Infinity ? function parseFloat(str) {
  var string = $trim(String(str), 3);
  var result = $parseFloat(string);
  return result === 0 && string.charAt(0) == '-' ? -0 : result;
} : $parseFloat;

/***/ }),

/***/ "./node_modules/core-js/modules/_parse-int.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_parse-int.js ***!
  \****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var $parseInt = (__webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").parseInt);
var $trim = (__webpack_require__(/*! ./_string-trim */ "./node_modules/core-js/modules/_string-trim.js").trim);
var ws = __webpack_require__(/*! ./_string-ws */ "./node_modules/core-js/modules/_string-ws.js");
var hex = /^[-+]?0[xX]/;
module.exports = $parseInt(ws + '08') !== 8 || $parseInt(ws + '0x16') !== 22 ? function parseInt(str, radix) {
  var string = $trim(String(str), 3);
  return $parseInt(string, radix >>> 0 || (hex.test(string) ? 16 : 10));
} : $parseInt;

/***/ }),

/***/ "./node_modules/core-js/modules/_perform.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/modules/_perform.js ***!
  \**************************************************/
/***/ (function(module) {

module.exports = function (exec) {
  try {
    return {
      e: false,
      v: exec()
    };
  } catch (e) {
    return {
      e: true,
      v: e
    };
  }
};

/***/ }),

/***/ "./node_modules/core-js/modules/_promise-resolve.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/_promise-resolve.js ***!
  \**********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var newPromiseCapability = __webpack_require__(/*! ./_new-promise-capability */ "./node_modules/core-js/modules/_new-promise-capability.js");
module.exports = function (C, x) {
  anObject(C);
  if (isObject(x) && x.constructor === C) return x;
  var promiseCapability = newPromiseCapability.f(C);
  var resolve = promiseCapability.resolve;
  resolve(x);
  return promiseCapability.promise;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_property-desc.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_property-desc.js ***!
  \********************************************************/
/***/ (function(module) {

module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};

/***/ }),

/***/ "./node_modules/core-js/modules/_redefine-all.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/_redefine-all.js ***!
  \*******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
module.exports = function (target, src, safe) {
  for (var key in src) redefine(target, key, src[key], safe);
  return target;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_redefine.js":
/*!***************************************************!*\
  !*** ./node_modules/core-js/modules/_redefine.js ***!
  \***************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var SRC = __webpack_require__(/*! ./_uid */ "./node_modules/core-js/modules/_uid.js")('src');
var $toString = __webpack_require__(/*! ./_function-to-string */ "./node_modules/core-js/modules/_function-to-string.js");
var TO_STRING = 'toString';
var TPL = ('' + $toString).split(TO_STRING);
(__webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js").inspectSource) = function (it) {
  return $toString.call(it);
};
(module.exports = function (O, key, val, safe) {
  var isFunction = typeof val == 'function';
  if (isFunction) has(val, 'name') || hide(val, 'name', key);
  if (O[key] === val) return;
  if (isFunction) has(val, SRC) || hide(val, SRC, O[key] ? '' + O[key] : TPL.join(String(key)));
  if (O === global) {
    O[key] = val;
  } else if (!safe) {
    delete O[key];
    hide(O, key, val);
  } else if (O[key]) {
    O[key] = val;
  } else {
    hide(O, key, val);
  }
  // add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
})(Function.prototype, TO_STRING, function toString() {
  return typeof this == 'function' && this[SRC] || $toString.call(this);
});

/***/ }),

/***/ "./node_modules/core-js/modules/_regexp-exec-abstract.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/_regexp-exec-abstract.js ***!
  \***************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var classof = __webpack_require__(/*! ./_classof */ "./node_modules/core-js/modules/_classof.js");
var builtinExec = RegExp.prototype.exec;

// `RegExpExec` abstract operation
// https://tc39.github.io/ecma262/#sec-regexpexec
module.exports = function (R, S) {
  var exec = R.exec;
  if (typeof exec === 'function') {
    var result = exec.call(R, S);
    if (_typeof(result) !== 'object') {
      throw new TypeError('RegExp exec method returned something other than an Object or null');
    }
    return result;
  }
  if (classof(R) !== 'RegExp') {
    throw new TypeError('RegExp#exec called on incompatible receiver');
  }
  return builtinExec.call(R, S);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_regexp-exec.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_regexp-exec.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var regexpFlags = __webpack_require__(/*! ./_flags */ "./node_modules/core-js/modules/_flags.js");
var nativeExec = RegExp.prototype.exec;
// This always refers to the native implementation, because the
// String#replace polyfill uses ./fix-regexp-well-known-symbol-logic.js,
// which loads this file before patching the method.
var nativeReplace = String.prototype.replace;
var patchedExec = nativeExec;
var LAST_INDEX = 'lastIndex';
var UPDATES_LAST_INDEX_WRONG = function () {
  var re1 = /a/,
    re2 = /b*/g;
  nativeExec.call(re1, 'a');
  nativeExec.call(re2, 'a');
  return re1[LAST_INDEX] !== 0 || re2[LAST_INDEX] !== 0;
}();

// nonparticipating capturing group, copied from es5-shim's String#split patch.
var NPCG_INCLUDED = /()??/.exec('')[1] !== undefined;
var PATCH = UPDATES_LAST_INDEX_WRONG || NPCG_INCLUDED;
if (PATCH) {
  patchedExec = function exec(str) {
    var re = this;
    var lastIndex, reCopy, match, i;
    if (NPCG_INCLUDED) {
      reCopy = new RegExp('^' + re.source + '$(?!\\s)', regexpFlags.call(re));
    }
    if (UPDATES_LAST_INDEX_WRONG) lastIndex = re[LAST_INDEX];
    match = nativeExec.call(re, str);
    if (UPDATES_LAST_INDEX_WRONG && match) {
      re[LAST_INDEX] = re.global ? match.index + match[0].length : lastIndex;
    }
    if (NPCG_INCLUDED && match && match.length > 1) {
      // Fix browsers whose `exec` methods don't consistently return `undefined`
      // for NPCG, like IE8. NOTE: This doesn' work for /(.?)?/
      // eslint-disable-next-line no-loop-func
      nativeReplace.call(match[0], reCopy, function () {
        for (i = 1; i < arguments.length - 2; i++) {
          if (arguments[i] === undefined) match[i] = undefined;
        }
      });
    }
    return match;
  };
}
module.exports = patchedExec;

/***/ }),

/***/ "./node_modules/core-js/modules/_replacer.js":
/*!***************************************************!*\
  !*** ./node_modules/core-js/modules/_replacer.js ***!
  \***************************************************/
/***/ (function(module) {

module.exports = function (regExp, replace) {
  var replacer = replace === Object(replace) ? function (part) {
    return replace[part];
  } : replace;
  return function (it) {
    return String(it).replace(regExp, replacer);
  };
};

/***/ }),

/***/ "./node_modules/core-js/modules/_same-value.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_same-value.js ***!
  \*****************************************************/
/***/ (function(module) {

// 7.2.9 SameValue(x, y)
module.exports = Object.is || function is(x, y) {
  // eslint-disable-next-line no-self-compare
  return x === y ? x !== 0 || 1 / x === 1 / y : x != x && y != y;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_set-collection-from.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/_set-collection-from.js ***!
  \**************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://tc39.github.io/proposal-setmap-offrom/
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var forOf = __webpack_require__(/*! ./_for-of */ "./node_modules/core-js/modules/_for-of.js");
module.exports = function (COLLECTION) {
  $export($export.S, COLLECTION, {
    from: function from(source /* , mapFn, thisArg */) {
      var mapFn = arguments[1];
      var mapping, A, n, cb;
      aFunction(this);
      mapping = mapFn !== undefined;
      if (mapping) aFunction(mapFn);
      if (source == undefined) return new this();
      A = [];
      if (mapping) {
        n = 0;
        cb = ctx(mapFn, arguments[2], 2);
        forOf(source, false, function (nextItem) {
          A.push(cb(nextItem, n++));
        });
      } else {
        forOf(source, false, A.push, A);
      }
      return new this(A);
    }
  });
};

/***/ }),

/***/ "./node_modules/core-js/modules/_set-collection-of.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/_set-collection-of.js ***!
  \************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://tc39.github.io/proposal-setmap-offrom/
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
module.exports = function (COLLECTION) {
  $export($export.S, COLLECTION, {
    of: function of() {
      var length = arguments.length;
      var A = new Array(length);
      while (length--) A[length] = arguments[length];
      return new this(A);
    }
  });
};

/***/ }),

/***/ "./node_modules/core-js/modules/_set-proto.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_set-proto.js ***!
  \****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// Works with __proto__ only. Old v8 can't work with null proto objects.
/* eslint-disable no-proto */
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var check = function check(O, proto) {
  anObject(O);
  if (!isObject(proto) && proto !== null) throw TypeError(proto + ": can't set as prototype!");
};
module.exports = {
  set: Object.setPrototypeOf || ('__proto__' in {} ?
  // eslint-disable-line
  function (test, buggy, set) {
    try {
      set = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js")(Function.call, (__webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js").f)(Object.prototype, '__proto__').set, 2);
      set(test, []);
      buggy = !(test instanceof Array);
    } catch (e) {
      buggy = true;
    }
    return function setPrototypeOf(O, proto) {
      check(O, proto);
      if (buggy) O.__proto__ = proto;else set(O, proto);
      return O;
    };
  }({}, false) : undefined),
  check: check
};

/***/ }),

/***/ "./node_modules/core-js/modules/_set-species.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_set-species.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var DESCRIPTORS = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js");
var SPECIES = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('species');
module.exports = function (KEY) {
  var C = global[KEY];
  if (DESCRIPTORS && C && !C[SPECIES]) dP.f(C, SPECIES, {
    configurable: true,
    get: function get() {
      return this;
    }
  });
};

/***/ }),

/***/ "./node_modules/core-js/modules/_set-to-string-tag.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/_set-to-string-tag.js ***!
  \************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var def = (__webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f);
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var TAG = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('toStringTag');
module.exports = function (it, tag, stat) {
  if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, {
    configurable: true,
    value: tag
  });
};

/***/ }),

/***/ "./node_modules/core-js/modules/_shared-key.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_shared-key.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var shared = __webpack_require__(/*! ./_shared */ "./node_modules/core-js/modules/_shared.js")('keys');
var uid = __webpack_require__(/*! ./_uid */ "./node_modules/core-js/modules/_uid.js");
module.exports = function (key) {
  return shared[key] || (shared[key] = uid(key));
};

/***/ }),

/***/ "./node_modules/core-js/modules/_shared.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/_shared.js ***!
  \*************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var core = __webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js");
var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var SHARED = '__core-js_shared__';
var store = global[SHARED] || (global[SHARED] = {});
(module.exports = function (key, value) {
  return store[key] || (store[key] = value !== undefined ? value : {});
})('versions', []).push({
  version: core.version,
  mode: __webpack_require__(/*! ./_library */ "./node_modules/core-js/modules/_library.js") ? 'pure' : 'global',
  copyright: '© 2020 Denis Pushkarev (zloirock.ru)'
});

/***/ }),

/***/ "./node_modules/core-js/modules/_species-constructor.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/_species-constructor.js ***!
  \**************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 7.3.20 SpeciesConstructor(O, defaultConstructor)
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var SPECIES = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('species');
module.exports = function (O, D) {
  var C = anObject(O).constructor;
  var S;
  return C === undefined || (S = anObject(C)[SPECIES]) == undefined ? D : aFunction(S);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_strict-method.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_strict-method.js ***!
  \********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
module.exports = function (method, arg) {
  return !!method && fails(function () {
    // eslint-disable-next-line no-useless-call
    arg ? method.call(null, function () {/* empty */}, 1) : method.call(null);
  });
};

/***/ }),

/***/ "./node_modules/core-js/modules/_string-at.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_string-at.js ***!
  \****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
// true  -> String#at
// false -> String#codePointAt
module.exports = function (TO_STRING) {
  return function (that, pos) {
    var s = String(defined(that));
    var i = toInteger(pos);
    var l = s.length;
    var a, b;
    if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
    a = s.charCodeAt(i);
    return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff ? TO_STRING ? s.charAt(i) : a : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
  };
};

/***/ }),

/***/ "./node_modules/core-js/modules/_string-context.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/_string-context.js ***!
  \*********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// helper for String#{startsWith, endsWith, includes}
var isRegExp = __webpack_require__(/*! ./_is-regexp */ "./node_modules/core-js/modules/_is-regexp.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
module.exports = function (that, searchString, NAME) {
  if (isRegExp(searchString)) throw TypeError('String#' + NAME + " doesn't accept regex!");
  return String(defined(that));
};

/***/ }),

/***/ "./node_modules/core-js/modules/_string-html.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_string-html.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
var quot = /"/g;
// B.2.3.2.1 CreateHTML(string, tag, attribute, value)
var createHTML = function createHTML(string, tag, attribute, value) {
  var S = String(defined(string));
  var p1 = '<' + tag;
  if (attribute !== '') p1 += ' ' + attribute + '="' + String(value).replace(quot, '&quot;') + '"';
  return p1 + '>' + S + '</' + tag + '>';
};
module.exports = function (NAME, exec) {
  var O = {};
  O[NAME] = exec(createHTML);
  $export($export.P + $export.F * fails(function () {
    var test = ''[NAME]('"');
    return test !== test.toLowerCase() || test.split('"').length > 3;
  }), 'String', O);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_string-pad.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_string-pad.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// https://github.com/tc39/proposal-string-pad-start-end
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var repeat = __webpack_require__(/*! ./_string-repeat */ "./node_modules/core-js/modules/_string-repeat.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
module.exports = function (that, maxLength, fillString, left) {
  var S = String(defined(that));
  var stringLength = S.length;
  var fillStr = fillString === undefined ? ' ' : String(fillString);
  var intMaxLength = toLength(maxLength);
  if (intMaxLength <= stringLength || fillStr == '') return S;
  var fillLen = intMaxLength - stringLength;
  var stringFiller = repeat.call(fillStr, Math.ceil(fillLen / fillStr.length));
  if (stringFiller.length > fillLen) stringFiller = stringFiller.slice(0, fillLen);
  return left ? stringFiller + S : S + stringFiller;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_string-repeat.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/_string-repeat.js ***!
  \********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
module.exports = function repeat(count) {
  var str = String(defined(this));
  var res = '';
  var n = toInteger(count);
  if (n < 0 || n == Infinity) throw RangeError("Count can't be negative");
  for (; n > 0; (n >>>= 1) && (str += str)) if (n & 1) res += str;
  return res;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_string-trim.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_string-trim.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var spaces = __webpack_require__(/*! ./_string-ws */ "./node_modules/core-js/modules/_string-ws.js");
var space = '[' + spaces + ']';
var non = "\u200B\x85";
var ltrim = RegExp('^' + space + space + '*');
var rtrim = RegExp(space + space + '*$');
var exporter = function exporter(KEY, exec, ALIAS) {
  var exp = {};
  var FORCE = fails(function () {
    return !!spaces[KEY]() || non[KEY]() != non;
  });
  var fn = exp[KEY] = FORCE ? exec(trim) : spaces[KEY];
  if (ALIAS) exp[ALIAS] = fn;
  $export($export.P + $export.F * FORCE, 'String', exp);
};

// 1 -> String#trimLeft
// 2 -> String#trimRight
// 3 -> String#trim
var trim = exporter.trim = function (string, TYPE) {
  string = String(defined(string));
  if (TYPE & 1) string = string.replace(ltrim, '');
  if (TYPE & 2) string = string.replace(rtrim, '');
  return string;
};
module.exports = exporter;

/***/ }),

/***/ "./node_modules/core-js/modules/_string-ws.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_string-ws.js ***!
  \****************************************************/
/***/ (function(module) {

module.exports = "\t\n\x0B\f\r \xA0\u1680\u180E\u2000\u2001\u2002\u2003" + "\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF";

/***/ }),

/***/ "./node_modules/core-js/modules/_task.js":
/*!***********************************************!*\
  !*** ./node_modules/core-js/modules/_task.js ***!
  \***********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var invoke = __webpack_require__(/*! ./_invoke */ "./node_modules/core-js/modules/_invoke.js");
var html = __webpack_require__(/*! ./_html */ "./node_modules/core-js/modules/_html.js");
var cel = __webpack_require__(/*! ./_dom-create */ "./node_modules/core-js/modules/_dom-create.js");
var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var process = global.process;
var setTask = global.setImmediate;
var clearTask = global.clearImmediate;
var MessageChannel = global.MessageChannel;
var Dispatch = global.Dispatch;
var counter = 0;
var queue = {};
var ONREADYSTATECHANGE = 'onreadystatechange';
var defer, channel, port;
var run = function run() {
  var id = +this;
  // eslint-disable-next-line no-prototype-builtins
  if (queue.hasOwnProperty(id)) {
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var listener = function listener(event) {
  run.call(event.data);
};
// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if (!setTask || !clearTask) {
  setTask = function setImmediate(fn) {
    var args = [];
    var i = 1;
    while (arguments.length > i) args.push(arguments[i++]);
    queue[++counter] = function () {
      // eslint-disable-next-line no-new-func
      invoke(typeof fn == 'function' ? fn : Function(fn), args);
    };
    defer(counter);
    return counter;
  };
  clearTask = function clearImmediate(id) {
    delete queue[id];
  };
  // Node.js 0.8-
  if (__webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js")(process) == 'process') {
    defer = function defer(id) {
      process.nextTick(ctx(run, id, 1));
    };
    // Sphere (JS game engine) Dispatch API
  } else if (Dispatch && Dispatch.now) {
    defer = function defer(id) {
      Dispatch.now(ctx(run, id, 1));
    };
    // Browsers with MessageChannel, includes WebWorkers
  } else if (MessageChannel) {
    channel = new MessageChannel();
    port = channel.port2;
    channel.port1.onmessage = listener;
    defer = ctx(port.postMessage, port, 1);
    // Browsers with postMessage, skip WebWorkers
    // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
  } else if (global.addEventListener && typeof postMessage == 'function' && !global.importScripts) {
    defer = function defer(id) {
      global.postMessage(id + '', '*');
    };
    global.addEventListener('message', listener, false);
    // IE8-
  } else if (ONREADYSTATECHANGE in cel('script')) {
    defer = function defer(id) {
      html.appendChild(cel('script'))[ONREADYSTATECHANGE] = function () {
        html.removeChild(this);
        run.call(id);
      };
    };
    // Rest old browsers
  } else {
    defer = function defer(id) {
      setTimeout(ctx(run, id, 1), 0);
    };
  }
}
module.exports = {
  set: setTask,
  clear: clearTask
};

/***/ }),

/***/ "./node_modules/core-js/modules/_to-absolute-index.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/_to-absolute-index.js ***!
  \************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var max = Math.max;
var min = Math.min;
module.exports = function (index, length) {
  index = toInteger(index);
  return index < 0 ? max(index + length, 0) : min(index, length);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_to-index.js":
/*!***************************************************!*\
  !*** ./node_modules/core-js/modules/_to-index.js ***!
  \***************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// https://tc39.github.io/ecma262/#sec-toindex
var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
module.exports = function (it) {
  if (it === undefined) return 0;
  var number = toInteger(it);
  var length = toLength(number);
  if (number !== length) throw RangeError('Wrong length!');
  return length;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_to-integer.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_to-integer.js ***!
  \*****************************************************/
/***/ (function(module) {

// 7.1.4 ToInteger
var ceil = Math.ceil;
var floor = Math.floor;
module.exports = function (it) {
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};

/***/ }),

/***/ "./node_modules/core-js/modules/_to-iobject.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_to-iobject.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// to indexed object, toObject with fallback for non-array-like ES3 strings
var IObject = __webpack_require__(/*! ./_iobject */ "./node_modules/core-js/modules/_iobject.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
module.exports = function (it) {
  return IObject(defined(it));
};

/***/ }),

/***/ "./node_modules/core-js/modules/_to-length.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_to-length.js ***!
  \****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 7.1.15 ToLength
var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var min = Math.min;
module.exports = function (it) {
  return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};

/***/ }),

/***/ "./node_modules/core-js/modules/_to-object.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/_to-object.js ***!
  \****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 7.1.13 ToObject(argument)
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
module.exports = function (it) {
  return Object(defined(it));
};

/***/ }),

/***/ "./node_modules/core-js/modules/_to-primitive.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/_to-primitive.js ***!
  \*******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// 7.1.1 ToPrimitive(input [, PreferredType])
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
module.exports = function (it, S) {
  if (!isObject(it)) return it;
  var fn, val;
  if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
  if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  throw TypeError("Can't convert object to primitive value");
};

/***/ }),

/***/ "./node_modules/core-js/modules/_typed-array.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/_typed-array.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
if (__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js")) {
  var LIBRARY = __webpack_require__(/*! ./_library */ "./node_modules/core-js/modules/_library.js");
  var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
  var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
  var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
  var $typed = __webpack_require__(/*! ./_typed */ "./node_modules/core-js/modules/_typed.js");
  var $buffer = __webpack_require__(/*! ./_typed-buffer */ "./node_modules/core-js/modules/_typed-buffer.js");
  var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
  var anInstance = __webpack_require__(/*! ./_an-instance */ "./node_modules/core-js/modules/_an-instance.js");
  var propertyDesc = __webpack_require__(/*! ./_property-desc */ "./node_modules/core-js/modules/_property-desc.js");
  var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
  var redefineAll = __webpack_require__(/*! ./_redefine-all */ "./node_modules/core-js/modules/_redefine-all.js");
  var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
  var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
  var toIndex = __webpack_require__(/*! ./_to-index */ "./node_modules/core-js/modules/_to-index.js");
  var toAbsoluteIndex = __webpack_require__(/*! ./_to-absolute-index */ "./node_modules/core-js/modules/_to-absolute-index.js");
  var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
  var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
  var classof = __webpack_require__(/*! ./_classof */ "./node_modules/core-js/modules/_classof.js");
  var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
  var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
  var isArrayIter = __webpack_require__(/*! ./_is-array-iter */ "./node_modules/core-js/modules/_is-array-iter.js");
  var create = __webpack_require__(/*! ./_object-create */ "./node_modules/core-js/modules/_object-create.js");
  var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
  var gOPN = (__webpack_require__(/*! ./_object-gopn */ "./node_modules/core-js/modules/_object-gopn.js").f);
  var getIterFn = __webpack_require__(/*! ./core.get-iterator-method */ "./node_modules/core-js/modules/core.get-iterator-method.js");
  var uid = __webpack_require__(/*! ./_uid */ "./node_modules/core-js/modules/_uid.js");
  var wks = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js");
  var createArrayMethod = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js");
  var createArrayIncludes = __webpack_require__(/*! ./_array-includes */ "./node_modules/core-js/modules/_array-includes.js");
  var speciesConstructor = __webpack_require__(/*! ./_species-constructor */ "./node_modules/core-js/modules/_species-constructor.js");
  var ArrayIterators = __webpack_require__(/*! ./es6.array.iterator */ "./node_modules/core-js/modules/es6.array.iterator.js");
  var Iterators = __webpack_require__(/*! ./_iterators */ "./node_modules/core-js/modules/_iterators.js");
  var $iterDetect = __webpack_require__(/*! ./_iter-detect */ "./node_modules/core-js/modules/_iter-detect.js");
  var setSpecies = __webpack_require__(/*! ./_set-species */ "./node_modules/core-js/modules/_set-species.js");
  var arrayFill = __webpack_require__(/*! ./_array-fill */ "./node_modules/core-js/modules/_array-fill.js");
  var arrayCopyWithin = __webpack_require__(/*! ./_array-copy-within */ "./node_modules/core-js/modules/_array-copy-within.js");
  var $DP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
  var $GOPD = __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js");
  var dP = $DP.f;
  var gOPD = $GOPD.f;
  var RangeError = global.RangeError;
  var TypeError = global.TypeError;
  var Uint8Array = global.Uint8Array;
  var ARRAY_BUFFER = 'ArrayBuffer';
  var SHARED_BUFFER = 'Shared' + ARRAY_BUFFER;
  var BYTES_PER_ELEMENT = 'BYTES_PER_ELEMENT';
  var PROTOTYPE = 'prototype';
  var ArrayProto = Array[PROTOTYPE];
  var $ArrayBuffer = $buffer.ArrayBuffer;
  var $DataView = $buffer.DataView;
  var arrayForEach = createArrayMethod(0);
  var arrayFilter = createArrayMethod(2);
  var arraySome = createArrayMethod(3);
  var arrayEvery = createArrayMethod(4);
  var arrayFind = createArrayMethod(5);
  var arrayFindIndex = createArrayMethod(6);
  var arrayIncludes = createArrayIncludes(true);
  var arrayIndexOf = createArrayIncludes(false);
  var arrayValues = ArrayIterators.values;
  var arrayKeys = ArrayIterators.keys;
  var arrayEntries = ArrayIterators.entries;
  var arrayLastIndexOf = ArrayProto.lastIndexOf;
  var arrayReduce = ArrayProto.reduce;
  var arrayReduceRight = ArrayProto.reduceRight;
  var arrayJoin = ArrayProto.join;
  var arraySort = ArrayProto.sort;
  var arraySlice = ArrayProto.slice;
  var arrayToString = ArrayProto.toString;
  var arrayToLocaleString = ArrayProto.toLocaleString;
  var ITERATOR = wks('iterator');
  var TAG = wks('toStringTag');
  var TYPED_CONSTRUCTOR = uid('typed_constructor');
  var DEF_CONSTRUCTOR = uid('def_constructor');
  var ALL_CONSTRUCTORS = $typed.CONSTR;
  var TYPED_ARRAY = $typed.TYPED;
  var VIEW = $typed.VIEW;
  var WRONG_LENGTH = 'Wrong length!';
  var $map = createArrayMethod(1, function (O, length) {
    return allocate(speciesConstructor(O, O[DEF_CONSTRUCTOR]), length);
  });
  var LITTLE_ENDIAN = fails(function () {
    // eslint-disable-next-line no-undef
    return new Uint8Array(new Uint16Array([1]).buffer)[0] === 1;
  });
  var FORCED_SET = !!Uint8Array && !!Uint8Array[PROTOTYPE].set && fails(function () {
    new Uint8Array(1).set({});
  });
  var toOffset = function toOffset(it, BYTES) {
    var offset = toInteger(it);
    if (offset < 0 || offset % BYTES) throw RangeError('Wrong offset!');
    return offset;
  };
  var validate = function validate(it) {
    if (isObject(it) && TYPED_ARRAY in it) return it;
    throw TypeError(it + ' is not a typed array!');
  };
  var allocate = function allocate(C, length) {
    if (!(isObject(C) && TYPED_CONSTRUCTOR in C)) {
      throw TypeError('It is not a typed array constructor!');
    }
    return new C(length);
  };
  var speciesFromList = function speciesFromList(O, list) {
    return fromList(speciesConstructor(O, O[DEF_CONSTRUCTOR]), list);
  };
  var fromList = function fromList(C, list) {
    var index = 0;
    var length = list.length;
    var result = allocate(C, length);
    while (length > index) result[index] = list[index++];
    return result;
  };
  var addGetter = function addGetter(it, key, internal) {
    dP(it, key, {
      get: function get() {
        return this._d[internal];
      }
    });
  };
  var $from = function from(source /* , mapfn, thisArg */) {
    var O = toObject(source);
    var aLen = arguments.length;
    var mapfn = aLen > 1 ? arguments[1] : undefined;
    var mapping = mapfn !== undefined;
    var iterFn = getIterFn(O);
    var i, length, values, result, step, iterator;
    if (iterFn != undefined && !isArrayIter(iterFn)) {
      for (iterator = iterFn.call(O), values = [], i = 0; !(step = iterator.next()).done; i++) {
        values.push(step.value);
      }
      O = values;
    }
    if (mapping && aLen > 2) mapfn = ctx(mapfn, arguments[2], 2);
    for (i = 0, length = toLength(O.length), result = allocate(this, length); length > i; i++) {
      result[i] = mapping ? mapfn(O[i], i) : O[i];
    }
    return result;
  };
  var $of = function of(/* ...items */
  ) {
    var index = 0;
    var length = arguments.length;
    var result = allocate(this, length);
    while (length > index) result[index] = arguments[index++];
    return result;
  };

  // iOS Safari 6.x fails here
  var TO_LOCALE_BUG = !!Uint8Array && fails(function () {
    arrayToLocaleString.call(new Uint8Array(1));
  });
  var $toLocaleString = function toLocaleString() {
    return arrayToLocaleString.apply(TO_LOCALE_BUG ? arraySlice.call(validate(this)) : validate(this), arguments);
  };
  var proto = {
    copyWithin: function copyWithin(target, start /* , end */) {
      return arrayCopyWithin.call(validate(this), target, start, arguments.length > 2 ? arguments[2] : undefined);
    },
    every: function every(callbackfn /* , thisArg */) {
      return arrayEvery(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    fill: function fill(value /* , start, end */) {
      // eslint-disable-line no-unused-vars
      return arrayFill.apply(validate(this), arguments);
    },
    filter: function filter(callbackfn /* , thisArg */) {
      return speciesFromList(this, arrayFilter(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined));
    },
    find: function find(predicate /* , thisArg */) {
      return arrayFind(validate(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
    },
    findIndex: function findIndex(predicate /* , thisArg */) {
      return arrayFindIndex(validate(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
    },
    forEach: function forEach(callbackfn /* , thisArg */) {
      arrayForEach(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    indexOf: function indexOf(searchElement /* , fromIndex */) {
      return arrayIndexOf(validate(this), searchElement, arguments.length > 1 ? arguments[1] : undefined);
    },
    includes: function includes(searchElement /* , fromIndex */) {
      return arrayIncludes(validate(this), searchElement, arguments.length > 1 ? arguments[1] : undefined);
    },
    join: function join(separator) {
      // eslint-disable-line no-unused-vars
      return arrayJoin.apply(validate(this), arguments);
    },
    lastIndexOf: function lastIndexOf(searchElement /* , fromIndex */) {
      // eslint-disable-line no-unused-vars
      return arrayLastIndexOf.apply(validate(this), arguments);
    },
    map: function map(mapfn /* , thisArg */) {
      return $map(validate(this), mapfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    reduce: function reduce(callbackfn /* , initialValue */) {
      // eslint-disable-line no-unused-vars
      return arrayReduce.apply(validate(this), arguments);
    },
    reduceRight: function reduceRight(callbackfn /* , initialValue */) {
      // eslint-disable-line no-unused-vars
      return arrayReduceRight.apply(validate(this), arguments);
    },
    reverse: function reverse() {
      var that = this;
      var length = validate(that).length;
      var middle = Math.floor(length / 2);
      var index = 0;
      var value;
      while (index < middle) {
        value = that[index];
        that[index++] = that[--length];
        that[length] = value;
      }
      return that;
    },
    some: function some(callbackfn /* , thisArg */) {
      return arraySome(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    sort: function sort(comparefn) {
      return arraySort.call(validate(this), comparefn);
    },
    subarray: function subarray(begin, end) {
      var O = validate(this);
      var length = O.length;
      var $begin = toAbsoluteIndex(begin, length);
      return new (speciesConstructor(O, O[DEF_CONSTRUCTOR]))(O.buffer, O.byteOffset + $begin * O.BYTES_PER_ELEMENT, toLength((end === undefined ? length : toAbsoluteIndex(end, length)) - $begin));
    }
  };
  var $slice = function slice(start, end) {
    return speciesFromList(this, arraySlice.call(validate(this), start, end));
  };
  var $set = function set(arrayLike /* , offset */) {
    validate(this);
    var offset = toOffset(arguments[1], 1);
    var length = this.length;
    var src = toObject(arrayLike);
    var len = toLength(src.length);
    var index = 0;
    if (len + offset > length) throw RangeError(WRONG_LENGTH);
    while (index < len) this[offset + index] = src[index++];
  };
  var $iterators = {
    entries: function entries() {
      return arrayEntries.call(validate(this));
    },
    keys: function keys() {
      return arrayKeys.call(validate(this));
    },
    values: function values() {
      return arrayValues.call(validate(this));
    }
  };
  var isTAIndex = function isTAIndex(target, key) {
    return isObject(target) && target[TYPED_ARRAY] && _typeof(key) != 'symbol' && key in target && String(+key) == String(key);
  };
  var $getDesc = function getOwnPropertyDescriptor(target, key) {
    return isTAIndex(target, key = toPrimitive(key, true)) ? propertyDesc(2, target[key]) : gOPD(target, key);
  };
  var $setDesc = function defineProperty(target, key, desc) {
    if (isTAIndex(target, key = toPrimitive(key, true)) && isObject(desc) && has(desc, 'value') && !has(desc, 'get') && !has(desc, 'set')
    // TODO: add validation descriptor w/o calling accessors
    && !desc.configurable && (!has(desc, 'writable') || desc.writable) && (!has(desc, 'enumerable') || desc.enumerable)) {
      target[key] = desc.value;
      return target;
    }
    return dP(target, key, desc);
  };
  if (!ALL_CONSTRUCTORS) {
    $GOPD.f = $getDesc;
    $DP.f = $setDesc;
  }
  $export($export.S + $export.F * !ALL_CONSTRUCTORS, 'Object', {
    getOwnPropertyDescriptor: $getDesc,
    defineProperty: $setDesc
  });
  if (fails(function () {
    arrayToString.call({});
  })) {
    arrayToString = arrayToLocaleString = function toString() {
      return arrayJoin.call(this);
    };
  }
  var $TypedArrayPrototype$ = redefineAll({}, proto);
  redefineAll($TypedArrayPrototype$, $iterators);
  hide($TypedArrayPrototype$, ITERATOR, $iterators.values);
  redefineAll($TypedArrayPrototype$, {
    slice: $slice,
    set: $set,
    constructor: function constructor() {/* noop */},
    toString: arrayToString,
    toLocaleString: $toLocaleString
  });
  addGetter($TypedArrayPrototype$, 'buffer', 'b');
  addGetter($TypedArrayPrototype$, 'byteOffset', 'o');
  addGetter($TypedArrayPrototype$, 'byteLength', 'l');
  addGetter($TypedArrayPrototype$, 'length', 'e');
  dP($TypedArrayPrototype$, TAG, {
    get: function get() {
      return this[TYPED_ARRAY];
    }
  });

  // eslint-disable-next-line max-statements
  module.exports = function (KEY, BYTES, wrapper, CLAMPED) {
    CLAMPED = !!CLAMPED;
    var NAME = KEY + (CLAMPED ? 'Clamped' : '') + 'Array';
    var GETTER = 'get' + KEY;
    var SETTER = 'set' + KEY;
    var TypedArray = global[NAME];
    var Base = TypedArray || {};
    var TAC = TypedArray && getPrototypeOf(TypedArray);
    var FORCED = !TypedArray || !$typed.ABV;
    var O = {};
    var TypedArrayPrototype = TypedArray && TypedArray[PROTOTYPE];
    var getter = function getter(that, index) {
      var data = that._d;
      return data.v[GETTER](index * BYTES + data.o, LITTLE_ENDIAN);
    };
    var setter = function setter(that, index, value) {
      var data = that._d;
      if (CLAMPED) value = (value = Math.round(value)) < 0 ? 0 : value > 0xff ? 0xff : value & 0xff;
      data.v[SETTER](index * BYTES + data.o, value, LITTLE_ENDIAN);
    };
    var addElement = function addElement(that, index) {
      dP(that, index, {
        get: function get() {
          return getter(this, index);
        },
        set: function set(value) {
          return setter(this, index, value);
        },
        enumerable: true
      });
    };
    if (FORCED) {
      TypedArray = wrapper(function (that, data, $offset, $length) {
        anInstance(that, TypedArray, NAME, '_d');
        var index = 0;
        var offset = 0;
        var buffer, byteLength, length, klass;
        if (!isObject(data)) {
          length = toIndex(data);
          byteLength = length * BYTES;
          buffer = new $ArrayBuffer(byteLength);
        } else if (data instanceof $ArrayBuffer || (klass = classof(data)) == ARRAY_BUFFER || klass == SHARED_BUFFER) {
          buffer = data;
          offset = toOffset($offset, BYTES);
          var $len = data.byteLength;
          if ($length === undefined) {
            if ($len % BYTES) throw RangeError(WRONG_LENGTH);
            byteLength = $len - offset;
            if (byteLength < 0) throw RangeError(WRONG_LENGTH);
          } else {
            byteLength = toLength($length) * BYTES;
            if (byteLength + offset > $len) throw RangeError(WRONG_LENGTH);
          }
          length = byteLength / BYTES;
        } else if (TYPED_ARRAY in data) {
          return fromList(TypedArray, data);
        } else {
          return $from.call(TypedArray, data);
        }
        hide(that, '_d', {
          b: buffer,
          o: offset,
          l: byteLength,
          e: length,
          v: new $DataView(buffer)
        });
        while (index < length) addElement(that, index++);
      });
      TypedArrayPrototype = TypedArray[PROTOTYPE] = create($TypedArrayPrototype$);
      hide(TypedArrayPrototype, 'constructor', TypedArray);
    } else if (!fails(function () {
      TypedArray(1);
    }) || !fails(function () {
      new TypedArray(-1); // eslint-disable-line no-new
    }) || !$iterDetect(function (iter) {
      new TypedArray(); // eslint-disable-line no-new
      new TypedArray(null); // eslint-disable-line no-new
      new TypedArray(1.5); // eslint-disable-line no-new
      new TypedArray(iter); // eslint-disable-line no-new
    }, true)) {
      TypedArray = wrapper(function (that, data, $offset, $length) {
        anInstance(that, TypedArray, NAME);
        var klass;
        // `ws` module bug, temporarily remove validation length for Uint8Array
        // https://github.com/websockets/ws/pull/645
        if (!isObject(data)) return new Base(toIndex(data));
        if (data instanceof $ArrayBuffer || (klass = classof(data)) == ARRAY_BUFFER || klass == SHARED_BUFFER) {
          return $length !== undefined ? new Base(data, toOffset($offset, BYTES), $length) : $offset !== undefined ? new Base(data, toOffset($offset, BYTES)) : new Base(data);
        }
        if (TYPED_ARRAY in data) return fromList(TypedArray, data);
        return $from.call(TypedArray, data);
      });
      arrayForEach(TAC !== Function.prototype ? gOPN(Base).concat(gOPN(TAC)) : gOPN(Base), function (key) {
        if (!(key in TypedArray)) hide(TypedArray, key, Base[key]);
      });
      TypedArray[PROTOTYPE] = TypedArrayPrototype;
      if (!LIBRARY) TypedArrayPrototype.constructor = TypedArray;
    }
    var $nativeIterator = TypedArrayPrototype[ITERATOR];
    var CORRECT_ITER_NAME = !!$nativeIterator && ($nativeIterator.name == 'values' || $nativeIterator.name == undefined);
    var $iterator = $iterators.values;
    hide(TypedArray, TYPED_CONSTRUCTOR, true);
    hide(TypedArrayPrototype, TYPED_ARRAY, NAME);
    hide(TypedArrayPrototype, VIEW, true);
    hide(TypedArrayPrototype, DEF_CONSTRUCTOR, TypedArray);
    if (CLAMPED ? new TypedArray(1)[TAG] != NAME : !(TAG in TypedArrayPrototype)) {
      dP(TypedArrayPrototype, TAG, {
        get: function get() {
          return NAME;
        }
      });
    }
    O[NAME] = TypedArray;
    $export($export.G + $export.W + $export.F * (TypedArray != Base), O);
    $export($export.S, NAME, {
      BYTES_PER_ELEMENT: BYTES
    });
    $export($export.S + $export.F * fails(function () {
      Base.of.call(TypedArray, 1);
    }), NAME, {
      from: $from,
      of: $of
    });
    if (!(BYTES_PER_ELEMENT in TypedArrayPrototype)) hide(TypedArrayPrototype, BYTES_PER_ELEMENT, BYTES);
    $export($export.P, NAME, proto);
    setSpecies(NAME);
    $export($export.P + $export.F * FORCED_SET, NAME, {
      set: $set
    });
    $export($export.P + $export.F * !CORRECT_ITER_NAME, NAME, $iterators);
    if (!LIBRARY && TypedArrayPrototype.toString != arrayToString) TypedArrayPrototype.toString = arrayToString;
    $export($export.P + $export.F * fails(function () {
      new TypedArray(1).slice();
    }), NAME, {
      slice: $slice
    });
    $export($export.P + $export.F * (fails(function () {
      return [1, 2].toLocaleString() != new TypedArray([1, 2]).toLocaleString();
    }) || !fails(function () {
      TypedArrayPrototype.toLocaleString.call([1, 2]);
    })), NAME, {
      toLocaleString: $toLocaleString
    });
    Iterators[NAME] = CORRECT_ITER_NAME ? $nativeIterator : $iterator;
    if (!LIBRARY && !CORRECT_ITER_NAME) hide(TypedArrayPrototype, ITERATOR, $iterator);
  };
} else module.exports = function () {/* empty */};

/***/ }),

/***/ "./node_modules/core-js/modules/_typed-buffer.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/_typed-buffer.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var DESCRIPTORS = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js");
var LIBRARY = __webpack_require__(/*! ./_library */ "./node_modules/core-js/modules/_library.js");
var $typed = __webpack_require__(/*! ./_typed */ "./node_modules/core-js/modules/_typed.js");
var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
var redefineAll = __webpack_require__(/*! ./_redefine-all */ "./node_modules/core-js/modules/_redefine-all.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var anInstance = __webpack_require__(/*! ./_an-instance */ "./node_modules/core-js/modules/_an-instance.js");
var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var toIndex = __webpack_require__(/*! ./_to-index */ "./node_modules/core-js/modules/_to-index.js");
var gOPN = (__webpack_require__(/*! ./_object-gopn */ "./node_modules/core-js/modules/_object-gopn.js").f);
var dP = (__webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f);
var arrayFill = __webpack_require__(/*! ./_array-fill */ "./node_modules/core-js/modules/_array-fill.js");
var setToStringTag = __webpack_require__(/*! ./_set-to-string-tag */ "./node_modules/core-js/modules/_set-to-string-tag.js");
var ARRAY_BUFFER = 'ArrayBuffer';
var DATA_VIEW = 'DataView';
var PROTOTYPE = 'prototype';
var WRONG_LENGTH = 'Wrong length!';
var WRONG_INDEX = 'Wrong index!';
var $ArrayBuffer = global[ARRAY_BUFFER];
var $DataView = global[DATA_VIEW];
var Math = global.Math;
var RangeError = global.RangeError;
// eslint-disable-next-line no-shadow-restricted-names
var Infinity = global.Infinity;
var BaseBuffer = $ArrayBuffer;
var abs = Math.abs;
var pow = Math.pow;
var floor = Math.floor;
var log = Math.log;
var LN2 = Math.LN2;
var BUFFER = 'buffer';
var BYTE_LENGTH = 'byteLength';
var BYTE_OFFSET = 'byteOffset';
var $BUFFER = DESCRIPTORS ? '_b' : BUFFER;
var $LENGTH = DESCRIPTORS ? '_l' : BYTE_LENGTH;
var $OFFSET = DESCRIPTORS ? '_o' : BYTE_OFFSET;

// IEEE754 conversions based on https://github.com/feross/ieee754
function packIEEE754(value, mLen, nBytes) {
  var buffer = new Array(nBytes);
  var eLen = nBytes * 8 - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var rt = mLen === 23 ? pow(2, -24) - pow(2, -77) : 0;
  var i = 0;
  var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
  var e, m, c;
  value = abs(value);
  // eslint-disable-next-line no-self-compare
  if (value != value || value === Infinity) {
    // eslint-disable-next-line no-self-compare
    m = value != value ? 1 : 0;
    e = eMax;
  } else {
    e = floor(log(value) / LN2);
    if (value * (c = pow(2, -e)) < 1) {
      e--;
      c *= 2;
    }
    if (e + eBias >= 1) {
      value += rt / c;
    } else {
      value += rt * pow(2, 1 - eBias);
    }
    if (value * c >= 2) {
      e++;
      c /= 2;
    }
    if (e + eBias >= eMax) {
      m = 0;
      e = eMax;
    } else if (e + eBias >= 1) {
      m = (value * c - 1) * pow(2, mLen);
      e = e + eBias;
    } else {
      m = value * pow(2, eBias - 1) * pow(2, mLen);
      e = 0;
    }
  }
  for (; mLen >= 8; buffer[i++] = m & 255, m /= 256, mLen -= 8);
  e = e << mLen | m;
  eLen += mLen;
  for (; eLen > 0; buffer[i++] = e & 255, e /= 256, eLen -= 8);
  buffer[--i] |= s * 128;
  return buffer;
}
function unpackIEEE754(buffer, mLen, nBytes) {
  var eLen = nBytes * 8 - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var nBits = eLen - 7;
  var i = nBytes - 1;
  var s = buffer[i--];
  var e = s & 127;
  var m;
  s >>= 7;
  for (; nBits > 0; e = e * 256 + buffer[i], i--, nBits -= 8);
  m = e & (1 << -nBits) - 1;
  e >>= -nBits;
  nBits += mLen;
  for (; nBits > 0; m = m * 256 + buffer[i], i--, nBits -= 8);
  if (e === 0) {
    e = 1 - eBias;
  } else if (e === eMax) {
    return m ? NaN : s ? -Infinity : Infinity;
  } else {
    m = m + pow(2, mLen);
    e = e - eBias;
  }
  return (s ? -1 : 1) * m * pow(2, e - mLen);
}
function unpackI32(bytes) {
  return bytes[3] << 24 | bytes[2] << 16 | bytes[1] << 8 | bytes[0];
}
function packI8(it) {
  return [it & 0xff];
}
function packI16(it) {
  return [it & 0xff, it >> 8 & 0xff];
}
function packI32(it) {
  return [it & 0xff, it >> 8 & 0xff, it >> 16 & 0xff, it >> 24 & 0xff];
}
function packF64(it) {
  return packIEEE754(it, 52, 8);
}
function packF32(it) {
  return packIEEE754(it, 23, 4);
}
function addGetter(C, key, internal) {
  dP(C[PROTOTYPE], key, {
    get: function get() {
      return this[internal];
    }
  });
}
function get(view, bytes, index, isLittleEndian) {
  var numIndex = +index;
  var intIndex = toIndex(numIndex);
  if (intIndex + bytes > view[$LENGTH]) throw RangeError(WRONG_INDEX);
  var store = view[$BUFFER]._b;
  var start = intIndex + view[$OFFSET];
  var pack = store.slice(start, start + bytes);
  return isLittleEndian ? pack : pack.reverse();
}
function set(view, bytes, index, conversion, value, isLittleEndian) {
  var numIndex = +index;
  var intIndex = toIndex(numIndex);
  if (intIndex + bytes > view[$LENGTH]) throw RangeError(WRONG_INDEX);
  var store = view[$BUFFER]._b;
  var start = intIndex + view[$OFFSET];
  var pack = conversion(+value);
  for (var i = 0; i < bytes; i++) store[start + i] = pack[isLittleEndian ? i : bytes - i - 1];
}
if (!$typed.ABV) {
  $ArrayBuffer = function ArrayBuffer(length) {
    anInstance(this, $ArrayBuffer, ARRAY_BUFFER);
    var byteLength = toIndex(length);
    this._b = arrayFill.call(new Array(byteLength), 0);
    this[$LENGTH] = byteLength;
  };
  $DataView = function DataView(buffer, byteOffset, byteLength) {
    anInstance(this, $DataView, DATA_VIEW);
    anInstance(buffer, $ArrayBuffer, DATA_VIEW);
    var bufferLength = buffer[$LENGTH];
    var offset = toInteger(byteOffset);
    if (offset < 0 || offset > bufferLength) throw RangeError('Wrong offset!');
    byteLength = byteLength === undefined ? bufferLength - offset : toLength(byteLength);
    if (offset + byteLength > bufferLength) throw RangeError(WRONG_LENGTH);
    this[$BUFFER] = buffer;
    this[$OFFSET] = offset;
    this[$LENGTH] = byteLength;
  };
  if (DESCRIPTORS) {
    addGetter($ArrayBuffer, BYTE_LENGTH, '_l');
    addGetter($DataView, BUFFER, '_b');
    addGetter($DataView, BYTE_LENGTH, '_l');
    addGetter($DataView, BYTE_OFFSET, '_o');
  }
  redefineAll($DataView[PROTOTYPE], {
    getInt8: function getInt8(byteOffset) {
      return get(this, 1, byteOffset)[0] << 24 >> 24;
    },
    getUint8: function getUint8(byteOffset) {
      return get(this, 1, byteOffset)[0];
    },
    getInt16: function getInt16(byteOffset /* , littleEndian */) {
      var bytes = get(this, 2, byteOffset, arguments[1]);
      return (bytes[1] << 8 | bytes[0]) << 16 >> 16;
    },
    getUint16: function getUint16(byteOffset /* , littleEndian */) {
      var bytes = get(this, 2, byteOffset, arguments[1]);
      return bytes[1] << 8 | bytes[0];
    },
    getInt32: function getInt32(byteOffset /* , littleEndian */) {
      return unpackI32(get(this, 4, byteOffset, arguments[1]));
    },
    getUint32: function getUint32(byteOffset /* , littleEndian */) {
      return unpackI32(get(this, 4, byteOffset, arguments[1])) >>> 0;
    },
    getFloat32: function getFloat32(byteOffset /* , littleEndian */) {
      return unpackIEEE754(get(this, 4, byteOffset, arguments[1]), 23, 4);
    },
    getFloat64: function getFloat64(byteOffset /* , littleEndian */) {
      return unpackIEEE754(get(this, 8, byteOffset, arguments[1]), 52, 8);
    },
    setInt8: function setInt8(byteOffset, value) {
      set(this, 1, byteOffset, packI8, value);
    },
    setUint8: function setUint8(byteOffset, value) {
      set(this, 1, byteOffset, packI8, value);
    },
    setInt16: function setInt16(byteOffset, value /* , littleEndian */) {
      set(this, 2, byteOffset, packI16, value, arguments[2]);
    },
    setUint16: function setUint16(byteOffset, value /* , littleEndian */) {
      set(this, 2, byteOffset, packI16, value, arguments[2]);
    },
    setInt32: function setInt32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packI32, value, arguments[2]);
    },
    setUint32: function setUint32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packI32, value, arguments[2]);
    },
    setFloat32: function setFloat32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packF32, value, arguments[2]);
    },
    setFloat64: function setFloat64(byteOffset, value /* , littleEndian */) {
      set(this, 8, byteOffset, packF64, value, arguments[2]);
    }
  });
} else {
  if (!fails(function () {
    $ArrayBuffer(1);
  }) || !fails(function () {
    new $ArrayBuffer(-1); // eslint-disable-line no-new
  }) || fails(function () {
    new $ArrayBuffer(); // eslint-disable-line no-new
    new $ArrayBuffer(1.5); // eslint-disable-line no-new
    new $ArrayBuffer(NaN); // eslint-disable-line no-new
    return $ArrayBuffer.name != ARRAY_BUFFER;
  })) {
    $ArrayBuffer = function ArrayBuffer(length) {
      anInstance(this, $ArrayBuffer);
      return new BaseBuffer(toIndex(length));
    };
    var ArrayBufferProto = $ArrayBuffer[PROTOTYPE] = BaseBuffer[PROTOTYPE];
    for (var keys = gOPN(BaseBuffer), j = 0, key; keys.length > j;) {
      if (!((key = keys[j++]) in $ArrayBuffer)) hide($ArrayBuffer, key, BaseBuffer[key]);
    }
    if (!LIBRARY) ArrayBufferProto.constructor = $ArrayBuffer;
  }
  // iOS Safari 7.x bug
  var view = new $DataView(new $ArrayBuffer(2));
  var $setInt8 = $DataView[PROTOTYPE].setInt8;
  view.setInt8(0, 2147483648);
  view.setInt8(1, 2147483649);
  if (view.getInt8(0) || !view.getInt8(1)) redefineAll($DataView[PROTOTYPE], {
    setInt8: function setInt8(byteOffset, value) {
      $setInt8.call(this, byteOffset, value << 24 >> 24);
    },
    setUint8: function setUint8(byteOffset, value) {
      $setInt8.call(this, byteOffset, value << 24 >> 24);
    }
  }, true);
}
setToStringTag($ArrayBuffer, ARRAY_BUFFER);
setToStringTag($DataView, DATA_VIEW);
hide($DataView[PROTOTYPE], $typed.VIEW, true);
exports[ARRAY_BUFFER] = $ArrayBuffer;
exports[DATA_VIEW] = $DataView;

/***/ }),

/***/ "./node_modules/core-js/modules/_typed.js":
/*!************************************************!*\
  !*** ./node_modules/core-js/modules/_typed.js ***!
  \************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
var uid = __webpack_require__(/*! ./_uid */ "./node_modules/core-js/modules/_uid.js");
var TYPED = uid('typed_array');
var VIEW = uid('view');
var ABV = !!(global.ArrayBuffer && global.DataView);
var CONSTR = ABV;
var i = 0;
var l = 9;
var Typed;
var TypedArrayConstructors = 'Int8Array,Uint8Array,Uint8ClampedArray,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array'.split(',');
while (i < l) {
  if (Typed = global[TypedArrayConstructors[i++]]) {
    hide(Typed.prototype, TYPED, true);
    hide(Typed.prototype, VIEW, true);
  } else CONSTR = false;
}
module.exports = {
  ABV: ABV,
  CONSTR: CONSTR,
  TYPED: TYPED,
  VIEW: VIEW
};

/***/ }),

/***/ "./node_modules/core-js/modules/_uid.js":
/*!**********************************************!*\
  !*** ./node_modules/core-js/modules/_uid.js ***!
  \**********************************************/
/***/ (function(module) {

var id = 0;
var px = Math.random();
module.exports = function (key) {
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
};

/***/ }),

/***/ "./node_modules/core-js/modules/_user-agent.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_user-agent.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var navigator = global.navigator;
module.exports = navigator && navigator.userAgent || '';

/***/ }),

/***/ "./node_modules/core-js/modules/_validate-collection.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/_validate-collection.js ***!
  \**************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
module.exports = function (it, TYPE) {
  if (!isObject(it) || it._t !== TYPE) throw TypeError('Incompatible receiver, ' + TYPE + ' required!');
  return it;
};

/***/ }),

/***/ "./node_modules/core-js/modules/_wks-define.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/_wks-define.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var core = __webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js");
var LIBRARY = __webpack_require__(/*! ./_library */ "./node_modules/core-js/modules/_library.js");
var wksExt = __webpack_require__(/*! ./_wks-ext */ "./node_modules/core-js/modules/_wks-ext.js");
var defineProperty = (__webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f);
module.exports = function (name) {
  var $Symbol = core.Symbol || (core.Symbol = LIBRARY ? {} : global.Symbol || {});
  if (name.charAt(0) != '_' && !(name in $Symbol)) defineProperty($Symbol, name, {
    value: wksExt.f(name)
  });
};

/***/ }),

/***/ "./node_modules/core-js/modules/_wks-ext.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/modules/_wks-ext.js ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

exports.f = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js");

/***/ }),

/***/ "./node_modules/core-js/modules/_wks.js":
/*!**********************************************!*\
  !*** ./node_modules/core-js/modules/_wks.js ***!
  \**********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var store = __webpack_require__(/*! ./_shared */ "./node_modules/core-js/modules/_shared.js")('wks');
var uid = __webpack_require__(/*! ./_uid */ "./node_modules/core-js/modules/_uid.js");
var _Symbol = (__webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").Symbol);
var USE_SYMBOL = typeof _Symbol == 'function';
var $exports = module.exports = function (name) {
  return store[name] || (store[name] = USE_SYMBOL && _Symbol[name] || (USE_SYMBOL ? _Symbol : uid)('Symbol.' + name));
};
$exports.store = store;

/***/ }),

/***/ "./node_modules/core-js/modules/core.get-iterator-method.js":
/*!******************************************************************!*\
  !*** ./node_modules/core-js/modules/core.get-iterator-method.js ***!
  \******************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var classof = __webpack_require__(/*! ./_classof */ "./node_modules/core-js/modules/_classof.js");
var ITERATOR = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('iterator');
var Iterators = __webpack_require__(/*! ./_iterators */ "./node_modules/core-js/modules/_iterators.js");
module.exports = (__webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js").getIteratorMethod) = function (it) {
  if (it != undefined) return it[ITERATOR] || it['@@iterator'] || Iterators[classof(it)];
};

/***/ }),

/***/ "./node_modules/core-js/modules/core.regexp.escape.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/core.regexp.escape.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://github.com/benjamingr/RexExp.escape
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $re = __webpack_require__(/*! ./_replacer */ "./node_modules/core-js/modules/_replacer.js")(/[\\^$*+?.()|[\]{}]/g, '\\$&');
$export($export.S, 'RegExp', {
  escape: function escape(it) {
    return $re(it);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.copy-within.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.copy-within.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 22.1.3.3 Array.prototype.copyWithin(target, start, end = this.length)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.P, 'Array', {
  copyWithin: __webpack_require__(/*! ./_array-copy-within */ "./node_modules/core-js/modules/_array-copy-within.js")
});
__webpack_require__(/*! ./_add-to-unscopables */ "./node_modules/core-js/modules/_add-to-unscopables.js")('copyWithin');

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.every.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.every.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $every = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(4);
$export($export.P + $export.F * !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].every, true), 'Array', {
  // 22.1.3.5 / 15.4.4.16 Array.prototype.every(callbackfn [, thisArg])
  every: function every(callbackfn /* , thisArg */) {
    return $every(this, callbackfn, arguments[1]);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.fill.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.fill.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 22.1.3.6 Array.prototype.fill(value, start = 0, end = this.length)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.P, 'Array', {
  fill: __webpack_require__(/*! ./_array-fill */ "./node_modules/core-js/modules/_array-fill.js")
});
__webpack_require__(/*! ./_add-to-unscopables */ "./node_modules/core-js/modules/_add-to-unscopables.js")('fill');

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.filter.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.filter.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $filter = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(2);
$export($export.P + $export.F * !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].filter, true), 'Array', {
  // 22.1.3.7 / 15.4.4.20 Array.prototype.filter(callbackfn [, thisArg])
  filter: function filter(callbackfn /* , thisArg */) {
    return $filter(this, callbackfn, arguments[1]);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.find-index.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.find-index.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// 22.1.3.9 Array.prototype.findIndex(predicate, thisArg = undefined)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $find = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(6);
var KEY = 'findIndex';
var forced = true;
// Shouldn't skip holes
if (KEY in []) Array(1)[KEY](function () {
  forced = false;
});
$export($export.P + $export.F * forced, 'Array', {
  findIndex: function findIndex(callbackfn /* , that = undefined */) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
__webpack_require__(/*! ./_add-to-unscopables */ "./node_modules/core-js/modules/_add-to-unscopables.js")(KEY);

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.find.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.find.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// 22.1.3.8 Array.prototype.find(predicate, thisArg = undefined)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $find = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(5);
var KEY = 'find';
var forced = true;
// Shouldn't skip holes
if (KEY in []) Array(1)[KEY](function () {
  forced = false;
});
$export($export.P + $export.F * forced, 'Array', {
  find: function find(callbackfn /* , that = undefined */) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
__webpack_require__(/*! ./_add-to-unscopables */ "./node_modules/core-js/modules/_add-to-unscopables.js")(KEY);

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.for-each.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.for-each.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $forEach = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(0);
var STRICT = __webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].forEach, true);
$export($export.P + $export.F * !STRICT, 'Array', {
  // 22.1.3.10 / 15.4.4.18 Array.prototype.forEach(callbackfn [, thisArg])
  forEach: function forEach(callbackfn /* , thisArg */) {
    return $forEach(this, callbackfn, arguments[1]);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.from.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.from.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var call = __webpack_require__(/*! ./_iter-call */ "./node_modules/core-js/modules/_iter-call.js");
var isArrayIter = __webpack_require__(/*! ./_is-array-iter */ "./node_modules/core-js/modules/_is-array-iter.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var createProperty = __webpack_require__(/*! ./_create-property */ "./node_modules/core-js/modules/_create-property.js");
var getIterFn = __webpack_require__(/*! ./core.get-iterator-method */ "./node_modules/core-js/modules/core.get-iterator-method.js");
$export($export.S + $export.F * !__webpack_require__(/*! ./_iter-detect */ "./node_modules/core-js/modules/_iter-detect.js")(function (iter) {
  Array.from(iter);
}), 'Array', {
  // 22.1.2.1 Array.from(arrayLike, mapfn = undefined, thisArg = undefined)
  from: function from(arrayLike /* , mapfn = undefined, thisArg = undefined */) {
    var O = toObject(arrayLike);
    var C = typeof this == 'function' ? this : Array;
    var aLen = arguments.length;
    var mapfn = aLen > 1 ? arguments[1] : undefined;
    var mapping = mapfn !== undefined;
    var index = 0;
    var iterFn = getIterFn(O);
    var length, result, step, iterator;
    if (mapping) mapfn = ctx(mapfn, aLen > 2 ? arguments[2] : undefined, 2);
    // if object isn't iterable or it's array with default iterator - use simple case
    if (iterFn != undefined && !(C == Array && isArrayIter(iterFn))) {
      for (iterator = iterFn.call(O), result = new C(); !(step = iterator.next()).done; index++) {
        createProperty(result, index, mapping ? call(iterator, mapfn, [step.value, index], true) : step.value);
      }
    } else {
      length = toLength(O.length);
      for (result = new C(length); length > index; index++) {
        createProperty(result, index, mapping ? mapfn(O[index], index) : O[index]);
      }
    }
    result.length = index;
    return result;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.index-of.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.index-of.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $indexOf = __webpack_require__(/*! ./_array-includes */ "./node_modules/core-js/modules/_array-includes.js")(false);
var $native = [].indexOf;
var NEGATIVE_ZERO = !!$native && 1 / [1].indexOf(1, -0) < 0;
$export($export.P + $export.F * (NEGATIVE_ZERO || !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")($native)), 'Array', {
  // 22.1.3.11 / 15.4.4.14 Array.prototype.indexOf(searchElement [, fromIndex])
  indexOf: function indexOf(searchElement /* , fromIndex = 0 */) {
    return NEGATIVE_ZERO
    // convert -0 to +0
    ? $native.apply(this, arguments) || 0 : $indexOf(this, searchElement, arguments[1]);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.is-array.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.is-array.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 22.1.2.2 / 15.4.3.2 Array.isArray(arg)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Array', {
  isArray: __webpack_require__(/*! ./_is-array */ "./node_modules/core-js/modules/_is-array.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.iterator.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.iterator.js ***!
  \************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var addToUnscopables = __webpack_require__(/*! ./_add-to-unscopables */ "./node_modules/core-js/modules/_add-to-unscopables.js");
var step = __webpack_require__(/*! ./_iter-step */ "./node_modules/core-js/modules/_iter-step.js");
var Iterators = __webpack_require__(/*! ./_iterators */ "./node_modules/core-js/modules/_iterators.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");

// 22.1.3.4 Array.prototype.entries()
// 22.1.3.13 Array.prototype.keys()
// 22.1.3.29 Array.prototype.values()
// 22.1.3.30 Array.prototype[@@iterator]()
module.exports = __webpack_require__(/*! ./_iter-define */ "./node_modules/core-js/modules/_iter-define.js")(Array, 'Array', function (iterated, kind) {
  this._t = toIObject(iterated); // target
  this._i = 0; // next index
  this._k = kind; // kind
  // 22.1.5.2.1 %ArrayIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var kind = this._k;
  var index = this._i++;
  if (!O || index >= O.length) {
    this._t = undefined;
    return step(1);
  }
  if (kind == 'keys') return step(0, index);
  if (kind == 'values') return step(0, O[index]);
  return step(0, [index, O[index]]);
}, 'values');

// argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
Iterators.Arguments = Iterators.Array;
addToUnscopables('keys');
addToUnscopables('values');
addToUnscopables('entries');

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.join.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.join.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// 22.1.3.13 Array.prototype.join(separator)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var arrayJoin = [].join;

// fallback for not array-like strings
$export($export.P + $export.F * (__webpack_require__(/*! ./_iobject */ "./node_modules/core-js/modules/_iobject.js") != Object || !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")(arrayJoin)), 'Array', {
  join: function join(separator) {
    return arrayJoin.call(toIObject(this), separator === undefined ? ',' : separator);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.last-index-of.js":
/*!*****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.last-index-of.js ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var $native = [].lastIndexOf;
var NEGATIVE_ZERO = !!$native && 1 / [1].lastIndexOf(1, -0) < 0;
$export($export.P + $export.F * (NEGATIVE_ZERO || !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")($native)), 'Array', {
  // 22.1.3.14 / 15.4.4.15 Array.prototype.lastIndexOf(searchElement [, fromIndex])
  lastIndexOf: function lastIndexOf(searchElement /* , fromIndex = @[*-1] */) {
    // convert -0 to +0
    if (NEGATIVE_ZERO) return $native.apply(this, arguments) || 0;
    var O = toIObject(this);
    var length = toLength(O.length);
    var index = length - 1;
    if (arguments.length > 1) index = Math.min(index, toInteger(arguments[1]));
    if (index < 0) index = length + index;
    for (; index >= 0; index--) if (index in O) if (O[index] === searchElement) return index || 0;
    return -1;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.map.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.map.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $map = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(1);
$export($export.P + $export.F * !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].map, true), 'Array', {
  // 22.1.3.15 / 15.4.4.19 Array.prototype.map(callbackfn [, thisArg])
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments[1]);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.of.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.of.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var createProperty = __webpack_require__(/*! ./_create-property */ "./node_modules/core-js/modules/_create-property.js");

// WebKit Array.of isn't generic
$export($export.S + $export.F * __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  function F() {/* empty */}
  return !(Array.of.call(F) instanceof F);
}), 'Array', {
  // 22.1.2.3 Array.of( ...items)
  of: function of(/* ...args */
  ) {
    var index = 0;
    var aLen = arguments.length;
    var result = new (typeof this == 'function' ? this : Array)(aLen);
    while (aLen > index) createProperty(result, index, arguments[index++]);
    result.length = aLen;
    return result;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.reduce-right.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.reduce-right.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $reduce = __webpack_require__(/*! ./_array-reduce */ "./node_modules/core-js/modules/_array-reduce.js");
$export($export.P + $export.F * !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].reduceRight, true), 'Array', {
  // 22.1.3.19 / 15.4.4.22 Array.prototype.reduceRight(callbackfn [, initialValue])
  reduceRight: function reduceRight(callbackfn /* , initialValue */) {
    return $reduce(this, callbackfn, arguments.length, arguments[1], true);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.reduce.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.reduce.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $reduce = __webpack_require__(/*! ./_array-reduce */ "./node_modules/core-js/modules/_array-reduce.js");
$export($export.P + $export.F * !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].reduce, true), 'Array', {
  // 22.1.3.18 / 15.4.4.21 Array.prototype.reduce(callbackfn [, initialValue])
  reduce: function reduce(callbackfn /* , initialValue */) {
    return $reduce(this, callbackfn, arguments.length, arguments[1], false);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.slice.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.slice.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var html = __webpack_require__(/*! ./_html */ "./node_modules/core-js/modules/_html.js");
var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
var toAbsoluteIndex = __webpack_require__(/*! ./_to-absolute-index */ "./node_modules/core-js/modules/_to-absolute-index.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var arraySlice = [].slice;

// fallback for not array-like ES3 strings and DOM objects
$export($export.P + $export.F * __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  if (html) arraySlice.call(html);
}), 'Array', {
  slice: function slice(begin, end) {
    var len = toLength(this.length);
    var klass = cof(this);
    end = end === undefined ? len : end;
    if (klass == 'Array') return arraySlice.call(this, begin, end);
    var start = toAbsoluteIndex(begin, len);
    var upTo = toAbsoluteIndex(end, len);
    var size = toLength(upTo - start);
    var cloned = new Array(size);
    var i = 0;
    for (; i < size; i++) cloned[i] = klass == 'String' ? this.charAt(start + i) : this[start + i];
    return cloned;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.some.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.some.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $some = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(3);
$export($export.P + $export.F * !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")([].some, true), 'Array', {
  // 22.1.3.23 / 15.4.4.17 Array.prototype.some(callbackfn [, thisArg])
  some: function some(callbackfn /* , thisArg */) {
    return $some(this, callbackfn, arguments[1]);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.sort.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.sort.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var $sort = [].sort;
var test = [1, 2, 3];
$export($export.P + $export.F * (fails(function () {
  // IE8-
  test.sort(undefined);
}) || !fails(function () {
  // V8 bug
  test.sort(null);
  // Old WebKit
}) || !__webpack_require__(/*! ./_strict-method */ "./node_modules/core-js/modules/_strict-method.js")($sort)), 'Array', {
  // 22.1.3.25 Array.prototype.sort(comparefn)
  sort: function sort(comparefn) {
    return comparefn === undefined ? $sort.call(toObject(this)) : $sort.call(toObject(this), aFunction(comparefn));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.array.species.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.array.species.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ./_set-species */ "./node_modules/core-js/modules/_set-species.js")('Array');

/***/ }),

/***/ "./node_modules/core-js/modules/es6.date.now.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.date.now.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.3.3.1 / 15.9.4.4 Date.now()
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Date', {
  now: function now() {
    return new Date().getTime();
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.date.to-iso-string.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.date.to-iso-string.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.3.4.36 / 15.9.5.43 Date.prototype.toISOString()
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toISOString = __webpack_require__(/*! ./_date-to-iso-string */ "./node_modules/core-js/modules/_date-to-iso-string.js");

// PhantomJS / old WebKit has a broken implementations
$export($export.P + $export.F * (Date.prototype.toISOString !== toISOString), 'Date', {
  toISOString: toISOString
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.date.to-json.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.date.to-json.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
$export($export.P + $export.F * __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return new Date(NaN).toJSON() !== null || Date.prototype.toJSON.call({
    toISOString: function toISOString() {
      return 1;
    }
  }) !== 1;
}), 'Date', {
  // eslint-disable-next-line no-unused-vars
  toJSON: function toJSON(key) {
    var O = toObject(this);
    var pv = toPrimitive(O);
    return typeof pv == 'number' && !isFinite(pv) ? null : O.toISOString();
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.date.to-primitive.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.date.to-primitive.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var TO_PRIMITIVE = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('toPrimitive');
var proto = Date.prototype;
if (!(TO_PRIMITIVE in proto)) __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js")(proto, TO_PRIMITIVE, __webpack_require__(/*! ./_date-to-primitive */ "./node_modules/core-js/modules/_date-to-primitive.js"));

/***/ }),

/***/ "./node_modules/core-js/modules/es6.date.to-string.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.date.to-string.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var DateProto = Date.prototype;
var INVALID_DATE = 'Invalid Date';
var TO_STRING = 'toString';
var $toString = DateProto[TO_STRING];
var getTime = DateProto.getTime;
if (new Date(NaN) + '' != INVALID_DATE) {
  __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js")(DateProto, TO_STRING, function toString() {
    var value = getTime.call(this);
    // eslint-disable-next-line no-self-compare
    return value === value ? $toString.call(this) : INVALID_DATE;
  });
}

/***/ }),

/***/ "./node_modules/core-js/modules/es6.function.bind.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.function.bind.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.2.3.2 / 15.3.4.5 Function.prototype.bind(thisArg, args...)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.P, 'Function', {
  bind: __webpack_require__(/*! ./_bind */ "./node_modules/core-js/modules/_bind.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.function.has-instance.js":
/*!*******************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.function.has-instance.js ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var HAS_INSTANCE = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('hasInstance');
var FunctionProto = Function.prototype;
// 19.2.3.6 Function.prototype[@@hasInstance](V)
if (!(HAS_INSTANCE in FunctionProto)) (__webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f)(FunctionProto, HAS_INSTANCE, {
  value: function value(O) {
    if (typeof this != 'function' || !isObject(O)) return false;
    if (!isObject(this.prototype)) return O instanceof this;
    // for environment w/o native `@@hasInstance` logic enough `instanceof`, but add this:
    while (O = getPrototypeOf(O)) if (this.prototype === O) return true;
    return false;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.function.name.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.function.name.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var dP = (__webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f);
var FProto = Function.prototype;
var nameRE = /^\s*function ([^ (]*)/;
var NAME = 'name';

// 19.2.4.2 name
NAME in FProto || __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") && dP(FProto, NAME, {
  configurable: true,
  get: function get() {
    try {
      return ('' + this).match(nameRE)[1];
    } catch (e) {
      return '';
    }
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.map.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/es6.map.js ***!
  \*************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var strong = __webpack_require__(/*! ./_collection-strong */ "./node_modules/core-js/modules/_collection-strong.js");
var validate = __webpack_require__(/*! ./_validate-collection */ "./node_modules/core-js/modules/_validate-collection.js");
var MAP = 'Map';

// 23.1 Map Objects
module.exports = __webpack_require__(/*! ./_collection */ "./node_modules/core-js/modules/_collection.js")(MAP, function (get) {
  return function Map() {
    return get(this, arguments.length > 0 ? arguments[0] : undefined);
  };
}, {
  // 23.1.3.6 Map.prototype.get(key)
  get: function get(key) {
    var entry = strong.getEntry(validate(this, MAP), key);
    return entry && entry.v;
  },
  // 23.1.3.9 Map.prototype.set(key, value)
  set: function set(key, value) {
    return strong.def(validate(this, MAP), key === 0 ? 0 : key, value);
  }
}, strong, true);

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.acosh.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.acosh.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.3 Math.acosh(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var log1p = __webpack_require__(/*! ./_math-log1p */ "./node_modules/core-js/modules/_math-log1p.js");
var sqrt = Math.sqrt;
var $acosh = Math.acosh;
$export($export.S + $export.F * !($acosh
// V8 bug: https://code.google.com/p/v8/issues/detail?id=3509
&& Math.floor($acosh(Number.MAX_VALUE)) == 710
// Tor Browser bug: Math.acosh(Infinity) -> NaN
&& $acosh(Infinity) == Infinity), 'Math', {
  acosh: function acosh(x) {
    return (x = +x) < 1 ? NaN : x > 94906265.62425156 ? Math.log(x) + Math.LN2 : log1p(x - 1 + sqrt(x - 1) * sqrt(x + 1));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.asinh.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.asinh.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.5 Math.asinh(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $asinh = Math.asinh;
function asinh(x) {
  return !isFinite(x = +x) || x == 0 ? x : x < 0 ? -asinh(-x) : Math.log(x + Math.sqrt(x * x + 1));
}

// Tor Browser bug: Math.asinh(0) -> -0
$export($export.S + $export.F * !($asinh && 1 / $asinh(0) > 0), 'Math', {
  asinh: asinh
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.atanh.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.atanh.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.7 Math.atanh(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $atanh = Math.atanh;

// Tor Browser bug: Math.atanh(-0) -> 0
$export($export.S + $export.F * !($atanh && 1 / $atanh(-0) < 0), 'Math', {
  atanh: function atanh(x) {
    return (x = +x) == 0 ? x : Math.log((1 + x) / (1 - x)) / 2;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.cbrt.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.cbrt.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.9 Math.cbrt(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var sign = __webpack_require__(/*! ./_math-sign */ "./node_modules/core-js/modules/_math-sign.js");
$export($export.S, 'Math', {
  cbrt: function cbrt(x) {
    return sign(x = +x) * Math.pow(Math.abs(x), 1 / 3);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.clz32.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.clz32.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.11 Math.clz32(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  clz32: function clz32(x) {
    return (x >>>= 0) ? 31 - Math.floor(Math.log(x + 0.5) * Math.LOG2E) : 32;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.cosh.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.cosh.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.12 Math.cosh(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var exp = Math.exp;
$export($export.S, 'Math', {
  cosh: function cosh(x) {
    return (exp(x = +x) + exp(-x)) / 2;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.expm1.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.expm1.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.14 Math.expm1(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $expm1 = __webpack_require__(/*! ./_math-expm1 */ "./node_modules/core-js/modules/_math-expm1.js");
$export($export.S + $export.F * ($expm1 != Math.expm1), 'Math', {
  expm1: $expm1
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.fround.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.fround.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.16 Math.fround(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  fround: __webpack_require__(/*! ./_math-fround */ "./node_modules/core-js/modules/_math-fround.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.hypot.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.hypot.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.17 Math.hypot([value1[, value2[, … ]]])
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var abs = Math.abs;
$export($export.S, 'Math', {
  hypot: function hypot(value1, value2) {
    // eslint-disable-line no-unused-vars
    var sum = 0;
    var i = 0;
    var aLen = arguments.length;
    var larg = 0;
    var arg, div;
    while (i < aLen) {
      arg = abs(arguments[i++]);
      if (larg < arg) {
        div = larg / arg;
        sum = sum * div * div + 1;
        larg = arg;
      } else if (arg > 0) {
        div = arg / larg;
        sum += div * div;
      } else sum += arg;
    }
    return larg === Infinity ? Infinity : larg * Math.sqrt(sum);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.imul.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.imul.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.18 Math.imul(x, y)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $imul = Math.imul;

// some WebKit versions fails with big numbers, some has wrong arity
$export($export.S + $export.F * __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return $imul(0xffffffff, 5) != -5 || $imul.length != 2;
}), 'Math', {
  imul: function imul(x, y) {
    var UINT16 = 0xffff;
    var xn = +x;
    var yn = +y;
    var xl = UINT16 & xn;
    var yl = UINT16 & yn;
    return 0 | xl * yl + ((UINT16 & xn >>> 16) * yl + xl * (UINT16 & yn >>> 16) << 16 >>> 0);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.log10.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.log10.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.21 Math.log10(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  log10: function log10(x) {
    return Math.log(x) * Math.LOG10E;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.log1p.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.log1p.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.20 Math.log1p(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  log1p: __webpack_require__(/*! ./_math-log1p */ "./node_modules/core-js/modules/_math-log1p.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.log2.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.log2.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.22 Math.log2(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  log2: function log2(x) {
    return Math.log(x) / Math.LN2;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.sign.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.sign.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.28 Math.sign(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  sign: __webpack_require__(/*! ./_math-sign */ "./node_modules/core-js/modules/_math-sign.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.sinh.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.sinh.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.30 Math.sinh(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var expm1 = __webpack_require__(/*! ./_math-expm1 */ "./node_modules/core-js/modules/_math-expm1.js");
var exp = Math.exp;

// V8 near Chromium 38 has a problem with very small numbers
$export($export.S + $export.F * __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return !Math.sinh(-2e-17) != -2e-17;
}), 'Math', {
  sinh: function sinh(x) {
    return Math.abs(x = +x) < 1 ? (expm1(x) - expm1(-x)) / 2 : (exp(x - 1) - exp(-x - 1)) * (Math.E / 2);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.tanh.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.tanh.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.33 Math.tanh(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var expm1 = __webpack_require__(/*! ./_math-expm1 */ "./node_modules/core-js/modules/_math-expm1.js");
var exp = Math.exp;
$export($export.S, 'Math', {
  tanh: function tanh(x) {
    var a = expm1(x = +x);
    var b = expm1(-x);
    return a == Infinity ? 1 : b == Infinity ? -1 : (a - b) / (exp(x) + exp(-x));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.math.trunc.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.math.trunc.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.2.2.34 Math.trunc(x)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  trunc: function trunc(it) {
    return (it > 0 ? Math.floor : Math.ceil)(it);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.constructor.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.constructor.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
var inheritIfRequired = __webpack_require__(/*! ./_inherit-if-required */ "./node_modules/core-js/modules/_inherit-if-required.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var gOPN = (__webpack_require__(/*! ./_object-gopn */ "./node_modules/core-js/modules/_object-gopn.js").f);
var gOPD = (__webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js").f);
var dP = (__webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f);
var $trim = (__webpack_require__(/*! ./_string-trim */ "./node_modules/core-js/modules/_string-trim.js").trim);
var NUMBER = 'Number';
var $Number = global[NUMBER];
var Base = $Number;
var proto = $Number.prototype;
// Opera ~12 has broken Object#toString
var BROKEN_COF = cof(__webpack_require__(/*! ./_object-create */ "./node_modules/core-js/modules/_object-create.js")(proto)) == NUMBER;
var TRIM = 'trim' in String.prototype;

// 7.1.3 ToNumber(argument)
var toNumber = function toNumber(argument) {
  var it = toPrimitive(argument, false);
  if (typeof it == 'string' && it.length > 2) {
    it = TRIM ? it.trim() : $trim(it, 3);
    var first = it.charCodeAt(0);
    var third, radix, maxCode;
    if (first === 43 || first === 45) {
      third = it.charCodeAt(2);
      if (third === 88 || third === 120) return NaN; // Number('+0x1') should be NaN, old V8 fix
    } else if (first === 48) {
      switch (it.charCodeAt(1)) {
        case 66:
        case 98:
          radix = 2;
          maxCode = 49;
          break;
        // fast equal /^0b[01]+$/i
        case 79:
        case 111:
          radix = 8;
          maxCode = 55;
          break;
        // fast equal /^0o[0-7]+$/i
        default:
          return +it;
      }
      for (var digits = it.slice(2), i = 0, l = digits.length, code; i < l; i++) {
        code = digits.charCodeAt(i);
        // parseInt parses a string to a first unavailable symbol
        // but ToNumber should return NaN if a string contains unavailable symbols
        if (code < 48 || code > maxCode) return NaN;
      }
      return parseInt(digits, radix);
    }
  }
  return +it;
};
if (!$Number(' 0o1') || !$Number('0b1') || $Number('+0x1')) {
  $Number = function Number(value) {
    var it = arguments.length < 1 ? 0 : value;
    var that = this;
    return that instanceof $Number
    // check on 1..constructor(foo) case
    && (BROKEN_COF ? fails(function () {
      proto.valueOf.call(that);
    }) : cof(that) != NUMBER) ? inheritIfRequired(new Base(toNumber(it)), that, $Number) : toNumber(it);
  };
  for (var keys = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") ? gOPN(Base) : (
    // ES3:
    'MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,' +
    // ES6 (in case, if modules with ES6 Number statics required before):
    'EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,' + 'MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger').split(','), j = 0, key; keys.length > j; j++) {
    if (has(Base, key = keys[j]) && !has($Number, key)) {
      dP($Number, key, gOPD(Base, key));
    }
  }
  $Number.prototype = proto;
  proto.constructor = $Number;
  __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js")(global, NUMBER, $Number);
}

/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.epsilon.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.epsilon.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.1.2.1 Number.EPSILON
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Number', {
  EPSILON: Math.pow(2, -52)
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.is-finite.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.is-finite.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.1.2.2 Number.isFinite(number)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var _isFinite = (__webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").isFinite);
$export($export.S, 'Number', {
  isFinite: function isFinite(it) {
    return typeof it == 'number' && _isFinite(it);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.is-integer.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.is-integer.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.1.2.3 Number.isInteger(number)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Number', {
  isInteger: __webpack_require__(/*! ./_is-integer */ "./node_modules/core-js/modules/_is-integer.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.is-nan.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.is-nan.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.1.2.4 Number.isNaN(number)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Number', {
  isNaN: function isNaN(number) {
    // eslint-disable-next-line no-self-compare
    return number != number;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.is-safe-integer.js":
/*!********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.is-safe-integer.js ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.1.2.5 Number.isSafeInteger(number)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var isInteger = __webpack_require__(/*! ./_is-integer */ "./node_modules/core-js/modules/_is-integer.js");
var abs = Math.abs;
$export($export.S, 'Number', {
  isSafeInteger: function isSafeInteger(number) {
    return isInteger(number) && abs(number) <= 0x1fffffffffffff;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.max-safe-integer.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.max-safe-integer.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.1.2.6 Number.MAX_SAFE_INTEGER
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Number', {
  MAX_SAFE_INTEGER: 0x1fffffffffffff
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.min-safe-integer.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.min-safe-integer.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 20.1.2.10 Number.MIN_SAFE_INTEGER
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Number', {
  MIN_SAFE_INTEGER: -0x1fffffffffffff
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.parse-float.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.parse-float.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $parseFloat = __webpack_require__(/*! ./_parse-float */ "./node_modules/core-js/modules/_parse-float.js");
// 20.1.2.12 Number.parseFloat(string)
$export($export.S + $export.F * (Number.parseFloat != $parseFloat), 'Number', {
  parseFloat: $parseFloat
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.parse-int.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.parse-int.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $parseInt = __webpack_require__(/*! ./_parse-int */ "./node_modules/core-js/modules/_parse-int.js");
// 20.1.2.13 Number.parseInt(string, radix)
$export($export.S + $export.F * (Number.parseInt != $parseInt), 'Number', {
  parseInt: $parseInt
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.to-fixed.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.to-fixed.js ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var aNumberValue = __webpack_require__(/*! ./_a-number-value */ "./node_modules/core-js/modules/_a-number-value.js");
var repeat = __webpack_require__(/*! ./_string-repeat */ "./node_modules/core-js/modules/_string-repeat.js");
var $toFixed = 1.0.toFixed;
var floor = Math.floor;
var data = [0, 0, 0, 0, 0, 0];
var ERROR = 'Number.toFixed: incorrect invocation!';
var ZERO = '0';
var multiply = function multiply(n, c) {
  var i = -1;
  var c2 = c;
  while (++i < 6) {
    c2 += n * data[i];
    data[i] = c2 % 1e7;
    c2 = floor(c2 / 1e7);
  }
};
var divide = function divide(n) {
  var i = 6;
  var c = 0;
  while (--i >= 0) {
    c += data[i];
    data[i] = floor(c / n);
    c = c % n * 1e7;
  }
};
var numToString = function numToString() {
  var i = 6;
  var s = '';
  while (--i >= 0) {
    if (s !== '' || i === 0 || data[i] !== 0) {
      var t = String(data[i]);
      s = s === '' ? t : s + repeat.call(ZERO, 7 - t.length) + t;
    }
  }
  return s;
};
var _pow = function pow(x, n, acc) {
  return n === 0 ? acc : n % 2 === 1 ? _pow(x, n - 1, acc * x) : _pow(x * x, n / 2, acc);
};
var log = function log(x) {
  var n = 0;
  var x2 = x;
  while (x2 >= 4096) {
    n += 12;
    x2 /= 4096;
  }
  while (x2 >= 2) {
    n += 1;
    x2 /= 2;
  }
  return n;
};
$export($export.P + $export.F * (!!$toFixed && (0.00008.toFixed(3) !== '0.000' || 0.9.toFixed(0) !== '1' || 1.255.toFixed(2) !== '1.25' || 1000000000000000128.0.toFixed(0) !== '1000000000000000128') || !__webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  // V8 ~ Android 4.3-
  $toFixed.call({});
})), 'Number', {
  toFixed: function toFixed(fractionDigits) {
    var x = aNumberValue(this, ERROR);
    var f = toInteger(fractionDigits);
    var s = '';
    var m = ZERO;
    var e, z, j, k;
    if (f < 0 || f > 20) throw RangeError(ERROR);
    // eslint-disable-next-line no-self-compare
    if (x != x) return 'NaN';
    if (x <= -1e21 || x >= 1e21) return String(x);
    if (x < 0) {
      s = '-';
      x = -x;
    }
    if (x > 1e-21) {
      e = log(x * _pow(2, 69, 1)) - 69;
      z = e < 0 ? x * _pow(2, -e, 1) : x / _pow(2, e, 1);
      z *= 0x10000000000000;
      e = 52 - e;
      if (e > 0) {
        multiply(0, z);
        j = f;
        while (j >= 7) {
          multiply(1e7, 0);
          j -= 7;
        }
        multiply(_pow(10, j, 1), 0);
        j = e - 1;
        while (j >= 23) {
          divide(1 << 23);
          j -= 23;
        }
        divide(1 << j);
        multiply(1, 1);
        divide(2);
        m = numToString();
      } else {
        multiply(0, z);
        multiply(1 << -e, 0);
        m = numToString() + repeat.call(ZERO, f);
      }
    }
    if (f > 0) {
      k = m.length;
      m = s + (k <= f ? '0.' + repeat.call(ZERO, f - k) + m : m.slice(0, k - f) + '.' + m.slice(k - f));
    } else {
      m = s + m;
    }
    return m;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.number.to-precision.js":
/*!*****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.number.to-precision.js ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var aNumberValue = __webpack_require__(/*! ./_a-number-value */ "./node_modules/core-js/modules/_a-number-value.js");
var $toPrecision = 1.0.toPrecision;
$export($export.P + $export.F * ($fails(function () {
  // IE7-
  return $toPrecision.call(1, undefined) !== '1';
}) || !$fails(function () {
  // V8 ~ Android 4.3-
  $toPrecision.call({});
})), 'Number', {
  toPrecision: function toPrecision(precision) {
    var that = aNumberValue(this, 'Number#toPrecision: incorrect invocation!');
    return precision === undefined ? $toPrecision.call(that) : $toPrecision.call(that, precision);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.assign.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.assign.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.1.3.1 Object.assign(target, source)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S + $export.F, 'Object', {
  assign: __webpack_require__(/*! ./_object-assign */ "./node_modules/core-js/modules/_object-assign.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.create.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.create.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
$export($export.S, 'Object', {
  create: __webpack_require__(/*! ./_object-create */ "./node_modules/core-js/modules/_object-create.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.define-properties.js":
/*!**********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.define-properties.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
// 19.1.2.3 / 15.2.3.7 Object.defineProperties(O, Properties)
$export($export.S + $export.F * !__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js"), 'Object', {
  defineProperties: __webpack_require__(/*! ./_object-dps */ "./node_modules/core-js/modules/_object-dps.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.define-property.js":
/*!********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.define-property.js ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
// 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
$export($export.S + $export.F * !__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js"), 'Object', {
  defineProperty: (__webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f)
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.freeze.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.freeze.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.1.2.5 Object.freeze(O)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var meta = (__webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js").onFreeze);
__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('freeze', function ($freeze) {
  return function freeze(it) {
    return $freeze && isObject(it) ? $freeze(meta(it)) : it;
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.get-own-property-descriptor.js":
/*!********************************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.get-own-property-descriptor.js ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var $getOwnPropertyDescriptor = (__webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js").f);
__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('getOwnPropertyDescriptor', function () {
  return function getOwnPropertyDescriptor(it, key) {
    return $getOwnPropertyDescriptor(toIObject(it), key);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.get-own-property-names.js":
/*!***************************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.get-own-property-names.js ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.1.2.7 Object.getOwnPropertyNames(O)
__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('getOwnPropertyNames', function () {
  return (__webpack_require__(/*! ./_object-gopn-ext */ "./node_modules/core-js/modules/_object-gopn-ext.js").f);
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.get-prototype-of.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.get-prototype-of.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.1.2.9 Object.getPrototypeOf(O)
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var $getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('getPrototypeOf', function () {
  return function getPrototypeOf(it) {
    return $getPrototypeOf(toObject(it));
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.is-extensible.js":
/*!******************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.is-extensible.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.1.2.11 Object.isExtensible(O)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('isExtensible', function ($isExtensible) {
  return function isExtensible(it) {
    return isObject(it) ? $isExtensible ? $isExtensible(it) : true : false;
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.is-frozen.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.is-frozen.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.1.2.12 Object.isFrozen(O)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('isFrozen', function ($isFrozen) {
  return function isFrozen(it) {
    return isObject(it) ? $isFrozen ? $isFrozen(it) : false : true;
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.is-sealed.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.is-sealed.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.1.2.13 Object.isSealed(O)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('isSealed', function ($isSealed) {
  return function isSealed(it) {
    return isObject(it) ? $isSealed ? $isSealed(it) : false : true;
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.is.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.is.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.1.3.10 Object.is(value1, value2)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Object', {
  is: __webpack_require__(/*! ./_same-value */ "./node_modules/core-js/modules/_same-value.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.keys.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.keys.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.1.2.14 Object.keys(O)
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var $keys = __webpack_require__(/*! ./_object-keys */ "./node_modules/core-js/modules/_object-keys.js");
__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('keys', function () {
  return function keys(it) {
    return $keys(toObject(it));
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.prevent-extensions.js":
/*!***********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.prevent-extensions.js ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.1.2.15 Object.preventExtensions(O)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var meta = (__webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js").onFreeze);
__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('preventExtensions', function ($preventExtensions) {
  return function preventExtensions(it) {
    return $preventExtensions && isObject(it) ? $preventExtensions(meta(it)) : it;
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.seal.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.seal.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.1.2.17 Object.seal(O)
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var meta = (__webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js").onFreeze);
__webpack_require__(/*! ./_object-sap */ "./node_modules/core-js/modules/_object-sap.js")('seal', function ($seal) {
  return function seal(it) {
    return $seal && isObject(it) ? $seal(meta(it)) : it;
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.set-prototype-of.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.set-prototype-of.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 19.1.3.19 Object.setPrototypeOf(O, proto)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Object', {
  setPrototypeOf: (__webpack_require__(/*! ./_set-proto */ "./node_modules/core-js/modules/_set-proto.js").set)
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.object.to-string.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.object.to-string.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// 19.1.3.6 Object.prototype.toString()
var classof = __webpack_require__(/*! ./_classof */ "./node_modules/core-js/modules/_classof.js");
var test = {};
test[__webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('toStringTag')] = 'z';
if (test + '' != '[object z]') {
  __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js")(Object.prototype, 'toString', function toString() {
    return '[object ' + classof(this) + ']';
  }, true);
}

/***/ }),

/***/ "./node_modules/core-js/modules/es6.parse-float.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.parse-float.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $parseFloat = __webpack_require__(/*! ./_parse-float */ "./node_modules/core-js/modules/_parse-float.js");
// 18.2.4 parseFloat(string)
$export($export.G + $export.F * (parseFloat != $parseFloat), {
  parseFloat: $parseFloat
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.parse-int.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.parse-int.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $parseInt = __webpack_require__(/*! ./_parse-int */ "./node_modules/core-js/modules/_parse-int.js");
// 18.2.5 parseInt(string, radix)
$export($export.G + $export.F * (parseInt != $parseInt), {
  parseInt: $parseInt
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.promise.js":
/*!*****************************************************!*\
  !*** ./node_modules/core-js/modules/es6.promise.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var LIBRARY = __webpack_require__(/*! ./_library */ "./node_modules/core-js/modules/_library.js");
var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var ctx = __webpack_require__(/*! ./_ctx */ "./node_modules/core-js/modules/_ctx.js");
var classof = __webpack_require__(/*! ./_classof */ "./node_modules/core-js/modules/_classof.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var anInstance = __webpack_require__(/*! ./_an-instance */ "./node_modules/core-js/modules/_an-instance.js");
var forOf = __webpack_require__(/*! ./_for-of */ "./node_modules/core-js/modules/_for-of.js");
var speciesConstructor = __webpack_require__(/*! ./_species-constructor */ "./node_modules/core-js/modules/_species-constructor.js");
var task = (__webpack_require__(/*! ./_task */ "./node_modules/core-js/modules/_task.js").set);
var microtask = __webpack_require__(/*! ./_microtask */ "./node_modules/core-js/modules/_microtask.js")();
var newPromiseCapabilityModule = __webpack_require__(/*! ./_new-promise-capability */ "./node_modules/core-js/modules/_new-promise-capability.js");
var perform = __webpack_require__(/*! ./_perform */ "./node_modules/core-js/modules/_perform.js");
var userAgent = __webpack_require__(/*! ./_user-agent */ "./node_modules/core-js/modules/_user-agent.js");
var promiseResolve = __webpack_require__(/*! ./_promise-resolve */ "./node_modules/core-js/modules/_promise-resolve.js");
var PROMISE = 'Promise';
var TypeError = global.TypeError;
var process = global.process;
var versions = process && process.versions;
var v8 = versions && versions.v8 || '';
var $Promise = global[PROMISE];
var isNode = classof(process) == 'process';
var empty = function empty() {/* empty */};
var Internal, newGenericPromiseCapability, OwnPromiseCapability, Wrapper;
var newPromiseCapability = newGenericPromiseCapability = newPromiseCapabilityModule.f;
var USE_NATIVE = !!function () {
  try {
    // correct subclassing with @@species support
    var promise = $Promise.resolve(1);
    var FakePromise = (promise.constructor = {})[__webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('species')] = function (exec) {
      exec(empty, empty);
    };
    // unhandled rejections tracking support, NodeJS Promise without it fails @@species test
    return (isNode || typeof PromiseRejectionEvent == 'function') && promise.then(empty) instanceof FakePromise
    // v8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
    // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
    // we can't detect it synchronously, so just check versions
    && v8.indexOf('6.6') !== 0 && userAgent.indexOf('Chrome/66') === -1;
  } catch (e) {/* empty */}
}();

// helpers
var isThenable = function isThenable(it) {
  var then;
  return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
};
var notify = function notify(promise, isReject) {
  if (promise._n) return;
  promise._n = true;
  var chain = promise._c;
  microtask(function () {
    var value = promise._v;
    var ok = promise._s == 1;
    var i = 0;
    var run = function run(reaction) {
      var handler = ok ? reaction.ok : reaction.fail;
      var resolve = reaction.resolve;
      var reject = reaction.reject;
      var domain = reaction.domain;
      var result, then, exited;
      try {
        if (handler) {
          if (!ok) {
            if (promise._h == 2) onHandleUnhandled(promise);
            promise._h = 1;
          }
          if (handler === true) result = value;else {
            if (domain) domain.enter();
            result = handler(value); // may throw
            if (domain) {
              domain.exit();
              exited = true;
            }
          }
          if (result === reaction.promise) {
            reject(TypeError('Promise-chain cycle'));
          } else if (then = isThenable(result)) {
            then.call(result, resolve, reject);
          } else resolve(result);
        } else reject(value);
      } catch (e) {
        if (domain && !exited) domain.exit();
        reject(e);
      }
    };
    while (chain.length > i) run(chain[i++]); // variable length - can't use forEach
    promise._c = [];
    promise._n = false;
    if (isReject && !promise._h) onUnhandled(promise);
  });
};
var onUnhandled = function onUnhandled(promise) {
  task.call(global, function () {
    var value = promise._v;
    var unhandled = isUnhandled(promise);
    var result, handler, console;
    if (unhandled) {
      result = perform(function () {
        if (isNode) {
          process.emit('unhandledRejection', value, promise);
        } else if (handler = global.onunhandledrejection) {
          handler({
            promise: promise,
            reason: value
          });
        } else if ((console = global.console) && console.error) {
          console.error('Unhandled promise rejection', value);
        }
      });
      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
      promise._h = isNode || isUnhandled(promise) ? 2 : 1;
    }
    promise._a = undefined;
    if (unhandled && result.e) throw result.v;
  });
};
var isUnhandled = function isUnhandled(promise) {
  return promise._h !== 1 && (promise._a || promise._c).length === 0;
};
var onHandleUnhandled = function onHandleUnhandled(promise) {
  task.call(global, function () {
    var handler;
    if (isNode) {
      process.emit('rejectionHandled', promise);
    } else if (handler = global.onrejectionhandled) {
      handler({
        promise: promise,
        reason: promise._v
      });
    }
  });
};
var $reject = function $reject(value) {
  var promise = this;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  promise._v = value;
  promise._s = 2;
  if (!promise._a) promise._a = promise._c.slice();
  notify(promise, true);
};
var _$resolve = function $resolve(value) {
  var promise = this;
  var then;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  try {
    if (promise === value) throw TypeError("Promise can't be resolved itself");
    if (then = isThenable(value)) {
      microtask(function () {
        var wrapper = {
          _w: promise,
          _d: false
        }; // wrap
        try {
          then.call(value, ctx(_$resolve, wrapper, 1), ctx($reject, wrapper, 1));
        } catch (e) {
          $reject.call(wrapper, e);
        }
      });
    } else {
      promise._v = value;
      promise._s = 1;
      notify(promise, false);
    }
  } catch (e) {
    $reject.call({
      _w: promise,
      _d: false
    }, e); // wrap
  }
};

// constructor polyfill
if (!USE_NATIVE) {
  // 25.4.3.1 Promise(executor)
  $Promise = function Promise(executor) {
    anInstance(this, $Promise, PROMISE, '_h');
    aFunction(executor);
    Internal.call(this);
    try {
      executor(ctx(_$resolve, this, 1), ctx($reject, this, 1));
    } catch (err) {
      $reject.call(this, err);
    }
  };
  // eslint-disable-next-line no-unused-vars
  Internal = function Promise(executor) {
    this._c = []; // <- awaiting reactions
    this._a = undefined; // <- checked in isUnhandled reactions
    this._s = 0; // <- state
    this._d = false; // <- done
    this._v = undefined; // <- value
    this._h = 0; // <- rejection state, 0 - default, 1 - handled, 2 - unhandled
    this._n = false; // <- notify
  };
  Internal.prototype = __webpack_require__(/*! ./_redefine-all */ "./node_modules/core-js/modules/_redefine-all.js")($Promise.prototype, {
    // 25.4.5.3 Promise.prototype.then(onFulfilled, onRejected)
    then: function then(onFulfilled, onRejected) {
      var reaction = newPromiseCapability(speciesConstructor(this, $Promise));
      reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
      reaction.fail = typeof onRejected == 'function' && onRejected;
      reaction.domain = isNode ? process.domain : undefined;
      this._c.push(reaction);
      if (this._a) this._a.push(reaction);
      if (this._s) notify(this, false);
      return reaction.promise;
    },
    // 25.4.5.1 Promise.prototype.catch(onRejected)
    'catch': function _catch(onRejected) {
      return this.then(undefined, onRejected);
    }
  });
  OwnPromiseCapability = function OwnPromiseCapability() {
    var promise = new Internal();
    this.promise = promise;
    this.resolve = ctx(_$resolve, promise, 1);
    this.reject = ctx($reject, promise, 1);
  };
  newPromiseCapabilityModule.f = newPromiseCapability = function newPromiseCapability(C) {
    return C === $Promise || C === Wrapper ? new OwnPromiseCapability(C) : newGenericPromiseCapability(C);
  };
}
$export($export.G + $export.W + $export.F * !USE_NATIVE, {
  Promise: $Promise
});
__webpack_require__(/*! ./_set-to-string-tag */ "./node_modules/core-js/modules/_set-to-string-tag.js")($Promise, PROMISE);
__webpack_require__(/*! ./_set-species */ "./node_modules/core-js/modules/_set-species.js")(PROMISE);
Wrapper = __webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js")[PROMISE];

// statics
$export($export.S + $export.F * !USE_NATIVE, PROMISE, {
  // 25.4.4.5 Promise.reject(r)
  reject: function reject(r) {
    var capability = newPromiseCapability(this);
    var $$reject = capability.reject;
    $$reject(r);
    return capability.promise;
  }
});
$export($export.S + $export.F * (LIBRARY || !USE_NATIVE), PROMISE, {
  // 25.4.4.6 Promise.resolve(x)
  resolve: function resolve(x) {
    return promiseResolve(LIBRARY && this === Wrapper ? $Promise : this, x);
  }
});
$export($export.S + $export.F * !(USE_NATIVE && __webpack_require__(/*! ./_iter-detect */ "./node_modules/core-js/modules/_iter-detect.js")(function (iter) {
  $Promise.all(iter)['catch'](empty);
})), PROMISE, {
  // 25.4.4.1 Promise.all(iterable)
  all: function all(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var values = [];
      var index = 0;
      var remaining = 1;
      forOf(iterable, false, function (promise) {
        var $index = index++;
        var alreadyCalled = false;
        values.push(undefined);
        remaining++;
        C.resolve(promise).then(function (value) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[$index] = value;
          --remaining || resolve(values);
        }, reject);
      });
      --remaining || resolve(values);
    });
    if (result.e) reject(result.v);
    return capability.promise;
  },
  // 25.4.4.4 Promise.race(iterable)
  race: function race(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var reject = capability.reject;
    var result = perform(function () {
      forOf(iterable, false, function (promise) {
        C.resolve(promise).then(capability.resolve, reject);
      });
    });
    if (result.e) reject(result.v);
    return capability.promise;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.apply.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.apply.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 26.1.1 Reflect.apply(target, thisArgument, argumentsList)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var rApply = ((__webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").Reflect) || {}).apply;
var fApply = Function.apply;
// MS Edge argumentsList argument is optional
$export($export.S + $export.F * !__webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  rApply(function () {/* empty */});
}), 'Reflect', {
  apply: function apply(target, thisArgument, argumentsList) {
    var T = aFunction(target);
    var L = anObject(argumentsList);
    return rApply ? rApply(T, thisArgument, L) : fApply.call(T, thisArgument, L);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.construct.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.construct.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 26.1.2 Reflect.construct(target, argumentsList [, newTarget])
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var create = __webpack_require__(/*! ./_object-create */ "./node_modules/core-js/modules/_object-create.js");
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var bind = __webpack_require__(/*! ./_bind */ "./node_modules/core-js/modules/_bind.js");
var rConstruct = ((__webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").Reflect) || {}).construct;

// MS Edge supports only 2 arguments and argumentsList argument is optional
// FF Nightly sets third argument as `new.target`, but does not create `this` from it
var NEW_TARGET_BUG = fails(function () {
  function F() {/* empty */}
  return !(rConstruct(function () {/* empty */}, [], F) instanceof F);
});
var ARGS_BUG = !fails(function () {
  rConstruct(function () {/* empty */});
});
$export($export.S + $export.F * (NEW_TARGET_BUG || ARGS_BUG), 'Reflect', {
  construct: function construct(Target, args /* , newTarget */) {
    aFunction(Target);
    anObject(args);
    var newTarget = arguments.length < 3 ? Target : aFunction(arguments[2]);
    if (ARGS_BUG && !NEW_TARGET_BUG) return rConstruct(Target, args, newTarget);
    if (Target == newTarget) {
      // w/o altered newTarget, optimization for 0-4 arguments
      switch (args.length) {
        case 0:
          return new Target();
        case 1:
          return new Target(args[0]);
        case 2:
          return new Target(args[0], args[1]);
        case 3:
          return new Target(args[0], args[1], args[2]);
        case 4:
          return new Target(args[0], args[1], args[2], args[3]);
      }
      // w/o altered newTarget, lot of arguments case
      var $args = [null];
      $args.push.apply($args, args);
      return new (bind.apply(Target, $args))();
    }
    // with altered newTarget, not support built-in constructors
    var proto = newTarget.prototype;
    var instance = create(isObject(proto) ? proto : Object.prototype);
    var result = Function.apply.call(Target, instance, args);
    return isObject(result) ? result : instance;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.define-property.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.define-property.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 26.1.3 Reflect.defineProperty(target, propertyKey, attributes)
var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");

// MS Edge has broken Reflect.defineProperty - throwing instead of returning false
$export($export.S + $export.F * __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  // eslint-disable-next-line no-undef
  Reflect.defineProperty(dP.f({}, 1, {
    value: 1
  }), 1, {
    value: 2
  });
}), 'Reflect', {
  defineProperty: function defineProperty(target, propertyKey, attributes) {
    anObject(target);
    propertyKey = toPrimitive(propertyKey, true);
    anObject(attributes);
    try {
      dP.f(target, propertyKey, attributes);
      return true;
    } catch (e) {
      return false;
    }
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.delete-property.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.delete-property.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 26.1.4 Reflect.deleteProperty(target, propertyKey)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var gOPD = (__webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js").f);
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
$export($export.S, 'Reflect', {
  deleteProperty: function deleteProperty(target, propertyKey) {
    var desc = gOPD(anObject(target), propertyKey);
    return desc && !desc.configurable ? false : delete target[propertyKey];
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.enumerate.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.enumerate.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// 26.1.5 Reflect.enumerate(target)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var Enumerate = function Enumerate(iterated) {
  this._t = anObject(iterated); // target
  this._i = 0; // next index
  var keys = this._k = []; // keys
  var key;
  for (key in iterated) keys.push(key);
};
__webpack_require__(/*! ./_iter-create */ "./node_modules/core-js/modules/_iter-create.js")(Enumerate, 'Object', function () {
  var that = this;
  var keys = that._k;
  var key;
  do {
    if (that._i >= keys.length) return {
      value: undefined,
      done: true
    };
  } while (!((key = keys[that._i++]) in that._t));
  return {
    value: key,
    done: false
  };
});
$export($export.S, 'Reflect', {
  enumerate: function enumerate(target) {
    return new Enumerate(target);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.get-own-property-descriptor.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.get-own-property-descriptor.js ***!
  \*********************************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 26.1.7 Reflect.getOwnPropertyDescriptor(target, propertyKey)
var gOPD = __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
$export($export.S, 'Reflect', {
  getOwnPropertyDescriptor: function getOwnPropertyDescriptor(target, propertyKey) {
    return gOPD.f(anObject(target), propertyKey);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.get-prototype-of.js":
/*!**********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.get-prototype-of.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 26.1.8 Reflect.getPrototypeOf(target)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var getProto = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
$export($export.S, 'Reflect', {
  getPrototypeOf: function getPrototypeOf(target) {
    return getProto(anObject(target));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.get.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.get.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 26.1.6 Reflect.get(target, propertyKey [, receiver])
var gOPD = __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js");
var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
function get(target, propertyKey /* , receiver */) {
  var receiver = arguments.length < 3 ? target : arguments[2];
  var desc, proto;
  if (anObject(target) === receiver) return target[propertyKey];
  if (desc = gOPD.f(target, propertyKey)) return has(desc, 'value') ? desc.value : desc.get !== undefined ? desc.get.call(receiver) : undefined;
  if (isObject(proto = getPrototypeOf(target))) return get(proto, propertyKey, receiver);
}
$export($export.S, 'Reflect', {
  get: get
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.has.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.has.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 26.1.9 Reflect.has(target, propertyKey)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Reflect', {
  has: function has(target, propertyKey) {
    return propertyKey in target;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.is-extensible.js":
/*!*******************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.is-extensible.js ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 26.1.10 Reflect.isExtensible(target)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var $isExtensible = Object.isExtensible;
$export($export.S, 'Reflect', {
  isExtensible: function isExtensible(target) {
    anObject(target);
    return $isExtensible ? $isExtensible(target) : true;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.own-keys.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.own-keys.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 26.1.11 Reflect.ownKeys(target)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Reflect', {
  ownKeys: __webpack_require__(/*! ./_own-keys */ "./node_modules/core-js/modules/_own-keys.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.prevent-extensions.js":
/*!************************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.prevent-extensions.js ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 26.1.12 Reflect.preventExtensions(target)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var $preventExtensions = Object.preventExtensions;
$export($export.S, 'Reflect', {
  preventExtensions: function preventExtensions(target) {
    anObject(target);
    try {
      if ($preventExtensions) $preventExtensions(target);
      return true;
    } catch (e) {
      return false;
    }
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.set-prototype-of.js":
/*!**********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.set-prototype-of.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 26.1.14 Reflect.setPrototypeOf(target, proto)
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var setProto = __webpack_require__(/*! ./_set-proto */ "./node_modules/core-js/modules/_set-proto.js");
if (setProto) $export($export.S, 'Reflect', {
  setPrototypeOf: function setPrototypeOf(target, proto) {
    setProto.check(target, proto);
    try {
      setProto.set(target, proto);
      return true;
    } catch (e) {
      return false;
    }
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.reflect.set.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.reflect.set.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 26.1.13 Reflect.set(target, propertyKey, V [, receiver])
var dP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var gOPD = __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js");
var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var createDesc = __webpack_require__(/*! ./_property-desc */ "./node_modules/core-js/modules/_property-desc.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
function set(target, propertyKey, V /* , receiver */) {
  var receiver = arguments.length < 4 ? target : arguments[3];
  var ownDesc = gOPD.f(anObject(target), propertyKey);
  var existingDescriptor, proto;
  if (!ownDesc) {
    if (isObject(proto = getPrototypeOf(target))) {
      return set(proto, propertyKey, V, receiver);
    }
    ownDesc = createDesc(0);
  }
  if (has(ownDesc, 'value')) {
    if (ownDesc.writable === false || !isObject(receiver)) return false;
    if (existingDescriptor = gOPD.f(receiver, propertyKey)) {
      if (existingDescriptor.get || existingDescriptor.set || existingDescriptor.writable === false) return false;
      existingDescriptor.value = V;
      dP.f(receiver, propertyKey, existingDescriptor);
    } else dP.f(receiver, propertyKey, createDesc(0, V));
    return true;
  }
  return ownDesc.set === undefined ? false : (ownDesc.set.call(receiver, V), true);
}
$export($export.S, 'Reflect', {
  set: set
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.constructor.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.constructor.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var inheritIfRequired = __webpack_require__(/*! ./_inherit-if-required */ "./node_modules/core-js/modules/_inherit-if-required.js");
var dP = (__webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f);
var gOPN = (__webpack_require__(/*! ./_object-gopn */ "./node_modules/core-js/modules/_object-gopn.js").f);
var isRegExp = __webpack_require__(/*! ./_is-regexp */ "./node_modules/core-js/modules/_is-regexp.js");
var $flags = __webpack_require__(/*! ./_flags */ "./node_modules/core-js/modules/_flags.js");
var $RegExp = global.RegExp;
var Base = $RegExp;
var proto = $RegExp.prototype;
var re1 = /a/g;
var re2 = /a/g;
// "new" creates a new object, old webkit buggy here
var CORRECT_NEW = new $RegExp(re1) !== re1;
if (__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") && (!CORRECT_NEW || __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  re2[__webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('match')] = false;
  // RegExp constructor can alter flags and IsRegExp works correct with @@match
  return $RegExp(re1) != re1 || $RegExp(re2) == re2 || $RegExp(re1, 'i') != '/a/i';
}))) {
  $RegExp = function RegExp(p, f) {
    var tiRE = this instanceof $RegExp;
    var piRE = isRegExp(p);
    var fiU = f === undefined;
    return !tiRE && piRE && p.constructor === $RegExp && fiU ? p : inheritIfRequired(CORRECT_NEW ? new Base(piRE && !fiU ? p.source : p, f) : Base((piRE = p instanceof $RegExp) ? p.source : p, piRE && fiU ? $flags.call(p) : f), tiRE ? this : proto, $RegExp);
  };
  var proxy = function proxy(key) {
    key in $RegExp || dP($RegExp, key, {
      configurable: true,
      get: function get() {
        return Base[key];
      },
      set: function set(it) {
        Base[key] = it;
      }
    });
  };
  for (var keys = gOPN(Base), i = 0; keys.length > i;) proxy(keys[i++]);
  proto.constructor = $RegExp;
  $RegExp.prototype = proto;
  __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js")(global, 'RegExp', $RegExp);
}
__webpack_require__(/*! ./_set-species */ "./node_modules/core-js/modules/_set-species.js")('RegExp');

/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.exec.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.exec.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var regexpExec = __webpack_require__(/*! ./_regexp-exec */ "./node_modules/core-js/modules/_regexp-exec.js");
__webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js")({
  target: 'RegExp',
  proto: true,
  forced: regexpExec !== /./.exec
}, {
  exec: regexpExec
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.flags.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.flags.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// 21.2.5.3 get RegExp.prototype.flags()
if (__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") && /./g.flags != 'g') (__webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js").f)(RegExp.prototype, 'flags', {
  configurable: true,
  get: __webpack_require__(/*! ./_flags */ "./node_modules/core-js/modules/_flags.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.match.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.match.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var advanceStringIndex = __webpack_require__(/*! ./_advance-string-index */ "./node_modules/core-js/modules/_advance-string-index.js");
var regExpExec = __webpack_require__(/*! ./_regexp-exec-abstract */ "./node_modules/core-js/modules/_regexp-exec-abstract.js");

// @@match logic
__webpack_require__(/*! ./_fix-re-wks */ "./node_modules/core-js/modules/_fix-re-wks.js")('match', 1, function (defined, MATCH, $match, maybeCallNative) {
  return [
  // `String.prototype.match` method
  // https://tc39.github.io/ecma262/#sec-string.prototype.match
  function match(regexp) {
    var O = defined(this);
    var fn = regexp == undefined ? undefined : regexp[MATCH];
    return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[MATCH](String(O));
  },
  // `RegExp.prototype[@@match]` method
  // https://tc39.github.io/ecma262/#sec-regexp.prototype-@@match
  function (regexp) {
    var res = maybeCallNative($match, regexp, this);
    if (res.done) return res.value;
    var rx = anObject(regexp);
    var S = String(this);
    if (!rx.global) return regExpExec(rx, S);
    var fullUnicode = rx.unicode;
    rx.lastIndex = 0;
    var A = [];
    var n = 0;
    var result;
    while ((result = regExpExec(rx, S)) !== null) {
      var matchStr = String(result[0]);
      A[n] = matchStr;
      if (matchStr === '') rx.lastIndex = advanceStringIndex(S, toLength(rx.lastIndex), fullUnicode);
      n++;
    }
    return n === 0 ? null : A;
  }];
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.replace.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.replace.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var advanceStringIndex = __webpack_require__(/*! ./_advance-string-index */ "./node_modules/core-js/modules/_advance-string-index.js");
var regExpExec = __webpack_require__(/*! ./_regexp-exec-abstract */ "./node_modules/core-js/modules/_regexp-exec-abstract.js");
var max = Math.max;
var min = Math.min;
var floor = Math.floor;
var SUBSTITUTION_SYMBOLS = /\$([$&`']|\d\d?|<[^>]*>)/g;
var SUBSTITUTION_SYMBOLS_NO_NAMED = /\$([$&`']|\d\d?)/g;
var maybeToString = function maybeToString(it) {
  return it === undefined ? it : String(it);
};

// @@replace logic
__webpack_require__(/*! ./_fix-re-wks */ "./node_modules/core-js/modules/_fix-re-wks.js")('replace', 2, function (defined, REPLACE, $replace, maybeCallNative) {
  return [
  // `String.prototype.replace` method
  // https://tc39.github.io/ecma262/#sec-string.prototype.replace
  function replace(searchValue, replaceValue) {
    var O = defined(this);
    var fn = searchValue == undefined ? undefined : searchValue[REPLACE];
    return fn !== undefined ? fn.call(searchValue, O, replaceValue) : $replace.call(String(O), searchValue, replaceValue);
  },
  // `RegExp.prototype[@@replace]` method
  // https://tc39.github.io/ecma262/#sec-regexp.prototype-@@replace
  function (regexp, replaceValue) {
    var res = maybeCallNative($replace, regexp, this, replaceValue);
    if (res.done) return res.value;
    var rx = anObject(regexp);
    var S = String(this);
    var functionalReplace = typeof replaceValue === 'function';
    if (!functionalReplace) replaceValue = String(replaceValue);
    var global = rx.global;
    if (global) {
      var fullUnicode = rx.unicode;
      rx.lastIndex = 0;
    }
    var results = [];
    while (true) {
      var result = regExpExec(rx, S);
      if (result === null) break;
      results.push(result);
      if (!global) break;
      var matchStr = String(result[0]);
      if (matchStr === '') rx.lastIndex = advanceStringIndex(S, toLength(rx.lastIndex), fullUnicode);
    }
    var accumulatedResult = '';
    var nextSourcePosition = 0;
    for (var i = 0; i < results.length; i++) {
      result = results[i];
      var matched = String(result[0]);
      var position = max(min(toInteger(result.index), S.length), 0);
      var captures = [];
      // NOTE: This is equivalent to
      //   captures = result.slice(1).map(maybeToString)
      // but for some reason `nativeSlice.call(result, 1, result.length)` (called in
      // the slice polyfill when slicing native arrays) "doesn't work" in safari 9 and
      // causes a crash (https://pastebin.com/N21QzeQA) when trying to debug it.
      for (var j = 1; j < result.length; j++) captures.push(maybeToString(result[j]));
      var namedCaptures = result.groups;
      if (functionalReplace) {
        var replacerArgs = [matched].concat(captures, position, S);
        if (namedCaptures !== undefined) replacerArgs.push(namedCaptures);
        var replacement = String(replaceValue.apply(undefined, replacerArgs));
      } else {
        replacement = getSubstitution(matched, S, position, captures, namedCaptures, replaceValue);
      }
      if (position >= nextSourcePosition) {
        accumulatedResult += S.slice(nextSourcePosition, position) + replacement;
        nextSourcePosition = position + matched.length;
      }
    }
    return accumulatedResult + S.slice(nextSourcePosition);
  }];

  // https://tc39.github.io/ecma262/#sec-getsubstitution
  function getSubstitution(matched, str, position, captures, namedCaptures, replacement) {
    var tailPos = position + matched.length;
    var m = captures.length;
    var symbols = SUBSTITUTION_SYMBOLS_NO_NAMED;
    if (namedCaptures !== undefined) {
      namedCaptures = toObject(namedCaptures);
      symbols = SUBSTITUTION_SYMBOLS;
    }
    return $replace.call(replacement, symbols, function (match, ch) {
      var capture;
      switch (ch.charAt(0)) {
        case '$':
          return '$';
        case '&':
          return matched;
        case '`':
          return str.slice(0, position);
        case "'":
          return str.slice(tailPos);
        case '<':
          capture = namedCaptures[ch.slice(1, -1)];
          break;
        default:
          // \d\d?
          var n = +ch;
          if (n === 0) return match;
          if (n > m) {
            var f = floor(n / 10);
            if (f === 0) return match;
            if (f <= m) return captures[f - 1] === undefined ? ch.charAt(1) : captures[f - 1] + ch.charAt(1);
            return match;
          }
          capture = captures[n - 1];
      }
      return capture === undefined ? '' : capture;
    });
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.search.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.search.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var sameValue = __webpack_require__(/*! ./_same-value */ "./node_modules/core-js/modules/_same-value.js");
var regExpExec = __webpack_require__(/*! ./_regexp-exec-abstract */ "./node_modules/core-js/modules/_regexp-exec-abstract.js");

// @@search logic
__webpack_require__(/*! ./_fix-re-wks */ "./node_modules/core-js/modules/_fix-re-wks.js")('search', 1, function (defined, SEARCH, $search, maybeCallNative) {
  return [
  // `String.prototype.search` method
  // https://tc39.github.io/ecma262/#sec-string.prototype.search
  function search(regexp) {
    var O = defined(this);
    var fn = regexp == undefined ? undefined : regexp[SEARCH];
    return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[SEARCH](String(O));
  },
  // `RegExp.prototype[@@search]` method
  // https://tc39.github.io/ecma262/#sec-regexp.prototype-@@search
  function (regexp) {
    var res = maybeCallNative($search, regexp, this);
    if (res.done) return res.value;
    var rx = anObject(regexp);
    var S = String(this);
    var previousLastIndex = rx.lastIndex;
    if (!sameValue(previousLastIndex, 0)) rx.lastIndex = 0;
    var result = regExpExec(rx, S);
    if (!sameValue(rx.lastIndex, previousLastIndex)) rx.lastIndex = previousLastIndex;
    return result === null ? -1 : result.index;
  }];
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.split.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.split.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var isRegExp = __webpack_require__(/*! ./_is-regexp */ "./node_modules/core-js/modules/_is-regexp.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var speciesConstructor = __webpack_require__(/*! ./_species-constructor */ "./node_modules/core-js/modules/_species-constructor.js");
var advanceStringIndex = __webpack_require__(/*! ./_advance-string-index */ "./node_modules/core-js/modules/_advance-string-index.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var callRegExpExec = __webpack_require__(/*! ./_regexp-exec-abstract */ "./node_modules/core-js/modules/_regexp-exec-abstract.js");
var regexpExec = __webpack_require__(/*! ./_regexp-exec */ "./node_modules/core-js/modules/_regexp-exec.js");
var fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var $min = Math.min;
var $push = [].push;
var $SPLIT = 'split';
var LENGTH = 'length';
var LAST_INDEX = 'lastIndex';
var MAX_UINT32 = 0xffffffff;

// babel-minify transpiles RegExp('x', 'y') -> /x/y and it causes SyntaxError
var SUPPORTS_Y = !fails(function () {
  RegExp(MAX_UINT32, 'y');
});

// @@split logic
__webpack_require__(/*! ./_fix-re-wks */ "./node_modules/core-js/modules/_fix-re-wks.js")('split', 2, function (defined, SPLIT, $split, maybeCallNative) {
  var internalSplit;
  if ('abbc'[$SPLIT](/(b)*/)[1] == 'c' || 'test'[$SPLIT](/(?:)/, -1)[LENGTH] != 4 || 'ab'[$SPLIT](/(?:ab)*/)[LENGTH] != 2 || '.'[$SPLIT](/(.?)(.?)/)[LENGTH] != 4 || '.'[$SPLIT](/()()/)[LENGTH] > 1 || ''[$SPLIT](/.?/)[LENGTH]) {
    // based on es5-shim implementation, need to rework it
    internalSplit = function internalSplit(separator, limit) {
      var string = String(this);
      if (separator === undefined && limit === 0) return [];
      // If `separator` is not a regex, use native split
      if (!isRegExp(separator)) return $split.call(string, separator, limit);
      var output = [];
      var flags = (separator.ignoreCase ? 'i' : '') + (separator.multiline ? 'm' : '') + (separator.unicode ? 'u' : '') + (separator.sticky ? 'y' : '');
      var lastLastIndex = 0;
      var splitLimit = limit === undefined ? MAX_UINT32 : limit >>> 0;
      // Make `global` and avoid `lastIndex` issues by working with a copy
      var separatorCopy = new RegExp(separator.source, flags + 'g');
      var match, lastIndex, lastLength;
      while (match = regexpExec.call(separatorCopy, string)) {
        lastIndex = separatorCopy[LAST_INDEX];
        if (lastIndex > lastLastIndex) {
          output.push(string.slice(lastLastIndex, match.index));
          if (match[LENGTH] > 1 && match.index < string[LENGTH]) $push.apply(output, match.slice(1));
          lastLength = match[0][LENGTH];
          lastLastIndex = lastIndex;
          if (output[LENGTH] >= splitLimit) break;
        }
        if (separatorCopy[LAST_INDEX] === match.index) separatorCopy[LAST_INDEX]++; // Avoid an infinite loop
      }
      if (lastLastIndex === string[LENGTH]) {
        if (lastLength || !separatorCopy.test('')) output.push('');
      } else output.push(string.slice(lastLastIndex));
      return output[LENGTH] > splitLimit ? output.slice(0, splitLimit) : output;
    };
    // Chakra, V8
  } else if ('0'[$SPLIT](undefined, 0)[LENGTH]) {
    internalSplit = function internalSplit(separator, limit) {
      return separator === undefined && limit === 0 ? [] : $split.call(this, separator, limit);
    };
  } else {
    internalSplit = $split;
  }
  return [
  // `String.prototype.split` method
  // https://tc39.github.io/ecma262/#sec-string.prototype.split
  function split(separator, limit) {
    var O = defined(this);
    var splitter = separator == undefined ? undefined : separator[SPLIT];
    return splitter !== undefined ? splitter.call(separator, O, limit) : internalSplit.call(String(O), separator, limit);
  },
  // `RegExp.prototype[@@split]` method
  // https://tc39.github.io/ecma262/#sec-regexp.prototype-@@split
  //
  // NOTE: This cannot be properly polyfilled in engines that don't support
  // the 'y' flag.
  function (regexp, limit) {
    var res = maybeCallNative(internalSplit, regexp, this, limit, internalSplit !== $split);
    if (res.done) return res.value;
    var rx = anObject(regexp);
    var S = String(this);
    var C = speciesConstructor(rx, RegExp);
    var unicodeMatching = rx.unicode;
    var flags = (rx.ignoreCase ? 'i' : '') + (rx.multiline ? 'm' : '') + (rx.unicode ? 'u' : '') + (SUPPORTS_Y ? 'y' : 'g');

    // ^(? + rx + ) is needed, in combination with some S slicing, to
    // simulate the 'y' flag.
    var splitter = new C(SUPPORTS_Y ? rx : '^(?:' + rx.source + ')', flags);
    var lim = limit === undefined ? MAX_UINT32 : limit >>> 0;
    if (lim === 0) return [];
    if (S.length === 0) return callRegExpExec(splitter, S) === null ? [S] : [];
    var p = 0;
    var q = 0;
    var A = [];
    while (q < S.length) {
      splitter.lastIndex = SUPPORTS_Y ? q : 0;
      var z = callRegExpExec(splitter, SUPPORTS_Y ? S : S.slice(q));
      var e;
      if (z === null || (e = $min(toLength(splitter.lastIndex + (SUPPORTS_Y ? 0 : q)), S.length)) === p) {
        q = advanceStringIndex(S, q, unicodeMatching);
      } else {
        A.push(S.slice(p, q));
        if (A.length === lim) return A;
        for (var i = 1; i <= z.length - 1; i++) {
          A.push(z[i]);
          if (A.length === lim) return A;
        }
        q = p = e;
      }
    }
    A.push(S.slice(p));
    return A;
  }];
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.regexp.to-string.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.regexp.to-string.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


__webpack_require__(/*! ./es6.regexp.flags */ "./node_modules/core-js/modules/es6.regexp.flags.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var $flags = __webpack_require__(/*! ./_flags */ "./node_modules/core-js/modules/_flags.js");
var DESCRIPTORS = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js");
var TO_STRING = 'toString';
var $toString = /./[TO_STRING];
var define = function define(fn) {
  __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js")(RegExp.prototype, TO_STRING, fn, true);
};

// 21.2.5.14 RegExp.prototype.toString()
if (__webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return $toString.call({
    source: 'a',
    flags: 'b'
  }) != '/a/b';
})) {
  define(function toString() {
    var R = anObject(this);
    return '/'.concat(R.source, '/', 'flags' in R ? R.flags : !DESCRIPTORS && R instanceof RegExp ? $flags.call(R) : undefined);
  });
  // FF44- RegExp#toString has a wrong name
} else if ($toString.name != TO_STRING) {
  define(function toString() {
    return $toString.call(this);
  });
}

/***/ }),

/***/ "./node_modules/core-js/modules/es6.set.js":
/*!*************************************************!*\
  !*** ./node_modules/core-js/modules/es6.set.js ***!
  \*************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var strong = __webpack_require__(/*! ./_collection-strong */ "./node_modules/core-js/modules/_collection-strong.js");
var validate = __webpack_require__(/*! ./_validate-collection */ "./node_modules/core-js/modules/_validate-collection.js");
var SET = 'Set';

// 23.2 Set Objects
module.exports = __webpack_require__(/*! ./_collection */ "./node_modules/core-js/modules/_collection.js")(SET, function (get) {
  return function Set() {
    return get(this, arguments.length > 0 ? arguments[0] : undefined);
  };
}, {
  // 23.2.3.1 Set.prototype.add(value)
  add: function add(value) {
    return strong.def(validate(this, SET), value = value === 0 ? 0 : value, value);
  }
}, strong);

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.anchor.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.anchor.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// B.2.3.2 String.prototype.anchor(name)
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('anchor', function (createHTML) {
  return function anchor(name) {
    return createHTML(this, 'a', 'name', name);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.big.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.big.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// B.2.3.3 String.prototype.big()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('big', function (createHTML) {
  return function big() {
    return createHTML(this, 'big', '', '');
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.blink.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.blink.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// B.2.3.4 String.prototype.blink()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('blink', function (createHTML) {
  return function blink() {
    return createHTML(this, 'blink', '', '');
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.bold.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.bold.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// B.2.3.5 String.prototype.bold()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('bold', function (createHTML) {
  return function bold() {
    return createHTML(this, 'b', '', '');
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.code-point-at.js":
/*!******************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.code-point-at.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $at = __webpack_require__(/*! ./_string-at */ "./node_modules/core-js/modules/_string-at.js")(false);
$export($export.P, 'String', {
  // 21.1.3.3 String.prototype.codePointAt(pos)
  codePointAt: function codePointAt(pos) {
    return $at(this, pos);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.ends-with.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.ends-with.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";
// 21.1.3.6 String.prototype.endsWith(searchString [, endPosition])


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var context = __webpack_require__(/*! ./_string-context */ "./node_modules/core-js/modules/_string-context.js");
var ENDS_WITH = 'endsWith';
var $endsWith = ''[ENDS_WITH];
$export($export.P + $export.F * __webpack_require__(/*! ./_fails-is-regexp */ "./node_modules/core-js/modules/_fails-is-regexp.js")(ENDS_WITH), 'String', {
  endsWith: function endsWith(searchString /* , endPosition = @length */) {
    var that = context(this, searchString, ENDS_WITH);
    var endPosition = arguments.length > 1 ? arguments[1] : undefined;
    var len = toLength(that.length);
    var end = endPosition === undefined ? len : Math.min(toLength(endPosition), len);
    var search = String(searchString);
    return $endsWith ? $endsWith.call(that, search, end) : that.slice(end - search.length, end) === search;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.fixed.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.fixed.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// B.2.3.6 String.prototype.fixed()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('fixed', function (createHTML) {
  return function fixed() {
    return createHTML(this, 'tt', '', '');
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.fontcolor.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.fontcolor.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// B.2.3.7 String.prototype.fontcolor(color)
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('fontcolor', function (createHTML) {
  return function fontcolor(color) {
    return createHTML(this, 'font', 'color', color);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.fontsize.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.fontsize.js ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// B.2.3.8 String.prototype.fontsize(size)
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('fontsize', function (createHTML) {
  return function fontsize(size) {
    return createHTML(this, 'font', 'size', size);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.from-code-point.js":
/*!********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.from-code-point.js ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toAbsoluteIndex = __webpack_require__(/*! ./_to-absolute-index */ "./node_modules/core-js/modules/_to-absolute-index.js");
var fromCharCode = String.fromCharCode;
var $fromCodePoint = String.fromCodePoint;

// length should be 1, old FF problem
$export($export.S + $export.F * (!!$fromCodePoint && $fromCodePoint.length != 1), 'String', {
  // 21.1.2.2 String.fromCodePoint(...codePoints)
  fromCodePoint: function fromCodePoint(x) {
    // eslint-disable-line no-unused-vars
    var res = [];
    var aLen = arguments.length;
    var i = 0;
    var code;
    while (aLen > i) {
      code = +arguments[i++];
      if (toAbsoluteIndex(code, 0x10ffff) !== code) throw RangeError(code + ' is not a valid code point');
      res.push(code < 0x10000 ? fromCharCode(code) : fromCharCode(((code -= 0x10000) >> 10) + 0xd800, code % 0x400 + 0xdc00));
    }
    return res.join('');
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.includes.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.includes.js ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";
// 21.1.3.7 String.prototype.includes(searchString, position = 0)


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var context = __webpack_require__(/*! ./_string-context */ "./node_modules/core-js/modules/_string-context.js");
var INCLUDES = 'includes';
$export($export.P + $export.F * __webpack_require__(/*! ./_fails-is-regexp */ "./node_modules/core-js/modules/_fails-is-regexp.js")(INCLUDES), 'String', {
  includes: function includes(searchString /* , position = 0 */) {
    return !!~context(this, searchString, INCLUDES).indexOf(searchString, arguments.length > 1 ? arguments[1] : undefined);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.italics.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.italics.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// B.2.3.9 String.prototype.italics()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('italics', function (createHTML) {
  return function italics() {
    return createHTML(this, 'i', '', '');
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.iterator.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.iterator.js ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $at = __webpack_require__(/*! ./_string-at */ "./node_modules/core-js/modules/_string-at.js")(true);

// 21.1.3.27 String.prototype[@@iterator]()
__webpack_require__(/*! ./_iter-define */ "./node_modules/core-js/modules/_iter-define.js")(String, 'String', function (iterated) {
  this._t = String(iterated); // target
  this._i = 0; // next index
  // 21.1.5.2.1 %StringIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var index = this._i;
  var point;
  if (index >= O.length) return {
    value: undefined,
    done: true
  };
  point = $at(O, index);
  this._i += point.length;
  return {
    value: point,
    done: false
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.link.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.link.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// B.2.3.10 String.prototype.link(url)
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('link', function (createHTML) {
  return function link(url) {
    return createHTML(this, 'a', 'href', url);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.raw.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.raw.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
$export($export.S, 'String', {
  // 21.1.2.4 String.raw(callSite, ...substitutions)
  raw: function raw(callSite) {
    var tpl = toIObject(callSite.raw);
    var len = toLength(tpl.length);
    var aLen = arguments.length;
    var res = [];
    var i = 0;
    while (len > i) {
      res.push(String(tpl[i++]));
      if (i < aLen) res.push(String(arguments[i]));
    }
    return res.join('');
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.repeat.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.repeat.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.P, 'String', {
  // 21.1.3.13 String.prototype.repeat(count)
  repeat: __webpack_require__(/*! ./_string-repeat */ "./node_modules/core-js/modules/_string-repeat.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.small.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.small.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// B.2.3.11 String.prototype.small()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('small', function (createHTML) {
  return function small() {
    return createHTML(this, 'small', '', '');
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.starts-with.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.starts-with.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";
// 21.1.3.18 String.prototype.startsWith(searchString [, position ])


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var context = __webpack_require__(/*! ./_string-context */ "./node_modules/core-js/modules/_string-context.js");
var STARTS_WITH = 'startsWith';
var $startsWith = ''[STARTS_WITH];
$export($export.P + $export.F * __webpack_require__(/*! ./_fails-is-regexp */ "./node_modules/core-js/modules/_fails-is-regexp.js")(STARTS_WITH), 'String', {
  startsWith: function startsWith(searchString /* , position = 0 */) {
    var that = context(this, searchString, STARTS_WITH);
    var index = toLength(Math.min(arguments.length > 1 ? arguments[1] : undefined, that.length));
    var search = String(searchString);
    return $startsWith ? $startsWith.call(that, search, index) : that.slice(index, index + search.length) === search;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.strike.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.strike.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// B.2.3.12 String.prototype.strike()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('strike', function (createHTML) {
  return function strike() {
    return createHTML(this, 'strike', '', '');
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.sub.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.sub.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// B.2.3.13 String.prototype.sub()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('sub', function (createHTML) {
  return function sub() {
    return createHTML(this, 'sub', '', '');
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.sup.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.sup.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// B.2.3.14 String.prototype.sup()
__webpack_require__(/*! ./_string-html */ "./node_modules/core-js/modules/_string-html.js")('sup', function (createHTML) {
  return function sup() {
    return createHTML(this, 'sup', '', '');
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.string.trim.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es6.string.trim.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// 21.1.3.25 String.prototype.trim()
__webpack_require__(/*! ./_string-trim */ "./node_modules/core-js/modules/_string-trim.js")('trim', function ($trim) {
  return function trim() {
    return $trim(this, 3);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.symbol.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/es6.symbol.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// ECMAScript 6 symbols shim
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var has = __webpack_require__(/*! ./_has */ "./node_modules/core-js/modules/_has.js");
var DESCRIPTORS = __webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var META = (__webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js").KEY);
var $fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var shared = __webpack_require__(/*! ./_shared */ "./node_modules/core-js/modules/_shared.js");
var setToStringTag = __webpack_require__(/*! ./_set-to-string-tag */ "./node_modules/core-js/modules/_set-to-string-tag.js");
var uid = __webpack_require__(/*! ./_uid */ "./node_modules/core-js/modules/_uid.js");
var wks = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js");
var wksExt = __webpack_require__(/*! ./_wks-ext */ "./node_modules/core-js/modules/_wks-ext.js");
var wksDefine = __webpack_require__(/*! ./_wks-define */ "./node_modules/core-js/modules/_wks-define.js");
var enumKeys = __webpack_require__(/*! ./_enum-keys */ "./node_modules/core-js/modules/_enum-keys.js");
var isArray = __webpack_require__(/*! ./_is-array */ "./node_modules/core-js/modules/_is-array.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
var createDesc = __webpack_require__(/*! ./_property-desc */ "./node_modules/core-js/modules/_property-desc.js");
var _create = __webpack_require__(/*! ./_object-create */ "./node_modules/core-js/modules/_object-create.js");
var gOPNExt = __webpack_require__(/*! ./_object-gopn-ext */ "./node_modules/core-js/modules/_object-gopn-ext.js");
var $GOPD = __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js");
var $GOPS = __webpack_require__(/*! ./_object-gops */ "./node_modules/core-js/modules/_object-gops.js");
var $DP = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");
var $keys = __webpack_require__(/*! ./_object-keys */ "./node_modules/core-js/modules/_object-keys.js");
var gOPD = $GOPD.f;
var dP = $DP.f;
var gOPN = gOPNExt.f;
var $Symbol = global.Symbol;
var $JSON = global.JSON;
var _stringify = $JSON && $JSON.stringify;
var PROTOTYPE = 'prototype';
var HIDDEN = wks('_hidden');
var TO_PRIMITIVE = wks('toPrimitive');
var isEnum = {}.propertyIsEnumerable;
var SymbolRegistry = shared('symbol-registry');
var AllSymbols = shared('symbols');
var OPSymbols = shared('op-symbols');
var ObjectProto = Object[PROTOTYPE];
var USE_NATIVE = typeof $Symbol == 'function' && !!$GOPS.f;
var QObject = global.QObject;
// Don't use setters in Qt Script, https://github.com/zloirock/core-js/issues/173
var setter = !QObject || !QObject[PROTOTYPE] || !QObject[PROTOTYPE].findChild;

// fallback for old Android, https://code.google.com/p/v8/issues/detail?id=687
var setSymbolDesc = DESCRIPTORS && $fails(function () {
  return _create(dP({}, 'a', {
    get: function get() {
      return dP(this, 'a', {
        value: 7
      }).a;
    }
  })).a != 7;
}) ? function (it, key, D) {
  var protoDesc = gOPD(ObjectProto, key);
  if (protoDesc) delete ObjectProto[key];
  dP(it, key, D);
  if (protoDesc && it !== ObjectProto) dP(ObjectProto, key, protoDesc);
} : dP;
var wrap = function wrap(tag) {
  var sym = AllSymbols[tag] = _create($Symbol[PROTOTYPE]);
  sym._k = tag;
  return sym;
};
var isSymbol = USE_NATIVE && _typeof($Symbol.iterator) == 'symbol' ? function (it) {
  return _typeof(it) == 'symbol';
} : function (it) {
  return it instanceof $Symbol;
};
var $defineProperty = function defineProperty(it, key, D) {
  if (it === ObjectProto) $defineProperty(OPSymbols, key, D);
  anObject(it);
  key = toPrimitive(key, true);
  anObject(D);
  if (has(AllSymbols, key)) {
    if (!D.enumerable) {
      if (!has(it, HIDDEN)) dP(it, HIDDEN, createDesc(1, {}));
      it[HIDDEN][key] = true;
    } else {
      if (has(it, HIDDEN) && it[HIDDEN][key]) it[HIDDEN][key] = false;
      D = _create(D, {
        enumerable: createDesc(0, false)
      });
    }
    return setSymbolDesc(it, key, D);
  }
  return dP(it, key, D);
};
var $defineProperties = function defineProperties(it, P) {
  anObject(it);
  var keys = enumKeys(P = toIObject(P));
  var i = 0;
  var l = keys.length;
  var key;
  while (l > i) $defineProperty(it, key = keys[i++], P[key]);
  return it;
};
var $create = function create(it, P) {
  return P === undefined ? _create(it) : $defineProperties(_create(it), P);
};
var $propertyIsEnumerable = function propertyIsEnumerable(key) {
  var E = isEnum.call(this, key = toPrimitive(key, true));
  if (this === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return false;
  return E || !has(this, key) || !has(AllSymbols, key) || has(this, HIDDEN) && this[HIDDEN][key] ? E : true;
};
var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(it, key) {
  it = toIObject(it);
  key = toPrimitive(key, true);
  if (it === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return;
  var D = gOPD(it, key);
  if (D && has(AllSymbols, key) && !(has(it, HIDDEN) && it[HIDDEN][key])) D.enumerable = true;
  return D;
};
var $getOwnPropertyNames = function getOwnPropertyNames(it) {
  var names = gOPN(toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (!has(AllSymbols, key = names[i++]) && key != HIDDEN && key != META) result.push(key);
  }
  return result;
};
var $getOwnPropertySymbols = function getOwnPropertySymbols(it) {
  var IS_OP = it === ObjectProto;
  var names = gOPN(IS_OP ? OPSymbols : toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (has(AllSymbols, key = names[i++]) && (IS_OP ? has(ObjectProto, key) : true)) result.push(AllSymbols[key]);
  }
  return result;
};

// 19.4.1.1 Symbol([description])
if (!USE_NATIVE) {
  $Symbol = function _Symbol() {
    if (this instanceof $Symbol) throw TypeError('Symbol is not a constructor!');
    var tag = uid(arguments.length > 0 ? arguments[0] : undefined);
    var _$set = function $set(value) {
      if (this === ObjectProto) _$set.call(OPSymbols, value);
      if (has(this, HIDDEN) && has(this[HIDDEN], tag)) this[HIDDEN][tag] = false;
      setSymbolDesc(this, tag, createDesc(1, value));
    };
    if (DESCRIPTORS && setter) setSymbolDesc(ObjectProto, tag, {
      configurable: true,
      set: _$set
    });
    return wrap(tag);
  };
  redefine($Symbol[PROTOTYPE], 'toString', function toString() {
    return this._k;
  });
  $GOPD.f = $getOwnPropertyDescriptor;
  $DP.f = $defineProperty;
  (__webpack_require__(/*! ./_object-gopn */ "./node_modules/core-js/modules/_object-gopn.js").f) = gOPNExt.f = $getOwnPropertyNames;
  (__webpack_require__(/*! ./_object-pie */ "./node_modules/core-js/modules/_object-pie.js").f) = $propertyIsEnumerable;
  $GOPS.f = $getOwnPropertySymbols;
  if (DESCRIPTORS && !__webpack_require__(/*! ./_library */ "./node_modules/core-js/modules/_library.js")) {
    redefine(ObjectProto, 'propertyIsEnumerable', $propertyIsEnumerable, true);
  }
  wksExt.f = function (name) {
    return wrap(wks(name));
  };
}
$export($export.G + $export.W + $export.F * !USE_NATIVE, {
  Symbol: $Symbol
});
for (var es6Symbols =
  // 19.4.2.2, 19.4.2.3, 19.4.2.4, 19.4.2.6, 19.4.2.8, 19.4.2.9, 19.4.2.10, 19.4.2.11, 19.4.2.12, 19.4.2.13, 19.4.2.14
  'hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables'.split(','), j = 0; es6Symbols.length > j;) wks(es6Symbols[j++]);
for (var wellKnownSymbols = $keys(wks.store), k = 0; wellKnownSymbols.length > k;) wksDefine(wellKnownSymbols[k++]);
$export($export.S + $export.F * !USE_NATIVE, 'Symbol', {
  // 19.4.2.1 Symbol.for(key)
  'for': function _for(key) {
    return has(SymbolRegistry, key += '') ? SymbolRegistry[key] : SymbolRegistry[key] = $Symbol(key);
  },
  // 19.4.2.5 Symbol.keyFor(sym)
  keyFor: function keyFor(sym) {
    if (!isSymbol(sym)) throw TypeError(sym + ' is not a symbol!');
    for (var key in SymbolRegistry) if (SymbolRegistry[key] === sym) return key;
  },
  useSetter: function useSetter() {
    setter = true;
  },
  useSimple: function useSimple() {
    setter = false;
  }
});
$export($export.S + $export.F * !USE_NATIVE, 'Object', {
  // 19.1.2.2 Object.create(O [, Properties])
  create: $create,
  // 19.1.2.4 Object.defineProperty(O, P, Attributes)
  defineProperty: $defineProperty,
  // 19.1.2.3 Object.defineProperties(O, Properties)
  defineProperties: $defineProperties,
  // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
  getOwnPropertyDescriptor: $getOwnPropertyDescriptor,
  // 19.1.2.7 Object.getOwnPropertyNames(O)
  getOwnPropertyNames: $getOwnPropertyNames,
  // 19.1.2.8 Object.getOwnPropertySymbols(O)
  getOwnPropertySymbols: $getOwnPropertySymbols
});

// Chrome 38 and 39 `Object.getOwnPropertySymbols` fails on primitives
// https://bugs.chromium.org/p/v8/issues/detail?id=3443
var FAILS_ON_PRIMITIVES = $fails(function () {
  $GOPS.f(1);
});
$export($export.S + $export.F * FAILS_ON_PRIMITIVES, 'Object', {
  getOwnPropertySymbols: function getOwnPropertySymbols(it) {
    return $GOPS.f(toObject(it));
  }
});

// 24.3.2 JSON.stringify(value [, replacer [, space]])
$JSON && $export($export.S + $export.F * (!USE_NATIVE || $fails(function () {
  var S = $Symbol();
  // MS Edge converts symbol values to JSON as {}
  // WebKit converts symbol values to JSON as null
  // V8 throws on boxed symbols
  return _stringify([S]) != '[null]' || _stringify({
    a: S
  }) != '{}' || _stringify(Object(S)) != '{}';
})), 'JSON', {
  stringify: function stringify(it) {
    var args = [it];
    var i = 1;
    var replacer, $replacer;
    while (arguments.length > i) args.push(arguments[i++]);
    $replacer = replacer = args[1];
    if (!isObject(replacer) && it === undefined || isSymbol(it)) return; // IE8 returns string on undefined
    if (!isArray(replacer)) replacer = function replacer(key, value) {
      if (typeof $replacer == 'function') value = $replacer.call(this, key, value);
      if (!isSymbol(value)) return value;
    };
    args[1] = replacer;
    return _stringify.apply($JSON, args);
  }
});

// 19.4.3.4 Symbol.prototype[@@toPrimitive](hint)
$Symbol[PROTOTYPE][TO_PRIMITIVE] || __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js")($Symbol[PROTOTYPE], TO_PRIMITIVE, $Symbol[PROTOTYPE].valueOf);
// 19.4.3.5 Symbol.prototype[@@toStringTag]
setToStringTag($Symbol, 'Symbol');
// 20.2.1.9 Math[@@toStringTag]
setToStringTag(Math, 'Math', true);
// 24.3.3 JSON[@@toStringTag]
setToStringTag(global.JSON, 'JSON', true);

/***/ }),

/***/ "./node_modules/core-js/modules/es6.typed.array-buffer.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.typed.array-buffer.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $typed = __webpack_require__(/*! ./_typed */ "./node_modules/core-js/modules/_typed.js");
var buffer = __webpack_require__(/*! ./_typed-buffer */ "./node_modules/core-js/modules/_typed-buffer.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var toAbsoluteIndex = __webpack_require__(/*! ./_to-absolute-index */ "./node_modules/core-js/modules/_to-absolute-index.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var ArrayBuffer = (__webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").ArrayBuffer);
var speciesConstructor = __webpack_require__(/*! ./_species-constructor */ "./node_modules/core-js/modules/_species-constructor.js");
var $ArrayBuffer = buffer.ArrayBuffer;
var $DataView = buffer.DataView;
var $isView = $typed.ABV && ArrayBuffer.isView;
var $slice = $ArrayBuffer.prototype.slice;
var VIEW = $typed.VIEW;
var ARRAY_BUFFER = 'ArrayBuffer';
$export($export.G + $export.W + $export.F * (ArrayBuffer !== $ArrayBuffer), {
  ArrayBuffer: $ArrayBuffer
});
$export($export.S + $export.F * !$typed.CONSTR, ARRAY_BUFFER, {
  // 24.1.3.1 ArrayBuffer.isView(arg)
  isView: function isView(it) {
    return $isView && $isView(it) || isObject(it) && VIEW in it;
  }
});
$export($export.P + $export.U + $export.F * __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js")(function () {
  return !new $ArrayBuffer(2).slice(1, undefined).byteLength;
}), ARRAY_BUFFER, {
  // 24.1.4.3 ArrayBuffer.prototype.slice(start, end)
  slice: function slice(start, end) {
    if ($slice !== undefined && end === undefined) return $slice.call(anObject(this), start); // FF fix
    var len = anObject(this).byteLength;
    var first = toAbsoluteIndex(start, len);
    var fin = toAbsoluteIndex(end === undefined ? len : end, len);
    var result = new (speciesConstructor(this, $ArrayBuffer))(toLength(fin - first));
    var viewS = new $DataView(this);
    var viewT = new $DataView(result);
    var index = 0;
    while (first < fin) {
      viewT.setUint8(index++, viewS.getUint8(first++));
    }
    return result;
  }
});
__webpack_require__(/*! ./_set-species */ "./node_modules/core-js/modules/_set-species.js")(ARRAY_BUFFER);

/***/ }),

/***/ "./node_modules/core-js/modules/es6.typed.data-view.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.typed.data-view.js ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.G + $export.W + $export.F * !(__webpack_require__(/*! ./_typed */ "./node_modules/core-js/modules/_typed.js").ABV), {
  DataView: (__webpack_require__(/*! ./_typed-buffer */ "./node_modules/core-js/modules/_typed-buffer.js").DataView)
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.typed.float32-array.js":
/*!*****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.typed.float32-array.js ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ./_typed-array */ "./node_modules/core-js/modules/_typed-array.js")('Float32', 4, function (init) {
  return function Float32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.typed.float64-array.js":
/*!*****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.typed.float64-array.js ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ./_typed-array */ "./node_modules/core-js/modules/_typed-array.js")('Float64', 8, function (init) {
  return function Float64Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.typed.int16-array.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.typed.int16-array.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ./_typed-array */ "./node_modules/core-js/modules/_typed-array.js")('Int16', 2, function (init) {
  return function Int16Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.typed.int32-array.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.typed.int32-array.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ./_typed-array */ "./node_modules/core-js/modules/_typed-array.js")('Int32', 4, function (init) {
  return function Int32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.typed.int8-array.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.typed.int8-array.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ./_typed-array */ "./node_modules/core-js/modules/_typed-array.js")('Int8', 1, function (init) {
  return function Int8Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.typed.uint16-array.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.typed.uint16-array.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ./_typed-array */ "./node_modules/core-js/modules/_typed-array.js")('Uint16', 2, function (init) {
  return function Uint16Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.typed.uint32-array.js":
/*!****************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.typed.uint32-array.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ./_typed-array */ "./node_modules/core-js/modules/_typed-array.js")('Uint32', 4, function (init) {
  return function Uint32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.typed.uint8-array.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.typed.uint8-array.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ./_typed-array */ "./node_modules/core-js/modules/_typed-array.js")('Uint8', 1, function (init) {
  return function Uint8Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ "./node_modules/core-js/modules/es6.typed.uint8-clamped-array.js":
/*!***********************************************************************!*\
  !*** ./node_modules/core-js/modules/es6.typed.uint8-clamped-array.js ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ./_typed-array */ "./node_modules/core-js/modules/_typed-array.js")('Uint8', 1, function (init) {
  return function Uint8ClampedArray(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
}, true);

/***/ }),

/***/ "./node_modules/core-js/modules/es6.weak-map.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.weak-map.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var each = __webpack_require__(/*! ./_array-methods */ "./node_modules/core-js/modules/_array-methods.js")(0);
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var meta = __webpack_require__(/*! ./_meta */ "./node_modules/core-js/modules/_meta.js");
var assign = __webpack_require__(/*! ./_object-assign */ "./node_modules/core-js/modules/_object-assign.js");
var weak = __webpack_require__(/*! ./_collection-weak */ "./node_modules/core-js/modules/_collection-weak.js");
var isObject = __webpack_require__(/*! ./_is-object */ "./node_modules/core-js/modules/_is-object.js");
var validate = __webpack_require__(/*! ./_validate-collection */ "./node_modules/core-js/modules/_validate-collection.js");
var NATIVE_WEAK_MAP = __webpack_require__(/*! ./_validate-collection */ "./node_modules/core-js/modules/_validate-collection.js");
var IS_IE11 = !global.ActiveXObject && 'ActiveXObject' in global;
var WEAK_MAP = 'WeakMap';
var getWeak = meta.getWeak;
var isExtensible = Object.isExtensible;
var uncaughtFrozenStore = weak.ufstore;
var InternalMap;
var wrapper = function wrapper(get) {
  return function WeakMap() {
    return get(this, arguments.length > 0 ? arguments[0] : undefined);
  };
};
var methods = {
  // 23.3.3.3 WeakMap.prototype.get(key)
  get: function get(key) {
    if (isObject(key)) {
      var data = getWeak(key);
      if (data === true) return uncaughtFrozenStore(validate(this, WEAK_MAP)).get(key);
      return data ? data[this._i] : undefined;
    }
  },
  // 23.3.3.5 WeakMap.prototype.set(key, value)
  set: function set(key, value) {
    return weak.def(validate(this, WEAK_MAP), key, value);
  }
};

// 23.3 WeakMap Objects
var $WeakMap = module.exports = __webpack_require__(/*! ./_collection */ "./node_modules/core-js/modules/_collection.js")(WEAK_MAP, wrapper, methods, weak, true, true);

// IE11 WeakMap frozen keys fix
if (NATIVE_WEAK_MAP && IS_IE11) {
  InternalMap = weak.getConstructor(wrapper, WEAK_MAP);
  assign(InternalMap.prototype, methods);
  meta.NEED = true;
  each(['delete', 'has', 'get', 'set'], function (key) {
    var proto = $WeakMap.prototype;
    var method = proto[key];
    redefine(proto, key, function (a, b) {
      // store frozen objects on internal weakmap shim
      if (isObject(a) && !isExtensible(a)) {
        if (!this._f) this._f = new InternalMap();
        var result = this._f[key](a, b);
        return key == 'set' ? this : result;
        // store all the rest on native weakmap
      }
      return method.call(this, a, b);
    });
  });
}

/***/ }),

/***/ "./node_modules/core-js/modules/es6.weak-set.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es6.weak-set.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var weak = __webpack_require__(/*! ./_collection-weak */ "./node_modules/core-js/modules/_collection-weak.js");
var validate = __webpack_require__(/*! ./_validate-collection */ "./node_modules/core-js/modules/_validate-collection.js");
var WEAK_SET = 'WeakSet';

// 23.4 WeakSet Objects
__webpack_require__(/*! ./_collection */ "./node_modules/core-js/modules/_collection.js")(WEAK_SET, function (get) {
  return function WeakSet() {
    return get(this, arguments.length > 0 ? arguments[0] : undefined);
  };
}, {
  // 23.4.3.1 WeakSet.prototype.add(value)
  add: function add(value) {
    return weak.def(validate(this, WEAK_SET), value, true);
  }
}, weak, false, true);

/***/ }),

/***/ "./node_modules/core-js/modules/es7.array.flat-map.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.array.flat-map.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://tc39.github.io/proposal-flatMap/#sec-Array.prototype.flatMap
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var flattenIntoArray = __webpack_require__(/*! ./_flatten-into-array */ "./node_modules/core-js/modules/_flatten-into-array.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var arraySpeciesCreate = __webpack_require__(/*! ./_array-species-create */ "./node_modules/core-js/modules/_array-species-create.js");
$export($export.P, 'Array', {
  flatMap: function flatMap(callbackfn /* , thisArg */) {
    var O = toObject(this);
    var sourceLen, A;
    aFunction(callbackfn);
    sourceLen = toLength(O.length);
    A = arraySpeciesCreate(O, 0);
    flattenIntoArray(A, O, O, sourceLen, 0, 1, callbackfn, arguments[1]);
    return A;
  }
});
__webpack_require__(/*! ./_add-to-unscopables */ "./node_modules/core-js/modules/_add-to-unscopables.js")('flatMap');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.array.flatten.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.array.flatten.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://tc39.github.io/proposal-flatMap/#sec-Array.prototype.flatten
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var flattenIntoArray = __webpack_require__(/*! ./_flatten-into-array */ "./node_modules/core-js/modules/_flatten-into-array.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var toInteger = __webpack_require__(/*! ./_to-integer */ "./node_modules/core-js/modules/_to-integer.js");
var arraySpeciesCreate = __webpack_require__(/*! ./_array-species-create */ "./node_modules/core-js/modules/_array-species-create.js");
$export($export.P, 'Array', {
  flatten: function flatten(/* depthArg = 1 */
  ) {
    var depthArg = arguments[0];
    var O = toObject(this);
    var sourceLen = toLength(O.length);
    var A = arraySpeciesCreate(O, 0);
    flattenIntoArray(A, O, O, sourceLen, 0, depthArg === undefined ? 1 : toInteger(depthArg));
    return A;
  }
});
__webpack_require__(/*! ./_add-to-unscopables */ "./node_modules/core-js/modules/_add-to-unscopables.js")('flatten');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.array.includes.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.array.includes.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://github.com/tc39/Array.prototype.includes
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $includes = __webpack_require__(/*! ./_array-includes */ "./node_modules/core-js/modules/_array-includes.js")(true);
$export($export.P, 'Array', {
  includes: function includes(el /* , fromIndex = 0 */) {
    return $includes(this, el, arguments.length > 1 ? arguments[1] : undefined);
  }
});
__webpack_require__(/*! ./_add-to-unscopables */ "./node_modules/core-js/modules/_add-to-unscopables.js")('includes');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.asap.js":
/*!**************************************************!*\
  !*** ./node_modules/core-js/modules/es7.asap.js ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://github.com/rwaldron/tc39-notes/blob/master/es6/2014-09/sept-25.md#510-globalasap-for-enqueuing-a-microtask
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var microtask = __webpack_require__(/*! ./_microtask */ "./node_modules/core-js/modules/_microtask.js")();
var process = (__webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js").process);
var isNode = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js")(process) == 'process';
$export($export.G, {
  asap: function asap(fn) {
    var domain = isNode && process.domain;
    microtask(domain ? domain.bind(fn) : fn);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.error.is-error.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.error.is-error.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://github.com/ljharb/proposal-is-error
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var cof = __webpack_require__(/*! ./_cof */ "./node_modules/core-js/modules/_cof.js");
$export($export.S, 'Error', {
  isError: function isError(it) {
    return cof(it) === 'Error';
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.global.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/es7.global.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://github.com/tc39/proposal-global
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.G, {
  global: __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.map.from.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es7.map.from.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-map.from
__webpack_require__(/*! ./_set-collection-from */ "./node_modules/core-js/modules/_set-collection-from.js")('Map');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.map.of.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/es7.map.of.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-map.of
__webpack_require__(/*! ./_set-collection-of */ "./node_modules/core-js/modules/_set-collection-of.js")('Map');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.map.to-json.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.map.to-json.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.P + $export.R, 'Map', {
  toJSON: __webpack_require__(/*! ./_collection-to-json */ "./node_modules/core-js/modules/_collection-to-json.js")('Map')
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.math.clamp.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.math.clamp.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  clamp: function clamp(x, lower, upper) {
    return Math.min(upper, Math.max(lower, x));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.math.deg-per-rad.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.math.deg-per-rad.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  DEG_PER_RAD: Math.PI / 180
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.math.degrees.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.math.degrees.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var RAD_PER_DEG = 180 / Math.PI;
$export($export.S, 'Math', {
  degrees: function degrees(radians) {
    return radians * RAD_PER_DEG;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.math.fscale.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.math.fscale.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var scale = __webpack_require__(/*! ./_math-scale */ "./node_modules/core-js/modules/_math-scale.js");
var fround = __webpack_require__(/*! ./_math-fround */ "./node_modules/core-js/modules/_math-fround.js");
$export($export.S, 'Math', {
  fscale: function fscale(x, inLow, inHigh, outLow, outHigh) {
    return fround(scale(x, inLow, inHigh, outLow, outHigh));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.math.iaddh.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.math.iaddh.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  iaddh: function iaddh(x0, x1, y0, y1) {
    var $x0 = x0 >>> 0;
    var $x1 = x1 >>> 0;
    var $y0 = y0 >>> 0;
    return $x1 + (y1 >>> 0) + (($x0 & $y0 | ($x0 | $y0) & ~($x0 + $y0 >>> 0)) >>> 31) | 0;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.math.imulh.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.math.imulh.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  imulh: function imulh(u, v) {
    var UINT16 = 0xffff;
    var $u = +u;
    var $v = +v;
    var u0 = $u & UINT16;
    var v0 = $v & UINT16;
    var u1 = $u >> 16;
    var v1 = $v >> 16;
    var t = (u1 * v0 >>> 0) + (u0 * v0 >>> 16);
    return u1 * v1 + (t >> 16) + ((u0 * v1 >>> 0) + (t & UINT16) >> 16);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.math.isubh.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.math.isubh.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  isubh: function isubh(x0, x1, y0, y1) {
    var $x0 = x0 >>> 0;
    var $x1 = x1 >>> 0;
    var $y0 = y0 >>> 0;
    return $x1 - (y1 >>> 0) - ((~$x0 & $y0 | ~($x0 ^ $y0) & $x0 - $y0 >>> 0) >>> 31) | 0;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.math.rad-per-deg.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.math.rad-per-deg.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  RAD_PER_DEG: 180 / Math.PI
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.math.radians.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.math.radians.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var DEG_PER_RAD = Math.PI / 180;
$export($export.S, 'Math', {
  radians: function radians(degrees) {
    return degrees * DEG_PER_RAD;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.math.scale.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.math.scale.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  scale: __webpack_require__(/*! ./_math-scale */ "./node_modules/core-js/modules/_math-scale.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.math.signbit.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.math.signbit.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// http://jfbastien.github.io/papers/Math.signbit.html
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  signbit: function signbit(x) {
    // eslint-disable-next-line no-self-compare
    return (x = +x) != x ? x : x == 0 ? 1 / x == Infinity : x > 0;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.math.umulh.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.math.umulh.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'Math', {
  umulh: function umulh(u, v) {
    var UINT16 = 0xffff;
    var $u = +u;
    var $v = +v;
    var u0 = $u & UINT16;
    var v0 = $v & UINT16;
    var u1 = $u >>> 16;
    var v1 = $v >>> 16;
    var t = (u1 * v0 >>> 0) + (u0 * v0 >>> 16);
    return u1 * v1 + (t >>> 16) + ((u0 * v1 >>> 0) + (t & UINT16) >>> 16);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.object.define-getter.js":
/*!******************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.object.define-getter.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var $defineProperty = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");

// B.2.2.2 Object.prototype.__defineGetter__(P, getter)
__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") && $export($export.P + __webpack_require__(/*! ./_object-forced-pam */ "./node_modules/core-js/modules/_object-forced-pam.js"), 'Object', {
  __defineGetter__: function __defineGetter__(P, getter) {
    $defineProperty.f(toObject(this), P, {
      get: aFunction(getter),
      enumerable: true,
      configurable: true
    });
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.object.define-setter.js":
/*!******************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.object.define-setter.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var $defineProperty = __webpack_require__(/*! ./_object-dp */ "./node_modules/core-js/modules/_object-dp.js");

// B.2.2.3 Object.prototype.__defineSetter__(P, setter)
__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") && $export($export.P + __webpack_require__(/*! ./_object-forced-pam */ "./node_modules/core-js/modules/_object-forced-pam.js"), 'Object', {
  __defineSetter__: function __defineSetter__(P, setter) {
    $defineProperty.f(toObject(this), P, {
      set: aFunction(setter),
      enumerable: true,
      configurable: true
    });
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.object.entries.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.object.entries.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://github.com/tc39/proposal-object-values-entries
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $entries = __webpack_require__(/*! ./_object-to-array */ "./node_modules/core-js/modules/_object-to-array.js")(true);
$export($export.S, 'Object', {
  entries: function entries(it) {
    return $entries(it);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.object.get-own-property-descriptors.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.object.get-own-property-descriptors.js ***!
  \*********************************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://github.com/tc39/proposal-object-getownpropertydescriptors
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var ownKeys = __webpack_require__(/*! ./_own-keys */ "./node_modules/core-js/modules/_own-keys.js");
var toIObject = __webpack_require__(/*! ./_to-iobject */ "./node_modules/core-js/modules/_to-iobject.js");
var gOPD = __webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js");
var createProperty = __webpack_require__(/*! ./_create-property */ "./node_modules/core-js/modules/_create-property.js");
$export($export.S, 'Object', {
  getOwnPropertyDescriptors: function getOwnPropertyDescriptors(object) {
    var O = toIObject(object);
    var getDesc = gOPD.f;
    var keys = ownKeys(O);
    var result = {};
    var i = 0;
    var key, desc;
    while (keys.length > i) {
      desc = getDesc(O, key = keys[i++]);
      if (desc !== undefined) createProperty(result, key, desc);
    }
    return result;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.object.lookup-getter.js":
/*!******************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.object.lookup-getter.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var getOwnPropertyDescriptor = (__webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js").f);

// B.2.2.4 Object.prototype.__lookupGetter__(P)
__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") && $export($export.P + __webpack_require__(/*! ./_object-forced-pam */ "./node_modules/core-js/modules/_object-forced-pam.js"), 'Object', {
  __lookupGetter__: function __lookupGetter__(P) {
    var O = toObject(this);
    var K = toPrimitive(P, true);
    var D;
    do {
      if (D = getOwnPropertyDescriptor(O, K)) return D.get;
    } while (O = getPrototypeOf(O));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.object.lookup-setter.js":
/*!******************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.object.lookup-setter.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var toObject = __webpack_require__(/*! ./_to-object */ "./node_modules/core-js/modules/_to-object.js");
var toPrimitive = __webpack_require__(/*! ./_to-primitive */ "./node_modules/core-js/modules/_to-primitive.js");
var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var getOwnPropertyDescriptor = (__webpack_require__(/*! ./_object-gopd */ "./node_modules/core-js/modules/_object-gopd.js").f);

// B.2.2.5 Object.prototype.__lookupSetter__(P)
__webpack_require__(/*! ./_descriptors */ "./node_modules/core-js/modules/_descriptors.js") && $export($export.P + __webpack_require__(/*! ./_object-forced-pam */ "./node_modules/core-js/modules/_object-forced-pam.js"), 'Object', {
  __lookupSetter__: function __lookupSetter__(P) {
    var O = toObject(this);
    var K = toPrimitive(P, true);
    var D;
    do {
      if (D = getOwnPropertyDescriptor(O, K)) return D.set;
    } while (O = getPrototypeOf(O));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.object.values.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.object.values.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://github.com/tc39/proposal-object-values-entries
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $values = __webpack_require__(/*! ./_object-to-array */ "./node_modules/core-js/modules/_object-to-array.js")(false);
$export($export.S, 'Object', {
  values: function values(it) {
    return $values(it);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.observable.js":
/*!********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.observable.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://github.com/zenparsing/es-observable
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var core = __webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js");
var microtask = __webpack_require__(/*! ./_microtask */ "./node_modules/core-js/modules/_microtask.js")();
var OBSERVABLE = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js")('observable');
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var anInstance = __webpack_require__(/*! ./_an-instance */ "./node_modules/core-js/modules/_an-instance.js");
var redefineAll = __webpack_require__(/*! ./_redefine-all */ "./node_modules/core-js/modules/_redefine-all.js");
var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
var forOf = __webpack_require__(/*! ./_for-of */ "./node_modules/core-js/modules/_for-of.js");
var RETURN = forOf.RETURN;
var getMethod = function getMethod(fn) {
  return fn == null ? undefined : aFunction(fn);
};
var cleanupSubscription = function cleanupSubscription(subscription) {
  var cleanup = subscription._c;
  if (cleanup) {
    subscription._c = undefined;
    cleanup();
  }
};
var subscriptionClosed = function subscriptionClosed(subscription) {
  return subscription._o === undefined;
};
var closeSubscription = function closeSubscription(subscription) {
  if (!subscriptionClosed(subscription)) {
    subscription._o = undefined;
    cleanupSubscription(subscription);
  }
};
var Subscription = function Subscription(observer, subscriber) {
  anObject(observer);
  this._c = undefined;
  this._o = observer;
  observer = new SubscriptionObserver(this);
  try {
    var cleanup = subscriber(observer);
    var subscription = cleanup;
    if (cleanup != null) {
      if (typeof cleanup.unsubscribe === 'function') cleanup = function cleanup() {
        subscription.unsubscribe();
      };else aFunction(cleanup);
      this._c = cleanup;
    }
  } catch (e) {
    observer.error(e);
    return;
  }
  if (subscriptionClosed(this)) cleanupSubscription(this);
};
Subscription.prototype = redefineAll({}, {
  unsubscribe: function unsubscribe() {
    closeSubscription(this);
  }
});
var SubscriptionObserver = function SubscriptionObserver(subscription) {
  this._s = subscription;
};
SubscriptionObserver.prototype = redefineAll({}, {
  next: function next(value) {
    var subscription = this._s;
    if (!subscriptionClosed(subscription)) {
      var observer = subscription._o;
      try {
        var m = getMethod(observer.next);
        if (m) return m.call(observer, value);
      } catch (e) {
        try {
          closeSubscription(subscription);
        } finally {
          throw e;
        }
      }
    }
  },
  error: function error(value) {
    var subscription = this._s;
    if (subscriptionClosed(subscription)) throw value;
    var observer = subscription._o;
    subscription._o = undefined;
    try {
      var m = getMethod(observer.error);
      if (!m) throw value;
      value = m.call(observer, value);
    } catch (e) {
      try {
        cleanupSubscription(subscription);
      } finally {
        throw e;
      }
    }
    cleanupSubscription(subscription);
    return value;
  },
  complete: function complete(value) {
    var subscription = this._s;
    if (!subscriptionClosed(subscription)) {
      var observer = subscription._o;
      subscription._o = undefined;
      try {
        var m = getMethod(observer.complete);
        value = m ? m.call(observer, value) : undefined;
      } catch (e) {
        try {
          cleanupSubscription(subscription);
        } finally {
          throw e;
        }
      }
      cleanupSubscription(subscription);
      return value;
    }
  }
});
var $Observable = function Observable(subscriber) {
  anInstance(this, $Observable, 'Observable', '_f')._f = aFunction(subscriber);
};
redefineAll($Observable.prototype, {
  subscribe: function subscribe(observer) {
    return new Subscription(observer, this._f);
  },
  forEach: function forEach(fn) {
    var that = this;
    return new (core.Promise || global.Promise)(function (resolve, reject) {
      aFunction(fn);
      var subscription = that.subscribe({
        next: function next(value) {
          try {
            return fn(value);
          } catch (e) {
            reject(e);
            subscription.unsubscribe();
          }
        },
        error: reject,
        complete: resolve
      });
    });
  }
});
redefineAll($Observable, {
  from: function from(x) {
    var C = typeof this === 'function' ? this : $Observable;
    var method = getMethod(anObject(x)[OBSERVABLE]);
    if (method) {
      var observable = anObject(method.call(x));
      return observable.constructor === C ? observable : new C(function (observer) {
        return observable.subscribe(observer);
      });
    }
    return new C(function (observer) {
      var done = false;
      microtask(function () {
        if (!done) {
          try {
            if (forOf(x, false, function (it) {
              observer.next(it);
              if (done) return RETURN;
            }) === RETURN) return;
          } catch (e) {
            if (done) throw e;
            observer.error(e);
            return;
          }
          observer.complete();
        }
      });
      return function () {
        done = true;
      };
    });
  },
  of: function of() {
    for (var i = 0, l = arguments.length, items = new Array(l); i < l;) items[i] = arguments[i++];
    return new (typeof this === 'function' ? this : $Observable)(function (observer) {
      var done = false;
      microtask(function () {
        if (!done) {
          for (var j = 0; j < items.length; ++j) {
            observer.next(items[j]);
            if (done) return;
          }
          observer.complete();
        }
      });
      return function () {
        done = true;
      };
    });
  }
});
hide($Observable.prototype, OBSERVABLE, function () {
  return this;
});
$export($export.G, {
  Observable: $Observable
});
__webpack_require__(/*! ./_set-species */ "./node_modules/core-js/modules/_set-species.js")('Observable');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.promise.finally.js":
/*!*************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.promise.finally.js ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";
// https://github.com/tc39/proposal-promise-finally


var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var core = __webpack_require__(/*! ./_core */ "./node_modules/core-js/modules/_core.js");
var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var speciesConstructor = __webpack_require__(/*! ./_species-constructor */ "./node_modules/core-js/modules/_species-constructor.js");
var promiseResolve = __webpack_require__(/*! ./_promise-resolve */ "./node_modules/core-js/modules/_promise-resolve.js");
$export($export.P + $export.R, 'Promise', {
  'finally': function _finally(onFinally) {
    var C = speciesConstructor(this, core.Promise || global.Promise);
    var isFunction = typeof onFinally == 'function';
    return this.then(isFunction ? function (x) {
      return promiseResolve(C, onFinally()).then(function () {
        return x;
      });
    } : onFinally, isFunction ? function (e) {
      return promiseResolve(C, onFinally()).then(function () {
        throw e;
      });
    } : onFinally);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.promise.try.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.promise.try.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://github.com/tc39/proposal-promise-try
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var newPromiseCapability = __webpack_require__(/*! ./_new-promise-capability */ "./node_modules/core-js/modules/_new-promise-capability.js");
var perform = __webpack_require__(/*! ./_perform */ "./node_modules/core-js/modules/_perform.js");
$export($export.S, 'Promise', {
  'try': function _try(callbackfn) {
    var promiseCapability = newPromiseCapability.f(this);
    var result = perform(callbackfn);
    (result.e ? promiseCapability.reject : promiseCapability.resolve)(result.v);
    return promiseCapability.promise;
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.reflect.define-metadata.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.reflect.define-metadata.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var metadata = __webpack_require__(/*! ./_metadata */ "./node_modules/core-js/modules/_metadata.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var toMetaKey = metadata.key;
var ordinaryDefineOwnMetadata = metadata.set;
metadata.exp({
  defineMetadata: function defineMetadata(metadataKey, metadataValue, target, targetKey) {
    ordinaryDefineOwnMetadata(metadataKey, metadataValue, anObject(target), toMetaKey(targetKey));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.reflect.delete-metadata.js":
/*!*********************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.reflect.delete-metadata.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var metadata = __webpack_require__(/*! ./_metadata */ "./node_modules/core-js/modules/_metadata.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var toMetaKey = metadata.key;
var getOrCreateMetadataMap = metadata.map;
var store = metadata.store;
metadata.exp({
  deleteMetadata: function deleteMetadata(metadataKey, target /* , targetKey */) {
    var targetKey = arguments.length < 3 ? undefined : toMetaKey(arguments[2]);
    var metadataMap = getOrCreateMetadataMap(anObject(target), targetKey, false);
    if (metadataMap === undefined || !metadataMap['delete'](metadataKey)) return false;
    if (metadataMap.size) return true;
    var targetMetadata = store.get(target);
    targetMetadata['delete'](targetKey);
    return !!targetMetadata.size || store['delete'](target);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.reflect.get-metadata-keys.js":
/*!***********************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.reflect.get-metadata-keys.js ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var Set = __webpack_require__(/*! ./es6.set */ "./node_modules/core-js/modules/es6.set.js");
var from = __webpack_require__(/*! ./_array-from-iterable */ "./node_modules/core-js/modules/_array-from-iterable.js");
var metadata = __webpack_require__(/*! ./_metadata */ "./node_modules/core-js/modules/_metadata.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var ordinaryOwnMetadataKeys = metadata.keys;
var toMetaKey = metadata.key;
var _ordinaryMetadataKeys = function ordinaryMetadataKeys(O, P) {
  var oKeys = ordinaryOwnMetadataKeys(O, P);
  var parent = getPrototypeOf(O);
  if (parent === null) return oKeys;
  var pKeys = _ordinaryMetadataKeys(parent, P);
  return pKeys.length ? oKeys.length ? from(new Set(oKeys.concat(pKeys))) : pKeys : oKeys;
};
metadata.exp({
  getMetadataKeys: function getMetadataKeys(target /* , targetKey */) {
    return _ordinaryMetadataKeys(anObject(target), arguments.length < 2 ? undefined : toMetaKey(arguments[1]));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.reflect.get-metadata.js":
/*!******************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.reflect.get-metadata.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var metadata = __webpack_require__(/*! ./_metadata */ "./node_modules/core-js/modules/_metadata.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var ordinaryHasOwnMetadata = metadata.has;
var ordinaryGetOwnMetadata = metadata.get;
var toMetaKey = metadata.key;
var _ordinaryGetMetadata = function ordinaryGetMetadata(MetadataKey, O, P) {
  var hasOwn = ordinaryHasOwnMetadata(MetadataKey, O, P);
  if (hasOwn) return ordinaryGetOwnMetadata(MetadataKey, O, P);
  var parent = getPrototypeOf(O);
  return parent !== null ? _ordinaryGetMetadata(MetadataKey, parent, P) : undefined;
};
metadata.exp({
  getMetadata: function getMetadata(metadataKey, target /* , targetKey */) {
    return _ordinaryGetMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.reflect.get-own-metadata-keys.js":
/*!***************************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.reflect.get-own-metadata-keys.js ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var metadata = __webpack_require__(/*! ./_metadata */ "./node_modules/core-js/modules/_metadata.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var ordinaryOwnMetadataKeys = metadata.keys;
var toMetaKey = metadata.key;
metadata.exp({
  getOwnMetadataKeys: function getOwnMetadataKeys(target /* , targetKey */) {
    return ordinaryOwnMetadataKeys(anObject(target), arguments.length < 2 ? undefined : toMetaKey(arguments[1]));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.reflect.get-own-metadata.js":
/*!**********************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.reflect.get-own-metadata.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var metadata = __webpack_require__(/*! ./_metadata */ "./node_modules/core-js/modules/_metadata.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var ordinaryGetOwnMetadata = metadata.get;
var toMetaKey = metadata.key;
metadata.exp({
  getOwnMetadata: function getOwnMetadata(metadataKey, target /* , targetKey */) {
    return ordinaryGetOwnMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.reflect.has-metadata.js":
/*!******************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.reflect.has-metadata.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var metadata = __webpack_require__(/*! ./_metadata */ "./node_modules/core-js/modules/_metadata.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var getPrototypeOf = __webpack_require__(/*! ./_object-gpo */ "./node_modules/core-js/modules/_object-gpo.js");
var ordinaryHasOwnMetadata = metadata.has;
var toMetaKey = metadata.key;
var _ordinaryHasMetadata = function ordinaryHasMetadata(MetadataKey, O, P) {
  var hasOwn = ordinaryHasOwnMetadata(MetadataKey, O, P);
  if (hasOwn) return true;
  var parent = getPrototypeOf(O);
  return parent !== null ? _ordinaryHasMetadata(MetadataKey, parent, P) : false;
};
metadata.exp({
  hasMetadata: function hasMetadata(metadataKey, target /* , targetKey */) {
    return _ordinaryHasMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.reflect.has-own-metadata.js":
/*!**********************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.reflect.has-own-metadata.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var metadata = __webpack_require__(/*! ./_metadata */ "./node_modules/core-js/modules/_metadata.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var ordinaryHasOwnMetadata = metadata.has;
var toMetaKey = metadata.key;
metadata.exp({
  hasOwnMetadata: function hasOwnMetadata(metadataKey, target /* , targetKey */) {
    return ordinaryHasOwnMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.reflect.metadata.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.reflect.metadata.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $metadata = __webpack_require__(/*! ./_metadata */ "./node_modules/core-js/modules/_metadata.js");
var anObject = __webpack_require__(/*! ./_an-object */ "./node_modules/core-js/modules/_an-object.js");
var aFunction = __webpack_require__(/*! ./_a-function */ "./node_modules/core-js/modules/_a-function.js");
var toMetaKey = $metadata.key;
var ordinaryDefineOwnMetadata = $metadata.set;
$metadata.exp({
  metadata: function metadata(metadataKey, metadataValue) {
    return function decorator(target, targetKey) {
      ordinaryDefineOwnMetadata(metadataKey, metadataValue, (targetKey !== undefined ? anObject : aFunction)(target), toMetaKey(targetKey));
    };
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.set.from.js":
/*!******************************************************!*\
  !*** ./node_modules/core-js/modules/es7.set.from.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-set.from
__webpack_require__(/*! ./_set-collection-from */ "./node_modules/core-js/modules/_set-collection-from.js")('Set');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.set.of.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/es7.set.of.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-set.of
__webpack_require__(/*! ./_set-collection-of */ "./node_modules/core-js/modules/_set-collection-of.js")('Set');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.set.to-json.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.set.to-json.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.P + $export.R, 'Set', {
  toJSON: __webpack_require__(/*! ./_collection-to-json */ "./node_modules/core-js/modules/_collection-to-json.js")('Set')
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.string.at.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/es7.string.at.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://github.com/mathiasbynens/String.prototype.at
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $at = __webpack_require__(/*! ./_string-at */ "./node_modules/core-js/modules/_string-at.js")(true);
var $fails = __webpack_require__(/*! ./_fails */ "./node_modules/core-js/modules/_fails.js");
var FORCED = $fails(function () {
  return '𠮷'.at(0) !== '𠮷';
});
$export($export.P + $export.F * FORCED, 'String', {
  at: function at(pos) {
    return $at(this, pos);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.string.match-all.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.string.match-all.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://tc39.github.io/String.prototype.matchAll/
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var defined = __webpack_require__(/*! ./_defined */ "./node_modules/core-js/modules/_defined.js");
var toLength = __webpack_require__(/*! ./_to-length */ "./node_modules/core-js/modules/_to-length.js");
var isRegExp = __webpack_require__(/*! ./_is-regexp */ "./node_modules/core-js/modules/_is-regexp.js");
var getFlags = __webpack_require__(/*! ./_flags */ "./node_modules/core-js/modules/_flags.js");
var RegExpProto = RegExp.prototype;
var $RegExpStringIterator = function $RegExpStringIterator(regexp, string) {
  this._r = regexp;
  this._s = string;
};
__webpack_require__(/*! ./_iter-create */ "./node_modules/core-js/modules/_iter-create.js")($RegExpStringIterator, 'RegExp String', function next() {
  var match = this._r.exec(this._s);
  return {
    value: match,
    done: match === null
  };
});
$export($export.P, 'String', {
  matchAll: function matchAll(regexp) {
    defined(this);
    if (!isRegExp(regexp)) throw TypeError(regexp + ' is not a regexp!');
    var S = String(this);
    var flags = 'flags' in RegExpProto ? String(regexp.flags) : getFlags.call(regexp);
    var rx = new RegExp(regexp.source, ~flags.indexOf('g') ? flags : 'g' + flags);
    rx.lastIndex = toLength(regexp.lastIndex);
    return new $RegExpStringIterator(rx, S);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.string.pad-end.js":
/*!************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.string.pad-end.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://github.com/tc39/proposal-string-pad-start-end
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $pad = __webpack_require__(/*! ./_string-pad */ "./node_modules/core-js/modules/_string-pad.js");
var userAgent = __webpack_require__(/*! ./_user-agent */ "./node_modules/core-js/modules/_user-agent.js");

// https://github.com/zloirock/core-js/issues/280
var WEBKIT_BUG = /Version\/10\.\d+(\.\d+)?( Mobile\/\w+)? Safari\//.test(userAgent);
$export($export.P + $export.F * WEBKIT_BUG, 'String', {
  padEnd: function padEnd(maxLength /* , fillString = ' ' */) {
    return $pad(this, maxLength, arguments.length > 1 ? arguments[1] : undefined, false);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.string.pad-start.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.string.pad-start.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://github.com/tc39/proposal-string-pad-start-end
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $pad = __webpack_require__(/*! ./_string-pad */ "./node_modules/core-js/modules/_string-pad.js");
var userAgent = __webpack_require__(/*! ./_user-agent */ "./node_modules/core-js/modules/_user-agent.js");

// https://github.com/zloirock/core-js/issues/280
var WEBKIT_BUG = /Version\/10\.\d+(\.\d+)?( Mobile\/\w+)? Safari\//.test(userAgent);
$export($export.P + $export.F * WEBKIT_BUG, 'String', {
  padStart: function padStart(maxLength /* , fillString = ' ' */) {
    return $pad(this, maxLength, arguments.length > 1 ? arguments[1] : undefined, true);
  }
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.string.trim-left.js":
/*!**************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.string.trim-left.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://github.com/sebmarkbage/ecmascript-string-left-right-trim
__webpack_require__(/*! ./_string-trim */ "./node_modules/core-js/modules/_string-trim.js")('trimLeft', function ($trim) {
  return function trimLeft() {
    return $trim(this, 1);
  };
}, 'trimStart');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.string.trim-right.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.string.trim-right.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

"use strict";


// https://github.com/sebmarkbage/ecmascript-string-left-right-trim
__webpack_require__(/*! ./_string-trim */ "./node_modules/core-js/modules/_string-trim.js")('trimRight', function ($trim) {
  return function trimRight() {
    return $trim(this, 2);
  };
}, 'trimEnd');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.symbol.async-iterator.js":
/*!*******************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.symbol.async-iterator.js ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ./_wks-define */ "./node_modules/core-js/modules/_wks-define.js")('asyncIterator');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.symbol.observable.js":
/*!***************************************************************!*\
  !*** ./node_modules/core-js/modules/es7.symbol.observable.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ./_wks-define */ "./node_modules/core-js/modules/_wks-define.js")('observable');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.system.global.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.system.global.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://github.com/tc39/proposal-global
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
$export($export.S, 'System', {
  global: __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js")
});

/***/ }),

/***/ "./node_modules/core-js/modules/es7.weak-map.from.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.weak-map.from.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakmap.from
__webpack_require__(/*! ./_set-collection-from */ "./node_modules/core-js/modules/_set-collection-from.js")('WeakMap');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.weak-map.of.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.weak-map.of.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakmap.of
__webpack_require__(/*! ./_set-collection-of */ "./node_modules/core-js/modules/_set-collection-of.js")('WeakMap');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.weak-set.from.js":
/*!***********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.weak-set.from.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakset.from
__webpack_require__(/*! ./_set-collection-from */ "./node_modules/core-js/modules/_set-collection-from.js")('WeakSet');

/***/ }),

/***/ "./node_modules/core-js/modules/es7.weak-set.of.js":
/*!*********************************************************!*\
  !*** ./node_modules/core-js/modules/es7.weak-set.of.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakset.of
__webpack_require__(/*! ./_set-collection-of */ "./node_modules/core-js/modules/_set-collection-of.js")('WeakSet');

/***/ }),

/***/ "./node_modules/core-js/modules/web.dom.iterable.js":
/*!**********************************************************!*\
  !*** ./node_modules/core-js/modules/web.dom.iterable.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $iterators = __webpack_require__(/*! ./es6.array.iterator */ "./node_modules/core-js/modules/es6.array.iterator.js");
var getKeys = __webpack_require__(/*! ./_object-keys */ "./node_modules/core-js/modules/_object-keys.js");
var redefine = __webpack_require__(/*! ./_redefine */ "./node_modules/core-js/modules/_redefine.js");
var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var hide = __webpack_require__(/*! ./_hide */ "./node_modules/core-js/modules/_hide.js");
var Iterators = __webpack_require__(/*! ./_iterators */ "./node_modules/core-js/modules/_iterators.js");
var wks = __webpack_require__(/*! ./_wks */ "./node_modules/core-js/modules/_wks.js");
var ITERATOR = wks('iterator');
var TO_STRING_TAG = wks('toStringTag');
var ArrayValues = Iterators.Array;
var DOMIterables = {
  CSSRuleList: true,
  // TODO: Not spec compliant, should be false.
  CSSStyleDeclaration: false,
  CSSValueList: false,
  ClientRectList: false,
  DOMRectList: false,
  DOMStringList: false,
  DOMTokenList: true,
  DataTransferItemList: false,
  FileList: false,
  HTMLAllCollection: false,
  HTMLCollection: false,
  HTMLFormElement: false,
  HTMLSelectElement: false,
  MediaList: true,
  // TODO: Not spec compliant, should be false.
  MimeTypeArray: false,
  NamedNodeMap: false,
  NodeList: true,
  PaintRequestList: false,
  Plugin: false,
  PluginArray: false,
  SVGLengthList: false,
  SVGNumberList: false,
  SVGPathSegList: false,
  SVGPointList: false,
  SVGStringList: false,
  SVGTransformList: false,
  SourceBufferList: false,
  StyleSheetList: true,
  // TODO: Not spec compliant, should be false.
  TextTrackCueList: false,
  TextTrackList: false,
  TouchList: false
};
for (var collections = getKeys(DOMIterables), i = 0; i < collections.length; i++) {
  var NAME = collections[i];
  var explicit = DOMIterables[NAME];
  var Collection = global[NAME];
  var proto = Collection && Collection.prototype;
  var key;
  if (proto) {
    if (!proto[ITERATOR]) hide(proto, ITERATOR, ArrayValues);
    if (!proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
    Iterators[NAME] = ArrayValues;
    if (explicit) for (key in $iterators) if (!proto[key]) redefine(proto, key, $iterators[key], true);
  }
}

/***/ }),

/***/ "./node_modules/core-js/modules/web.immediate.js":
/*!*******************************************************!*\
  !*** ./node_modules/core-js/modules/web.immediate.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var $task = __webpack_require__(/*! ./_task */ "./node_modules/core-js/modules/_task.js");
$export($export.G + $export.B, {
  setImmediate: $task.set,
  clearImmediate: $task.clear
});

/***/ }),

/***/ "./node_modules/core-js/modules/web.timers.js":
/*!****************************************************!*\
  !*** ./node_modules/core-js/modules/web.timers.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

// ie9- setTimeout & setInterval additional parameters fix
var global = __webpack_require__(/*! ./_global */ "./node_modules/core-js/modules/_global.js");
var $export = __webpack_require__(/*! ./_export */ "./node_modules/core-js/modules/_export.js");
var userAgent = __webpack_require__(/*! ./_user-agent */ "./node_modules/core-js/modules/_user-agent.js");
var slice = [].slice;
var MSIE = /MSIE .\./.test(userAgent); // <- dirty ie9- check
var wrap = function wrap(set) {
  return function (fn, time /* , ...args */) {
    var boundArgs = arguments.length > 2;
    var args = boundArgs ? slice.call(arguments, 2) : false;
    return set(boundArgs ? function () {
      // eslint-disable-next-line no-new-func
      (typeof fn == 'function' ? fn : Function(fn)).apply(this, args);
    } : fn, time);
  };
};
$export($export.G + $export.B + $export.F * MSIE, {
  setTimeout: wrap(global.setTimeout),
  setInterval: wrap(global.setInterval)
});

/***/ }),

/***/ "./node_modules/core-js/shim.js":
/*!**************************************!*\
  !*** ./node_modules/core-js/shim.js ***!
  \**************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

__webpack_require__(/*! ./modules/es6.symbol */ "./node_modules/core-js/modules/es6.symbol.js");
__webpack_require__(/*! ./modules/es6.object.create */ "./node_modules/core-js/modules/es6.object.create.js");
__webpack_require__(/*! ./modules/es6.object.define-property */ "./node_modules/core-js/modules/es6.object.define-property.js");
__webpack_require__(/*! ./modules/es6.object.define-properties */ "./node_modules/core-js/modules/es6.object.define-properties.js");
__webpack_require__(/*! ./modules/es6.object.get-own-property-descriptor */ "./node_modules/core-js/modules/es6.object.get-own-property-descriptor.js");
__webpack_require__(/*! ./modules/es6.object.get-prototype-of */ "./node_modules/core-js/modules/es6.object.get-prototype-of.js");
__webpack_require__(/*! ./modules/es6.object.keys */ "./node_modules/core-js/modules/es6.object.keys.js");
__webpack_require__(/*! ./modules/es6.object.get-own-property-names */ "./node_modules/core-js/modules/es6.object.get-own-property-names.js");
__webpack_require__(/*! ./modules/es6.object.freeze */ "./node_modules/core-js/modules/es6.object.freeze.js");
__webpack_require__(/*! ./modules/es6.object.seal */ "./node_modules/core-js/modules/es6.object.seal.js");
__webpack_require__(/*! ./modules/es6.object.prevent-extensions */ "./node_modules/core-js/modules/es6.object.prevent-extensions.js");
__webpack_require__(/*! ./modules/es6.object.is-frozen */ "./node_modules/core-js/modules/es6.object.is-frozen.js");
__webpack_require__(/*! ./modules/es6.object.is-sealed */ "./node_modules/core-js/modules/es6.object.is-sealed.js");
__webpack_require__(/*! ./modules/es6.object.is-extensible */ "./node_modules/core-js/modules/es6.object.is-extensible.js");
__webpack_require__(/*! ./modules/es6.object.assign */ "./node_modules/core-js/modules/es6.object.assign.js");
__webpack_require__(/*! ./modules/es6.object.is */ "./node_modules/core-js/modules/es6.object.is.js");
__webpack_require__(/*! ./modules/es6.object.set-prototype-of */ "./node_modules/core-js/modules/es6.object.set-prototype-of.js");
__webpack_require__(/*! ./modules/es6.object.to-string */ "./node_modules/core-js/modules/es6.object.to-string.js");
__webpack_require__(/*! ./modules/es6.function.bind */ "./node_modules/core-js/modules/es6.function.bind.js");
__webpack_require__(/*! ./modules/es6.function.name */ "./node_modules/core-js/modules/es6.function.name.js");
__webpack_require__(/*! ./modules/es6.function.has-instance */ "./node_modules/core-js/modules/es6.function.has-instance.js");
__webpack_require__(/*! ./modules/es6.parse-int */ "./node_modules/core-js/modules/es6.parse-int.js");
__webpack_require__(/*! ./modules/es6.parse-float */ "./node_modules/core-js/modules/es6.parse-float.js");
__webpack_require__(/*! ./modules/es6.number.constructor */ "./node_modules/core-js/modules/es6.number.constructor.js");
__webpack_require__(/*! ./modules/es6.number.to-fixed */ "./node_modules/core-js/modules/es6.number.to-fixed.js");
__webpack_require__(/*! ./modules/es6.number.to-precision */ "./node_modules/core-js/modules/es6.number.to-precision.js");
__webpack_require__(/*! ./modules/es6.number.epsilon */ "./node_modules/core-js/modules/es6.number.epsilon.js");
__webpack_require__(/*! ./modules/es6.number.is-finite */ "./node_modules/core-js/modules/es6.number.is-finite.js");
__webpack_require__(/*! ./modules/es6.number.is-integer */ "./node_modules/core-js/modules/es6.number.is-integer.js");
__webpack_require__(/*! ./modules/es6.number.is-nan */ "./node_modules/core-js/modules/es6.number.is-nan.js");
__webpack_require__(/*! ./modules/es6.number.is-safe-integer */ "./node_modules/core-js/modules/es6.number.is-safe-integer.js");
__webpack_require__(/*! ./modules/es6.number.max-safe-integer */ "./node_modules/core-js/modules/es6.number.max-safe-integer.js");
__webpack_require__(/*! ./modules/es6.number.min-safe-integer */ "./node_modules/core-js/modules/es6.number.min-safe-integer.js");
__webpack_require__(/*! ./modules/es6.number.parse-float */ "./node_modules/core-js/modules/es6.number.parse-float.js");
__webpack_require__(/*! ./modules/es6.number.parse-int */ "./node_modules/core-js/modules/es6.number.parse-int.js");
__webpack_require__(/*! ./modules/es6.math.acosh */ "./node_modules/core-js/modules/es6.math.acosh.js");
__webpack_require__(/*! ./modules/es6.math.asinh */ "./node_modules/core-js/modules/es6.math.asinh.js");
__webpack_require__(/*! ./modules/es6.math.atanh */ "./node_modules/core-js/modules/es6.math.atanh.js");
__webpack_require__(/*! ./modules/es6.math.cbrt */ "./node_modules/core-js/modules/es6.math.cbrt.js");
__webpack_require__(/*! ./modules/es6.math.clz32 */ "./node_modules/core-js/modules/es6.math.clz32.js");
__webpack_require__(/*! ./modules/es6.math.cosh */ "./node_modules/core-js/modules/es6.math.cosh.js");
__webpack_require__(/*! ./modules/es6.math.expm1 */ "./node_modules/core-js/modules/es6.math.expm1.js");
__webpack_require__(/*! ./modules/es6.math.fround */ "./node_modules/core-js/modules/es6.math.fround.js");
__webpack_require__(/*! ./modules/es6.math.hypot */ "./node_modules/core-js/modules/es6.math.hypot.js");
__webpack_require__(/*! ./modules/es6.math.imul */ "./node_modules/core-js/modules/es6.math.imul.js");
__webpack_require__(/*! ./modules/es6.math.log10 */ "./node_modules/core-js/modules/es6.math.log10.js");
__webpack_require__(/*! ./modules/es6.math.log1p */ "./node_modules/core-js/modules/es6.math.log1p.js");
__webpack_require__(/*! ./modules/es6.math.log2 */ "./node_modules/core-js/modules/es6.math.log2.js");
__webpack_require__(/*! ./modules/es6.math.sign */ "./node_modules/core-js/modules/es6.math.sign.js");
__webpack_require__(/*! ./modules/es6.math.sinh */ "./node_modules/core-js/modules/es6.math.sinh.js");
__webpack_require__(/*! ./modules/es6.math.tanh */ "./node_modules/core-js/modules/es6.math.tanh.js");
__webpack_require__(/*! ./modules/es6.math.trunc */ "./node_modules/core-js/modules/es6.math.trunc.js");
__webpack_require__(/*! ./modules/es6.string.from-code-point */ "./node_modules/core-js/modules/es6.string.from-code-point.js");
__webpack_require__(/*! ./modules/es6.string.raw */ "./node_modules/core-js/modules/es6.string.raw.js");
__webpack_require__(/*! ./modules/es6.string.trim */ "./node_modules/core-js/modules/es6.string.trim.js");
__webpack_require__(/*! ./modules/es6.string.iterator */ "./node_modules/core-js/modules/es6.string.iterator.js");
__webpack_require__(/*! ./modules/es6.string.code-point-at */ "./node_modules/core-js/modules/es6.string.code-point-at.js");
__webpack_require__(/*! ./modules/es6.string.ends-with */ "./node_modules/core-js/modules/es6.string.ends-with.js");
__webpack_require__(/*! ./modules/es6.string.includes */ "./node_modules/core-js/modules/es6.string.includes.js");
__webpack_require__(/*! ./modules/es6.string.repeat */ "./node_modules/core-js/modules/es6.string.repeat.js");
__webpack_require__(/*! ./modules/es6.string.starts-with */ "./node_modules/core-js/modules/es6.string.starts-with.js");
__webpack_require__(/*! ./modules/es6.string.anchor */ "./node_modules/core-js/modules/es6.string.anchor.js");
__webpack_require__(/*! ./modules/es6.string.big */ "./node_modules/core-js/modules/es6.string.big.js");
__webpack_require__(/*! ./modules/es6.string.blink */ "./node_modules/core-js/modules/es6.string.blink.js");
__webpack_require__(/*! ./modules/es6.string.bold */ "./node_modules/core-js/modules/es6.string.bold.js");
__webpack_require__(/*! ./modules/es6.string.fixed */ "./node_modules/core-js/modules/es6.string.fixed.js");
__webpack_require__(/*! ./modules/es6.string.fontcolor */ "./node_modules/core-js/modules/es6.string.fontcolor.js");
__webpack_require__(/*! ./modules/es6.string.fontsize */ "./node_modules/core-js/modules/es6.string.fontsize.js");
__webpack_require__(/*! ./modules/es6.string.italics */ "./node_modules/core-js/modules/es6.string.italics.js");
__webpack_require__(/*! ./modules/es6.string.link */ "./node_modules/core-js/modules/es6.string.link.js");
__webpack_require__(/*! ./modules/es6.string.small */ "./node_modules/core-js/modules/es6.string.small.js");
__webpack_require__(/*! ./modules/es6.string.strike */ "./node_modules/core-js/modules/es6.string.strike.js");
__webpack_require__(/*! ./modules/es6.string.sub */ "./node_modules/core-js/modules/es6.string.sub.js");
__webpack_require__(/*! ./modules/es6.string.sup */ "./node_modules/core-js/modules/es6.string.sup.js");
__webpack_require__(/*! ./modules/es6.date.now */ "./node_modules/core-js/modules/es6.date.now.js");
__webpack_require__(/*! ./modules/es6.date.to-json */ "./node_modules/core-js/modules/es6.date.to-json.js");
__webpack_require__(/*! ./modules/es6.date.to-iso-string */ "./node_modules/core-js/modules/es6.date.to-iso-string.js");
__webpack_require__(/*! ./modules/es6.date.to-string */ "./node_modules/core-js/modules/es6.date.to-string.js");
__webpack_require__(/*! ./modules/es6.date.to-primitive */ "./node_modules/core-js/modules/es6.date.to-primitive.js");
__webpack_require__(/*! ./modules/es6.array.is-array */ "./node_modules/core-js/modules/es6.array.is-array.js");
__webpack_require__(/*! ./modules/es6.array.from */ "./node_modules/core-js/modules/es6.array.from.js");
__webpack_require__(/*! ./modules/es6.array.of */ "./node_modules/core-js/modules/es6.array.of.js");
__webpack_require__(/*! ./modules/es6.array.join */ "./node_modules/core-js/modules/es6.array.join.js");
__webpack_require__(/*! ./modules/es6.array.slice */ "./node_modules/core-js/modules/es6.array.slice.js");
__webpack_require__(/*! ./modules/es6.array.sort */ "./node_modules/core-js/modules/es6.array.sort.js");
__webpack_require__(/*! ./modules/es6.array.for-each */ "./node_modules/core-js/modules/es6.array.for-each.js");
__webpack_require__(/*! ./modules/es6.array.map */ "./node_modules/core-js/modules/es6.array.map.js");
__webpack_require__(/*! ./modules/es6.array.filter */ "./node_modules/core-js/modules/es6.array.filter.js");
__webpack_require__(/*! ./modules/es6.array.some */ "./node_modules/core-js/modules/es6.array.some.js");
__webpack_require__(/*! ./modules/es6.array.every */ "./node_modules/core-js/modules/es6.array.every.js");
__webpack_require__(/*! ./modules/es6.array.reduce */ "./node_modules/core-js/modules/es6.array.reduce.js");
__webpack_require__(/*! ./modules/es6.array.reduce-right */ "./node_modules/core-js/modules/es6.array.reduce-right.js");
__webpack_require__(/*! ./modules/es6.array.index-of */ "./node_modules/core-js/modules/es6.array.index-of.js");
__webpack_require__(/*! ./modules/es6.array.last-index-of */ "./node_modules/core-js/modules/es6.array.last-index-of.js");
__webpack_require__(/*! ./modules/es6.array.copy-within */ "./node_modules/core-js/modules/es6.array.copy-within.js");
__webpack_require__(/*! ./modules/es6.array.fill */ "./node_modules/core-js/modules/es6.array.fill.js");
__webpack_require__(/*! ./modules/es6.array.find */ "./node_modules/core-js/modules/es6.array.find.js");
__webpack_require__(/*! ./modules/es6.array.find-index */ "./node_modules/core-js/modules/es6.array.find-index.js");
__webpack_require__(/*! ./modules/es6.array.species */ "./node_modules/core-js/modules/es6.array.species.js");
__webpack_require__(/*! ./modules/es6.array.iterator */ "./node_modules/core-js/modules/es6.array.iterator.js");
__webpack_require__(/*! ./modules/es6.regexp.constructor */ "./node_modules/core-js/modules/es6.regexp.constructor.js");
__webpack_require__(/*! ./modules/es6.regexp.exec */ "./node_modules/core-js/modules/es6.regexp.exec.js");
__webpack_require__(/*! ./modules/es6.regexp.to-string */ "./node_modules/core-js/modules/es6.regexp.to-string.js");
__webpack_require__(/*! ./modules/es6.regexp.flags */ "./node_modules/core-js/modules/es6.regexp.flags.js");
__webpack_require__(/*! ./modules/es6.regexp.match */ "./node_modules/core-js/modules/es6.regexp.match.js");
__webpack_require__(/*! ./modules/es6.regexp.replace */ "./node_modules/core-js/modules/es6.regexp.replace.js");
__webpack_require__(/*! ./modules/es6.regexp.search */ "./node_modules/core-js/modules/es6.regexp.search.js");
__webpack_require__(/*! ./modules/es6.regexp.split */ "./node_modules/core-js/modules/es6.regexp.split.js");
__webpack_require__(/*! ./modules/es6.promise */ "./node_modules/core-js/modules/es6.promise.js");
__webpack_require__(/*! ./modules/es6.map */ "./node_modules/core-js/modules/es6.map.js");
__webpack_require__(/*! ./modules/es6.set */ "./node_modules/core-js/modules/es6.set.js");
__webpack_require__(/*! ./modules/es6.weak-map */ "./node_modules/core-js/modules/es6.weak-map.js");
__webpack_require__(/*! ./modules/es6.weak-set */ "./node_modules/core-js/modules/es6.weak-set.js");
__webpack_require__(/*! ./modules/es6.typed.array-buffer */ "./node_modules/core-js/modules/es6.typed.array-buffer.js");
__webpack_require__(/*! ./modules/es6.typed.data-view */ "./node_modules/core-js/modules/es6.typed.data-view.js");
__webpack_require__(/*! ./modules/es6.typed.int8-array */ "./node_modules/core-js/modules/es6.typed.int8-array.js");
__webpack_require__(/*! ./modules/es6.typed.uint8-array */ "./node_modules/core-js/modules/es6.typed.uint8-array.js");
__webpack_require__(/*! ./modules/es6.typed.uint8-clamped-array */ "./node_modules/core-js/modules/es6.typed.uint8-clamped-array.js");
__webpack_require__(/*! ./modules/es6.typed.int16-array */ "./node_modules/core-js/modules/es6.typed.int16-array.js");
__webpack_require__(/*! ./modules/es6.typed.uint16-array */ "./node_modules/core-js/modules/es6.typed.uint16-array.js");
__webpack_require__(/*! ./modules/es6.typed.int32-array */ "./node_modules/core-js/modules/es6.typed.int32-array.js");
__webpack_require__(/*! ./modules/es6.typed.uint32-array */ "./node_modules/core-js/modules/es6.typed.uint32-array.js");
__webpack_require__(/*! ./modules/es6.typed.float32-array */ "./node_modules/core-js/modules/es6.typed.float32-array.js");
__webpack_require__(/*! ./modules/es6.typed.float64-array */ "./node_modules/core-js/modules/es6.typed.float64-array.js");
__webpack_require__(/*! ./modules/es6.reflect.apply */ "./node_modules/core-js/modules/es6.reflect.apply.js");
__webpack_require__(/*! ./modules/es6.reflect.construct */ "./node_modules/core-js/modules/es6.reflect.construct.js");
__webpack_require__(/*! ./modules/es6.reflect.define-property */ "./node_modules/core-js/modules/es6.reflect.define-property.js");
__webpack_require__(/*! ./modules/es6.reflect.delete-property */ "./node_modules/core-js/modules/es6.reflect.delete-property.js");
__webpack_require__(/*! ./modules/es6.reflect.enumerate */ "./node_modules/core-js/modules/es6.reflect.enumerate.js");
__webpack_require__(/*! ./modules/es6.reflect.get */ "./node_modules/core-js/modules/es6.reflect.get.js");
__webpack_require__(/*! ./modules/es6.reflect.get-own-property-descriptor */ "./node_modules/core-js/modules/es6.reflect.get-own-property-descriptor.js");
__webpack_require__(/*! ./modules/es6.reflect.get-prototype-of */ "./node_modules/core-js/modules/es6.reflect.get-prototype-of.js");
__webpack_require__(/*! ./modules/es6.reflect.has */ "./node_modules/core-js/modules/es6.reflect.has.js");
__webpack_require__(/*! ./modules/es6.reflect.is-extensible */ "./node_modules/core-js/modules/es6.reflect.is-extensible.js");
__webpack_require__(/*! ./modules/es6.reflect.own-keys */ "./node_modules/core-js/modules/es6.reflect.own-keys.js");
__webpack_require__(/*! ./modules/es6.reflect.prevent-extensions */ "./node_modules/core-js/modules/es6.reflect.prevent-extensions.js");
__webpack_require__(/*! ./modules/es6.reflect.set */ "./node_modules/core-js/modules/es6.reflect.set.js");
__webpack_require__(/*! ./modules/es6.reflect.set-prototype-of */ "./node_modules/core-js/modules/es6.reflect.set-prototype-of.js");
__webpack_require__(/*! ./modules/es7.array.includes */ "./node_modules/core-js/modules/es7.array.includes.js");
__webpack_require__(/*! ./modules/es7.array.flat-map */ "./node_modules/core-js/modules/es7.array.flat-map.js");
__webpack_require__(/*! ./modules/es7.array.flatten */ "./node_modules/core-js/modules/es7.array.flatten.js");
__webpack_require__(/*! ./modules/es7.string.at */ "./node_modules/core-js/modules/es7.string.at.js");
__webpack_require__(/*! ./modules/es7.string.pad-start */ "./node_modules/core-js/modules/es7.string.pad-start.js");
__webpack_require__(/*! ./modules/es7.string.pad-end */ "./node_modules/core-js/modules/es7.string.pad-end.js");
__webpack_require__(/*! ./modules/es7.string.trim-left */ "./node_modules/core-js/modules/es7.string.trim-left.js");
__webpack_require__(/*! ./modules/es7.string.trim-right */ "./node_modules/core-js/modules/es7.string.trim-right.js");
__webpack_require__(/*! ./modules/es7.string.match-all */ "./node_modules/core-js/modules/es7.string.match-all.js");
__webpack_require__(/*! ./modules/es7.symbol.async-iterator */ "./node_modules/core-js/modules/es7.symbol.async-iterator.js");
__webpack_require__(/*! ./modules/es7.symbol.observable */ "./node_modules/core-js/modules/es7.symbol.observable.js");
__webpack_require__(/*! ./modules/es7.object.get-own-property-descriptors */ "./node_modules/core-js/modules/es7.object.get-own-property-descriptors.js");
__webpack_require__(/*! ./modules/es7.object.values */ "./node_modules/core-js/modules/es7.object.values.js");
__webpack_require__(/*! ./modules/es7.object.entries */ "./node_modules/core-js/modules/es7.object.entries.js");
__webpack_require__(/*! ./modules/es7.object.define-getter */ "./node_modules/core-js/modules/es7.object.define-getter.js");
__webpack_require__(/*! ./modules/es7.object.define-setter */ "./node_modules/core-js/modules/es7.object.define-setter.js");
__webpack_require__(/*! ./modules/es7.object.lookup-getter */ "./node_modules/core-js/modules/es7.object.lookup-getter.js");
__webpack_require__(/*! ./modules/es7.object.lookup-setter */ "./node_modules/core-js/modules/es7.object.lookup-setter.js");
__webpack_require__(/*! ./modules/es7.map.to-json */ "./node_modules/core-js/modules/es7.map.to-json.js");
__webpack_require__(/*! ./modules/es7.set.to-json */ "./node_modules/core-js/modules/es7.set.to-json.js");
__webpack_require__(/*! ./modules/es7.map.of */ "./node_modules/core-js/modules/es7.map.of.js");
__webpack_require__(/*! ./modules/es7.set.of */ "./node_modules/core-js/modules/es7.set.of.js");
__webpack_require__(/*! ./modules/es7.weak-map.of */ "./node_modules/core-js/modules/es7.weak-map.of.js");
__webpack_require__(/*! ./modules/es7.weak-set.of */ "./node_modules/core-js/modules/es7.weak-set.of.js");
__webpack_require__(/*! ./modules/es7.map.from */ "./node_modules/core-js/modules/es7.map.from.js");
__webpack_require__(/*! ./modules/es7.set.from */ "./node_modules/core-js/modules/es7.set.from.js");
__webpack_require__(/*! ./modules/es7.weak-map.from */ "./node_modules/core-js/modules/es7.weak-map.from.js");
__webpack_require__(/*! ./modules/es7.weak-set.from */ "./node_modules/core-js/modules/es7.weak-set.from.js");
__webpack_require__(/*! ./modules/es7.global */ "./node_modules/core-js/modules/es7.global.js");
__webpack_require__(/*! ./modules/es7.system.global */ "./node_modules/core-js/modules/es7.system.global.js");
__webpack_require__(/*! ./modules/es7.error.is-error */ "./node_modules/core-js/modules/es7.error.is-error.js");
__webpack_require__(/*! ./modules/es7.math.clamp */ "./node_modules/core-js/modules/es7.math.clamp.js");
__webpack_require__(/*! ./modules/es7.math.deg-per-rad */ "./node_modules/core-js/modules/es7.math.deg-per-rad.js");
__webpack_require__(/*! ./modules/es7.math.degrees */ "./node_modules/core-js/modules/es7.math.degrees.js");
__webpack_require__(/*! ./modules/es7.math.fscale */ "./node_modules/core-js/modules/es7.math.fscale.js");
__webpack_require__(/*! ./modules/es7.math.iaddh */ "./node_modules/core-js/modules/es7.math.iaddh.js");
__webpack_require__(/*! ./modules/es7.math.isubh */ "./node_modules/core-js/modules/es7.math.isubh.js");
__webpack_require__(/*! ./modules/es7.math.imulh */ "./node_modules/core-js/modules/es7.math.imulh.js");
__webpack_require__(/*! ./modules/es7.math.rad-per-deg */ "./node_modules/core-js/modules/es7.math.rad-per-deg.js");
__webpack_require__(/*! ./modules/es7.math.radians */ "./node_modules/core-js/modules/es7.math.radians.js");
__webpack_require__(/*! ./modules/es7.math.scale */ "./node_modules/core-js/modules/es7.math.scale.js");
__webpack_require__(/*! ./modules/es7.math.umulh */ "./node_modules/core-js/modules/es7.math.umulh.js");
__webpack_require__(/*! ./modules/es7.math.signbit */ "./node_modules/core-js/modules/es7.math.signbit.js");
__webpack_require__(/*! ./modules/es7.promise.finally */ "./node_modules/core-js/modules/es7.promise.finally.js");
__webpack_require__(/*! ./modules/es7.promise.try */ "./node_modules/core-js/modules/es7.promise.try.js");
__webpack_require__(/*! ./modules/es7.reflect.define-metadata */ "./node_modules/core-js/modules/es7.reflect.define-metadata.js");
__webpack_require__(/*! ./modules/es7.reflect.delete-metadata */ "./node_modules/core-js/modules/es7.reflect.delete-metadata.js");
__webpack_require__(/*! ./modules/es7.reflect.get-metadata */ "./node_modules/core-js/modules/es7.reflect.get-metadata.js");
__webpack_require__(/*! ./modules/es7.reflect.get-metadata-keys */ "./node_modules/core-js/modules/es7.reflect.get-metadata-keys.js");
__webpack_require__(/*! ./modules/es7.reflect.get-own-metadata */ "./node_modules/core-js/modules/es7.reflect.get-own-metadata.js");
__webpack_require__(/*! ./modules/es7.reflect.get-own-metadata-keys */ "./node_modules/core-js/modules/es7.reflect.get-own-metadata-keys.js");
__webpack_require__(/*! ./modules/es7.reflect.has-metadata */ "./node_modules/core-js/modules/es7.reflect.has-metadata.js");
__webpack_require__(/*! ./modules/es7.reflect.has-own-metadata */ "./node_modules/core-js/modules/es7.reflect.has-own-metadata.js");
__webpack_require__(/*! ./modules/es7.reflect.metadata */ "./node_modules/core-js/modules/es7.reflect.metadata.js");
__webpack_require__(/*! ./modules/es7.asap */ "./node_modules/core-js/modules/es7.asap.js");
__webpack_require__(/*! ./modules/es7.observable */ "./node_modules/core-js/modules/es7.observable.js");
__webpack_require__(/*! ./modules/web.timers */ "./node_modules/core-js/modules/web.timers.js");
__webpack_require__(/*! ./modules/web.immediate */ "./node_modules/core-js/modules/web.immediate.js");
__webpack_require__(/*! ./modules/web.dom.iterable */ "./node_modules/core-js/modules/web.dom.iterable.js");
module.exports = __webpack_require__(/*! ./modules/_core */ "./node_modules/core-js/modules/_core.js");

/***/ }),

/***/ "./node_modules/reflect-metadata/Reflect.js":
/*!**************************************************!*\
  !*** ./node_modules/reflect-metadata/Reflect.js ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
/*! *****************************************************************************
Copyright (C) Microsoft. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
var Reflect;
(function (Reflect) {
  // Metadata Proposal
  // https://rbuckton.github.io/reflect-metadata/
  (function (factory) {
    var root = (typeof __webpack_require__.g === "undefined" ? "undefined" : _typeof(__webpack_require__.g)) === "object" ? __webpack_require__.g : (typeof self === "undefined" ? "undefined" : _typeof(self)) === "object" ? self : _typeof(this) === "object" ? this : Function("return this;")();
    var exporter = makeExporter(Reflect);
    if (typeof root.Reflect === "undefined") {
      root.Reflect = Reflect;
    } else {
      exporter = makeExporter(root.Reflect, exporter);
    }
    factory(exporter);
    function makeExporter(target, previous) {
      return function (key, value) {
        if (typeof target[key] !== "function") {
          Object.defineProperty(target, key, {
            configurable: true,
            writable: true,
            value: value
          });
        }
        if (previous) previous(key, value);
      };
    }
  })(function (exporter) {
    var hasOwn = Object.prototype.hasOwnProperty;
    // feature test for Symbol support
    var supportsSymbol = typeof Symbol === "function";
    var toPrimitiveSymbol = supportsSymbol && typeof Symbol.toPrimitive !== "undefined" ? Symbol.toPrimitive : "@@toPrimitive";
    var iteratorSymbol = supportsSymbol && typeof Symbol.iterator !== "undefined" ? Symbol.iterator : "@@iterator";
    var supportsCreate = typeof Object.create === "function"; // feature test for Object.create support
    var supportsProto = {
      __proto__: []
    } instanceof Array; // feature test for __proto__ support
    var downLevel = !supportsCreate && !supportsProto;
    var HashMap = {
      // create an object in dictionary mode (a.k.a. "slow" mode in v8)
      create: supportsCreate ? function () {
        return MakeDictionary(Object.create(null));
      } : supportsProto ? function () {
        return MakeDictionary({
          __proto__: null
        });
      } : function () {
        return MakeDictionary({});
      },
      has: downLevel ? function (map, key) {
        return hasOwn.call(map, key);
      } : function (map, key) {
        return key in map;
      },
      get: downLevel ? function (map, key) {
        return hasOwn.call(map, key) ? map[key] : undefined;
      } : function (map, key) {
        return map[key];
      }
    };
    // Load global or shim versions of Map, Set, and WeakMap
    var functionPrototype = Object.getPrototypeOf(Function);
    var usePolyfill = (typeof process === "undefined" ? "undefined" : _typeof(process)) === "object" && process["env" + ""] && process["env" + ""]["REFLECT_METADATA_USE_MAP_POLYFILL"] === "true";
    var _Map = !usePolyfill && typeof Map === "function" && typeof Map.prototype.entries === "function" ? Map : CreateMapPolyfill();
    var _Set = !usePolyfill && typeof Set === "function" && typeof Set.prototype.entries === "function" ? Set : CreateSetPolyfill();
    var _WeakMap = !usePolyfill && typeof WeakMap === "function" ? WeakMap : CreateWeakMapPolyfill();
    // [[Metadata]] internal slot
    // https://rbuckton.github.io/reflect-metadata/#ordinary-object-internal-methods-and-internal-slots
    var Metadata = new _WeakMap();
    /**
     * Applies a set of decorators to a property of a target object.
     * @param decorators An array of decorators.
     * @param target The target object.
     * @param propertyKey (Optional) The property key to decorate.
     * @param attributes (Optional) The property descriptor for the target key.
     * @remarks Decorators are applied in reverse order.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     Example = Reflect.decorate(decoratorsArray, Example);
     *
     *     // property (on constructor)
     *     Reflect.decorate(decoratorsArray, Example, "staticProperty");
     *
     *     // property (on prototype)
     *     Reflect.decorate(decoratorsArray, Example.prototype, "property");
     *
     *     // method (on constructor)
     *     Object.defineProperty(Example, "staticMethod",
     *         Reflect.decorate(decoratorsArray, Example, "staticMethod",
     *             Object.getOwnPropertyDescriptor(Example, "staticMethod")));
     *
     *     // method (on prototype)
     *     Object.defineProperty(Example.prototype, "method",
     *         Reflect.decorate(decoratorsArray, Example.prototype, "method",
     *             Object.getOwnPropertyDescriptor(Example.prototype, "method")));
     *
     */
    function decorate(decorators, target, propertyKey, attributes) {
      if (!IsUndefined(propertyKey)) {
        if (!IsArray(decorators)) throw new TypeError();
        if (!IsObject(target)) throw new TypeError();
        if (!IsObject(attributes) && !IsUndefined(attributes) && !IsNull(attributes)) throw new TypeError();
        if (IsNull(attributes)) attributes = undefined;
        propertyKey = ToPropertyKey(propertyKey);
        return DecorateProperty(decorators, target, propertyKey, attributes);
      } else {
        if (!IsArray(decorators)) throw new TypeError();
        if (!IsConstructor(target)) throw new TypeError();
        return DecorateConstructor(decorators, target);
      }
    }
    exporter("decorate", decorate);
    // 4.1.2 Reflect.metadata(metadataKey, metadataValue)
    // https://rbuckton.github.io/reflect-metadata/#reflect.metadata
    /**
     * A default metadata decorator factory that can be used on a class, class member, or parameter.
     * @param metadataKey The key for the metadata entry.
     * @param metadataValue The value for the metadata entry.
     * @returns A decorator function.
     * @remarks
     * If `metadataKey` is already defined for the target and target key, the
     * metadataValue for that key will be overwritten.
     * @example
     *
     *     // constructor
     *     @Reflect.metadata(key, value)
     *     class Example {
     *     }
     *
     *     // property (on constructor, TypeScript only)
     *     class Example {
     *         @Reflect.metadata(key, value)
     *         static staticProperty;
     *     }
     *
     *     // property (on prototype, TypeScript only)
     *     class Example {
     *         @Reflect.metadata(key, value)
     *         property;
     *     }
     *
     *     // method (on constructor)
     *     class Example {
     *         @Reflect.metadata(key, value)
     *         static staticMethod() { }
     *     }
     *
     *     // method (on prototype)
     *     class Example {
     *         @Reflect.metadata(key, value)
     *         method() { }
     *     }
     *
     */
    function metadata(metadataKey, metadataValue) {
      function decorator(target, propertyKey) {
        if (!IsObject(target)) throw new TypeError();
        if (!IsUndefined(propertyKey) && !IsPropertyKey(propertyKey)) throw new TypeError();
        OrdinaryDefineOwnMetadata(metadataKey, metadataValue, target, propertyKey);
      }
      return decorator;
    }
    exporter("metadata", metadata);
    /**
     * Define a unique metadata entry on the target.
     * @param metadataKey A key used to store and retrieve metadata.
     * @param metadataValue A value that contains attached metadata.
     * @param target The target object on which to define metadata.
     * @param propertyKey (Optional) The property key for the target.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     Reflect.defineMetadata("custom:annotation", options, Example);
     *
     *     // property (on constructor)
     *     Reflect.defineMetadata("custom:annotation", options, Example, "staticProperty");
     *
     *     // property (on prototype)
     *     Reflect.defineMetadata("custom:annotation", options, Example.prototype, "property");
     *
     *     // method (on constructor)
     *     Reflect.defineMetadata("custom:annotation", options, Example, "staticMethod");
     *
     *     // method (on prototype)
     *     Reflect.defineMetadata("custom:annotation", options, Example.prototype, "method");
     *
     *     // decorator factory as metadata-producing annotation.
     *     function MyAnnotation(options): Decorator {
     *         return (target, key?) => Reflect.defineMetadata("custom:annotation", options, target, key);
     *     }
     *
     */
    function defineMetadata(metadataKey, metadataValue, target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryDefineOwnMetadata(metadataKey, metadataValue, target, propertyKey);
    }
    exporter("defineMetadata", defineMetadata);
    /**
     * Gets a value indicating whether the target object or its prototype chain has the provided metadata key defined.
     * @param metadataKey A key used to store and retrieve metadata.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns `true` if the metadata key was defined on the target object or its prototype chain; otherwise, `false`.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.hasMetadata("custom:annotation", Example);
     *
     *     // property (on constructor)
     *     result = Reflect.hasMetadata("custom:annotation", Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.hasMetadata("custom:annotation", Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.hasMetadata("custom:annotation", Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.hasMetadata("custom:annotation", Example.prototype, "method");
     *
     */
    function hasMetadata(metadataKey, target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryHasMetadata(metadataKey, target, propertyKey);
    }
    exporter("hasMetadata", hasMetadata);
    /**
     * Gets a value indicating whether the target object has the provided metadata key defined.
     * @param metadataKey A key used to store and retrieve metadata.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns `true` if the metadata key was defined on the target object; otherwise, `false`.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.hasOwnMetadata("custom:annotation", Example);
     *
     *     // property (on constructor)
     *     result = Reflect.hasOwnMetadata("custom:annotation", Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.hasOwnMetadata("custom:annotation", Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.hasOwnMetadata("custom:annotation", Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.hasOwnMetadata("custom:annotation", Example.prototype, "method");
     *
     */
    function hasOwnMetadata(metadataKey, target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryHasOwnMetadata(metadataKey, target, propertyKey);
    }
    exporter("hasOwnMetadata", hasOwnMetadata);
    /**
     * Gets the metadata value for the provided metadata key on the target object or its prototype chain.
     * @param metadataKey A key used to store and retrieve metadata.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns The metadata value for the metadata key if found; otherwise, `undefined`.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.getMetadata("custom:annotation", Example);
     *
     *     // property (on constructor)
     *     result = Reflect.getMetadata("custom:annotation", Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.getMetadata("custom:annotation", Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.getMetadata("custom:annotation", Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.getMetadata("custom:annotation", Example.prototype, "method");
     *
     */
    function getMetadata(metadataKey, target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryGetMetadata(metadataKey, target, propertyKey);
    }
    exporter("getMetadata", getMetadata);
    /**
     * Gets the metadata value for the provided metadata key on the target object.
     * @param metadataKey A key used to store and retrieve metadata.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns The metadata value for the metadata key if found; otherwise, `undefined`.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.getOwnMetadata("custom:annotation", Example);
     *
     *     // property (on constructor)
     *     result = Reflect.getOwnMetadata("custom:annotation", Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.getOwnMetadata("custom:annotation", Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.getOwnMetadata("custom:annotation", Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.getOwnMetadata("custom:annotation", Example.prototype, "method");
     *
     */
    function getOwnMetadata(metadataKey, target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryGetOwnMetadata(metadataKey, target, propertyKey);
    }
    exporter("getOwnMetadata", getOwnMetadata);
    /**
     * Gets the metadata keys defined on the target object or its prototype chain.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns An array of unique metadata keys.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.getMetadataKeys(Example);
     *
     *     // property (on constructor)
     *     result = Reflect.getMetadataKeys(Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.getMetadataKeys(Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.getMetadataKeys(Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.getMetadataKeys(Example.prototype, "method");
     *
     */
    function getMetadataKeys(target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryMetadataKeys(target, propertyKey);
    }
    exporter("getMetadataKeys", getMetadataKeys);
    /**
     * Gets the unique metadata keys defined on the target object.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns An array of unique metadata keys.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.getOwnMetadataKeys(Example);
     *
     *     // property (on constructor)
     *     result = Reflect.getOwnMetadataKeys(Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.getOwnMetadataKeys(Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.getOwnMetadataKeys(Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.getOwnMetadataKeys(Example.prototype, "method");
     *
     */
    function getOwnMetadataKeys(target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryOwnMetadataKeys(target, propertyKey);
    }
    exporter("getOwnMetadataKeys", getOwnMetadataKeys);
    /**
     * Deletes the metadata entry from the target object with the provided key.
     * @param metadataKey A key used to store and retrieve metadata.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns `true` if the metadata entry was found and deleted; otherwise, false.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.deleteMetadata("custom:annotation", Example);
     *
     *     // property (on constructor)
     *     result = Reflect.deleteMetadata("custom:annotation", Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.deleteMetadata("custom:annotation", Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.deleteMetadata("custom:annotation", Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.deleteMetadata("custom:annotation", Example.prototype, "method");
     *
     */
    function deleteMetadata(metadataKey, target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      var metadataMap = GetOrCreateMetadataMap(target, propertyKey, /*Create*/false);
      if (IsUndefined(metadataMap)) return false;
      if (!metadataMap.delete(metadataKey)) return false;
      if (metadataMap.size > 0) return true;
      var targetMetadata = Metadata.get(target);
      targetMetadata.delete(propertyKey);
      if (targetMetadata.size > 0) return true;
      Metadata.delete(target);
      return true;
    }
    exporter("deleteMetadata", deleteMetadata);
    function DecorateConstructor(decorators, target) {
      for (var i = decorators.length - 1; i >= 0; --i) {
        var decorator = decorators[i];
        var decorated = decorator(target);
        if (!IsUndefined(decorated) && !IsNull(decorated)) {
          if (!IsConstructor(decorated)) throw new TypeError();
          target = decorated;
        }
      }
      return target;
    }
    function DecorateProperty(decorators, target, propertyKey, descriptor) {
      for (var i = decorators.length - 1; i >= 0; --i) {
        var decorator = decorators[i];
        var decorated = decorator(target, propertyKey, descriptor);
        if (!IsUndefined(decorated) && !IsNull(decorated)) {
          if (!IsObject(decorated)) throw new TypeError();
          descriptor = decorated;
        }
      }
      return descriptor;
    }
    function GetOrCreateMetadataMap(O, P, Create) {
      var targetMetadata = Metadata.get(O);
      if (IsUndefined(targetMetadata)) {
        if (!Create) return undefined;
        targetMetadata = new _Map();
        Metadata.set(O, targetMetadata);
      }
      var metadataMap = targetMetadata.get(P);
      if (IsUndefined(metadataMap)) {
        if (!Create) return undefined;
        metadataMap = new _Map();
        targetMetadata.set(P, metadataMap);
      }
      return metadataMap;
    }
    // 3.1.1.1 OrdinaryHasMetadata(MetadataKey, O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinaryhasmetadata
    function OrdinaryHasMetadata(MetadataKey, O, P) {
      var hasOwn = OrdinaryHasOwnMetadata(MetadataKey, O, P);
      if (hasOwn) return true;
      var parent = OrdinaryGetPrototypeOf(O);
      if (!IsNull(parent)) return OrdinaryHasMetadata(MetadataKey, parent, P);
      return false;
    }
    // 3.1.2.1 OrdinaryHasOwnMetadata(MetadataKey, O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinaryhasownmetadata
    function OrdinaryHasOwnMetadata(MetadataKey, O, P) {
      var metadataMap = GetOrCreateMetadataMap(O, P, /*Create*/false);
      if (IsUndefined(metadataMap)) return false;
      return ToBoolean(metadataMap.has(MetadataKey));
    }
    // 3.1.3.1 OrdinaryGetMetadata(MetadataKey, O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinarygetmetadata
    function OrdinaryGetMetadata(MetadataKey, O, P) {
      var hasOwn = OrdinaryHasOwnMetadata(MetadataKey, O, P);
      if (hasOwn) return OrdinaryGetOwnMetadata(MetadataKey, O, P);
      var parent = OrdinaryGetPrototypeOf(O);
      if (!IsNull(parent)) return OrdinaryGetMetadata(MetadataKey, parent, P);
      return undefined;
    }
    // 3.1.4.1 OrdinaryGetOwnMetadata(MetadataKey, O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinarygetownmetadata
    function OrdinaryGetOwnMetadata(MetadataKey, O, P) {
      var metadataMap = GetOrCreateMetadataMap(O, P, /*Create*/false);
      if (IsUndefined(metadataMap)) return undefined;
      return metadataMap.get(MetadataKey);
    }
    // 3.1.5.1 OrdinaryDefineOwnMetadata(MetadataKey, MetadataValue, O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinarydefineownmetadata
    function OrdinaryDefineOwnMetadata(MetadataKey, MetadataValue, O, P) {
      var metadataMap = GetOrCreateMetadataMap(O, P, /*Create*/true);
      metadataMap.set(MetadataKey, MetadataValue);
    }
    // 3.1.6.1 OrdinaryMetadataKeys(O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinarymetadatakeys
    function OrdinaryMetadataKeys(O, P) {
      var ownKeys = OrdinaryOwnMetadataKeys(O, P);
      var parent = OrdinaryGetPrototypeOf(O);
      if (parent === null) return ownKeys;
      var parentKeys = OrdinaryMetadataKeys(parent, P);
      if (parentKeys.length <= 0) return ownKeys;
      if (ownKeys.length <= 0) return parentKeys;
      var set = new _Set();
      var keys = [];
      for (var _i = 0, ownKeys_1 = ownKeys; _i < ownKeys_1.length; _i++) {
        var key = ownKeys_1[_i];
        var hasKey = set.has(key);
        if (!hasKey) {
          set.add(key);
          keys.push(key);
        }
      }
      for (var _a = 0, parentKeys_1 = parentKeys; _a < parentKeys_1.length; _a++) {
        var key = parentKeys_1[_a];
        var hasKey = set.has(key);
        if (!hasKey) {
          set.add(key);
          keys.push(key);
        }
      }
      return keys;
    }
    // 3.1.7.1 OrdinaryOwnMetadataKeys(O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinaryownmetadatakeys
    function OrdinaryOwnMetadataKeys(O, P) {
      var keys = [];
      var metadataMap = GetOrCreateMetadataMap(O, P, /*Create*/false);
      if (IsUndefined(metadataMap)) return keys;
      var keysObj = metadataMap.keys();
      var iterator = GetIterator(keysObj);
      var k = 0;
      while (true) {
        var next = IteratorStep(iterator);
        if (!next) {
          keys.length = k;
          return keys;
        }
        var nextValue = IteratorValue(next);
        try {
          keys[k] = nextValue;
        } catch (e) {
          try {
            IteratorClose(iterator);
          } finally {
            throw e;
          }
        }
        k++;
      }
    }
    // 6 ECMAScript Data Typ0es and Values
    // https://tc39.github.io/ecma262/#sec-ecmascript-data-types-and-values
    function Type(x) {
      if (x === null) return 1 /* Null */;
      switch (_typeof(x)) {
        case "undefined":
          return 0 /* Undefined */;
        case "boolean":
          return 2 /* Boolean */;
        case "string":
          return 3 /* String */;
        case "symbol":
          return 4 /* Symbol */;
        case "number":
          return 5 /* Number */;
        case "object":
          return x === null ? 1 /* Null */ : 6 /* Object */;
        default:
          return 6 /* Object */;
      }
    }
    // 6.1.1 The Undefined Type
    // https://tc39.github.io/ecma262/#sec-ecmascript-language-types-undefined-type
    function IsUndefined(x) {
      return x === undefined;
    }
    // 6.1.2 The Null Type
    // https://tc39.github.io/ecma262/#sec-ecmascript-language-types-null-type
    function IsNull(x) {
      return x === null;
    }
    // 6.1.5 The Symbol Type
    // https://tc39.github.io/ecma262/#sec-ecmascript-language-types-symbol-type
    function IsSymbol(x) {
      return _typeof(x) === "symbol";
    }
    // 6.1.7 The Object Type
    // https://tc39.github.io/ecma262/#sec-object-type
    function IsObject(x) {
      return _typeof(x) === "object" ? x !== null : typeof x === "function";
    }
    // 7.1 Type Conversion
    // https://tc39.github.io/ecma262/#sec-type-conversion
    // 7.1.1 ToPrimitive(input [, PreferredType])
    // https://tc39.github.io/ecma262/#sec-toprimitive
    function ToPrimitive(input, PreferredType) {
      switch (Type(input)) {
        case 0 /* Undefined */:
          return input;
        case 1 /* Null */:
          return input;
        case 2 /* Boolean */:
          return input;
        case 3 /* String */:
          return input;
        case 4 /* Symbol */:
          return input;
        case 5 /* Number */:
          return input;
      }
      var hint = PreferredType === 3 /* String */ ? "string" : PreferredType === 5 /* Number */ ? "number" : "default";
      var exoticToPrim = GetMethod(input, toPrimitiveSymbol);
      if (exoticToPrim !== undefined) {
        var result = exoticToPrim.call(input, hint);
        if (IsObject(result)) throw new TypeError();
        return result;
      }
      return OrdinaryToPrimitive(input, hint === "default" ? "number" : hint);
    }
    // 7.1.1.1 OrdinaryToPrimitive(O, hint)
    // https://tc39.github.io/ecma262/#sec-ordinarytoprimitive
    function OrdinaryToPrimitive(O, hint) {
      if (hint === "string") {
        var toString_1 = O.toString;
        if (IsCallable(toString_1)) {
          var result = toString_1.call(O);
          if (!IsObject(result)) return result;
        }
        var valueOf = O.valueOf;
        if (IsCallable(valueOf)) {
          var result = valueOf.call(O);
          if (!IsObject(result)) return result;
        }
      } else {
        var valueOf = O.valueOf;
        if (IsCallable(valueOf)) {
          var result = valueOf.call(O);
          if (!IsObject(result)) return result;
        }
        var toString_2 = O.toString;
        if (IsCallable(toString_2)) {
          var result = toString_2.call(O);
          if (!IsObject(result)) return result;
        }
      }
      throw new TypeError();
    }
    // 7.1.2 ToBoolean(argument)
    // https://tc39.github.io/ecma262/2016/#sec-toboolean
    function ToBoolean(argument) {
      return !!argument;
    }
    // 7.1.12 ToString(argument)
    // https://tc39.github.io/ecma262/#sec-tostring
    function ToString(argument) {
      return "" + argument;
    }
    // 7.1.14 ToPropertyKey(argument)
    // https://tc39.github.io/ecma262/#sec-topropertykey
    function ToPropertyKey(argument) {
      var key = ToPrimitive(argument, 3 /* String */);
      if (IsSymbol(key)) return key;
      return ToString(key);
    }
    // 7.2 Testing and Comparison Operations
    // https://tc39.github.io/ecma262/#sec-testing-and-comparison-operations
    // 7.2.2 IsArray(argument)
    // https://tc39.github.io/ecma262/#sec-isarray
    function IsArray(argument) {
      return Array.isArray ? Array.isArray(argument) : argument instanceof Object ? argument instanceof Array : Object.prototype.toString.call(argument) === "[object Array]";
    }
    // 7.2.3 IsCallable(argument)
    // https://tc39.github.io/ecma262/#sec-iscallable
    function IsCallable(argument) {
      // NOTE: This is an approximation as we cannot check for [[Call]] internal method.
      return typeof argument === "function";
    }
    // 7.2.4 IsConstructor(argument)
    // https://tc39.github.io/ecma262/#sec-isconstructor
    function IsConstructor(argument) {
      // NOTE: This is an approximation as we cannot check for [[Construct]] internal method.
      return typeof argument === "function";
    }
    // 7.2.7 IsPropertyKey(argument)
    // https://tc39.github.io/ecma262/#sec-ispropertykey
    function IsPropertyKey(argument) {
      switch (Type(argument)) {
        case 3 /* String */:
          return true;
        case 4 /* Symbol */:
          return true;
        default:
          return false;
      }
    }
    // 7.3 Operations on Objects
    // https://tc39.github.io/ecma262/#sec-operations-on-objects
    // 7.3.9 GetMethod(V, P)
    // https://tc39.github.io/ecma262/#sec-getmethod
    function GetMethod(V, P) {
      var func = V[P];
      if (func === undefined || func === null) return undefined;
      if (!IsCallable(func)) throw new TypeError();
      return func;
    }
    // 7.4 Operations on Iterator Objects
    // https://tc39.github.io/ecma262/#sec-operations-on-iterator-objects
    function GetIterator(obj) {
      var method = GetMethod(obj, iteratorSymbol);
      if (!IsCallable(method)) throw new TypeError(); // from Call
      var iterator = method.call(obj);
      if (!IsObject(iterator)) throw new TypeError();
      return iterator;
    }
    // 7.4.4 IteratorValue(iterResult)
    // https://tc39.github.io/ecma262/2016/#sec-iteratorvalue
    function IteratorValue(iterResult) {
      return iterResult.value;
    }
    // 7.4.5 IteratorStep(iterator)
    // https://tc39.github.io/ecma262/#sec-iteratorstep
    function IteratorStep(iterator) {
      var result = iterator.next();
      return result.done ? false : result;
    }
    // 7.4.6 IteratorClose(iterator, completion)
    // https://tc39.github.io/ecma262/#sec-iteratorclose
    function IteratorClose(iterator) {
      var f = iterator["return"];
      if (f) f.call(iterator);
    }
    // 9.1 Ordinary Object Internal Methods and Internal Slots
    // https://tc39.github.io/ecma262/#sec-ordinary-object-internal-methods-and-internal-slots
    // 9.1.1.1 OrdinaryGetPrototypeOf(O)
    // https://tc39.github.io/ecma262/#sec-ordinarygetprototypeof
    function OrdinaryGetPrototypeOf(O) {
      var proto = Object.getPrototypeOf(O);
      if (typeof O !== "function" || O === functionPrototype) return proto;
      // TypeScript doesn't set __proto__ in ES5, as it's non-standard.
      // Try to determine the superclass constructor. Compatible implementations
      // must either set __proto__ on a subclass constructor to the superclass constructor,
      // or ensure each class has a valid `constructor` property on its prototype that
      // points back to the constructor.
      // If this is not the same as Function.[[Prototype]], then this is definately inherited.
      // This is the case when in ES6 or when using __proto__ in a compatible browser.
      if (proto !== functionPrototype) return proto;
      // If the super prototype is Object.prototype, null, or undefined, then we cannot determine the heritage.
      var prototype = O.prototype;
      var prototypeProto = prototype && Object.getPrototypeOf(prototype);
      if (prototypeProto == null || prototypeProto === Object.prototype) return proto;
      // If the constructor was not a function, then we cannot determine the heritage.
      var constructor = prototypeProto.constructor;
      if (typeof constructor !== "function") return proto;
      // If we have some kind of self-reference, then we cannot determine the heritage.
      if (constructor === O) return proto;
      // we have a pretty good guess at the heritage.
      return constructor;
    }
    // naive Map shim
    function CreateMapPolyfill() {
      var cacheSentinel = {};
      var arraySentinel = [];
      var MapIterator = /** @class */function () {
        function MapIterator(keys, values, selector) {
          this._index = 0;
          this._keys = keys;
          this._values = values;
          this._selector = selector;
        }
        MapIterator.prototype["@@iterator"] = function () {
          return this;
        };
        MapIterator.prototype[iteratorSymbol] = function () {
          return this;
        };
        MapIterator.prototype.next = function () {
          var index = this._index;
          if (index >= 0 && index < this._keys.length) {
            var result = this._selector(this._keys[index], this._values[index]);
            if (index + 1 >= this._keys.length) {
              this._index = -1;
              this._keys = arraySentinel;
              this._values = arraySentinel;
            } else {
              this._index++;
            }
            return {
              value: result,
              done: false
            };
          }
          return {
            value: undefined,
            done: true
          };
        };
        MapIterator.prototype.throw = function (error) {
          if (this._index >= 0) {
            this._index = -1;
            this._keys = arraySentinel;
            this._values = arraySentinel;
          }
          throw error;
        };
        MapIterator.prototype.return = function (value) {
          if (this._index >= 0) {
            this._index = -1;
            this._keys = arraySentinel;
            this._values = arraySentinel;
          }
          return {
            value: value,
            done: true
          };
        };
        return MapIterator;
      }();
      return /** @class */function () {
        function Map() {
          this._keys = [];
          this._values = [];
          this._cacheKey = cacheSentinel;
          this._cacheIndex = -2;
        }
        Object.defineProperty(Map.prototype, "size", {
          get: function get() {
            return this._keys.length;
          },
          enumerable: true,
          configurable: true
        });
        Map.prototype.has = function (key) {
          return this._find(key, /*insert*/false) >= 0;
        };
        Map.prototype.get = function (key) {
          var index = this._find(key, /*insert*/false);
          return index >= 0 ? this._values[index] : undefined;
        };
        Map.prototype.set = function (key, value) {
          var index = this._find(key, /*insert*/true);
          this._values[index] = value;
          return this;
        };
        Map.prototype.delete = function (key) {
          var index = this._find(key, /*insert*/false);
          if (index >= 0) {
            var size = this._keys.length;
            for (var i = index + 1; i < size; i++) {
              this._keys[i - 1] = this._keys[i];
              this._values[i - 1] = this._values[i];
            }
            this._keys.length--;
            this._values.length--;
            if (key === this._cacheKey) {
              this._cacheKey = cacheSentinel;
              this._cacheIndex = -2;
            }
            return true;
          }
          return false;
        };
        Map.prototype.clear = function () {
          this._keys.length = 0;
          this._values.length = 0;
          this._cacheKey = cacheSentinel;
          this._cacheIndex = -2;
        };
        Map.prototype.keys = function () {
          return new MapIterator(this._keys, this._values, getKey);
        };
        Map.prototype.values = function () {
          return new MapIterator(this._keys, this._values, getValue);
        };
        Map.prototype.entries = function () {
          return new MapIterator(this._keys, this._values, getEntry);
        };
        Map.prototype["@@iterator"] = function () {
          return this.entries();
        };
        Map.prototype[iteratorSymbol] = function () {
          return this.entries();
        };
        Map.prototype._find = function (key, insert) {
          if (this._cacheKey !== key) {
            this._cacheIndex = this._keys.indexOf(this._cacheKey = key);
          }
          if (this._cacheIndex < 0 && insert) {
            this._cacheIndex = this._keys.length;
            this._keys.push(key);
            this._values.push(undefined);
          }
          return this._cacheIndex;
        };
        return Map;
      }();
      function getKey(key, _) {
        return key;
      }
      function getValue(_, value) {
        return value;
      }
      function getEntry(key, value) {
        return [key, value];
      }
    }
    // naive Set shim
    function CreateSetPolyfill() {
      return /** @class */function () {
        function Set() {
          this._map = new _Map();
        }
        Object.defineProperty(Set.prototype, "size", {
          get: function get() {
            return this._map.size;
          },
          enumerable: true,
          configurable: true
        });
        Set.prototype.has = function (value) {
          return this._map.has(value);
        };
        Set.prototype.add = function (value) {
          return this._map.set(value, value), this;
        };
        Set.prototype.delete = function (value) {
          return this._map.delete(value);
        };
        Set.prototype.clear = function () {
          this._map.clear();
        };
        Set.prototype.keys = function () {
          return this._map.keys();
        };
        Set.prototype.values = function () {
          return this._map.values();
        };
        Set.prototype.entries = function () {
          return this._map.entries();
        };
        Set.prototype["@@iterator"] = function () {
          return this.keys();
        };
        Set.prototype[iteratorSymbol] = function () {
          return this.keys();
        };
        return Set;
      }();
    }
    // naive WeakMap shim
    function CreateWeakMapPolyfill() {
      var UUID_SIZE = 16;
      var keys = HashMap.create();
      var rootKey = CreateUniqueKey();
      return /** @class */function () {
        function WeakMap() {
          this._key = CreateUniqueKey();
        }
        WeakMap.prototype.has = function (target) {
          var table = GetOrCreateWeakMapTable(target, /*create*/false);
          return table !== undefined ? HashMap.has(table, this._key) : false;
        };
        WeakMap.prototype.get = function (target) {
          var table = GetOrCreateWeakMapTable(target, /*create*/false);
          return table !== undefined ? HashMap.get(table, this._key) : undefined;
        };
        WeakMap.prototype.set = function (target, value) {
          var table = GetOrCreateWeakMapTable(target, /*create*/true);
          table[this._key] = value;
          return this;
        };
        WeakMap.prototype.delete = function (target) {
          var table = GetOrCreateWeakMapTable(target, /*create*/false);
          return table !== undefined ? delete table[this._key] : false;
        };
        WeakMap.prototype.clear = function () {
          // NOTE: not a real clear, just makes the previous data unreachable
          this._key = CreateUniqueKey();
        };
        return WeakMap;
      }();
      function CreateUniqueKey() {
        var key;
        do key = "@@WeakMap@@" + CreateUUID(); while (HashMap.has(keys, key));
        keys[key] = true;
        return key;
      }
      function GetOrCreateWeakMapTable(target, create) {
        if (!hasOwn.call(target, rootKey)) {
          if (!create) return undefined;
          Object.defineProperty(target, rootKey, {
            value: HashMap.create()
          });
        }
        return target[rootKey];
      }
      function FillRandomBytes(buffer, size) {
        for (var i = 0; i < size; ++i) buffer[i] = Math.random() * 0xff | 0;
        return buffer;
      }
      function GenRandomBytes(size) {
        if (typeof Uint8Array === "function") {
          if (typeof crypto !== "undefined") return crypto.getRandomValues(new Uint8Array(size));
          if (typeof msCrypto !== "undefined") return msCrypto.getRandomValues(new Uint8Array(size));
          return FillRandomBytes(new Uint8Array(size), size);
        }
        return FillRandomBytes(new Array(size), size);
      }
      function CreateUUID() {
        var data = GenRandomBytes(UUID_SIZE);
        // mark as random - RFC 4122 § 4.4
        data[6] = data[6] & 0x4f | 0x40;
        data[8] = data[8] & 0xbf | 0x80;
        var result = "";
        for (var offset = 0; offset < UUID_SIZE; ++offset) {
          var byte = data[offset];
          if (offset === 4 || offset === 6 || offset === 8) result += "-";
          if (byte < 16) result += "0";
          result += byte.toString(16).toLowerCase();
        }
        return result;
      }
    }
    // uses a heuristic used by v8 and chakra to force an object into dictionary mode.
    function MakeDictionary(obj) {
      obj.__ = undefined;
      delete obj.__;
      return obj;
    }
  });
})(Reflect || (Reflect = {}));

/***/ }),

/***/ "./node_modules/regenerator-runtime/runtime.js":
/*!*****************************************************!*\
  !*** ./node_modules/regenerator-runtime/runtime.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/* module decorator */ module = __webpack_require__.nmd(module);
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
/**
 * Copyright (c) 2014, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * https://raw.github.com/facebook/regenerator/master/LICENSE file. An
 * additional grant of patent rights can be found in the PATENTS file in
 * the same directory.
 */

!function (global) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
  var inModule = ( false ? 0 : _typeof(module)) === "object";
  var runtime = global.regeneratorRuntime;
  if (runtime) {
    if (inModule) {
      // If regeneratorRuntime is defined globally and we're in a module,
      // make the exports object identical to regeneratorRuntime.
      module.exports = runtime;
    }
    // Don't bother evaluating the rest of this file if the runtime was
    // already defined globally.
    return;
  }

  // Define the runtime globally (as expected by generated code) as either
  // module.exports (if we're in a module) or a new, empty object.
  runtime = global.regeneratorRuntime = inModule ? module.exports : {};
  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);
    return generator;
  }
  runtime.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return {
        type: "normal",
        arg: fn.call(obj, arg)
      };
    } catch (err) {
      return {
        type: "throw",
        arg: err
      };
    }
  }
  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };
  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }
  var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunctionPrototype[toStringTagSymbol] = GeneratorFunction.displayName = "GeneratorFunction";

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function (method) {
      prototype[method] = function (arg) {
        return this._invoke(method, arg);
      };
    });
  }
  runtime.isGeneratorFunction = function (genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor ? ctor === GeneratorFunction ||
    // For the native GeneratorFunction constructor, the best we can
    // do is to check its .name property.
    (ctor.displayName || ctor.name) === "GeneratorFunction" : false;
  };
  runtime.mark = function (genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      if (!(toStringTagSymbol in genFun)) {
        genFun[toStringTagSymbol] = "GeneratorFunction";
      }
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  runtime.awrap = function (arg) {
    return {
      __await: arg
    };
  };
  function AsyncIterator(generator) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value && _typeof(value) === "object" && hasOwn.call(value, "__await")) {
          return Promise.resolve(value.__await).then(function (value) {
            invoke("next", value, resolve, reject);
          }, function (err) {
            invoke("throw", err, resolve, reject);
          });
        }
        return Promise.resolve(value).then(function (unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration. If the Promise is rejected, however, the
          // result for this iteration will be rejected with the same
          // reason. Note that rejections of yielded Promises are not
          // thrown back into the generator function, as is the case
          // when an awaited Promise is rejected. This difference in
          // behavior between yield and await is important, because it
          // allows the consumer to decide what to do with the yielded
          // rejection (swallow it and continue, manually .throw it back
          // into the generator, abandon iteration, whatever). With
          // await, by contrast, there is no opportunity to examine the
          // rejection reason outside the generator function, so the
          // only option is to throw it from the await expression, and
          // let the generator function handle the exception.
          result.value = unwrapped;
          resolve(result);
        }, reject);
      }
    }
    if (_typeof(global.process) === "object" && global.process.domain) {
      invoke = global.process.domain.bind(invoke);
    }
    var previousPromise;
    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new Promise(function (resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }
      return previousPromise =
      // If enqueue has been called before, then we want to wait until
      // all previous Promises have been resolved before calling invoke,
      // so that results are always delivered in the correct order. If
      // enqueue has not been called before, then it is important to
      // call invoke immediately, without waiting on a callback to fire,
      // so that the async generator function has the opportunity to do
      // any necessary setup in a predictable way. This predictability
      // is why the Promise constructor synchronously invokes its
      // executor callback, and why async functions synchronously
      // execute code before the first await. Since we implement simple
      // async functions in terms of async generators, it is especially
      // important to get this right, even though it requires care.
      previousPromise ? previousPromise.then(callInvokeWithMethodAndArg,
      // Avoid propagating failures to Promises returned by later
      // invocations of the iterator.
      callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }
  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  runtime.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  runtime.async = function (innerFn, outerFn, self, tryLocsList) {
    var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList));
    return runtime.isGeneratorFunction(outerFn) ? iter // If outerFn is a generator, return the full iterator.
    : iter.next().then(function (result) {
      return result.done ? result.value : iter.next();
    });
  };
  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;
    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }
      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }
      context.method = method;
      context.arg = arg;
      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }
        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;
        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }
          context.dispatchException(context.arg);
        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }
        state = GenStateExecuting;
        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done ? GenStateCompleted : GenStateSuspendedYield;
          if (record.arg === ContinueSentinel) {
            continue;
          }
          return {
            value: record.arg,
            done: context.done
          };
        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;
      if (context.method === "throw") {
        if (delegate.iterator.return) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);
          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }
        context.method = "throw";
        context.arg = new TypeError("The iterator does not provide a 'throw' method");
      }
      return ContinueSentinel;
    }
    var record = tryCatch(method, delegate.iterator, context.arg);
    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }
    var info = record.arg;
    if (!info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }
    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }
    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);
  Gp[toStringTagSymbol] = "Generator";

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function () {
    return this;
  };
  Gp.toString = function () {
    return "[object Generator]";
  };
  function pushTryEntry(locs) {
    var entry = {
      tryLoc: locs[0]
    };
    if (1 in locs) {
      entry.catchLoc = locs[1];
    }
    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }
    this.tryEntries.push(entry);
  }
  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }
  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{
      tryLoc: "root"
    }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }
  runtime.keys = function (object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };
  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }
      if (typeof iterable.next === "function") {
        return iterable;
      }
      if (!isNaN(iterable.length)) {
        var i = -1,
          next = function next() {
            while (++i < iterable.length) {
              if (hasOwn.call(iterable, i)) {
                next.value = iterable[i];
                next.done = false;
                return next;
              }
            }
            next.value = undefined;
            next.done = true;
            return next;
          };
        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return {
      next: doneResult
    };
  }
  runtime.values = values;
  function doneResult() {
    return {
      value: undefined,
      done: true
    };
  }
  Context.prototype = {
    constructor: Context,
    reset: function reset(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;
      this.method = "next";
      this.arg = undefined;
      this.tryEntries.forEach(resetTryEntry);
      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" && hasOwn.call(this, name) && !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },
    stop: function stop() {
      this.done = true;
      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }
      return this.rval;
    },
    dispatchException: function dispatchException(exception) {
      if (this.done) {
        throw exception;
      }
      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;
        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }
        return !!caught;
      }
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;
        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }
        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");
          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }
          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }
          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }
          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },
    abrupt: function abrupt(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }
      if (finallyEntry && (type === "break" || type === "continue") && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }
      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;
      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }
      return this.complete(record);
    },
    complete: function complete(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }
      if (record.type === "break" || record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }
      return ContinueSentinel;
    },
    finish: function finish(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },
    "catch": function _catch(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },
    delegateYield: function delegateYield(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };
      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }
      return ContinueSentinel;
    }
  };
}(
// Among the various tricks for obtaining a reference to the global
// object, this seems to be the most reliable technique that does not
// use indirect eval (which violates Content Security Policy).
(typeof __webpack_require__.g === "undefined" ? "undefined" : _typeof(__webpack_require__.g)) === "object" ? __webpack_require__.g : (typeof window === "undefined" ? "undefined" : _typeof(window)) === "object" ? window : (typeof self === "undefined" ? "undefined" : _typeof(self)) === "object" ? self : this);

/***/ }),

/***/ "./node_modules/ts-mixer/dist/esm/index.js":
/*!*************************************************!*\
  !*** ./node_modules/ts-mixer/dist/esm/index.js ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Mixin: function() { return /* binding */ Mixin; },
/* harmony export */   decorate: function() { return /* binding */ decorate; },
/* harmony export */   hasMixin: function() { return /* binding */ hasMixin; },
/* harmony export */   mix: function() { return /* binding */ mix; },
/* harmony export */   settings: function() { return /* binding */ settings; }
/* harmony export */ });
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _construct(t, e, r) { if (_isNativeReflectConstruct()) return Reflect.construct.apply(null, arguments); var o = [null]; o.push.apply(o, e); var p = new (t.bind.apply(t, o))(); return r && _setPrototypeOf(p, r.prototype), p; }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _toConsumableArray(r) { return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArray(r) { if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r); }
function _arrayWithoutHoles(r) { if (Array.isArray(r)) return _arrayLikeToArray(r); }
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
/**
 * Utility function that works like `Object.apply`, but copies getters and setters properly as well.  Additionally gives
 * the option to exclude properties by name.
 */
var copyProps = function copyProps(dest, src) {
  var exclude = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
  var props = Object.getOwnPropertyDescriptors(src);
  var _iterator = _createForOfIteratorHelper(exclude),
    _step;
  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var prop = _step.value;
      delete props[prop];
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  Object.defineProperties(dest, props);
};
/**
 * Returns the full chain of prototypes up until Object.prototype given a starting object.  The order of prototypes will
 * be closest to farthest in the chain.
 */
var _protoChain = function protoChain(obj) {
  var currentChain = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [obj];
  var proto = Object.getPrototypeOf(obj);
  if (proto === null) return currentChain;
  return _protoChain(proto, [].concat(_toConsumableArray(currentChain), [proto]));
};
/**
 * Identifies the nearest ancestor common to all the given objects in their prototype chains.  For most unrelated
 * objects, this function should return Object.prototype.
 */
var nearestCommonProto = function nearestCommonProto() {
  for (var _len = arguments.length, objs = new Array(_len), _key = 0; _key < _len; _key++) {
    objs[_key] = arguments[_key];
  }
  if (objs.length === 0) return undefined;
  var commonProto = undefined;
  var protoChains = objs.map(function (obj) {
    return _protoChain(obj);
  });
  var _loop = function _loop() {
    var protos = protoChains.map(function (protoChain) {
      return protoChain.pop();
    });
    var potentialCommonProto = protos[0];
    if (protos.every(function (proto) {
      return proto === potentialCommonProto;
    })) commonProto = potentialCommonProto;else return 1; // break
  };
  while (protoChains.every(function (protoChain) {
    return protoChain.length > 0;
  })) {
    if (_loop()) break;
  }
  return commonProto;
};
/**
 * Creates a new prototype object that is a mixture of the given prototypes.  The mixing is achieved by first
 * identifying the nearest common ancestor and using it as the prototype for a new object.  Then all properties/methods
 * downstream of this prototype (ONLY downstream) are copied into the new object.
 *
 * The resulting prototype is more performant than softMixProtos(...), as well as ES5 compatible.  However, it's not as
 * flexible as updates to the source prototypes aren't captured by the mixed result.  See softMixProtos for why you may
 * want to use that instead.
 */
var hardMixProtos = function hardMixProtos(ingredients, constructor) {
  var exclude = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
  var _a;
  var base = (_a = nearestCommonProto.apply(void 0, _toConsumableArray(ingredients))) !== null && _a !== void 0 ? _a : Object.prototype;
  var mixedProto = Object.create(base);
  // Keeps track of prototypes we've already visited to avoid copying the same properties multiple times.  We init the
  // list with the proto chain below the nearest common ancestor because we don't want any of those methods mixed in
  // when they will already be accessible via prototype access.
  var visitedProtos = _protoChain(base);
  var _iterator2 = _createForOfIteratorHelper(ingredients),
    _step2;
  try {
    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
      var prototype = _step2.value;
      var protos = _protoChain(prototype);
      // Apply the prototype chain in reverse order so that old methods don't override newer ones.
      for (var i = protos.length - 1; i >= 0; i--) {
        var newProto = protos[i];
        if (visitedProtos.indexOf(newProto) === -1) {
          copyProps(mixedProto, newProto, ['constructor'].concat(_toConsumableArray(exclude)));
          visitedProtos.push(newProto);
        }
      }
    }
  } catch (err) {
    _iterator2.e(err);
  } finally {
    _iterator2.f();
  }
  mixedProto.constructor = constructor;
  return mixedProto;
};
var unique = function unique(arr) {
  return arr.filter(function (e, i) {
    return arr.indexOf(e) == i;
  });
};

/**
 * Finds the ingredient with the given prop, searching in reverse order and breadth-first if searching ingredient
 * prototypes is required.
 */
var getIngredientWithProp = function getIngredientWithProp(prop, ingredients) {
  var protoChains = ingredients.map(function (ingredient) {
    return _protoChain(ingredient);
  });
  // since we search breadth-first, we need to keep track of our depth in the prototype chains
  var protoDepth = 0;
  // not all prototype chains are the same depth, so this remains true as long as at least one of the ingredients'
  // prototype chains has an object at this depth
  var protosAreLeftToSearch = true;
  while (protosAreLeftToSearch) {
    // with the start of each horizontal slice, we assume this is the one that's deeper than any of the proto chains
    protosAreLeftToSearch = false;
    // scan through the ingredients right to left
    for (var i = ingredients.length - 1; i >= 0; i--) {
      var searchTarget = protoChains[i][protoDepth];
      if (searchTarget !== undefined && searchTarget !== null) {
        // if we find something, this is proof that this horizontal slice potentially more objects to search
        protosAreLeftToSearch = true;
        // eureka, we found it
        if (Object.getOwnPropertyDescriptor(searchTarget, prop) != undefined) {
          return protoChains[i][0];
        }
      }
    }
    protoDepth++;
  }
  return undefined;
};
/**
 * "Mixes" ingredients by wrapping them in a Proxy.  The optional prototype argument allows the mixed object to sit
 * downstream of an existing prototype chain.  Note that "properties" cannot be added, deleted, or modified.
 */
var proxyMix = function proxyMix(ingredients) {
  var prototype = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : Object.prototype;
  return new Proxy({}, {
    getPrototypeOf: function getPrototypeOf() {
      return prototype;
    },
    setPrototypeOf: function setPrototypeOf() {
      throw Error('Cannot set prototype of Proxies created by ts-mixer');
    },
    getOwnPropertyDescriptor: function getOwnPropertyDescriptor(_, prop) {
      return Object.getOwnPropertyDescriptor(getIngredientWithProp(prop, ingredients) || {}, prop);
    },
    defineProperty: function defineProperty() {
      throw new Error('Cannot define new properties on Proxies created by ts-mixer');
    },
    has: function has(_, prop) {
      return getIngredientWithProp(prop, ingredients) !== undefined || prototype[prop] !== undefined;
    },
    get: function get(_, prop) {
      return (getIngredientWithProp(prop, ingredients) || prototype)[prop];
    },
    set: function set(_, prop, val) {
      var ingredientWithProp = getIngredientWithProp(prop, ingredients);
      if (ingredientWithProp === undefined) throw new Error('Cannot set new properties on Proxies created by ts-mixer');
      ingredientWithProp[prop] = val;
      return true;
    },
    deleteProperty: function deleteProperty() {
      throw new Error('Cannot delete properties on Proxies created by ts-mixer');
    },
    ownKeys: function ownKeys() {
      return ingredients.map(Object.getOwnPropertyNames).reduce(function (prev, curr) {
        return curr.concat(prev.filter(function (key) {
          return curr.indexOf(key) < 0;
        }));
      });
    }
  });
};
/**
 * Creates a new proxy-prototype object that is a "soft" mixture of the given prototypes.  The mixing is achieved by
 * proxying all property access to the ingredients.  This is not ES5 compatible and less performant.  However, any
 * changes made to the source prototypes will be reflected in the proxy-prototype, which may be desirable.
 */
var softMixProtos = function softMixProtos(ingredients, constructor) {
  return proxyMix([].concat(_toConsumableArray(ingredients), [{
    constructor: constructor
  }]));
};
var settings = {
  initFunction: null,
  staticsStrategy: 'copy',
  prototypeStrategy: 'copy',
  decoratorInheritance: 'deep'
};

// Keeps track of constituent classes for every mixin class created by ts-mixer.
var mixins = new Map();
var getMixinsForClass = function getMixinsForClass(clazz) {
  return mixins.get(clazz);
};
var registerMixins = function registerMixins(mixedClass, constituents) {
  return mixins.set(mixedClass, constituents);
};
var hasMixin = function hasMixin(instance, mixin) {
  if (instance instanceof mixin) return true;
  var constructor = instance.constructor;
  var visited = new Set();
  var frontier = new Set();
  frontier.add(constructor);
  var _loop2 = function _loop2() {
      // check if the frontier has the mixin we're looking for.  if not, we can say we visited every item in the frontier
      if (frontier.has(mixin)) return {
        v: true
      };
      frontier.forEach(function (item) {
        return visited.add(item);
      });
      // build a new frontier based on the associated mixin classes and prototype chains of each frontier item
      var newFrontier = new Set();
      frontier.forEach(function (item) {
        var _a;
        var itemConstituents = (_a = mixins.get(item)) !== null && _a !== void 0 ? _a : _protoChain(item.prototype).map(function (proto) {
          return proto.constructor;
        }).filter(function (item) {
          return item !== null;
        });
        if (itemConstituents) itemConstituents.forEach(function (constituent) {
          if (!visited.has(constituent) && !frontier.has(constituent)) newFrontier.add(constituent);
        });
      });
      // we have a new frontier, now search again
      frontier = newFrontier;
    },
    _ret;
  while (frontier.size > 0) {
    _ret = _loop2();
    if (_ret) return _ret.v;
  }
  // if we get here, we couldn't find the mixin anywhere in the prototype chain or associated mixin classes
  return false;
};
var mergeObjectsOfDecorators = function mergeObjectsOfDecorators(o1, o2) {
  var _a, _b;
  var allKeys = unique([].concat(_toConsumableArray(Object.getOwnPropertyNames(o1)), _toConsumableArray(Object.getOwnPropertyNames(o2))));
  var mergedObject = {};
  var _iterator3 = _createForOfIteratorHelper(allKeys),
    _step3;
  try {
    for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
      var key = _step3.value;
      mergedObject[key] = unique([].concat(_toConsumableArray((_a = o1 === null || o1 === void 0 ? void 0 : o1[key]) !== null && _a !== void 0 ? _a : []), _toConsumableArray((_b = o2 === null || o2 === void 0 ? void 0 : o2[key]) !== null && _b !== void 0 ? _b : [])));
    }
  } catch (err) {
    _iterator3.e(err);
  } finally {
    _iterator3.f();
  }
  return mergedObject;
};
var mergePropertyAndMethodDecorators = function mergePropertyAndMethodDecorators(d1, d2) {
  var _a, _b, _c, _d;
  return {
    property: mergeObjectsOfDecorators((_a = d1 === null || d1 === void 0 ? void 0 : d1.property) !== null && _a !== void 0 ? _a : {}, (_b = d2 === null || d2 === void 0 ? void 0 : d2.property) !== null && _b !== void 0 ? _b : {}),
    method: mergeObjectsOfDecorators((_c = d1 === null || d1 === void 0 ? void 0 : d1.method) !== null && _c !== void 0 ? _c : {}, (_d = d2 === null || d2 === void 0 ? void 0 : d2.method) !== null && _d !== void 0 ? _d : {})
  };
};
var mergeDecorators = function mergeDecorators(d1, d2) {
  var _a, _b, _c, _d, _e, _f;
  return {
    class: unique([].concat(_toConsumableArray((_a = d1 === null || d1 === void 0 ? void 0 : d1.class) !== null && _a !== void 0 ? _a : []), _toConsumableArray((_b = d2 === null || d2 === void 0 ? void 0 : d2.class) !== null && _b !== void 0 ? _b : []))),
    static: mergePropertyAndMethodDecorators((_c = d1 === null || d1 === void 0 ? void 0 : d1.static) !== null && _c !== void 0 ? _c : {}, (_d = d2 === null || d2 === void 0 ? void 0 : d2.static) !== null && _d !== void 0 ? _d : {}),
    instance: mergePropertyAndMethodDecorators((_e = d1 === null || d1 === void 0 ? void 0 : d1.instance) !== null && _e !== void 0 ? _e : {}, (_f = d2 === null || d2 === void 0 ? void 0 : d2.instance) !== null && _f !== void 0 ? _f : {})
  };
};
var decorators = new Map();
var findAllConstituentClasses = function findAllConstituentClasses() {
  var _a;
  var allClasses = new Set();
  for (var _len2 = arguments.length, classes = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    classes[_key2] = arguments[_key2];
  }
  var frontier = new Set([].concat(classes));
  while (frontier.size > 0) {
    var _iterator4 = _createForOfIteratorHelper(frontier),
      _step4;
    try {
      for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
        var clazz = _step4.value;
        var protoChainClasses = _protoChain(clazz.prototype).map(function (proto) {
          return proto.constructor;
        });
        var mixinClasses = (_a = getMixinsForClass(clazz)) !== null && _a !== void 0 ? _a : [];
        var potentiallyNewClasses = [].concat(_toConsumableArray(protoChainClasses), _toConsumableArray(mixinClasses));
        var newClasses = potentiallyNewClasses.filter(function (c) {
          return !allClasses.has(c);
        });
        var _iterator5 = _createForOfIteratorHelper(newClasses),
          _step5;
        try {
          for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
            var newClass = _step5.value;
            frontier.add(newClass);
          }
        } catch (err) {
          _iterator5.e(err);
        } finally {
          _iterator5.f();
        }
        allClasses.add(clazz);
        frontier.delete(clazz);
      }
    } catch (err) {
      _iterator4.e(err);
    } finally {
      _iterator4.f();
    }
  }
  return _toConsumableArray(allClasses);
};
var deepDecoratorSearch = function deepDecoratorSearch() {
  var decoratorsForClassChain = findAllConstituentClasses.apply(void 0, arguments).map(function (clazz) {
    return decorators.get(clazz);
  }).filter(function (decorators) {
    return !!decorators;
  });
  if (decoratorsForClassChain.length == 0) return {};
  if (decoratorsForClassChain.length == 1) return decoratorsForClassChain[0];
  return decoratorsForClassChain.reduce(function (d1, d2) {
    return mergeDecorators(d1, d2);
  });
};
var directDecoratorSearch = function directDecoratorSearch() {
  for (var _len3 = arguments.length, classes = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
    classes[_key3] = arguments[_key3];
  }
  var classDecorators = classes.map(function (clazz) {
    return getDecoratorsForClass(clazz);
  });
  if (classDecorators.length === 0) return {};
  if (classDecorators.length === 1) return classDecorators[1];
  return classDecorators.reduce(function (d1, d2) {
    return mergeDecorators(d1, d2);
  });
};
var getDecoratorsForClass = function getDecoratorsForClass(clazz) {
  var decoratorsForClass = decorators.get(clazz);
  if (!decoratorsForClass) {
    decoratorsForClass = {};
    decorators.set(clazz, decoratorsForClass);
  }
  return decoratorsForClass;
};
var decorateClass = function decorateClass(decorator) {
  return function (clazz) {
    var decoratorsForClass = getDecoratorsForClass(clazz);
    var classDecorators = decoratorsForClass.class;
    if (!classDecorators) {
      classDecorators = [];
      decoratorsForClass.class = classDecorators;
    }
    classDecorators.push(decorator);
    return decorator(clazz);
  };
};
var decorateMember = function decorateMember(decorator) {
  return function (object, key) {
    var decoratorTargetType = typeof object === 'function' ? 'static' : 'instance';
    var decoratorType = typeof object[key] === 'function' ? 'method' : 'property';
    var clazz = decoratorTargetType === 'static' ? object : object.constructor;
    var decoratorsForClass = getDecoratorsForClass(clazz);
    var decoratorsForTargetType = decoratorsForClass === null || decoratorsForClass === void 0 ? void 0 : decoratorsForClass[decoratorTargetType];
    if (!decoratorsForTargetType) {
      decoratorsForTargetType = {};
      decoratorsForClass[decoratorTargetType] = decoratorsForTargetType;
    }
    var decoratorsForType = decoratorsForTargetType === null || decoratorsForTargetType === void 0 ? void 0 : decoratorsForTargetType[decoratorType];
    if (!decoratorsForType) {
      decoratorsForType = {};
      decoratorsForTargetType[decoratorType] = decoratorsForType;
    }
    var decoratorsForKey = decoratorsForType === null || decoratorsForType === void 0 ? void 0 : decoratorsForType[key];
    if (!decoratorsForKey) {
      decoratorsForKey = [];
      decoratorsForType[key] = decoratorsForKey;
    }
    decoratorsForKey.push(decorator);
    // @ts-ignore
    for (var _len4 = arguments.length, otherArgs = new Array(_len4 > 2 ? _len4 - 2 : 0), _key4 = 2; _key4 < _len4; _key4++) {
      otherArgs[_key4 - 2] = arguments[_key4];
    }
    return decorator.apply(void 0, [object, key].concat(otherArgs));
  };
};
var decorate = function decorate(decorator) {
  return function () {
    if (arguments.length === 1) return decorateClass(decorator)(arguments.length <= 0 ? undefined : arguments[0]);
    return decorateMember(decorator).apply(void 0, arguments);
  };
};
function Mixin() {
  for (var _len5 = arguments.length, constructors = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
    constructors[_key5] = arguments[_key5];
  }
  var _a, _b, _c;
  var prototypes = constructors.map(function (constructor) {
    return constructor.prototype;
  });
  // Here we gather up the init functions of the ingredient prototypes, combine them into one init function, and
  // attach it to the mixed class prototype.  The reason we do this is because we want the init functions to mix
  // similarly to constructors -- not methods, which simply override each other.
  var initFunctionName = settings.initFunction;
  if (initFunctionName !== null) {
    var initFunctions = prototypes.map(function (proto) {
      return proto[initFunctionName];
    }).filter(function (func) {
      return typeof func === 'function';
    });
    var combinedInitFunction = function combinedInitFunction() {
      for (var _len6 = arguments.length, args = new Array(_len6), _key6 = 0; _key6 < _len6; _key6++) {
        args[_key6] = arguments[_key6];
      }
      var _iterator6 = _createForOfIteratorHelper(initFunctions),
        _step6;
      try {
        for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
          var initFunction = _step6.value;
          initFunction.apply(this, args);
        }
      } catch (err) {
        _iterator6.e(err);
      } finally {
        _iterator6.f();
      }
    };
    var extraProto = _defineProperty({}, initFunctionName, combinedInitFunction);
    prototypes.push(extraProto);
  }
  function MixedClass() {
    for (var _len7 = arguments.length, args = new Array(_len7), _key7 = 0; _key7 < _len7; _key7++) {
      args[_key7] = arguments[_key7];
    }
    var _iterator7 = _createForOfIteratorHelper(constructors),
      _step7;
    try {
      for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
        var constructor = _step7.value;
        copyProps(this, _construct(constructor, args));
      }
    } catch (err) {
      _iterator7.e(err);
    } finally {
      _iterator7.f();
    }
    if (initFunctionName !== null && typeof this[initFunctionName] === 'function') this[initFunctionName].apply(this, args);
  }
  MixedClass.prototype = settings.prototypeStrategy === 'copy' ? hardMixProtos(prototypes, MixedClass) : softMixProtos(prototypes, MixedClass);
  Object.setPrototypeOf(MixedClass, settings.staticsStrategy === 'copy' ? hardMixProtos(constructors, null, ['prototype']) : proxyMix(constructors, Function.prototype));
  var DecoratedMixedClass = MixedClass;
  if (settings.decoratorInheritance !== 'none') {
    var classDecorators = settings.decoratorInheritance === 'deep' ? deepDecoratorSearch.apply(void 0, constructors) : directDecoratorSearch.apply(void 0, constructors);
    var _iterator8 = _createForOfIteratorHelper((_a = classDecorators === null || classDecorators === void 0 ? void 0 : classDecorators.class) !== null && _a !== void 0 ? _a : []),
      _step8;
    try {
      for (_iterator8.s(); !(_step8 = _iterator8.n()).done;) {
        var decorator = _step8.value;
        DecoratedMixedClass = decorator(DecoratedMixedClass);
      }
    } catch (err) {
      _iterator8.e(err);
    } finally {
      _iterator8.f();
    }
    applyPropAndMethodDecorators((_b = classDecorators === null || classDecorators === void 0 ? void 0 : classDecorators.static) !== null && _b !== void 0 ? _b : {}, DecoratedMixedClass);
    applyPropAndMethodDecorators((_c = classDecorators === null || classDecorators === void 0 ? void 0 : classDecorators.instance) !== null && _c !== void 0 ? _c : {}, DecoratedMixedClass.prototype);
  }
  registerMixins(DecoratedMixedClass, constructors);
  return DecoratedMixedClass;
}
var applyPropAndMethodDecorators = function applyPropAndMethodDecorators(propAndMethodDecorators, target) {
  var propDecorators = propAndMethodDecorators.property;
  var methodDecorators = propAndMethodDecorators.method;
  if (propDecorators) for (var key in propDecorators) {
    var _iterator9 = _createForOfIteratorHelper(propDecorators[key]),
      _step9;
    try {
      for (_iterator9.s(); !(_step9 = _iterator9.n()).done;) {
        var decorator = _step9.value;
        decorator(target, key);
      }
    } catch (err) {
      _iterator9.e(err);
    } finally {
      _iterator9.f();
    }
  }
  if (methodDecorators) for (var _key8 in methodDecorators) {
    var _iterator0 = _createForOfIteratorHelper(methodDecorators[_key8]),
      _step0;
    try {
      for (_iterator0.s(); !(_step0 = _iterator0.n()).done;) {
        var _decorator = _step0.value;
        _decorator(target, _key8, Object.getOwnPropertyDescriptor(target, _key8));
      }
    } catch (err) {
      _iterator0.e(err);
    } finally {
      _iterator0.f();
    }
  }
};
/**
 * A decorator version of the `Mixin` function.  You'll want to use this instead of `Mixin` for mixing generic classes.
 */
var mix = function mix() {
  for (var _len8 = arguments.length, ingredients = new Array(_len8), _key9 = 0; _key9 < _len8; _key9++) {
    ingredients[_key9] = arguments[_key9];
  }
  return function (decoratedClass) {
    // @ts-ignore
    var mixedClass = Mixin.apply(void 0, _toConsumableArray(ingredients.concat([decoratedClass])));
    Object.defineProperty(mixedClass, 'name', {
      value: decoratedClass.name,
      writable: false
    });
    return mixedClass;
  };
};


/***/ }),

/***/ "./src/Constants.ts":
/*!**************************!*\
  !*** ./src/Constants.ts ***!
  \**************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LOCALE_MANAGER_KEYS: function() { return /* binding */ LOCALE_MANAGER_KEYS; }
/* harmony export */ });
var LOCALE_MANAGER_KEYS = [];

/***/ }),

/***/ "./src/Dashboard.ts":
/*!**************************!*\
  !*** ./src/Dashboard.ts ***!
  \**************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _app_Fragment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/Fragment */ "./src/app/Fragment.ts");
/* harmony import */ var _navigation_NavController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./navigation/NavController */ "./src/navigation/NavController.ts");
/* harmony import */ var _android_widget_fragmentImpl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./android/widget/fragmentImpl */ "./src/android/widget/fragmentImpl.ts");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
//start - import
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};
//end - import



//start - className
var Dashboard = /** @class */function (_super) {
  __extends(Dashboard, _super);
  function Dashboard() {
    return _super !== null && _super.apply(this, arguments) || this;
  }
  Dashboard.createInstance = function () {
    return new Dashboard();
  };
  Dashboard.prototype.goToPreviousScreen = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4 /*yield*/, this.navController.reset().popBackStack().executeCommand()];
          case 1:
            _a.sent();
            return [2 /*return*/];
        }
      });
    });
  };
  Dashboard.prototype.goBack = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4 /*yield*/, this.nav_host_fragment_container.popBackStack()];
          case 1:
            _a.sent();
            this.executeCommand(this.nav_host_fragment_container);
            return [2 /*return*/];
        }
      });
    });
  };
  __decorate([(0,_navigation_NavController__WEBPACK_IMPORTED_MODULE_1__.InjectController)({}), __metadata("design:type", _navigation_NavController__WEBPACK_IMPORTED_MODULE_1__.NavController)], Dashboard.prototype, "navController", void 0);
  __decorate([(0,_app_Fragment__WEBPACK_IMPORTED_MODULE_0__.Inject)({
    id: "@+id/nav_host_fragment_container"
  }), __metadata("design:type", _android_widget_fragmentImpl__WEBPACK_IMPORTED_MODULE_2__.fragment)], Dashboard.prototype, "nav_host_fragment_container", void 0);
  return Dashboard;
}(_app_Fragment__WEBPACK_IMPORTED_MODULE_0__.Fragment
//end - className
);
/* harmony default export */ __webpack_exports__["default"] = (Dashboard);

/***/ }),

/***/ "./src/ErrorDetailFragment.ts":
/*!************************************!*\
  !*** ./src/ErrorDetailFragment.ts ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _app_Fragment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/Fragment */ "./src/app/Fragment.ts");
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var ErrorDetailFragment = /** @class */function (_super) {
  __extends(ErrorDetailFragment, _super);
  function ErrorDetailFragment() {
    return _super.call(this) || this;
  }
  return ErrorDetailFragment;
}(_app_Fragment__WEBPACK_IMPORTED_MODULE_0__.Fragment);
/* harmony default export */ __webpack_exports__["default"] = (ErrorDetailFragment);

/***/ }),

/***/ "./src/ErrorFragment.ts":
/*!******************************!*\
  !*** ./src/ErrorFragment.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _app_Fragment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/Fragment */ "./src/app/Fragment.ts");
/* harmony import */ var _navigation_NavController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./navigation/NavController */ "./src/navigation/NavController.ts");
/* harmony import */ var _R_NavGraph__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./R/NavGraph */ "./src/R/NavGraph.ts");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};



var ErrorFragment = /** @class */function (_super) {
  __extends(ErrorFragment, _super);
  function ErrorFragment() {
    var _this = _super.call(this) || this;
    _this.display = function (errorData) {
      return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
          this.navController.navigate(_R_NavGraph__WEBPACK_IMPORTED_MODULE_2__.error, "errors->view as list", errorData.errors).executeCommand();
          return [2 /*return*/];
        });
      });
    };
    _this.gotoErrorDetails = function (obj) {
      return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
          switch (_a.label) {
            case 0:
              return [4 /*yield*/, this.navController.navigate(_R_NavGraph__WEBPACK_IMPORTED_MODULE_2__.error_detail, "error->view as map", obj.error).executeCommand()];
            case 1:
              _a.sent();
              return [2 /*return*/];
          }
        });
      });
    };
    return _this;
  }
  __decorate([(0,_navigation_NavController__WEBPACK_IMPORTED_MODULE_1__.InjectController)({}), __metadata("design:type", _navigation_NavController__WEBPACK_IMPORTED_MODULE_1__.NavController)], ErrorFragment.prototype, "navController", void 0);
  return ErrorFragment;
}(_app_Fragment__WEBPACK_IMPORTED_MODULE_0__.Fragment);
/* harmony default export */ __webpack_exports__["default"] = (ErrorFragment);

/***/ }),

/***/ "./src/FragmentFactory.ts":
/*!********************************!*\
  !*** ./src/FragmentFactory.ts ***!
  \********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FragmentMapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FragmentMapper */ "./src/FragmentMapper.ts");

var FragmentFactory = /** @class */function () {
  function FragmentFactory() {}
  FragmentFactory.prototype.createNewInstance = function (fileName, namespace) {
    if (namespace === void 0) {
      namespace = '';
    }
    if (!namespace || namespace == '') {
      return new _FragmentMapper__WEBPACK_IMPORTED_MODULE_0__.fragmentMapper[fileName]();
    } else {
      var fragment = FragmentFactory.fragmentMapperMap[namespace][fileName];
      return fragment.createInstance();
    }
  };
  FragmentFactory.registerFragmentMapper = function (namespace, fragmentMapper) {
    FragmentFactory.fragmentMapperMap[namespace] = fragmentMapper;
  };
  FragmentFactory.fragmentMapperMap = {};
  return FragmentFactory;
}();
/* harmony default export */ __webpack_exports__["default"] = (FragmentFactory);

/***/ }),

/***/ "./src/FragmentMapper.ts":
/*!*******************************!*\
  !*** ./src/FragmentMapper.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fragmentMapper: function() { return /* binding */ fragmentMapper; }
/* harmony export */ });
/* harmony import */ var _ErrorFragment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ErrorFragment */ "./src/ErrorFragment.ts");
/* harmony import */ var _ErrorDetailFragment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ErrorDetailFragment */ "./src/ErrorDetailFragment.ts");
/* harmony import */ var _Dashboard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Dashboard */ "./src/Dashboard.ts");
/* harmony import */ var _Home__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Home */ "./src/Home.ts");
/* harmony import */ var _Index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Index */ "./src/Index.ts");


//start - import



//end - import
var fragmentMapper = {
  'layout/error.xml': _ErrorFragment__WEBPACK_IMPORTED_MODULE_0__["default"],
  'layout/error_detail.xml': _ErrorDetailFragment__WEBPACK_IMPORTED_MODULE_1__["default"],
  //start - body
  'layout/dashboard.xml': _Dashboard__WEBPACK_IMPORTED_MODULE_2__["default"],
  'layout/home.xml': _Home__WEBPACK_IMPORTED_MODULE_3__["default"],
  'layout/index.xml': _Index__WEBPACK_IMPORTED_MODULE_4__["default"]
  //end - body
};

/***/ }),

/***/ "./src/Home.ts":
/*!*********************!*\
  !*** ./src/Home.ts ***!
  \*********************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _app_Fragment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/Fragment */ "./src/app/Fragment.ts");
/* harmony import */ var _navigation_NavController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./navigation/NavController */ "./src/navigation/NavController.ts");
/* harmony import */ var _android_widget_fragmentImpl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./android/widget/fragmentImpl */ "./src/android/widget/fragmentImpl.ts");
/* harmony import */ var _R_NavGraphChild__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./R/NavGraphChild */ "./src/R/NavGraphChild.ts");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
//start - import
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};
//end - import




//start - className
var Home = /** @class */function (_super) {
  __extends(Home, _super);
  function Home() {
    return _super !== null && _super.apply(this, arguments) || this;
  }
  Home.createInstance = function () {
    return new Home();
  };
  Home.prototype.goToPreviousScreen = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4 /*yield*/, this.navController.reset().popBackStack().executeCommand()];
          case 1:
            _a.sent();
            return [2 /*return*/];
        }
      });
    });
  };
  Home.prototype.gotToDashBoard = function () {
    this.nav_host_fragment_container.navigate(_R_NavGraphChild__WEBPACK_IMPORTED_MODULE_3__.dashboard, []);
    this.executeCommand(this.nav_host_fragment_container);
  };
  __decorate([(0,_navigation_NavController__WEBPACK_IMPORTED_MODULE_1__.InjectController)({}), __metadata("design:type", _navigation_NavController__WEBPACK_IMPORTED_MODULE_1__.NavController)], Home.prototype, "navController", void 0);
  __decorate([(0,_app_Fragment__WEBPACK_IMPORTED_MODULE_0__.Inject)({
    id: "@+id/nav_host_fragment_container"
  }), __metadata("design:type", _android_widget_fragmentImpl__WEBPACK_IMPORTED_MODULE_2__.fragment)], Home.prototype, "nav_host_fragment_container", void 0);
  return Home;
}(_app_Fragment__WEBPACK_IMPORTED_MODULE_0__.Fragment
//end - className
);
/* harmony default export */ __webpack_exports__["default"] = (Home);

/***/ }),

/***/ "./src/Index.ts":
/*!**********************!*\
  !*** ./src/Index.ts ***!
  \**********************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _android_widget_fragmentImpl__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./android/widget/fragmentImpl */ "./src/android/widget/fragmentImpl.ts");
/* harmony import */ var _app_Fragment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app/Fragment */ "./src/app/Fragment.ts");
/* harmony import */ var _navigation_NavController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./navigation/NavController */ "./src/navigation/NavController.ts");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
//start - import
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};

//end - import


var Index = /** @class */function (_super) {
  __extends(Index, _super);
  //end - body
  function Index() {
    return _super.call(this) || this;
  }
  Index.createInstance = function () {
    return new Index();
  };
  Index.prototype.goToPreviousScreen = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4 /*yield*/, this.navController.reset().popBackStack().executeCommand()];
          case 1:
            _a.sent();
            return [2 /*return*/];
        }
      });
    });
  };
  Index.prototype.onCreate = function (obj) {
    //alert("If you receive this  alert, you are good to write your first program");
  };
  __decorate([(0,_navigation_NavController__WEBPACK_IMPORTED_MODULE_2__.InjectController)({}), __metadata("design:type", _navigation_NavController__WEBPACK_IMPORTED_MODULE_2__.NavController)], Index.prototype, "navController", void 0);
  __decorate([(0,_app_Fragment__WEBPACK_IMPORTED_MODULE_1__.Inject)({
    id: "@+id/nav_host_fragment_container"
  }), __metadata("design:type", _android_widget_fragmentImpl__WEBPACK_IMPORTED_MODULE_0__.fragment)], Index.prototype, "nav_host_fragment_container", void 0);
  return Index;
}(_app_Fragment__WEBPACK_IMPORTED_MODULE_1__.Fragment);
/* harmony default export */ __webpack_exports__["default"] = (Index);

/***/ }),

/***/ "./src/R/NavGraph.ts":
/*!***************************!*\
  !*** ./src/R/NavGraph.ts ***!
  \***************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   action_error_to_error_detail: function() { return /* binding */ action_error_to_error_detail; },
/* harmony export */   error: function() { return /* binding */ error; },
/* harmony export */   error_detail: function() { return /* binding */ error_detail; },
/* harmony export */   index: function() { return /* binding */ index; }
/* harmony export */ });
var action_error_to_error_detail = 'action_error_to_error_detail#@layout/error_detail';
var index = 'fragment#index#layout/index.xml';
var error = 'fragment#error#layout/error.xml';
var error_detail = 'fragment#error_detail#layout/error_detail.xml';

/***/ }),

/***/ "./src/R/NavGraphChild.ts":
/*!********************************!*\
  !*** ./src/R/NavGraphChild.ts ***!
  \********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   action_error_to_error_detail: function() { return /* binding */ action_error_to_error_detail; },
/* harmony export */   dashboard: function() { return /* binding */ dashboard; },
/* harmony export */   error: function() { return /* binding */ error; },
/* harmony export */   error_detail: function() { return /* binding */ error_detail; },
/* harmony export */   index: function() { return /* binding */ index; }
/* harmony export */ });
var action_error_to_error_detail = 'action_error_to_error_detail#@layout/error_detail';
var index = 'fragment#index#layout/home.xml';
var dashboard = 'fragment#dashboard#layout/dashboard.xml';
var error = 'fragment#error#layout/error.xml';
var error_detail = 'fragment#error_detail#layout/error_detail.xml';

/***/ }),

/***/ "./src/android/widget/ViewGroupImpl.ts":
/*!*********************************************!*\
  !*** ./src/android/widget/ViewGroupImpl.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LayoutTransitionTransformer: function() { return /* binding */ LayoutTransitionTransformer; },
/* harmony export */   PersistentDrawingCacheTransformer: function() { return /* binding */ PersistentDrawingCacheTransformer; },
/* harmony export */   ViewGroup: function() { return /* binding */ ViewGroup; },
/* harmony export */   ViewGroupImpl: function() { return /* binding */ ViewGroupImpl; },
/* harmony export */   ViewGroupImpl_LayoutParams: function() { return /* binding */ ViewGroupImpl_LayoutParams; },
/* harmony export */   ViewGroup_LayoutParams: function() { return /* binding */ ViewGroup_LayoutParams; }
/* harmony export */ });
/* harmony import */ var _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../widget/CommandAttr */ "./src/widget/CommandAttr.ts");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/exclude.decorator.js");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/expose.decorator.js");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/type.decorator.js");
/* harmony import */ var _widget_TransformerFactory__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../widget/TransformerFactory */ "./src/widget/TransformerFactory.ts");
/* harmony import */ var ts_mixer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ts-mixer */ "./node_modules/ts-mixer/dist/esm/index.js");
/* harmony import */ var _ViewGroupModelImpl__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ViewGroupModelImpl */ "./src/android/widget/ViewGroupModelImpl.ts");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
// start - imports
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var PersistentDrawingCacheTransformer = /** @class */function () {
  function PersistentDrawingCacheTransformer() {}
  PersistentDrawingCacheTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "all":
            valueArr.push("all" /* PersistentDrawingCache.all */);
            break;
          case "animation":
            valueArr.push("animation" /* PersistentDrawingCache.animation */);
            break;
          case "none":
            valueArr.push("none" /* PersistentDrawingCache.none */);
            break;
          case "scrolling":
            valueArr.push("scrolling" /* PersistentDrawingCache.scrolling */);
            break;
        }
      }
      return valueArr;
    }
  };
  return PersistentDrawingCacheTransformer;
}();

var LayoutTransitionTransformer = /** @class */function () {
  function LayoutTransitionTransformer() {}
  LayoutTransitionTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "change_appearing":
            valueArr.push("change_appearing" /* LayoutTransition.change_appearing */);
            break;
          case "change_disappearing":
            valueArr.push("change_disappearing" /* LayoutTransition.change_disappearing */);
            break;
          case "appearing":
            valueArr.push("appearing" /* LayoutTransition.appearing */);
            break;
          case "disappearing":
            valueArr.push("disappearing" /* LayoutTransition.disappearing */);
            break;
          case "changing":
            valueArr.push("changing" /* LayoutTransition.changing */);
            break;
        }
      }
      return valueArr;
    }
  };
  return LayoutTransitionTransformer;
}();

// end - imports

var ViewGroupImpl = /** @class */function (_super) {
  __extends(ViewGroupImpl, _super);
  function ViewGroupImpl(id, path, event) {
    var _this = _super.call(this, id, path, event) || this;
    _this.thisPointer = _this.getThisPointer();
    return _this;
  }
  //start - body
  ViewGroupImpl.initialize = function () {
    _widget_TransformerFactory__WEBPACK_IMPORTED_MODULE_4__.TransformerFactory.getInstance().register("persistentDrawingCache", new PersistentDrawingCacheTransformer());
    _widget_TransformerFactory__WEBPACK_IMPORTED_MODULE_4__.TransformerFactory.getInstance().register("layoutTransition", new LayoutTransitionTransformer());
  };
  ViewGroupImpl.prototype.reset = function () {
    _super.prototype.reset.call(this);
    this.alwaysDrawnWithCache = undefined;
    this.animationCache = undefined;
    this.clipChildren = undefined;
    this.clipToPadding = undefined;
    this.descendantFocusability = undefined;
    this.layoutMode = undefined;
    this.persistentDrawingCache = undefined;
    this.splitMotionEvents = undefined;
    this.onChildViewAdded = undefined;
    this.onChildViewRemoved = undefined;
    this.animateLayoutChanges = undefined;
    this.layoutTransition = undefined;
    this.layoutTransitionDuration = undefined;
    this.animateParentHierarchy = undefined;
    this.listitem = undefined;
    this.addStatesFromChildren = undefined;
    this.childXml = undefined;
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetAlwaysDrawnWithCache = function () {
    this.resetIfRequired();
    if (this.alwaysDrawnWithCache == null || this.alwaysDrawnWithCache == undefined) {
      this.alwaysDrawnWithCache = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.alwaysDrawnWithCache.setGetter(true);
    this.orderGet++;
    this.alwaysDrawnWithCache.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.isAlwaysDrawnWithCache = function () {
    if (this.alwaysDrawnWithCache == null || this.alwaysDrawnWithCache == undefined) {
      this.alwaysDrawnWithCache = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.alwaysDrawnWithCache.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setAlwaysDrawnWithCache = function (value) {
    this.resetIfRequired();
    if (this.alwaysDrawnWithCache == null || this.alwaysDrawnWithCache == undefined) {
      this.alwaysDrawnWithCache = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.alwaysDrawnWithCache.setSetter(true);
    this.alwaysDrawnWithCache.setValue(value);
    this.orderSet++;
    this.alwaysDrawnWithCache.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetAnimationCache = function () {
    this.resetIfRequired();
    if (this.animationCache == null || this.animationCache == undefined) {
      this.animationCache = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.animationCache.setGetter(true);
    this.orderGet++;
    this.animationCache.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.isAnimationCache = function () {
    if (this.animationCache == null || this.animationCache == undefined) {
      this.animationCache = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.animationCache.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setAnimationCache = function (value) {
    this.resetIfRequired();
    if (this.animationCache == null || this.animationCache == undefined) {
      this.animationCache = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.animationCache.setSetter(true);
    this.animationCache.setValue(value);
    this.orderSet++;
    this.animationCache.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetClipChildren = function () {
    this.resetIfRequired();
    if (this.clipChildren == null || this.clipChildren == undefined) {
      this.clipChildren = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.clipChildren.setGetter(true);
    this.orderGet++;
    this.clipChildren.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.isClipChildren = function () {
    if (this.clipChildren == null || this.clipChildren == undefined) {
      this.clipChildren = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.clipChildren.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setClipChildren = function (value) {
    this.resetIfRequired();
    if (this.clipChildren == null || this.clipChildren == undefined) {
      this.clipChildren = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.clipChildren.setSetter(true);
    this.clipChildren.setValue(value);
    this.orderSet++;
    this.clipChildren.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetClipToPadding = function () {
    this.resetIfRequired();
    if (this.clipToPadding == null || this.clipToPadding == undefined) {
      this.clipToPadding = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.clipToPadding.setGetter(true);
    this.orderGet++;
    this.clipToPadding.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.isClipToPadding = function () {
    if (this.clipToPadding == null || this.clipToPadding == undefined) {
      this.clipToPadding = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.clipToPadding.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setClipToPadding = function (value) {
    this.resetIfRequired();
    if (this.clipToPadding == null || this.clipToPadding == undefined) {
      this.clipToPadding = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.clipToPadding.setSetter(true);
    this.clipToPadding.setValue(value);
    this.orderSet++;
    this.clipToPadding.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetDescendantFocusability = function () {
    this.resetIfRequired();
    if (this.descendantFocusability == null || this.descendantFocusability == undefined) {
      this.descendantFocusability = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.descendantFocusability.setGetter(true);
    this.orderGet++;
    this.descendantFocusability.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.getDescendantFocusability = function () {
    if (this.descendantFocusability == null || this.descendantFocusability == undefined) {
      this.descendantFocusability = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.descendantFocusability.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setDescendantFocusability = function (value) {
    this.resetIfRequired();
    if (this.descendantFocusability == null || this.descendantFocusability == undefined) {
      this.descendantFocusability = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.descendantFocusability.setSetter(true);
    this.descendantFocusability.setValue(value);
    this.orderSet++;
    this.descendantFocusability.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetLayoutMode = function () {
    this.resetIfRequired();
    if (this.layoutMode == null || this.layoutMode == undefined) {
      this.layoutMode = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layoutMode.setGetter(true);
    this.orderGet++;
    this.layoutMode.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.getLayoutMode = function () {
    if (this.layoutMode == null || this.layoutMode == undefined) {
      this.layoutMode = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.layoutMode.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setLayoutMode = function (value) {
    this.resetIfRequired();
    if (this.layoutMode == null || this.layoutMode == undefined) {
      this.layoutMode = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layoutMode.setSetter(true);
    this.layoutMode.setValue(value);
    this.orderSet++;
    this.layoutMode.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetPersistentDrawingCache = function () {
    this.resetIfRequired();
    if (this.persistentDrawingCache == null || this.persistentDrawingCache == undefined) {
      this.persistentDrawingCache = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.persistentDrawingCache.setGetter(true);
    this.orderGet++;
    this.persistentDrawingCache.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.getPersistentDrawingCache = function () {
    if (this.persistentDrawingCache == null || this.persistentDrawingCache == undefined) {
      this.persistentDrawingCache = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.persistentDrawingCache.setTransformer('persistentDrawingCache');
    return this.persistentDrawingCache.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setPersistentDrawingCache = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.persistentDrawingCache == null || this.persistentDrawingCache == undefined) {
      this.persistentDrawingCache = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.persistentDrawingCache.setSetter(true);
    this.persistentDrawingCache.setValue(value);
    this.orderSet++;
    this.persistentDrawingCache.setOrderSet(this.orderSet);
    this.persistentDrawingCache.setTransformer('persistentDrawingCache');
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetSplitMotionEvents = function () {
    this.resetIfRequired();
    if (this.splitMotionEvents == null || this.splitMotionEvents == undefined) {
      this.splitMotionEvents = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.splitMotionEvents.setGetter(true);
    this.orderGet++;
    this.splitMotionEvents.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.isSplitMotionEvents = function () {
    if (this.splitMotionEvents == null || this.splitMotionEvents == undefined) {
      this.splitMotionEvents = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.splitMotionEvents.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setSplitMotionEvents = function (value) {
    this.resetIfRequired();
    if (this.splitMotionEvents == null || this.splitMotionEvents == undefined) {
      this.splitMotionEvents = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.splitMotionEvents.setSetter(true);
    this.splitMotionEvents.setValue(value);
    this.orderSet++;
    this.splitMotionEvents.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setOnChildViewAdded = function (value) {
    this.resetIfRequired();
    if (this.onChildViewAdded == null || this.onChildViewAdded == undefined) {
      this.onChildViewAdded = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onChildViewAdded.setSetter(true);
    this.onChildViewAdded.setValue(value);
    this.orderSet++;
    this.onChildViewAdded.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setOnChildViewRemoved = function (value) {
    this.resetIfRequired();
    if (this.onChildViewRemoved == null || this.onChildViewRemoved == undefined) {
      this.onChildViewRemoved = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onChildViewRemoved.setSetter(true);
    this.onChildViewRemoved.setValue(value);
    this.orderSet++;
    this.onChildViewRemoved.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setAnimateLayoutChanges = function (value) {
    this.resetIfRequired();
    if (this.animateLayoutChanges == null || this.animateLayoutChanges == undefined) {
      this.animateLayoutChanges = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.animateLayoutChanges.setSetter(true);
    this.animateLayoutChanges.setValue(value);
    this.orderSet++;
    this.animateLayoutChanges.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setLayoutTransition = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.layoutTransition == null || this.layoutTransition == undefined) {
      this.layoutTransition = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layoutTransition.setSetter(true);
    this.layoutTransition.setValue(value);
    this.orderSet++;
    this.layoutTransition.setOrderSet(this.orderSet);
    this.layoutTransition.setTransformer('layoutTransition');
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setLayoutTransitionDuration = function (value) {
    this.resetIfRequired();
    if (this.layoutTransitionDuration == null || this.layoutTransitionDuration == undefined) {
      this.layoutTransitionDuration = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layoutTransitionDuration.setSetter(true);
    this.layoutTransitionDuration.setValue(value);
    this.orderSet++;
    this.layoutTransitionDuration.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setAnimateParentHierarchy = function (value) {
    this.resetIfRequired();
    if (this.animateParentHierarchy == null || this.animateParentHierarchy == undefined) {
      this.animateParentHierarchy = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.animateParentHierarchy.setSetter(true);
    this.animateParentHierarchy.setValue(value);
    this.orderSet++;
    this.animateParentHierarchy.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setListitem = function (value) {
    this.resetIfRequired();
    if (this.listitem == null || this.listitem == undefined) {
      this.listitem = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.listitem.setSetter(true);
    this.listitem.setValue(value);
    this.orderSet++;
    this.listitem.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetAddStatesFromChildren = function () {
    this.resetIfRequired();
    if (this.addStatesFromChildren == null || this.addStatesFromChildren == undefined) {
      this.addStatesFromChildren = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.addStatesFromChildren.setGetter(true);
    this.orderGet++;
    this.addStatesFromChildren.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.isAddStatesFromChildren = function () {
    if (this.addStatesFromChildren == null || this.addStatesFromChildren == undefined) {
      this.addStatesFromChildren = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.addStatesFromChildren.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setAddStatesFromChildren = function (value) {
    this.resetIfRequired();
    if (this.addStatesFromChildren == null || this.addStatesFromChildren == undefined) {
      this.addStatesFromChildren = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.addStatesFromChildren.setSetter(true);
    this.addStatesFromChildren.setValue(value);
    this.orderSet++;
    this.addStatesFromChildren.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setChildXml = function (value) {
    this.resetIfRequired();
    if (this.childXml == null || this.childXml == undefined) {
      this.childXml = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.childXml.setSetter(true);
    this.childXml.setValue(value);
    this.orderSet++;
    this.childXml.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "alwaysDrawnWithCache"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "alwaysDrawnWithCache", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "animationCache"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "animationCache", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "clipChildren"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "clipChildren", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "clipToPadding"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "clipToPadding", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "descendantFocusability"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "descendantFocusability", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layoutMode"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "layoutMode", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "persistentDrawingCache"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "persistentDrawingCache", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "splitMotionEvents"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "splitMotionEvents", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onChildViewAdded"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "onChildViewAdded", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onChildViewRemoved"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "onChildViewRemoved", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "animateLayoutChanges"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "animateLayoutChanges", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layoutTransition"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "layoutTransition", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layoutTransitionDuration"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "layoutTransitionDuration", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "animateParentHierarchy"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "animateParentHierarchy", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "listitem"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "listitem", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "addStatesFromChildren"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "addStatesFromChildren", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "childXml"
  })), __metadata("design:type", Object)], ViewGroupImpl.prototype, "childXml", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_1__.Exclude)()), __metadata("design:type", Object)], ViewGroupImpl.prototype, "thisPointer", void 0);
  return ViewGroupImpl;
}(_ViewGroupModelImpl__WEBPACK_IMPORTED_MODULE_6__.ViewGroupModelImpl);

//start - staticinit
var ViewGroupImpl_LayoutParams = /** @class */function () {
  function ViewGroupImpl_LayoutParams() {
    this.orderGet = 0;
    this.orderSet = 0;
    this.thisPointer = this.getThisPointer();
  }
  ViewGroupImpl_LayoutParams.prototype.reset = function () {
    this.layout_marginBottom = undefined;
    this.layout_marginTop = undefined;
    this.layout_marginStart = undefined;
    this.layout_marginEnd = undefined;
    this.layout_marginLeft = undefined;
    this.layout_marginRight = undefined;
    this.layout_margin = undefined;
    this.layout_marginHorizontal = undefined;
    this.layout_marginVertical = undefined;
    this.orderGet = 0;
    this.orderSet = 0;
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.tryGetLayoutMarginBottom = function () {
    if (this.layout_marginBottom == null || this.layout_marginBottom == undefined) {
      this.layout_marginBottom = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginBottom.setGetter(true);
    this.orderGet++;
    this.layout_marginBottom.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.getLayoutMarginBottom = function () {
    if (this.layout_marginBottom == null || this.layout_marginBottom == undefined) {
      this.layout_marginBottom = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.layout_marginBottom.getCommandReturnValue();
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginBottom = function (value) {
    if (this.layout_marginBottom == null || this.layout_marginBottom == undefined) {
      this.layout_marginBottom = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginBottom.setSetter(true);
    this.layout_marginBottom.setValue(value);
    this.orderSet++;
    this.layout_marginBottom.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.tryGetLayoutMarginTop = function () {
    if (this.layout_marginTop == null || this.layout_marginTop == undefined) {
      this.layout_marginTop = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginTop.setGetter(true);
    this.orderGet++;
    this.layout_marginTop.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.getLayoutMarginTop = function () {
    if (this.layout_marginTop == null || this.layout_marginTop == undefined) {
      this.layout_marginTop = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.layout_marginTop.getCommandReturnValue();
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginTop = function (value) {
    if (this.layout_marginTop == null || this.layout_marginTop == undefined) {
      this.layout_marginTop = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginTop.setSetter(true);
    this.layout_marginTop.setValue(value);
    this.orderSet++;
    this.layout_marginTop.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.tryGetLayoutMarginStart = function () {
    if (this.layout_marginStart == null || this.layout_marginStart == undefined) {
      this.layout_marginStart = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginStart.setGetter(true);
    this.orderGet++;
    this.layout_marginStart.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.getLayoutMarginStart = function () {
    if (this.layout_marginStart == null || this.layout_marginStart == undefined) {
      this.layout_marginStart = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.layout_marginStart.getCommandReturnValue();
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginStart = function (value) {
    if (this.layout_marginStart == null || this.layout_marginStart == undefined) {
      this.layout_marginStart = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginStart.setSetter(true);
    this.layout_marginStart.setValue(value);
    this.orderSet++;
    this.layout_marginStart.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.tryGetLayoutMarginEnd = function () {
    if (this.layout_marginEnd == null || this.layout_marginEnd == undefined) {
      this.layout_marginEnd = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginEnd.setGetter(true);
    this.orderGet++;
    this.layout_marginEnd.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.getLayoutMarginEnd = function () {
    if (this.layout_marginEnd == null || this.layout_marginEnd == undefined) {
      this.layout_marginEnd = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.layout_marginEnd.getCommandReturnValue();
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginEnd = function (value) {
    if (this.layout_marginEnd == null || this.layout_marginEnd == undefined) {
      this.layout_marginEnd = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginEnd.setSetter(true);
    this.layout_marginEnd.setValue(value);
    this.orderSet++;
    this.layout_marginEnd.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.tryGetLayoutMarginLeft = function () {
    if (this.layout_marginLeft == null || this.layout_marginLeft == undefined) {
      this.layout_marginLeft = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginLeft.setGetter(true);
    this.orderGet++;
    this.layout_marginLeft.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.getLayoutMarginLeft = function () {
    if (this.layout_marginLeft == null || this.layout_marginLeft == undefined) {
      this.layout_marginLeft = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.layout_marginLeft.getCommandReturnValue();
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginLeft = function (value) {
    if (this.layout_marginLeft == null || this.layout_marginLeft == undefined) {
      this.layout_marginLeft = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginLeft.setSetter(true);
    this.layout_marginLeft.setValue(value);
    this.orderSet++;
    this.layout_marginLeft.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.tryGetLayoutMarginRight = function () {
    if (this.layout_marginRight == null || this.layout_marginRight == undefined) {
      this.layout_marginRight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginRight.setGetter(true);
    this.orderGet++;
    this.layout_marginRight.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.getLayoutMarginRight = function () {
    if (this.layout_marginRight == null || this.layout_marginRight == undefined) {
      this.layout_marginRight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.layout_marginRight.getCommandReturnValue();
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginRight = function (value) {
    if (this.layout_marginRight == null || this.layout_marginRight == undefined) {
      this.layout_marginRight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginRight.setSetter(true);
    this.layout_marginRight.setValue(value);
    this.orderSet++;
    this.layout_marginRight.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMargin = function (value) {
    if (this.layout_margin == null || this.layout_margin == undefined) {
      this.layout_margin = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_margin.setSetter(true);
    this.layout_margin.setValue(value);
    this.orderSet++;
    this.layout_margin.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginHorizontal = function (value) {
    if (this.layout_marginHorizontal == null || this.layout_marginHorizontal == undefined) {
      this.layout_marginHorizontal = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginHorizontal.setSetter(true);
    this.layout_marginHorizontal.setValue(value);
    this.orderSet++;
    this.layout_marginHorizontal.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginVertical = function (value) {
    if (this.layout_marginVertical == null || this.layout_marginVertical == undefined) {
      this.layout_marginVertical = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout_marginVertical.setSetter(true);
    this.layout_marginVertical.setValue(value);
    this.orderSet++;
    this.layout_marginVertical.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layout_marginBottom"
  })), __metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginBottom", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layout_marginTop"
  })), __metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginTop", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layout_marginStart"
  })), __metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginStart", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layout_marginEnd"
  })), __metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginEnd", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layout_marginLeft"
  })), __metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginLeft", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layout_marginRight"
  })), __metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginRight", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layout_margin"
  })), __metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_margin", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layout_marginHorizontal"
  })), __metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginHorizontal", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layout_marginVertical"
  })), __metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginVertical", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_1__.Exclude)()), __metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "thisPointer", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_1__.Exclude)()), __metadata("design:type", Number)], ViewGroupImpl_LayoutParams.prototype, "orderGet", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_5__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_1__.Exclude)()), __metadata("design:type", Number)], ViewGroupImpl_LayoutParams.prototype, "orderSet", void 0);
  return ViewGroupImpl_LayoutParams;
}();

var ViewGroup_LayoutParams = /** @class */function (_super) {
  __extends(ViewGroup_LayoutParams, _super);
  function ViewGroup_LayoutParams() {
    return _super.call(this) || this;
  }
  ViewGroup_LayoutParams.prototype.getThisPointer = function () {
    return this;
  };
  return ViewGroup_LayoutParams;
}(ViewGroupImpl_LayoutParams);

var ViewGroup = /** @class */function (_super) {
  __extends(ViewGroup, _super);
  function ViewGroup(id, path, event) {
    return _super.call(this, id, path, event) || this;
  }
  ViewGroup.prototype.getThisPointer = function () {
    return this;
  };
  ViewGroup.prototype.getClass = function () {
    return ViewGroup;
  };
  return ViewGroup;
}(ViewGroupImpl);

ViewGroupImpl.initialize();
//end - staticinit

/***/ }),

/***/ "./src/android/widget/ViewGroupModelImpl.ts":
/*!**************************************************!*\
  !*** ./src/android/widget/ViewGroupModelImpl.ts ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ViewGroupModel: function() { return /* binding */ ViewGroupModel; },
/* harmony export */   ViewGroupModelImpl: function() { return /* binding */ ViewGroupModelImpl; }
/* harmony export */ });
/* harmony import */ var _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../widget/CommandAttr */ "./src/widget/CommandAttr.ts");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/exclude.decorator.js");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/expose.decorator.js");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/type.decorator.js");
/* harmony import */ var ts_mixer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ts-mixer */ "./node_modules/ts-mixer/dist/esm/index.js");
/* harmony import */ var _ViewImpl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ViewImpl */ "./src/android/widget/ViewImpl.ts");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
// start - imports
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



// end - imports

var ViewGroupModelImpl = /** @class */function (_super) {
  __extends(ViewGroupModelImpl, _super);
  function ViewGroupModelImpl(id, path, event) {
    var _this = _super.call(this, id, path, event) || this;
    _this.thisPointer = _this.getThisPointer();
    return _this;
  }
  //start - body
  ViewGroupModelImpl.initialize = function () {};
  ViewGroupModelImpl.prototype.reset = function () {
    _super.prototype.reset.call(this);
    this.addModel_ = undefined;
    this.addAllModel_ = undefined;
    this.addModelByIndex_ = undefined;
    this.removeModelAtIndex_ = undefined;
    this.removeModelById_ = undefined;
    this.modelFor = undefined;
    this.modelIdPath = undefined;
    this.modelDescPath = undefined;
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.addModel = function (value) {
    this.resetIfRequired();
    if (this.addModel_ == null || this.addModel_ == undefined) {
      this.addModel_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.addModel_.setSetter(true);
    this.addModel_.setValue(value);
    this.orderSet++;
    this.addModel_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.addAllModel = function (value) {
    this.resetIfRequired();
    if (this.addAllModel_ == null || this.addAllModel_ == undefined) {
      this.addAllModel_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.addAllModel_.setSetter(true);
    this.addAllModel_.setValue(value);
    this.orderSet++;
    this.addAllModel_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.addModelByIndex = function (value, index) {
    this.resetIfRequired();
    if (this.addModelByIndex_ == null || this.addModelByIndex_ == undefined) {
      this.addModelByIndex_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    var wrapper = {};
    wrapper["index"] = index;
    wrapper["data"] = value;
    this.addModelByIndex_.setSetter(true);
    this.addModelByIndex_.setValue(wrapper);
    this.orderSet++;
    this.addModelByIndex_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.removeModelAtIndex = function (value) {
    this.resetIfRequired();
    if (this.removeModelAtIndex_ == null || this.removeModelAtIndex_ == undefined) {
      this.removeModelAtIndex_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.removeModelAtIndex_.setSetter(true);
    this.removeModelAtIndex_.setValue(value);
    this.orderSet++;
    this.removeModelAtIndex_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.removeModelById = function (value) {
    this.resetIfRequired();
    if (this.removeModelById_ == null || this.removeModelById_ == undefined) {
      this.removeModelById_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.removeModelById_.setSetter(true);
    this.removeModelById_.setValue(value);
    this.orderSet++;
    this.removeModelById_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.setModelFor = function (value) {
    this.resetIfRequired();
    if (this.modelFor == null || this.modelFor == undefined) {
      this.modelFor = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelFor.setSetter(true);
    this.modelFor.setValue(value);
    this.orderSet++;
    this.modelFor.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.tryGetModelIdPath = function () {
    this.resetIfRequired();
    if (this.modelIdPath == null || this.modelIdPath == undefined) {
      this.modelIdPath = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelIdPath.setGetter(true);
    this.orderGet++;
    this.modelIdPath.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.getModelIdPath = function () {
    if (this.modelIdPath == null || this.modelIdPath == undefined) {
      this.modelIdPath = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.modelIdPath.getCommandReturnValue();
  };
  ViewGroupModelImpl.prototype.setModelIdPath = function (value) {
    this.resetIfRequired();
    if (this.modelIdPath == null || this.modelIdPath == undefined) {
      this.modelIdPath = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelIdPath.setSetter(true);
    this.modelIdPath.setValue(value);
    this.orderSet++;
    this.modelIdPath.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.tryGetModelDescPath = function () {
    this.resetIfRequired();
    if (this.modelDescPath == null || this.modelDescPath == undefined) {
      this.modelDescPath = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelDescPath.setGetter(true);
    this.orderGet++;
    this.modelDescPath.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.getModelDescPath = function () {
    if (this.modelDescPath == null || this.modelDescPath == undefined) {
      this.modelDescPath = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.modelDescPath.getCommandReturnValue();
  };
  ViewGroupModelImpl.prototype.setModelDescPath = function (value) {
    this.resetIfRequired();
    if (this.modelDescPath == null || this.modelDescPath == undefined) {
      this.modelDescPath = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelDescPath.setSetter(true);
    this.modelDescPath.setValue(value);
    this.orderSet++;
    this.modelDescPath.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "addModel"
  })), __metadata("design:type", Object)], ViewGroupModelImpl.prototype, "addModel_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "addAllModel"
  })), __metadata("design:type", Object)], ViewGroupModelImpl.prototype, "addAllModel_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "addModelByIndex"
  })), __metadata("design:type", Object)], ViewGroupModelImpl.prototype, "addModelByIndex_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "removeModelAtIndex"
  })), __metadata("design:type", Object)], ViewGroupModelImpl.prototype, "removeModelAtIndex_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "removeModelById"
  })), __metadata("design:type", Object)], ViewGroupModelImpl.prototype, "removeModelById_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "modelFor"
  })), __metadata("design:type", Object)], ViewGroupModelImpl.prototype, "modelFor", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "modelIdPath"
  })), __metadata("design:type", Object)], ViewGroupModelImpl.prototype, "modelIdPath", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "modelDescPath"
  })), __metadata("design:type", Object)], ViewGroupModelImpl.prototype, "modelDescPath", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_1__.Exclude)()), __metadata("design:type", Object)], ViewGroupModelImpl.prototype, "thisPointer", void 0);
  return ViewGroupModelImpl;
}(_ViewImpl__WEBPACK_IMPORTED_MODULE_5__.ViewImpl);

//start - staticinit
var ViewGroupModel = /** @class */function (_super) {
  __extends(ViewGroupModel, _super);
  function ViewGroupModel(id, path, event) {
    return _super.call(this, id, path, event) || this;
  }
  ViewGroupModel.prototype.getThisPointer = function () {
    return this;
  };
  ViewGroupModel.prototype.getClass = function () {
    return ViewGroupModel;
  };
  return ViewGroupModel;
}(ViewGroupModelImpl);

ViewGroupModelImpl.initialize();
//end - staticinit

/***/ }),

/***/ "./src/android/widget/ViewImpl.ts":
/*!****************************************!*\
  !*** ./src/android/widget/ViewImpl.ts ***!
  \****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HapticFeedbackConstantsFlagTransformer: function() { return /* binding */ HapticFeedbackConstantsFlagTransformer; },
/* harmony export */   ImportantForAutofillTransformer: function() { return /* binding */ ImportantForAutofillTransformer; },
/* harmony export */   RequiresFadingEdgeTransformer: function() { return /* binding */ RequiresFadingEdgeTransformer; },
/* harmony export */   ScrollIndicatorsTransformer: function() { return /* binding */ ScrollIndicatorsTransformer; },
/* harmony export */   ValidationErrorDisplayTransformer: function() { return /* binding */ ValidationErrorDisplayTransformer; },
/* harmony export */   View: function() { return /* binding */ View; },
/* harmony export */   ViewImpl: function() { return /* binding */ ViewImpl; },
/* harmony export */   ViewImpl_performHapticFeedbackWithFlags: function() { return /* binding */ ViewImpl_performHapticFeedbackWithFlags; }
/* harmony export */ });
/* harmony import */ var _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../widget/CommandAttr */ "./src/widget/CommandAttr.ts");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/exclude.decorator.js");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/expose.decorator.js");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/transform.decorator.js");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/type.decorator.js");
/* harmony import */ var _widget_TransformerFactory__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../widget/TransformerFactory */ "./src/widget/TransformerFactory.ts");
/* harmony import */ var _app_ScopedObject__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../app/ScopedObject */ "./src/app/ScopedObject.ts");
/* harmony import */ var ts_mixer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ts-mixer */ "./node_modules/ts-mixer/dist/esm/index.js");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
// start - imports
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var ImportantForAutofillTransformer = /** @class */function () {
  function ImportantForAutofillTransformer() {}
  ImportantForAutofillTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "auto":
            valueArr.push("auto" /* ImportantForAutofill.auto */);
            break;
          case "no":
            valueArr.push("no" /* ImportantForAutofill.no */);
            break;
          case "noExcludeDescendants":
            valueArr.push("noExcludeDescendants" /* ImportantForAutofill.noExcludeDescendants */);
            break;
          case "yes":
            valueArr.push("yes" /* ImportantForAutofill.yes */);
            break;
          case "yesExcludeDescendants":
            valueArr.push("yesExcludeDescendants" /* ImportantForAutofill.yesExcludeDescendants */);
            break;
        }
      }
      return valueArr;
    }
  };
  return ImportantForAutofillTransformer;
}();

var ScrollIndicatorsTransformer = /** @class */function () {
  function ScrollIndicatorsTransformer() {}
  ScrollIndicatorsTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "bottom":
            valueArr.push("bottom" /* ScrollIndicators.bottom */);
            break;
          case "end":
            valueArr.push("end" /* ScrollIndicators.end */);
            break;
          case "left":
            valueArr.push("left" /* ScrollIndicators.left */);
            break;
          case "none":
            valueArr.push("none" /* ScrollIndicators.none */);
            break;
          case "right":
            valueArr.push("right" /* ScrollIndicators.right */);
            break;
          case "start":
            valueArr.push("start" /* ScrollIndicators.start */);
            break;
          case "top":
            valueArr.push("top" /* ScrollIndicators.top */);
            break;
        }
      }
      return valueArr;
    }
  };
  return ScrollIndicatorsTransformer;
}();

var RequiresFadingEdgeTransformer = /** @class */function () {
  function RequiresFadingEdgeTransformer() {}
  RequiresFadingEdgeTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "horizontal":
            valueArr.push("horizontal" /* RequiresFadingEdge.horizontal */);
            break;
          case "none":
            valueArr.push("none" /* RequiresFadingEdge.none */);
            break;
          case "vertical":
            valueArr.push("vertical" /* RequiresFadingEdge.vertical */);
            break;
        }
      }
      return valueArr;
    }
  };
  return RequiresFadingEdgeTransformer;
}();

var ViewImpl_performHapticFeedbackWithFlags = /** @class */function () {
  function ViewImpl_performHapticFeedbackWithFlags() {}
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "value"
  })), __metadata("design:type", String)], ViewImpl_performHapticFeedbackWithFlags.prototype, "value", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "flags"
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Transform)(function (_a) {
    var value = _a.value,
      obj = _a.obj,
      type = _a.type;
    return _widget_TransformerFactory__WEBPACK_IMPORTED_MODULE_5__.TransformerFactory.getInstance().transform(value, obj, type, "HapticFeedbackConstantsFlag");
  })), __metadata("design:type", Array)], ViewImpl_performHapticFeedbackWithFlags.prototype, "flags", void 0);
  return ViewImpl_performHapticFeedbackWithFlags;
}();

var HapticFeedbackConstantsFlagTransformer = /** @class */function () {
  function HapticFeedbackConstantsFlagTransformer() {}
  HapticFeedbackConstantsFlagTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "FLAG_IGNORE_VIEW_SETTING":
            valueArr.push("FLAG_IGNORE_VIEW_SETTING" /* HapticFeedbackConstantsFlag.FLAG_IGNORE_VIEW_SETTING */);
            break;
          case "FLAG_IGNORE_GLOBAL_SETTING":
            valueArr.push("FLAG_IGNORE_GLOBAL_SETTING" /* HapticFeedbackConstantsFlag.FLAG_IGNORE_GLOBAL_SETTING */);
            break;
        }
      }
      return valueArr;
    }
  };
  return HapticFeedbackConstantsFlagTransformer;
}();

var ValidationErrorDisplayTransformer = /** @class */function () {
  function ValidationErrorDisplayTransformer() {}
  ValidationErrorDisplayTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "popup":
            valueArr.push("popup" /* ValidationErrorDisplay.popup */);
            break;
          case "label":
            valueArr.push("label" /* ValidationErrorDisplay.label */);
            break;
          case "style":
            valueArr.push("style" /* ValidationErrorDisplay.style */);
            break;
        }
      }
      return valueArr;
    }
  };
  return ValidationErrorDisplayTransformer;
}();

// end - imports
var ViewImpl = /** @class */function () {
  function ViewImpl(id, paths, event) {
    this.orderGet = 0;
    this.orderSet = 0;
    this.flush = false;
    this.id = id;
    this.paths = paths;
    this.event = event;
    this.thisPointer = this.getThisPointer();
    this.layoutParams = undefined;
  }
  //start - body
  ViewImpl.initialize = function () {
    _widget_TransformerFactory__WEBPACK_IMPORTED_MODULE_5__.TransformerFactory.getInstance().register("importantForAutofill", new ImportantForAutofillTransformer());
    _widget_TransformerFactory__WEBPACK_IMPORTED_MODULE_5__.TransformerFactory.getInstance().register("scrollIndicators", new ScrollIndicatorsTransformer());
    _widget_TransformerFactory__WEBPACK_IMPORTED_MODULE_5__.TransformerFactory.getInstance().register("requiresFadingEdge", new RequiresFadingEdgeTransformer());
    _widget_TransformerFactory__WEBPACK_IMPORTED_MODULE_5__.TransformerFactory.getInstance().register("HapticFeedbackConstantsFlag", new HapticFeedbackConstantsFlagTransformer());
    _widget_TransformerFactory__WEBPACK_IMPORTED_MODULE_5__.TransformerFactory.getInstance().register("validationErrorDisplay", new ValidationErrorDisplayTransformer());
  };
  ViewImpl.prototype.markForReset = function () {
    this.flush = true;
  };
  ViewImpl.prototype.resetIfRequired = function () {
    if (this.flush) {
      this.reset();
    }
  };
  ViewImpl.prototype.reset = function () {
    this.accessibilityHeading = undefined;
    this.accessibilityLiveRegion = undefined;
    this.accessibilityPaneTitle = undefined;
    this.accessibilityTraversalAfter = undefined;
    this.accessibilityTraversalBefore = undefined;
    this.alpha = undefined;
    this.autofillHints = undefined;
    this.backgroundTint = undefined;
    this.backgroundTintMode = undefined;
    this.clickable = undefined;
    this.contentDescription = undefined;
    this.contextClickable = undefined;
    this.defaultFocusHighlightEnabled = undefined;
    this.duplicateParentState = undefined;
    this.elevation = undefined;
    this.fadeScrollbars = undefined;
    this.fadingEdgeLength = undefined;
    this.filterTouchesWhenObscured = undefined;
    this.fitsSystemWindows = undefined;
    this.focusableInTouchMode = undefined;
    this.focusedByDefault = undefined;
    this.forceHasOverlappingRendering = undefined;
    this.foregroundTint = undefined;
    this.foregroundTintMode = undefined;
    this.hapticFeedbackEnabled = undefined;
    this.importantForAccessibility = undefined;
    this.importantForAutofill = undefined;
    this.isScrollContainer = undefined;
    this.keepScreenOn = undefined;
    this.keyboardNavigationCluster = undefined;
    this.layoutDirection = undefined;
    this.longClickable = undefined;
    this.minHeight = undefined;
    this.minWidth = undefined;
    this.nextClusterForward = undefined;
    this.nextFocusDown = undefined;
    this.nextFocusForward = undefined;
    this.nextFocusLeft = undefined;
    this.nextFocusRight = undefined;
    this.nextFocusUp = undefined;
    this.rotation = undefined;
    this.rotationX = undefined;
    this.rotationY = undefined;
    this.saveEnabled = undefined;
    this.scaleX = undefined;
    this.scaleY = undefined;
    this.screenReaderFocusable = undefined;
    this.scrollIndicators = undefined;
    this.scrollbarDefaultDelayBeforeFade = undefined;
    this.scrollbarFadeDuration = undefined;
    this.scrollbarSize = undefined;
    this.scrollbarStyle = undefined;
    this.soundEffectsEnabled = undefined;
    this.textAlignment = undefined;
    this.textDirection = undefined;
    this.tooltipText = undefined;
    this.transformPivotX = undefined;
    this.transformPivotY = undefined;
    this.transitionName = undefined;
    this.translationX = undefined;
    this.translationY = undefined;
    this.translationZ = undefined;
    this.visibility = undefined;
    this.onApplyWindowInsets = undefined;
    this.onCapturedPointer = undefined;
    this.onClick = undefined;
    this.onContextClick = undefined;
    this.onCreateContextMenu = undefined;
    this.onDrag = undefined;
    this.onFocusChange = undefined;
    this.onGenericMotion = undefined;
    this.onHover = undefined;
    this.onKey = undefined;
    this.onLongClick = undefined;
    this.onScrollChange = undefined;
    this.onSystemUiVisibilityChange = undefined;
    this.onTouch = undefined;
    this.padding = undefined;
    this.paddingTop = undefined;
    this.paddingBottom = undefined;
    this.paddingLeft = undefined;
    this.paddingRight = undefined;
    this.paddingStart = undefined;
    this.paddingEnd = undefined;
    this.paddingHorizontal = undefined;
    this.paddingVertical = undefined;
    this.layerType = undefined;
    this.requiresFadingEdge = undefined;
    this.background = undefined;
    this.foreground = undefined;
    this.backgroundRepeat = undefined;
    this.modelSyncEvents = undefined;
    this.updateModelData_ = undefined;
    this.notifyDataSetChanged_ = undefined;
    this.modelParam = undefined;
    this.modelPojoToUi = undefined;
    this.modelUiToPojo = undefined;
    this.modelPojoToUiParams = undefined;
    this.refreshUiFromModel_ = undefined;
    this.modelUiToPojoEventIds = undefined;
    this.foregroundRepeat = undefined;
    this.foregroundGravity = undefined;
    this.performHapticFeedback_ = undefined;
    this.performHapticFeedbackWithFlags_ = undefined;
    this.attributeUnderTest = undefined;
    this.selected = undefined;
    this.enabled = undefined;
    this.focusable = undefined;
    this.scrollX = undefined;
    this.scrollY = undefined;
    this.invalidate_ = undefined;
    this.requestLayout_ = undefined;
    this.asDragSource = undefined;
    this.zIndex = undefined;
    this.maxWidth = undefined;
    this.maxHeight = undefined;
    this.style = undefined;
    this.errorStyle = undefined;
    this.validateForm_ = undefined;
    this.validation = undefined;
    this.v_required = undefined;
    this.v_minlength = undefined;
    this.v_maxlength = undefined;
    this.v_min = undefined;
    this.v_max = undefined;
    this.v_pattern = undefined;
    this.v_type = undefined;
    this.validationErrorDisplayType = undefined;
    this.customErrorMessageValues = undefined;
    this.customErrorMessageKeys = undefined;
    this.invalidateOnFrameChange = undefined;
    this.onSwiped = undefined;
    this.animatorXml_ = undefined;
    this.startAnimator_ = undefined;
    this.endAnimator_ = undefined;
    this.onAnimationStart = undefined;
    this.onAnimationEnd = undefined;
    this.onAnimationCancel = undefined;
    this.onAnimationRepeat = undefined;
    this.left = undefined;
    this.right = undefined;
    this.top = undefined;
    this.bottom = undefined;
    this.outlineAmbientShadowColor = undefined;
    this.outlineSpotShadowColor = undefined;
    this.cornerRadius = undefined;
    this.orderGet = 0;
    this.orderSet = 0;
    this.flush = false;
    return this.thisPointer;
  };
  ViewImpl.prototype.setLayoutParams = function (layoutParams) {
    this.resetIfRequired();
    this.layoutParams = layoutParams;
  };
  ViewImpl.prototype.getLayoutParams = function () {
    return this.layoutParams;
  };
  ViewImpl.prototype.tryGetAccessibilityHeading = function () {
    this.resetIfRequired();
    if (this.accessibilityHeading == null || this.accessibilityHeading == undefined) {
      this.accessibilityHeading = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.accessibilityHeading.setGetter(true);
    this.orderGet++;
    this.accessibilityHeading.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isAccessibilityHeading = function () {
    if (this.accessibilityHeading == null || this.accessibilityHeading == undefined) {
      this.accessibilityHeading = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.accessibilityHeading.getCommandReturnValue();
  };
  ViewImpl.prototype.setAccessibilityHeading = function (value) {
    this.resetIfRequired();
    if (this.accessibilityHeading == null || this.accessibilityHeading == undefined) {
      this.accessibilityHeading = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.accessibilityHeading.setSetter(true);
    this.accessibilityHeading.setValue(value);
    this.orderSet++;
    this.accessibilityHeading.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetAccessibilityLiveRegion = function () {
    this.resetIfRequired();
    if (this.accessibilityLiveRegion == null || this.accessibilityLiveRegion == undefined) {
      this.accessibilityLiveRegion = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.accessibilityLiveRegion.setGetter(true);
    this.orderGet++;
    this.accessibilityLiveRegion.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getAccessibilityLiveRegion = function () {
    if (this.accessibilityLiveRegion == null || this.accessibilityLiveRegion == undefined) {
      this.accessibilityLiveRegion = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.accessibilityLiveRegion.getCommandReturnValue();
  };
  ViewImpl.prototype.setAccessibilityLiveRegion = function (value) {
    this.resetIfRequired();
    if (this.accessibilityLiveRegion == null || this.accessibilityLiveRegion == undefined) {
      this.accessibilityLiveRegion = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.accessibilityLiveRegion.setSetter(true);
    this.accessibilityLiveRegion.setValue(value);
    this.orderSet++;
    this.accessibilityLiveRegion.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetAccessibilityPaneTitle = function () {
    this.resetIfRequired();
    if (this.accessibilityPaneTitle == null || this.accessibilityPaneTitle == undefined) {
      this.accessibilityPaneTitle = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.accessibilityPaneTitle.setGetter(true);
    this.orderGet++;
    this.accessibilityPaneTitle.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getAccessibilityPaneTitle = function () {
    if (this.accessibilityPaneTitle == null || this.accessibilityPaneTitle == undefined) {
      this.accessibilityPaneTitle = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.accessibilityPaneTitle.getCommandReturnValue();
  };
  ViewImpl.prototype.setAccessibilityPaneTitle = function (value) {
    this.resetIfRequired();
    if (this.accessibilityPaneTitle == null || this.accessibilityPaneTitle == undefined) {
      this.accessibilityPaneTitle = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.accessibilityPaneTitle.setSetter(true);
    this.accessibilityPaneTitle.setValue(value);
    this.orderSet++;
    this.accessibilityPaneTitle.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetAccessibilityTraversalAfter = function () {
    this.resetIfRequired();
    if (this.accessibilityTraversalAfter == null || this.accessibilityTraversalAfter == undefined) {
      this.accessibilityTraversalAfter = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.accessibilityTraversalAfter.setGetter(true);
    this.orderGet++;
    this.accessibilityTraversalAfter.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getAccessibilityTraversalAfter = function () {
    if (this.accessibilityTraversalAfter == null || this.accessibilityTraversalAfter == undefined) {
      this.accessibilityTraversalAfter = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.accessibilityTraversalAfter.getCommandReturnValue();
  };
  ViewImpl.prototype.setAccessibilityTraversalAfter = function (value) {
    this.resetIfRequired();
    if (this.accessibilityTraversalAfter == null || this.accessibilityTraversalAfter == undefined) {
      this.accessibilityTraversalAfter = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.accessibilityTraversalAfter.setSetter(true);
    this.accessibilityTraversalAfter.setValue(value);
    this.orderSet++;
    this.accessibilityTraversalAfter.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetAccessibilityTraversalBefore = function () {
    this.resetIfRequired();
    if (this.accessibilityTraversalBefore == null || this.accessibilityTraversalBefore == undefined) {
      this.accessibilityTraversalBefore = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.accessibilityTraversalBefore.setGetter(true);
    this.orderGet++;
    this.accessibilityTraversalBefore.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getAccessibilityTraversalBefore = function () {
    if (this.accessibilityTraversalBefore == null || this.accessibilityTraversalBefore == undefined) {
      this.accessibilityTraversalBefore = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.accessibilityTraversalBefore.getCommandReturnValue();
  };
  ViewImpl.prototype.setAccessibilityTraversalBefore = function (value) {
    this.resetIfRequired();
    if (this.accessibilityTraversalBefore == null || this.accessibilityTraversalBefore == undefined) {
      this.accessibilityTraversalBefore = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.accessibilityTraversalBefore.setSetter(true);
    this.accessibilityTraversalBefore.setValue(value);
    this.orderSet++;
    this.accessibilityTraversalBefore.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetAlpha = function () {
    this.resetIfRequired();
    if (this.alpha == null || this.alpha == undefined) {
      this.alpha = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.alpha.setGetter(true);
    this.orderGet++;
    this.alpha.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getAlpha = function () {
    if (this.alpha == null || this.alpha == undefined) {
      this.alpha = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.alpha.getCommandReturnValue();
  };
  ViewImpl.prototype.setAlpha = function (value) {
    this.resetIfRequired();
    if (this.alpha == null || this.alpha == undefined) {
      this.alpha = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.alpha.setSetter(true);
    this.alpha.setValue(value);
    this.orderSet++;
    this.alpha.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetAutofillHints = function () {
    this.resetIfRequired();
    if (this.autofillHints == null || this.autofillHints == undefined) {
      this.autofillHints = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.autofillHints.setGetter(true);
    this.orderGet++;
    this.autofillHints.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getAutofillHints = function () {
    if (this.autofillHints == null || this.autofillHints == undefined) {
      this.autofillHints = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.autofillHints.getCommandReturnValue();
  };
  ViewImpl.prototype.setAutofillHints = function (value) {
    this.resetIfRequired();
    if (this.autofillHints == null || this.autofillHints == undefined) {
      this.autofillHints = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.autofillHints.setSetter(true);
    this.autofillHints.setValue(value);
    this.orderSet++;
    this.autofillHints.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetBackgroundTint = function () {
    this.resetIfRequired();
    if (this.backgroundTint == null || this.backgroundTint == undefined) {
      this.backgroundTint = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.backgroundTint.setGetter(true);
    this.orderGet++;
    this.backgroundTint.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getBackgroundTint = function () {
    if (this.backgroundTint == null || this.backgroundTint == undefined) {
      this.backgroundTint = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.backgroundTint.getCommandReturnValue();
  };
  ViewImpl.prototype.setBackgroundTint = function (value) {
    this.resetIfRequired();
    if (this.backgroundTint == null || this.backgroundTint == undefined) {
      this.backgroundTint = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.backgroundTint.setSetter(true);
    this.backgroundTint.setValue(value);
    this.orderSet++;
    this.backgroundTint.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetBackgroundTintMode = function () {
    this.resetIfRequired();
    if (this.backgroundTintMode == null || this.backgroundTintMode == undefined) {
      this.backgroundTintMode = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.backgroundTintMode.setGetter(true);
    this.orderGet++;
    this.backgroundTintMode.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getBackgroundTintMode = function () {
    if (this.backgroundTintMode == null || this.backgroundTintMode == undefined) {
      this.backgroundTintMode = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.backgroundTintMode.getCommandReturnValue();
  };
  ViewImpl.prototype.setBackgroundTintMode = function (value) {
    this.resetIfRequired();
    if (this.backgroundTintMode == null || this.backgroundTintMode == undefined) {
      this.backgroundTintMode = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.backgroundTintMode.setSetter(true);
    this.backgroundTintMode.setValue(value);
    this.orderSet++;
    this.backgroundTintMode.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetClickable = function () {
    this.resetIfRequired();
    if (this.clickable == null || this.clickable == undefined) {
      this.clickable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.clickable.setGetter(true);
    this.orderGet++;
    this.clickable.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isClickable = function () {
    if (this.clickable == null || this.clickable == undefined) {
      this.clickable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.clickable.getCommandReturnValue();
  };
  ViewImpl.prototype.setClickable = function (value) {
    this.resetIfRequired();
    if (this.clickable == null || this.clickable == undefined) {
      this.clickable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.clickable.setSetter(true);
    this.clickable.setValue(value);
    this.orderSet++;
    this.clickable.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetContentDescription = function () {
    this.resetIfRequired();
    if (this.contentDescription == null || this.contentDescription == undefined) {
      this.contentDescription = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.contentDescription.setGetter(true);
    this.orderGet++;
    this.contentDescription.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getContentDescription = function () {
    if (this.contentDescription == null || this.contentDescription == undefined) {
      this.contentDescription = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.contentDescription.getCommandReturnValue();
  };
  ViewImpl.prototype.setContentDescription = function (value) {
    this.resetIfRequired();
    if (this.contentDescription == null || this.contentDescription == undefined) {
      this.contentDescription = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.contentDescription.setSetter(true);
    this.contentDescription.setValue(value);
    this.orderSet++;
    this.contentDescription.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetContextClickable = function () {
    this.resetIfRequired();
    if (this.contextClickable == null || this.contextClickable == undefined) {
      this.contextClickable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.contextClickable.setGetter(true);
    this.orderGet++;
    this.contextClickable.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isContextClickable = function () {
    if (this.contextClickable == null || this.contextClickable == undefined) {
      this.contextClickable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.contextClickable.getCommandReturnValue();
  };
  ViewImpl.prototype.setContextClickable = function (value) {
    this.resetIfRequired();
    if (this.contextClickable == null || this.contextClickable == undefined) {
      this.contextClickable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.contextClickable.setSetter(true);
    this.contextClickable.setValue(value);
    this.orderSet++;
    this.contextClickable.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetDefaultFocusHighlightEnabled = function () {
    this.resetIfRequired();
    if (this.defaultFocusHighlightEnabled == null || this.defaultFocusHighlightEnabled == undefined) {
      this.defaultFocusHighlightEnabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.defaultFocusHighlightEnabled.setGetter(true);
    this.orderGet++;
    this.defaultFocusHighlightEnabled.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isDefaultFocusHighlightEnabled = function () {
    if (this.defaultFocusHighlightEnabled == null || this.defaultFocusHighlightEnabled == undefined) {
      this.defaultFocusHighlightEnabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.defaultFocusHighlightEnabled.getCommandReturnValue();
  };
  ViewImpl.prototype.setDefaultFocusHighlightEnabled = function (value) {
    this.resetIfRequired();
    if (this.defaultFocusHighlightEnabled == null || this.defaultFocusHighlightEnabled == undefined) {
      this.defaultFocusHighlightEnabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.defaultFocusHighlightEnabled.setSetter(true);
    this.defaultFocusHighlightEnabled.setValue(value);
    this.orderSet++;
    this.defaultFocusHighlightEnabled.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetDuplicateParentState = function () {
    this.resetIfRequired();
    if (this.duplicateParentState == null || this.duplicateParentState == undefined) {
      this.duplicateParentState = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.duplicateParentState.setGetter(true);
    this.orderGet++;
    this.duplicateParentState.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isDuplicateParentState = function () {
    if (this.duplicateParentState == null || this.duplicateParentState == undefined) {
      this.duplicateParentState = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.duplicateParentState.getCommandReturnValue();
  };
  ViewImpl.prototype.setDuplicateParentState = function (value) {
    this.resetIfRequired();
    if (this.duplicateParentState == null || this.duplicateParentState == undefined) {
      this.duplicateParentState = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.duplicateParentState.setSetter(true);
    this.duplicateParentState.setValue(value);
    this.orderSet++;
    this.duplicateParentState.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetElevation = function () {
    this.resetIfRequired();
    if (this.elevation == null || this.elevation == undefined) {
      this.elevation = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.elevation.setGetter(true);
    this.orderGet++;
    this.elevation.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getElevation = function () {
    if (this.elevation == null || this.elevation == undefined) {
      this.elevation = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.elevation.getCommandReturnValue();
  };
  ViewImpl.prototype.setElevation = function (value) {
    this.resetIfRequired();
    if (this.elevation == null || this.elevation == undefined) {
      this.elevation = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.elevation.setSetter(true);
    this.elevation.setValue(value);
    this.orderSet++;
    this.elevation.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetFadeScrollbars = function () {
    this.resetIfRequired();
    if (this.fadeScrollbars == null || this.fadeScrollbars == undefined) {
      this.fadeScrollbars = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.fadeScrollbars.setGetter(true);
    this.orderGet++;
    this.fadeScrollbars.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isFadeScrollbars = function () {
    if (this.fadeScrollbars == null || this.fadeScrollbars == undefined) {
      this.fadeScrollbars = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.fadeScrollbars.getCommandReturnValue();
  };
  ViewImpl.prototype.setFadeScrollbars = function (value) {
    this.resetIfRequired();
    if (this.fadeScrollbars == null || this.fadeScrollbars == undefined) {
      this.fadeScrollbars = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.fadeScrollbars.setSetter(true);
    this.fadeScrollbars.setValue(value);
    this.orderSet++;
    this.fadeScrollbars.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setFadingEdgeLength = function (value) {
    this.resetIfRequired();
    if (this.fadingEdgeLength == null || this.fadingEdgeLength == undefined) {
      this.fadingEdgeLength = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.fadingEdgeLength.setSetter(true);
    this.fadingEdgeLength.setValue(value);
    this.orderSet++;
    this.fadingEdgeLength.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetFilterTouchesWhenObscured = function () {
    this.resetIfRequired();
    if (this.filterTouchesWhenObscured == null || this.filterTouchesWhenObscured == undefined) {
      this.filterTouchesWhenObscured = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.filterTouchesWhenObscured.setGetter(true);
    this.orderGet++;
    this.filterTouchesWhenObscured.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isFilterTouchesWhenObscured = function () {
    if (this.filterTouchesWhenObscured == null || this.filterTouchesWhenObscured == undefined) {
      this.filterTouchesWhenObscured = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.filterTouchesWhenObscured.getCommandReturnValue();
  };
  ViewImpl.prototype.setFilterTouchesWhenObscured = function (value) {
    this.resetIfRequired();
    if (this.filterTouchesWhenObscured == null || this.filterTouchesWhenObscured == undefined) {
      this.filterTouchesWhenObscured = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.filterTouchesWhenObscured.setSetter(true);
    this.filterTouchesWhenObscured.setValue(value);
    this.orderSet++;
    this.filterTouchesWhenObscured.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetFitsSystemWindows = function () {
    this.resetIfRequired();
    if (this.fitsSystemWindows == null || this.fitsSystemWindows == undefined) {
      this.fitsSystemWindows = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.fitsSystemWindows.setGetter(true);
    this.orderGet++;
    this.fitsSystemWindows.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isFitsSystemWindows = function () {
    if (this.fitsSystemWindows == null || this.fitsSystemWindows == undefined) {
      this.fitsSystemWindows = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.fitsSystemWindows.getCommandReturnValue();
  };
  ViewImpl.prototype.setFitsSystemWindows = function (value) {
    this.resetIfRequired();
    if (this.fitsSystemWindows == null || this.fitsSystemWindows == undefined) {
      this.fitsSystemWindows = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.fitsSystemWindows.setSetter(true);
    this.fitsSystemWindows.setValue(value);
    this.orderSet++;
    this.fitsSystemWindows.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetFocusableInTouchMode = function () {
    this.resetIfRequired();
    if (this.focusableInTouchMode == null || this.focusableInTouchMode == undefined) {
      this.focusableInTouchMode = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.focusableInTouchMode.setGetter(true);
    this.orderGet++;
    this.focusableInTouchMode.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isFocusableInTouchMode = function () {
    if (this.focusableInTouchMode == null || this.focusableInTouchMode == undefined) {
      this.focusableInTouchMode = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.focusableInTouchMode.getCommandReturnValue();
  };
  ViewImpl.prototype.setFocusableInTouchMode = function (value) {
    this.resetIfRequired();
    if (this.focusableInTouchMode == null || this.focusableInTouchMode == undefined) {
      this.focusableInTouchMode = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.focusableInTouchMode.setSetter(true);
    this.focusableInTouchMode.setValue(value);
    this.orderSet++;
    this.focusableInTouchMode.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetFocusedByDefault = function () {
    this.resetIfRequired();
    if (this.focusedByDefault == null || this.focusedByDefault == undefined) {
      this.focusedByDefault = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.focusedByDefault.setGetter(true);
    this.orderGet++;
    this.focusedByDefault.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isFocusedByDefault = function () {
    if (this.focusedByDefault == null || this.focusedByDefault == undefined) {
      this.focusedByDefault = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.focusedByDefault.getCommandReturnValue();
  };
  ViewImpl.prototype.setFocusedByDefault = function (value) {
    this.resetIfRequired();
    if (this.focusedByDefault == null || this.focusedByDefault == undefined) {
      this.focusedByDefault = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.focusedByDefault.setSetter(true);
    this.focusedByDefault.setValue(value);
    this.orderSet++;
    this.focusedByDefault.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setForceHasOverlappingRendering = function (value) {
    this.resetIfRequired();
    if (this.forceHasOverlappingRendering == null || this.forceHasOverlappingRendering == undefined) {
      this.forceHasOverlappingRendering = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.forceHasOverlappingRendering.setSetter(true);
    this.forceHasOverlappingRendering.setValue(value);
    this.orderSet++;
    this.forceHasOverlappingRendering.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetForegroundTint = function () {
    this.resetIfRequired();
    if (this.foregroundTint == null || this.foregroundTint == undefined) {
      this.foregroundTint = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.foregroundTint.setGetter(true);
    this.orderGet++;
    this.foregroundTint.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getForegroundTint = function () {
    if (this.foregroundTint == null || this.foregroundTint == undefined) {
      this.foregroundTint = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.foregroundTint.getCommandReturnValue();
  };
  ViewImpl.prototype.setForegroundTint = function (value) {
    this.resetIfRequired();
    if (this.foregroundTint == null || this.foregroundTint == undefined) {
      this.foregroundTint = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.foregroundTint.setSetter(true);
    this.foregroundTint.setValue(value);
    this.orderSet++;
    this.foregroundTint.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetForegroundTintMode = function () {
    this.resetIfRequired();
    if (this.foregroundTintMode == null || this.foregroundTintMode == undefined) {
      this.foregroundTintMode = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.foregroundTintMode.setGetter(true);
    this.orderGet++;
    this.foregroundTintMode.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getForegroundTintMode = function () {
    if (this.foregroundTintMode == null || this.foregroundTintMode == undefined) {
      this.foregroundTintMode = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.foregroundTintMode.getCommandReturnValue();
  };
  ViewImpl.prototype.setForegroundTintMode = function (value) {
    this.resetIfRequired();
    if (this.foregroundTintMode == null || this.foregroundTintMode == undefined) {
      this.foregroundTintMode = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.foregroundTintMode.setSetter(true);
    this.foregroundTintMode.setValue(value);
    this.orderSet++;
    this.foregroundTintMode.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetHapticFeedbackEnabled = function () {
    this.resetIfRequired();
    if (this.hapticFeedbackEnabled == null || this.hapticFeedbackEnabled == undefined) {
      this.hapticFeedbackEnabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.hapticFeedbackEnabled.setGetter(true);
    this.orderGet++;
    this.hapticFeedbackEnabled.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isHapticFeedbackEnabled = function () {
    if (this.hapticFeedbackEnabled == null || this.hapticFeedbackEnabled == undefined) {
      this.hapticFeedbackEnabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.hapticFeedbackEnabled.getCommandReturnValue();
  };
  ViewImpl.prototype.setHapticFeedbackEnabled = function (value) {
    this.resetIfRequired();
    if (this.hapticFeedbackEnabled == null || this.hapticFeedbackEnabled == undefined) {
      this.hapticFeedbackEnabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.hapticFeedbackEnabled.setSetter(true);
    this.hapticFeedbackEnabled.setValue(value);
    this.orderSet++;
    this.hapticFeedbackEnabled.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetImportantForAccessibility = function () {
    this.resetIfRequired();
    if (this.importantForAccessibility == null || this.importantForAccessibility == undefined) {
      this.importantForAccessibility = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.importantForAccessibility.setGetter(true);
    this.orderGet++;
    this.importantForAccessibility.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getImportantForAccessibility = function () {
    if (this.importantForAccessibility == null || this.importantForAccessibility == undefined) {
      this.importantForAccessibility = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.importantForAccessibility.getCommandReturnValue();
  };
  ViewImpl.prototype.setImportantForAccessibility = function (value) {
    this.resetIfRequired();
    if (this.importantForAccessibility == null || this.importantForAccessibility == undefined) {
      this.importantForAccessibility = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.importantForAccessibility.setSetter(true);
    this.importantForAccessibility.setValue(value);
    this.orderSet++;
    this.importantForAccessibility.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetImportantForAutofill = function () {
    this.resetIfRequired();
    if (this.importantForAutofill == null || this.importantForAutofill == undefined) {
      this.importantForAutofill = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.importantForAutofill.setGetter(true);
    this.orderGet++;
    this.importantForAutofill.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getImportantForAutofill = function () {
    if (this.importantForAutofill == null || this.importantForAutofill == undefined) {
      this.importantForAutofill = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.importantForAutofill.setTransformer('importantForAutofill');
    return this.importantForAutofill.getCommandReturnValue();
  };
  ViewImpl.prototype.setImportantForAutofill = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.importantForAutofill == null || this.importantForAutofill == undefined) {
      this.importantForAutofill = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.importantForAutofill.setSetter(true);
    this.importantForAutofill.setValue(value);
    this.orderSet++;
    this.importantForAutofill.setOrderSet(this.orderSet);
    this.importantForAutofill.setTransformer('importantForAutofill');
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetIsScrollContainer = function () {
    this.resetIfRequired();
    if (this.isScrollContainer == null || this.isScrollContainer == undefined) {
      this.isScrollContainer = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.isScrollContainer.setGetter(true);
    this.orderGet++;
    this.isScrollContainer.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isIsScrollContainer = function () {
    if (this.isScrollContainer == null || this.isScrollContainer == undefined) {
      this.isScrollContainer = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.isScrollContainer.getCommandReturnValue();
  };
  ViewImpl.prototype.setIsScrollContainer = function (value) {
    this.resetIfRequired();
    if (this.isScrollContainer == null || this.isScrollContainer == undefined) {
      this.isScrollContainer = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.isScrollContainer.setSetter(true);
    this.isScrollContainer.setValue(value);
    this.orderSet++;
    this.isScrollContainer.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetKeepScreenOn = function () {
    this.resetIfRequired();
    if (this.keepScreenOn == null || this.keepScreenOn == undefined) {
      this.keepScreenOn = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.keepScreenOn.setGetter(true);
    this.orderGet++;
    this.keepScreenOn.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isKeepScreenOn = function () {
    if (this.keepScreenOn == null || this.keepScreenOn == undefined) {
      this.keepScreenOn = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.keepScreenOn.getCommandReturnValue();
  };
  ViewImpl.prototype.setKeepScreenOn = function (value) {
    this.resetIfRequired();
    if (this.keepScreenOn == null || this.keepScreenOn == undefined) {
      this.keepScreenOn = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.keepScreenOn.setSetter(true);
    this.keepScreenOn.setValue(value);
    this.orderSet++;
    this.keepScreenOn.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetKeyboardNavigationCluster = function () {
    this.resetIfRequired();
    if (this.keyboardNavigationCluster == null || this.keyboardNavigationCluster == undefined) {
      this.keyboardNavigationCluster = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.keyboardNavigationCluster.setGetter(true);
    this.orderGet++;
    this.keyboardNavigationCluster.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isKeyboardNavigationCluster = function () {
    if (this.keyboardNavigationCluster == null || this.keyboardNavigationCluster == undefined) {
      this.keyboardNavigationCluster = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.keyboardNavigationCluster.getCommandReturnValue();
  };
  ViewImpl.prototype.setKeyboardNavigationCluster = function (value) {
    this.resetIfRequired();
    if (this.keyboardNavigationCluster == null || this.keyboardNavigationCluster == undefined) {
      this.keyboardNavigationCluster = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.keyboardNavigationCluster.setSetter(true);
    this.keyboardNavigationCluster.setValue(value);
    this.orderSet++;
    this.keyboardNavigationCluster.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetLayoutDirection = function () {
    this.resetIfRequired();
    if (this.layoutDirection == null || this.layoutDirection == undefined) {
      this.layoutDirection = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layoutDirection.setGetter(true);
    this.orderGet++;
    this.layoutDirection.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getLayoutDirection = function () {
    if (this.layoutDirection == null || this.layoutDirection == undefined) {
      this.layoutDirection = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.layoutDirection.getCommandReturnValue();
  };
  ViewImpl.prototype.setLayoutDirection = function (value) {
    this.resetIfRequired();
    if (this.layoutDirection == null || this.layoutDirection == undefined) {
      this.layoutDirection = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layoutDirection.setSetter(true);
    this.layoutDirection.setValue(value);
    this.orderSet++;
    this.layoutDirection.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetLongClickable = function () {
    this.resetIfRequired();
    if (this.longClickable == null || this.longClickable == undefined) {
      this.longClickable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.longClickable.setGetter(true);
    this.orderGet++;
    this.longClickable.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isLongClickable = function () {
    if (this.longClickable == null || this.longClickable == undefined) {
      this.longClickable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.longClickable.getCommandReturnValue();
  };
  ViewImpl.prototype.setLongClickable = function (value) {
    this.resetIfRequired();
    if (this.longClickable == null || this.longClickable == undefined) {
      this.longClickable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.longClickable.setSetter(true);
    this.longClickable.setValue(value);
    this.orderSet++;
    this.longClickable.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetMinHeight = function () {
    this.resetIfRequired();
    if (this.minHeight == null || this.minHeight == undefined) {
      this.minHeight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.minHeight.setGetter(true);
    this.orderGet++;
    this.minHeight.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getMinHeight = function () {
    if (this.minHeight == null || this.minHeight == undefined) {
      this.minHeight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.minHeight.getCommandReturnValue();
  };
  ViewImpl.prototype.setMinHeight = function (value) {
    this.resetIfRequired();
    if (this.minHeight == null || this.minHeight == undefined) {
      this.minHeight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.minHeight.setSetter(true);
    this.minHeight.setValue(value);
    this.orderSet++;
    this.minHeight.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetMinWidth = function () {
    this.resetIfRequired();
    if (this.minWidth == null || this.minWidth == undefined) {
      this.minWidth = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.minWidth.setGetter(true);
    this.orderGet++;
    this.minWidth.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getMinWidth = function () {
    if (this.minWidth == null || this.minWidth == undefined) {
      this.minWidth = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.minWidth.getCommandReturnValue();
  };
  ViewImpl.prototype.setMinWidth = function (value) {
    this.resetIfRequired();
    if (this.minWidth == null || this.minWidth == undefined) {
      this.minWidth = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.minWidth.setSetter(true);
    this.minWidth.setValue(value);
    this.orderSet++;
    this.minWidth.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetNextClusterForward = function () {
    this.resetIfRequired();
    if (this.nextClusterForward == null || this.nextClusterForward == undefined) {
      this.nextClusterForward = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.nextClusterForward.setGetter(true);
    this.orderGet++;
    this.nextClusterForward.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getNextClusterForward = function () {
    if (this.nextClusterForward == null || this.nextClusterForward == undefined) {
      this.nextClusterForward = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.nextClusterForward.getCommandReturnValue();
  };
  ViewImpl.prototype.setNextClusterForward = function (value) {
    this.resetIfRequired();
    if (this.nextClusterForward == null || this.nextClusterForward == undefined) {
      this.nextClusterForward = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.nextClusterForward.setSetter(true);
    this.nextClusterForward.setValue(value);
    this.orderSet++;
    this.nextClusterForward.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetNextFocusDown = function () {
    this.resetIfRequired();
    if (this.nextFocusDown == null || this.nextFocusDown == undefined) {
      this.nextFocusDown = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.nextFocusDown.setGetter(true);
    this.orderGet++;
    this.nextFocusDown.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getNextFocusDown = function () {
    if (this.nextFocusDown == null || this.nextFocusDown == undefined) {
      this.nextFocusDown = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.nextFocusDown.getCommandReturnValue();
  };
  ViewImpl.prototype.setNextFocusDown = function (value) {
    this.resetIfRequired();
    if (this.nextFocusDown == null || this.nextFocusDown == undefined) {
      this.nextFocusDown = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.nextFocusDown.setSetter(true);
    this.nextFocusDown.setValue(value);
    this.orderSet++;
    this.nextFocusDown.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetNextFocusForward = function () {
    this.resetIfRequired();
    if (this.nextFocusForward == null || this.nextFocusForward == undefined) {
      this.nextFocusForward = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.nextFocusForward.setGetter(true);
    this.orderGet++;
    this.nextFocusForward.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getNextFocusForward = function () {
    if (this.nextFocusForward == null || this.nextFocusForward == undefined) {
      this.nextFocusForward = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.nextFocusForward.getCommandReturnValue();
  };
  ViewImpl.prototype.setNextFocusForward = function (value) {
    this.resetIfRequired();
    if (this.nextFocusForward == null || this.nextFocusForward == undefined) {
      this.nextFocusForward = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.nextFocusForward.setSetter(true);
    this.nextFocusForward.setValue(value);
    this.orderSet++;
    this.nextFocusForward.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetNextFocusLeft = function () {
    this.resetIfRequired();
    if (this.nextFocusLeft == null || this.nextFocusLeft == undefined) {
      this.nextFocusLeft = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.nextFocusLeft.setGetter(true);
    this.orderGet++;
    this.nextFocusLeft.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getNextFocusLeft = function () {
    if (this.nextFocusLeft == null || this.nextFocusLeft == undefined) {
      this.nextFocusLeft = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.nextFocusLeft.getCommandReturnValue();
  };
  ViewImpl.prototype.setNextFocusLeft = function (value) {
    this.resetIfRequired();
    if (this.nextFocusLeft == null || this.nextFocusLeft == undefined) {
      this.nextFocusLeft = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.nextFocusLeft.setSetter(true);
    this.nextFocusLeft.setValue(value);
    this.orderSet++;
    this.nextFocusLeft.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetNextFocusRight = function () {
    this.resetIfRequired();
    if (this.nextFocusRight == null || this.nextFocusRight == undefined) {
      this.nextFocusRight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.nextFocusRight.setGetter(true);
    this.orderGet++;
    this.nextFocusRight.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getNextFocusRight = function () {
    if (this.nextFocusRight == null || this.nextFocusRight == undefined) {
      this.nextFocusRight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.nextFocusRight.getCommandReturnValue();
  };
  ViewImpl.prototype.setNextFocusRight = function (value) {
    this.resetIfRequired();
    if (this.nextFocusRight == null || this.nextFocusRight == undefined) {
      this.nextFocusRight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.nextFocusRight.setSetter(true);
    this.nextFocusRight.setValue(value);
    this.orderSet++;
    this.nextFocusRight.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetNextFocusUp = function () {
    this.resetIfRequired();
    if (this.nextFocusUp == null || this.nextFocusUp == undefined) {
      this.nextFocusUp = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.nextFocusUp.setGetter(true);
    this.orderGet++;
    this.nextFocusUp.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getNextFocusUp = function () {
    if (this.nextFocusUp == null || this.nextFocusUp == undefined) {
      this.nextFocusUp = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.nextFocusUp.getCommandReturnValue();
  };
  ViewImpl.prototype.setNextFocusUp = function (value) {
    this.resetIfRequired();
    if (this.nextFocusUp == null || this.nextFocusUp == undefined) {
      this.nextFocusUp = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.nextFocusUp.setSetter(true);
    this.nextFocusUp.setValue(value);
    this.orderSet++;
    this.nextFocusUp.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetRotation = function () {
    this.resetIfRequired();
    if (this.rotation == null || this.rotation == undefined) {
      this.rotation = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.rotation.setGetter(true);
    this.orderGet++;
    this.rotation.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getRotation = function () {
    if (this.rotation == null || this.rotation == undefined) {
      this.rotation = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.rotation.getCommandReturnValue();
  };
  ViewImpl.prototype.setRotation = function (value) {
    this.resetIfRequired();
    if (this.rotation == null || this.rotation == undefined) {
      this.rotation = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.rotation.setSetter(true);
    this.rotation.setValue(value);
    this.orderSet++;
    this.rotation.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetRotationX = function () {
    this.resetIfRequired();
    if (this.rotationX == null || this.rotationX == undefined) {
      this.rotationX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.rotationX.setGetter(true);
    this.orderGet++;
    this.rotationX.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getRotationX = function () {
    if (this.rotationX == null || this.rotationX == undefined) {
      this.rotationX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.rotationX.getCommandReturnValue();
  };
  ViewImpl.prototype.setRotationX = function (value) {
    this.resetIfRequired();
    if (this.rotationX == null || this.rotationX == undefined) {
      this.rotationX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.rotationX.setSetter(true);
    this.rotationX.setValue(value);
    this.orderSet++;
    this.rotationX.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetRotationY = function () {
    this.resetIfRequired();
    if (this.rotationY == null || this.rotationY == undefined) {
      this.rotationY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.rotationY.setGetter(true);
    this.orderGet++;
    this.rotationY.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getRotationY = function () {
    if (this.rotationY == null || this.rotationY == undefined) {
      this.rotationY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.rotationY.getCommandReturnValue();
  };
  ViewImpl.prototype.setRotationY = function (value) {
    this.resetIfRequired();
    if (this.rotationY == null || this.rotationY == undefined) {
      this.rotationY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.rotationY.setSetter(true);
    this.rotationY.setValue(value);
    this.orderSet++;
    this.rotationY.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetSaveEnabled = function () {
    this.resetIfRequired();
    if (this.saveEnabled == null || this.saveEnabled == undefined) {
      this.saveEnabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.saveEnabled.setGetter(true);
    this.orderGet++;
    this.saveEnabled.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isSaveEnabled = function () {
    if (this.saveEnabled == null || this.saveEnabled == undefined) {
      this.saveEnabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.saveEnabled.getCommandReturnValue();
  };
  ViewImpl.prototype.setSaveEnabled = function (value) {
    this.resetIfRequired();
    if (this.saveEnabled == null || this.saveEnabled == undefined) {
      this.saveEnabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.saveEnabled.setSetter(true);
    this.saveEnabled.setValue(value);
    this.orderSet++;
    this.saveEnabled.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScaleX = function () {
    this.resetIfRequired();
    if (this.scaleX == null || this.scaleX == undefined) {
      this.scaleX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scaleX.setGetter(true);
    this.orderGet++;
    this.scaleX.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScaleX = function () {
    if (this.scaleX == null || this.scaleX == undefined) {
      this.scaleX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.scaleX.getCommandReturnValue();
  };
  ViewImpl.prototype.setScaleX = function (value) {
    this.resetIfRequired();
    if (this.scaleX == null || this.scaleX == undefined) {
      this.scaleX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scaleX.setSetter(true);
    this.scaleX.setValue(value);
    this.orderSet++;
    this.scaleX.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScaleY = function () {
    this.resetIfRequired();
    if (this.scaleY == null || this.scaleY == undefined) {
      this.scaleY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scaleY.setGetter(true);
    this.orderGet++;
    this.scaleY.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScaleY = function () {
    if (this.scaleY == null || this.scaleY == undefined) {
      this.scaleY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.scaleY.getCommandReturnValue();
  };
  ViewImpl.prototype.setScaleY = function (value) {
    this.resetIfRequired();
    if (this.scaleY == null || this.scaleY == undefined) {
      this.scaleY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scaleY.setSetter(true);
    this.scaleY.setValue(value);
    this.orderSet++;
    this.scaleY.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScreenReaderFocusable = function () {
    this.resetIfRequired();
    if (this.screenReaderFocusable == null || this.screenReaderFocusable == undefined) {
      this.screenReaderFocusable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.screenReaderFocusable.setGetter(true);
    this.orderGet++;
    this.screenReaderFocusable.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isScreenReaderFocusable = function () {
    if (this.screenReaderFocusable == null || this.screenReaderFocusable == undefined) {
      this.screenReaderFocusable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.screenReaderFocusable.getCommandReturnValue();
  };
  ViewImpl.prototype.setScreenReaderFocusable = function (value) {
    this.resetIfRequired();
    if (this.screenReaderFocusable == null || this.screenReaderFocusable == undefined) {
      this.screenReaderFocusable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.screenReaderFocusable.setSetter(true);
    this.screenReaderFocusable.setValue(value);
    this.orderSet++;
    this.screenReaderFocusable.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollIndicators = function () {
    this.resetIfRequired();
    if (this.scrollIndicators == null || this.scrollIndicators == undefined) {
      this.scrollIndicators = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollIndicators.setGetter(true);
    this.orderGet++;
    this.scrollIndicators.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollIndicators = function () {
    if (this.scrollIndicators == null || this.scrollIndicators == undefined) {
      this.scrollIndicators = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollIndicators.setTransformer('scrollIndicators');
    return this.scrollIndicators.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollIndicators = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.scrollIndicators == null || this.scrollIndicators == undefined) {
      this.scrollIndicators = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollIndicators.setSetter(true);
    this.scrollIndicators.setValue(value);
    this.orderSet++;
    this.scrollIndicators.setOrderSet(this.orderSet);
    this.scrollIndicators.setTransformer('scrollIndicators');
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollbarDefaultDelayBeforeFade = function () {
    this.resetIfRequired();
    if (this.scrollbarDefaultDelayBeforeFade == null || this.scrollbarDefaultDelayBeforeFade == undefined) {
      this.scrollbarDefaultDelayBeforeFade = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollbarDefaultDelayBeforeFade.setGetter(true);
    this.orderGet++;
    this.scrollbarDefaultDelayBeforeFade.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollbarDefaultDelayBeforeFade = function () {
    if (this.scrollbarDefaultDelayBeforeFade == null || this.scrollbarDefaultDelayBeforeFade == undefined) {
      this.scrollbarDefaultDelayBeforeFade = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.scrollbarDefaultDelayBeforeFade.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollbarDefaultDelayBeforeFade = function (value) {
    this.resetIfRequired();
    if (this.scrollbarDefaultDelayBeforeFade == null || this.scrollbarDefaultDelayBeforeFade == undefined) {
      this.scrollbarDefaultDelayBeforeFade = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollbarDefaultDelayBeforeFade.setSetter(true);
    this.scrollbarDefaultDelayBeforeFade.setValue(value);
    this.orderSet++;
    this.scrollbarDefaultDelayBeforeFade.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollbarFadeDuration = function () {
    this.resetIfRequired();
    if (this.scrollbarFadeDuration == null || this.scrollbarFadeDuration == undefined) {
      this.scrollbarFadeDuration = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollbarFadeDuration.setGetter(true);
    this.orderGet++;
    this.scrollbarFadeDuration.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollbarFadeDuration = function () {
    if (this.scrollbarFadeDuration == null || this.scrollbarFadeDuration == undefined) {
      this.scrollbarFadeDuration = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.scrollbarFadeDuration.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollbarFadeDuration = function (value) {
    this.resetIfRequired();
    if (this.scrollbarFadeDuration == null || this.scrollbarFadeDuration == undefined) {
      this.scrollbarFadeDuration = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollbarFadeDuration.setSetter(true);
    this.scrollbarFadeDuration.setValue(value);
    this.orderSet++;
    this.scrollbarFadeDuration.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollbarSize = function () {
    this.resetIfRequired();
    if (this.scrollbarSize == null || this.scrollbarSize == undefined) {
      this.scrollbarSize = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollbarSize.setGetter(true);
    this.orderGet++;
    this.scrollbarSize.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollbarSize = function () {
    if (this.scrollbarSize == null || this.scrollbarSize == undefined) {
      this.scrollbarSize = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.scrollbarSize.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollbarSize = function (value) {
    this.resetIfRequired();
    if (this.scrollbarSize == null || this.scrollbarSize == undefined) {
      this.scrollbarSize = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollbarSize.setSetter(true);
    this.scrollbarSize.setValue(value);
    this.orderSet++;
    this.scrollbarSize.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollbarStyle = function () {
    this.resetIfRequired();
    if (this.scrollbarStyle == null || this.scrollbarStyle == undefined) {
      this.scrollbarStyle = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollbarStyle.setGetter(true);
    this.orderGet++;
    this.scrollbarStyle.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollbarStyle = function () {
    if (this.scrollbarStyle == null || this.scrollbarStyle == undefined) {
      this.scrollbarStyle = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.scrollbarStyle.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollbarStyle = function (value) {
    this.resetIfRequired();
    if (this.scrollbarStyle == null || this.scrollbarStyle == undefined) {
      this.scrollbarStyle = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollbarStyle.setSetter(true);
    this.scrollbarStyle.setValue(value);
    this.orderSet++;
    this.scrollbarStyle.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetSoundEffectsEnabled = function () {
    this.resetIfRequired();
    if (this.soundEffectsEnabled == null || this.soundEffectsEnabled == undefined) {
      this.soundEffectsEnabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.soundEffectsEnabled.setGetter(true);
    this.orderGet++;
    this.soundEffectsEnabled.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isSoundEffectsEnabled = function () {
    if (this.soundEffectsEnabled == null || this.soundEffectsEnabled == undefined) {
      this.soundEffectsEnabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.soundEffectsEnabled.getCommandReturnValue();
  };
  ViewImpl.prototype.setSoundEffectsEnabled = function (value) {
    this.resetIfRequired();
    if (this.soundEffectsEnabled == null || this.soundEffectsEnabled == undefined) {
      this.soundEffectsEnabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.soundEffectsEnabled.setSetter(true);
    this.soundEffectsEnabled.setValue(value);
    this.orderSet++;
    this.soundEffectsEnabled.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTextAlignment = function () {
    this.resetIfRequired();
    if (this.textAlignment == null || this.textAlignment == undefined) {
      this.textAlignment = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.textAlignment.setGetter(true);
    this.orderGet++;
    this.textAlignment.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTextAlignment = function () {
    if (this.textAlignment == null || this.textAlignment == undefined) {
      this.textAlignment = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.textAlignment.getCommandReturnValue();
  };
  ViewImpl.prototype.setTextAlignment = function (value) {
    this.resetIfRequired();
    if (this.textAlignment == null || this.textAlignment == undefined) {
      this.textAlignment = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.textAlignment.setSetter(true);
    this.textAlignment.setValue(value);
    this.orderSet++;
    this.textAlignment.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTextDirection = function () {
    this.resetIfRequired();
    if (this.textDirection == null || this.textDirection == undefined) {
      this.textDirection = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.textDirection.setGetter(true);
    this.orderGet++;
    this.textDirection.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTextDirection = function () {
    if (this.textDirection == null || this.textDirection == undefined) {
      this.textDirection = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.textDirection.getCommandReturnValue();
  };
  ViewImpl.prototype.setTextDirection = function (value) {
    this.resetIfRequired();
    if (this.textDirection == null || this.textDirection == undefined) {
      this.textDirection = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.textDirection.setSetter(true);
    this.textDirection.setValue(value);
    this.orderSet++;
    this.textDirection.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTooltipText = function () {
    this.resetIfRequired();
    if (this.tooltipText == null || this.tooltipText == undefined) {
      this.tooltipText = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.tooltipText.setGetter(true);
    this.orderGet++;
    this.tooltipText.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTooltipText = function () {
    if (this.tooltipText == null || this.tooltipText == undefined) {
      this.tooltipText = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.tooltipText.getCommandReturnValue();
  };
  ViewImpl.prototype.setTooltipText = function (value) {
    this.resetIfRequired();
    if (this.tooltipText == null || this.tooltipText == undefined) {
      this.tooltipText = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.tooltipText.setSetter(true);
    this.tooltipText.setValue(value);
    this.orderSet++;
    this.tooltipText.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTransformPivotX = function () {
    this.resetIfRequired();
    if (this.transformPivotX == null || this.transformPivotX == undefined) {
      this.transformPivotX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.transformPivotX.setGetter(true);
    this.orderGet++;
    this.transformPivotX.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTransformPivotX = function () {
    if (this.transformPivotX == null || this.transformPivotX == undefined) {
      this.transformPivotX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.transformPivotX.getCommandReturnValue();
  };
  ViewImpl.prototype.setTransformPivotX = function (value) {
    this.resetIfRequired();
    if (this.transformPivotX == null || this.transformPivotX == undefined) {
      this.transformPivotX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.transformPivotX.setSetter(true);
    this.transformPivotX.setValue(value);
    this.orderSet++;
    this.transformPivotX.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTransformPivotY = function () {
    this.resetIfRequired();
    if (this.transformPivotY == null || this.transformPivotY == undefined) {
      this.transformPivotY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.transformPivotY.setGetter(true);
    this.orderGet++;
    this.transformPivotY.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTransformPivotY = function () {
    if (this.transformPivotY == null || this.transformPivotY == undefined) {
      this.transformPivotY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.transformPivotY.getCommandReturnValue();
  };
  ViewImpl.prototype.setTransformPivotY = function (value) {
    this.resetIfRequired();
    if (this.transformPivotY == null || this.transformPivotY == undefined) {
      this.transformPivotY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.transformPivotY.setSetter(true);
    this.transformPivotY.setValue(value);
    this.orderSet++;
    this.transformPivotY.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTransitionName = function () {
    this.resetIfRequired();
    if (this.transitionName == null || this.transitionName == undefined) {
      this.transitionName = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.transitionName.setGetter(true);
    this.orderGet++;
    this.transitionName.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTransitionName = function () {
    if (this.transitionName == null || this.transitionName == undefined) {
      this.transitionName = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.transitionName.getCommandReturnValue();
  };
  ViewImpl.prototype.setTransitionName = function (value) {
    this.resetIfRequired();
    if (this.transitionName == null || this.transitionName == undefined) {
      this.transitionName = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.transitionName.setSetter(true);
    this.transitionName.setValue(value);
    this.orderSet++;
    this.transitionName.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTranslationX = function () {
    this.resetIfRequired();
    if (this.translationX == null || this.translationX == undefined) {
      this.translationX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.translationX.setGetter(true);
    this.orderGet++;
    this.translationX.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTranslationX = function () {
    if (this.translationX == null || this.translationX == undefined) {
      this.translationX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.translationX.getCommandReturnValue();
  };
  ViewImpl.prototype.setTranslationX = function (value) {
    this.resetIfRequired();
    if (this.translationX == null || this.translationX == undefined) {
      this.translationX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.translationX.setSetter(true);
    this.translationX.setValue(value);
    this.orderSet++;
    this.translationX.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTranslationY = function () {
    this.resetIfRequired();
    if (this.translationY == null || this.translationY == undefined) {
      this.translationY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.translationY.setGetter(true);
    this.orderGet++;
    this.translationY.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTranslationY = function () {
    if (this.translationY == null || this.translationY == undefined) {
      this.translationY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.translationY.getCommandReturnValue();
  };
  ViewImpl.prototype.setTranslationY = function (value) {
    this.resetIfRequired();
    if (this.translationY == null || this.translationY == undefined) {
      this.translationY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.translationY.setSetter(true);
    this.translationY.setValue(value);
    this.orderSet++;
    this.translationY.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTranslationZ = function () {
    this.resetIfRequired();
    if (this.translationZ == null || this.translationZ == undefined) {
      this.translationZ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.translationZ.setGetter(true);
    this.orderGet++;
    this.translationZ.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTranslationZ = function () {
    if (this.translationZ == null || this.translationZ == undefined) {
      this.translationZ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.translationZ.getCommandReturnValue();
  };
  ViewImpl.prototype.setTranslationZ = function (value) {
    this.resetIfRequired();
    if (this.translationZ == null || this.translationZ == undefined) {
      this.translationZ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.translationZ.setSetter(true);
    this.translationZ.setValue(value);
    this.orderSet++;
    this.translationZ.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetVisibility = function () {
    this.resetIfRequired();
    if (this.visibility == null || this.visibility == undefined) {
      this.visibility = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.visibility.setGetter(true);
    this.orderGet++;
    this.visibility.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getVisibility = function () {
    if (this.visibility == null || this.visibility == undefined) {
      this.visibility = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.visibility.getCommandReturnValue();
  };
  ViewImpl.prototype.setVisibility = function (value) {
    this.resetIfRequired();
    if (this.visibility == null || this.visibility == undefined) {
      this.visibility = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.visibility.setSetter(true);
    this.visibility.setValue(value);
    this.orderSet++;
    this.visibility.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnApplyWindowInsets = function (value) {
    this.resetIfRequired();
    if (this.onApplyWindowInsets == null || this.onApplyWindowInsets == undefined) {
      this.onApplyWindowInsets = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onApplyWindowInsets.setSetter(true);
    this.onApplyWindowInsets.setValue(value);
    this.orderSet++;
    this.onApplyWindowInsets.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnCapturedPointer = function (value) {
    this.resetIfRequired();
    if (this.onCapturedPointer == null || this.onCapturedPointer == undefined) {
      this.onCapturedPointer = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onCapturedPointer.setSetter(true);
    this.onCapturedPointer.setValue(value);
    this.orderSet++;
    this.onCapturedPointer.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnClick = function (value) {
    this.resetIfRequired();
    if (this.onClick == null || this.onClick == undefined) {
      this.onClick = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onClick.setSetter(true);
    this.onClick.setValue(value);
    this.orderSet++;
    this.onClick.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnContextClick = function (value) {
    this.resetIfRequired();
    if (this.onContextClick == null || this.onContextClick == undefined) {
      this.onContextClick = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onContextClick.setSetter(true);
    this.onContextClick.setValue(value);
    this.orderSet++;
    this.onContextClick.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnCreateContextMenu = function (value) {
    this.resetIfRequired();
    if (this.onCreateContextMenu == null || this.onCreateContextMenu == undefined) {
      this.onCreateContextMenu = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onCreateContextMenu.setSetter(true);
    this.onCreateContextMenu.setValue(value);
    this.orderSet++;
    this.onCreateContextMenu.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnDrag = function (value) {
    this.resetIfRequired();
    if (this.onDrag == null || this.onDrag == undefined) {
      this.onDrag = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onDrag.setSetter(true);
    this.onDrag.setValue(value);
    this.orderSet++;
    this.onDrag.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnFocusChange = function (value) {
    this.resetIfRequired();
    if (this.onFocusChange == null || this.onFocusChange == undefined) {
      this.onFocusChange = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onFocusChange.setSetter(true);
    this.onFocusChange.setValue(value);
    this.orderSet++;
    this.onFocusChange.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnGenericMotion = function (value) {
    this.resetIfRequired();
    if (this.onGenericMotion == null || this.onGenericMotion == undefined) {
      this.onGenericMotion = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onGenericMotion.setSetter(true);
    this.onGenericMotion.setValue(value);
    this.orderSet++;
    this.onGenericMotion.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnHover = function (value) {
    this.resetIfRequired();
    if (this.onHover == null || this.onHover == undefined) {
      this.onHover = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onHover.setSetter(true);
    this.onHover.setValue(value);
    this.orderSet++;
    this.onHover.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnKey = function (value) {
    this.resetIfRequired();
    if (this.onKey == null || this.onKey == undefined) {
      this.onKey = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onKey.setSetter(true);
    this.onKey.setValue(value);
    this.orderSet++;
    this.onKey.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnLongClick = function (value) {
    this.resetIfRequired();
    if (this.onLongClick == null || this.onLongClick == undefined) {
      this.onLongClick = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onLongClick.setSetter(true);
    this.onLongClick.setValue(value);
    this.orderSet++;
    this.onLongClick.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnScrollChange = function (value) {
    this.resetIfRequired();
    if (this.onScrollChange == null || this.onScrollChange == undefined) {
      this.onScrollChange = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onScrollChange.setSetter(true);
    this.onScrollChange.setValue(value);
    this.orderSet++;
    this.onScrollChange.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnSystemUiVisibilityChange = function (value) {
    this.resetIfRequired();
    if (this.onSystemUiVisibilityChange == null || this.onSystemUiVisibilityChange == undefined) {
      this.onSystemUiVisibilityChange = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onSystemUiVisibilityChange.setSetter(true);
    this.onSystemUiVisibilityChange.setValue(value);
    this.orderSet++;
    this.onSystemUiVisibilityChange.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnTouch = function (value) {
    this.resetIfRequired();
    if (this.onTouch == null || this.onTouch == undefined) {
      this.onTouch = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onTouch.setSetter(true);
    this.onTouch.setValue(value);
    this.orderSet++;
    this.onTouch.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setPadding = function (value) {
    this.resetIfRequired();
    if (this.padding == null || this.padding == undefined) {
      this.padding = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.padding.setSetter(true);
    this.padding.setValue(value);
    this.orderSet++;
    this.padding.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetPaddingTop = function () {
    this.resetIfRequired();
    if (this.paddingTop == null || this.paddingTop == undefined) {
      this.paddingTop = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingTop.setGetter(true);
    this.orderGet++;
    this.paddingTop.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getPaddingTop = function () {
    if (this.paddingTop == null || this.paddingTop == undefined) {
      this.paddingTop = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.paddingTop.getCommandReturnValue();
  };
  ViewImpl.prototype.setPaddingTop = function (value) {
    this.resetIfRequired();
    if (this.paddingTop == null || this.paddingTop == undefined) {
      this.paddingTop = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingTop.setSetter(true);
    this.paddingTop.setValue(value);
    this.orderSet++;
    this.paddingTop.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetPaddingBottom = function () {
    this.resetIfRequired();
    if (this.paddingBottom == null || this.paddingBottom == undefined) {
      this.paddingBottom = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingBottom.setGetter(true);
    this.orderGet++;
    this.paddingBottom.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getPaddingBottom = function () {
    if (this.paddingBottom == null || this.paddingBottom == undefined) {
      this.paddingBottom = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.paddingBottom.getCommandReturnValue();
  };
  ViewImpl.prototype.setPaddingBottom = function (value) {
    this.resetIfRequired();
    if (this.paddingBottom == null || this.paddingBottom == undefined) {
      this.paddingBottom = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingBottom.setSetter(true);
    this.paddingBottom.setValue(value);
    this.orderSet++;
    this.paddingBottom.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetPaddingLeft = function () {
    this.resetIfRequired();
    if (this.paddingLeft == null || this.paddingLeft == undefined) {
      this.paddingLeft = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingLeft.setGetter(true);
    this.orderGet++;
    this.paddingLeft.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getPaddingLeft = function () {
    if (this.paddingLeft == null || this.paddingLeft == undefined) {
      this.paddingLeft = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.paddingLeft.getCommandReturnValue();
  };
  ViewImpl.prototype.setPaddingLeft = function (value) {
    this.resetIfRequired();
    if (this.paddingLeft == null || this.paddingLeft == undefined) {
      this.paddingLeft = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingLeft.setSetter(true);
    this.paddingLeft.setValue(value);
    this.orderSet++;
    this.paddingLeft.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetPaddingRight = function () {
    this.resetIfRequired();
    if (this.paddingRight == null || this.paddingRight == undefined) {
      this.paddingRight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingRight.setGetter(true);
    this.orderGet++;
    this.paddingRight.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getPaddingRight = function () {
    if (this.paddingRight == null || this.paddingRight == undefined) {
      this.paddingRight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.paddingRight.getCommandReturnValue();
  };
  ViewImpl.prototype.setPaddingRight = function (value) {
    this.resetIfRequired();
    if (this.paddingRight == null || this.paddingRight == undefined) {
      this.paddingRight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingRight.setSetter(true);
    this.paddingRight.setValue(value);
    this.orderSet++;
    this.paddingRight.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetPaddingStart = function () {
    this.resetIfRequired();
    if (this.paddingStart == null || this.paddingStart == undefined) {
      this.paddingStart = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingStart.setGetter(true);
    this.orderGet++;
    this.paddingStart.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getPaddingStart = function () {
    if (this.paddingStart == null || this.paddingStart == undefined) {
      this.paddingStart = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.paddingStart.getCommandReturnValue();
  };
  ViewImpl.prototype.setPaddingStart = function (value) {
    this.resetIfRequired();
    if (this.paddingStart == null || this.paddingStart == undefined) {
      this.paddingStart = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingStart.setSetter(true);
    this.paddingStart.setValue(value);
    this.orderSet++;
    this.paddingStart.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetPaddingEnd = function () {
    this.resetIfRequired();
    if (this.paddingEnd == null || this.paddingEnd == undefined) {
      this.paddingEnd = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingEnd.setGetter(true);
    this.orderGet++;
    this.paddingEnd.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getPaddingEnd = function () {
    if (this.paddingEnd == null || this.paddingEnd == undefined) {
      this.paddingEnd = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.paddingEnd.getCommandReturnValue();
  };
  ViewImpl.prototype.setPaddingEnd = function (value) {
    this.resetIfRequired();
    if (this.paddingEnd == null || this.paddingEnd == undefined) {
      this.paddingEnd = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingEnd.setSetter(true);
    this.paddingEnd.setValue(value);
    this.orderSet++;
    this.paddingEnd.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setPaddingHorizontal = function (value) {
    this.resetIfRequired();
    if (this.paddingHorizontal == null || this.paddingHorizontal == undefined) {
      this.paddingHorizontal = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingHorizontal.setSetter(true);
    this.paddingHorizontal.setValue(value);
    this.orderSet++;
    this.paddingHorizontal.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setPaddingVertical = function (value) {
    this.resetIfRequired();
    if (this.paddingVertical == null || this.paddingVertical == undefined) {
      this.paddingVertical = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.paddingVertical.setSetter(true);
    this.paddingVertical.setValue(value);
    this.orderSet++;
    this.paddingVertical.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setLayerType = function (value) {
    this.resetIfRequired();
    if (this.layerType == null || this.layerType == undefined) {
      this.layerType = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layerType.setSetter(true);
    this.layerType.setValue(value);
    this.orderSet++;
    this.layerType.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetRequiresFadingEdge = function () {
    this.resetIfRequired();
    if (this.requiresFadingEdge == null || this.requiresFadingEdge == undefined) {
      this.requiresFadingEdge = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.requiresFadingEdge.setGetter(true);
    this.orderGet++;
    this.requiresFadingEdge.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getRequiresFadingEdge = function () {
    if (this.requiresFadingEdge == null || this.requiresFadingEdge == undefined) {
      this.requiresFadingEdge = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.requiresFadingEdge.setTransformer('requiresFadingEdge');
    return this.requiresFadingEdge.getCommandReturnValue();
  };
  ViewImpl.prototype.setRequiresFadingEdge = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.requiresFadingEdge == null || this.requiresFadingEdge == undefined) {
      this.requiresFadingEdge = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.requiresFadingEdge.setSetter(true);
    this.requiresFadingEdge.setValue(value);
    this.orderSet++;
    this.requiresFadingEdge.setOrderSet(this.orderSet);
    this.requiresFadingEdge.setTransformer('requiresFadingEdge');
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetBackground = function () {
    this.resetIfRequired();
    if (this.background == null || this.background == undefined) {
      this.background = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.background.setGetter(true);
    this.orderGet++;
    this.background.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getBackground = function () {
    if (this.background == null || this.background == undefined) {
      this.background = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.background.getCommandReturnValue();
  };
  ViewImpl.prototype.setBackground = function (value) {
    this.resetIfRequired();
    if (this.background == null || this.background == undefined) {
      this.background = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.background.setSetter(true);
    this.background.setValue(value);
    this.orderSet++;
    this.background.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetForeground = function () {
    this.resetIfRequired();
    if (this.foreground == null || this.foreground == undefined) {
      this.foreground = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.foreground.setGetter(true);
    this.orderGet++;
    this.foreground.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getForeground = function () {
    if (this.foreground == null || this.foreground == undefined) {
      this.foreground = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.foreground.getCommandReturnValue();
  };
  ViewImpl.prototype.setForeground = function (value) {
    this.resetIfRequired();
    if (this.foreground == null || this.foreground == undefined) {
      this.foreground = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.foreground.setSetter(true);
    this.foreground.setValue(value);
    this.orderSet++;
    this.foreground.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setBackgroundRepeat = function (value) {
    this.resetIfRequired();
    if (this.backgroundRepeat == null || this.backgroundRepeat == undefined) {
      this.backgroundRepeat = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.backgroundRepeat.setSetter(true);
    this.backgroundRepeat.setValue(value);
    this.orderSet++;
    this.backgroundRepeat.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetModelSyncEvents = function () {
    this.resetIfRequired();
    if (this.modelSyncEvents == null || this.modelSyncEvents == undefined) {
      this.modelSyncEvents = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelSyncEvents.setGetter(true);
    this.orderGet++;
    this.modelSyncEvents.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getModelSyncEvents = function () {
    if (this.modelSyncEvents == null || this.modelSyncEvents == undefined) {
      this.modelSyncEvents = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.modelSyncEvents.getCommandReturnValue();
  };
  ViewImpl.prototype.setModelSyncEvents = function (value) {
    this.resetIfRequired();
    if (this.modelSyncEvents == null || this.modelSyncEvents == undefined) {
      this.modelSyncEvents = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelSyncEvents.setSetter(true);
    this.modelSyncEvents.setValue(value);
    this.orderSet++;
    this.modelSyncEvents.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.updateModelData = function (expression, payload) {
    this.resetIfRequired();
    if (this.updateModelData_ == null || this.updateModelData_ == undefined) {
      this.updateModelData_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    var wrapper = new _app_ScopedObject__WEBPACK_IMPORTED_MODULE_6__.ScopedObject();
    wrapper.expression = expression;
    wrapper.payload = payload;
    this.updateModelData_.setSetter(true);
    this.updateModelData_.setValue(wrapper);
    this.orderSet++;
    this.updateModelData_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.updateModelDataWithScopedObject = function () {
    var arr = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      arr[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.updateModelData_ == null || this.updateModelData_ == undefined) {
      this.updateModelData_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.updateModelData_.setSetter(true);
    this.updateModelData_.setValue(arr);
    this.orderSet++;
    this.updateModelData_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.notifyDataSetChanged = function (value) {
    this.resetIfRequired();
    if (this.notifyDataSetChanged_ == null || this.notifyDataSetChanged_ == undefined) {
      this.notifyDataSetChanged_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.notifyDataSetChanged_.setSetter(true);
    this.notifyDataSetChanged_.setValue(value);
    this.orderSet++;
    this.notifyDataSetChanged_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetModelParam = function () {
    this.resetIfRequired();
    if (this.modelParam == null || this.modelParam == undefined) {
      this.modelParam = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelParam.setGetter(true);
    this.orderGet++;
    this.modelParam.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getModelParam = function () {
    if (this.modelParam == null || this.modelParam == undefined) {
      this.modelParam = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.modelParam.getCommandReturnValue();
  };
  ViewImpl.prototype.setModelParam = function (value) {
    this.resetIfRequired();
    if (this.modelParam == null || this.modelParam == undefined) {
      this.modelParam = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelParam.setSetter(true);
    this.modelParam.setValue(value);
    this.orderSet++;
    this.modelParam.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetModelPojoToUi = function () {
    this.resetIfRequired();
    if (this.modelPojoToUi == null || this.modelPojoToUi == undefined) {
      this.modelPojoToUi = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelPojoToUi.setGetter(true);
    this.orderGet++;
    this.modelPojoToUi.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getModelPojoToUi = function () {
    if (this.modelPojoToUi == null || this.modelPojoToUi == undefined) {
      this.modelPojoToUi = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.modelPojoToUi.getCommandReturnValue();
  };
  ViewImpl.prototype.setModelPojoToUi = function (value) {
    this.resetIfRequired();
    if (this.modelPojoToUi == null || this.modelPojoToUi == undefined) {
      this.modelPojoToUi = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelPojoToUi.setSetter(true);
    this.modelPojoToUi.setValue(value);
    this.orderSet++;
    this.modelPojoToUi.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetModelUiToPojo = function () {
    this.resetIfRequired();
    if (this.modelUiToPojo == null || this.modelUiToPojo == undefined) {
      this.modelUiToPojo = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelUiToPojo.setGetter(true);
    this.orderGet++;
    this.modelUiToPojo.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getModelUiToPojo = function () {
    if (this.modelUiToPojo == null || this.modelUiToPojo == undefined) {
      this.modelUiToPojo = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.modelUiToPojo.getCommandReturnValue();
  };
  ViewImpl.prototype.setModelUiToPojo = function (value) {
    this.resetIfRequired();
    if (this.modelUiToPojo == null || this.modelUiToPojo == undefined) {
      this.modelUiToPojo = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelUiToPojo.setSetter(true);
    this.modelUiToPojo.setValue(value);
    this.orderSet++;
    this.modelUiToPojo.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setModelPojoToUiParams = function (value) {
    this.resetIfRequired();
    if (this.modelPojoToUiParams == null || this.modelPojoToUiParams == undefined) {
      this.modelPojoToUiParams = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelPojoToUiParams.setSetter(true);
    this.modelPojoToUiParams.setValue(value);
    this.orderSet++;
    this.modelPojoToUiParams.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.refreshUiFromModel = function (value) {
    this.resetIfRequired();
    if (this.refreshUiFromModel_ == null || this.refreshUiFromModel_ == undefined) {
      this.refreshUiFromModel_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.refreshUiFromModel_.setSetter(true);
    this.refreshUiFromModel_.setValue(value);
    this.orderSet++;
    this.refreshUiFromModel_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setModelUiToPojoEventIds = function (value) {
    this.resetIfRequired();
    if (this.modelUiToPojoEventIds == null || this.modelUiToPojoEventIds == undefined) {
      this.modelUiToPojoEventIds = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.modelUiToPojoEventIds.setSetter(true);
    this.modelUiToPojoEventIds.setValue(value);
    this.orderSet++;
    this.modelUiToPojoEventIds.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setForegroundRepeat = function (value) {
    this.resetIfRequired();
    if (this.foregroundRepeat == null || this.foregroundRepeat == undefined) {
      this.foregroundRepeat = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.foregroundRepeat.setSetter(true);
    this.foregroundRepeat.setValue(value);
    this.orderSet++;
    this.foregroundRepeat.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetForegroundGravity = function () {
    this.resetIfRequired();
    if (this.foregroundGravity == null || this.foregroundGravity == undefined) {
      this.foregroundGravity = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.foregroundGravity.setGetter(true);
    this.orderGet++;
    this.foregroundGravity.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getForegroundGravity = function () {
    if (this.foregroundGravity == null || this.foregroundGravity == undefined) {
      this.foregroundGravity = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.foregroundGravity.setTransformer('gravity');
    return this.foregroundGravity.getCommandReturnValue();
  };
  ViewImpl.prototype.setForegroundGravity = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.foregroundGravity == null || this.foregroundGravity == undefined) {
      this.foregroundGravity = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.foregroundGravity.setSetter(true);
    this.foregroundGravity.setValue(value);
    this.orderSet++;
    this.foregroundGravity.setOrderSet(this.orderSet);
    this.foregroundGravity.setTransformer('gravity');
    return this.thisPointer;
  };
  ViewImpl.prototype.performHapticFeedback = function (value) {
    this.resetIfRequired();
    if (this.performHapticFeedback_ == null || this.performHapticFeedback_ == undefined) {
      this.performHapticFeedback_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.performHapticFeedback_.setSetter(true);
    this.performHapticFeedback_.setValue(value);
    this.orderSet++;
    this.performHapticFeedback_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.performHapticFeedbackWithFlags = function (value) {
    var flags = [];
    for (var _i = 1; _i < arguments.length; _i++) {
      flags[_i - 1] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.performHapticFeedbackWithFlags_ == null || this.performHapticFeedbackWithFlags_ == undefined) {
      this.performHapticFeedbackWithFlags_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    var wrapper = new ViewImpl_performHapticFeedbackWithFlags();
    wrapper.value = value;
    wrapper.flags = flags;
    this.performHapticFeedbackWithFlags_.setSetter(true);
    this.performHapticFeedbackWithFlags_.setValue(wrapper);
    this.orderSet++;
    this.performHapticFeedbackWithFlags_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setAttributeUnderTest = function (value) {
    this.resetIfRequired();
    if (this.attributeUnderTest == null || this.attributeUnderTest == undefined) {
      this.attributeUnderTest = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.attributeUnderTest.setSetter(true);
    this.attributeUnderTest.setValue(value);
    this.orderSet++;
    this.attributeUnderTest.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetSelected = function () {
    this.resetIfRequired();
    if (this.selected == null || this.selected == undefined) {
      this.selected = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.selected.setGetter(true);
    this.orderGet++;
    this.selected.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isSelected = function () {
    if (this.selected == null || this.selected == undefined) {
      this.selected = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.selected.getCommandReturnValue();
  };
  ViewImpl.prototype.setSelected = function (value) {
    this.resetIfRequired();
    if (this.selected == null || this.selected == undefined) {
      this.selected = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.selected.setSetter(true);
    this.selected.setValue(value);
    this.orderSet++;
    this.selected.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetEnabled = function () {
    this.resetIfRequired();
    if (this.enabled == null || this.enabled == undefined) {
      this.enabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.enabled.setGetter(true);
    this.orderGet++;
    this.enabled.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isEnabled = function () {
    if (this.enabled == null || this.enabled == undefined) {
      this.enabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.enabled.getCommandReturnValue();
  };
  ViewImpl.prototype.setEnabled = function (value) {
    this.resetIfRequired();
    if (this.enabled == null || this.enabled == undefined) {
      this.enabled = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.enabled.setSetter(true);
    this.enabled.setValue(value);
    this.orderSet++;
    this.enabled.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetFocusable = function () {
    this.resetIfRequired();
    if (this.focusable == null || this.focusable == undefined) {
      this.focusable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.focusable.setGetter(true);
    this.orderGet++;
    this.focusable.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isFocusable = function () {
    if (this.focusable == null || this.focusable == undefined) {
      this.focusable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.focusable.getCommandReturnValue();
  };
  ViewImpl.prototype.setFocusable = function (value) {
    this.resetIfRequired();
    if (this.focusable == null || this.focusable == undefined) {
      this.focusable = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.focusable.setSetter(true);
    this.focusable.setValue(value);
    this.orderSet++;
    this.focusable.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollX = function () {
    this.resetIfRequired();
    if (this.scrollX == null || this.scrollX == undefined) {
      this.scrollX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollX.setGetter(true);
    this.orderGet++;
    this.scrollX.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollX = function () {
    if (this.scrollX == null || this.scrollX == undefined) {
      this.scrollX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.scrollX.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollX = function (value) {
    this.resetIfRequired();
    if (this.scrollX == null || this.scrollX == undefined) {
      this.scrollX = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollX.setSetter(true);
    this.scrollX.setValue(value);
    this.orderSet++;
    this.scrollX.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollY = function () {
    this.resetIfRequired();
    if (this.scrollY == null || this.scrollY == undefined) {
      this.scrollY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollY.setGetter(true);
    this.orderGet++;
    this.scrollY.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollY = function () {
    if (this.scrollY == null || this.scrollY == undefined) {
      this.scrollY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.scrollY.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollY = function (value) {
    this.resetIfRequired();
    if (this.scrollY == null || this.scrollY == undefined) {
      this.scrollY = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.scrollY.setSetter(true);
    this.scrollY.setValue(value);
    this.orderSet++;
    this.scrollY.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.invalidate = function () {
    this.resetIfRequired();
    if (this.invalidate_ == null || this.invalidate_ == undefined) {
      this.invalidate_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.invalidate_.setSetter(true);
    this.orderSet++;
    this.invalidate_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.requestLayout = function () {
    this.resetIfRequired();
    if (this.requestLayout_ == null || this.requestLayout_ == undefined) {
      this.requestLayout_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.requestLayout_.setSetter(true);
    this.orderSet++;
    this.requestLayout_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setAsDragSource = function (value) {
    this.resetIfRequired();
    if (this.asDragSource == null || this.asDragSource == undefined) {
      this.asDragSource = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.asDragSource.setSetter(true);
    this.asDragSource.setValue(value);
    this.orderSet++;
    this.asDragSource.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setZIndex = function (value) {
    this.resetIfRequired();
    if (this.zIndex == null || this.zIndex == undefined) {
      this.zIndex = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.zIndex.setSetter(true);
    this.zIndex.setValue(value);
    this.orderSet++;
    this.zIndex.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetMaxWidth = function () {
    this.resetIfRequired();
    if (this.maxWidth == null || this.maxWidth == undefined) {
      this.maxWidth = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.maxWidth.setGetter(true);
    this.orderGet++;
    this.maxWidth.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getMaxWidth = function () {
    if (this.maxWidth == null || this.maxWidth == undefined) {
      this.maxWidth = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.maxWidth.getCommandReturnValue();
  };
  ViewImpl.prototype.setMaxWidth = function (value) {
    this.resetIfRequired();
    if (this.maxWidth == null || this.maxWidth == undefined) {
      this.maxWidth = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.maxWidth.setSetter(true);
    this.maxWidth.setValue(value);
    this.orderSet++;
    this.maxWidth.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetMaxHeight = function () {
    this.resetIfRequired();
    if (this.maxHeight == null || this.maxHeight == undefined) {
      this.maxHeight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.maxHeight.setGetter(true);
    this.orderGet++;
    this.maxHeight.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getMaxHeight = function () {
    if (this.maxHeight == null || this.maxHeight == undefined) {
      this.maxHeight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.maxHeight.getCommandReturnValue();
  };
  ViewImpl.prototype.setMaxHeight = function (value) {
    this.resetIfRequired();
    if (this.maxHeight == null || this.maxHeight == undefined) {
      this.maxHeight = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.maxHeight.setSetter(true);
    this.maxHeight.setValue(value);
    this.orderSet++;
    this.maxHeight.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setStyle = function (value) {
    this.resetIfRequired();
    if (this.style == null || this.style == undefined) {
      this.style = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.style.setSetter(true);
    this.style.setValue(value);
    this.orderSet++;
    this.style.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setErrorStyle = function (value) {
    this.resetIfRequired();
    if (this.errorStyle == null || this.errorStyle == undefined) {
      this.errorStyle = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.errorStyle.setSetter(true);
    this.errorStyle.setValue(value);
    this.orderSet++;
    this.errorStyle.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetValidateForm = function () {
    this.resetIfRequired();
    if (this.validateForm_ == null || this.validateForm_ == undefined) {
      this.validateForm_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.validateForm_.setGetter(true);
    this.orderGet++;
    this.validateForm_.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getValidateForm = function () {
    if (this.validateForm_ == null || this.validateForm_ == undefined) {
      this.validateForm_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.validateForm_.getCommandReturnValue();
  };
  ViewImpl.prototype.validateForm = function (value) {
    this.resetIfRequired();
    if (this.validateForm_ == null || this.validateForm_ == undefined) {
      this.validateForm_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.validateForm_.setSetter(true);
    this.validateForm_.setValue(value);
    this.orderSet++;
    this.validateForm_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setValidation = function (value) {
    this.resetIfRequired();
    if (this.validation == null || this.validation == undefined) {
      this.validation = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.validation.setSetter(true);
    this.validation.setValue(value);
    this.orderSet++;
    this.validation.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_required = function (value) {
    this.resetIfRequired();
    if (this.v_required == null || this.v_required == undefined) {
      this.v_required = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.v_required.setSetter(true);
    this.v_required.setValue(value);
    this.orderSet++;
    this.v_required.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_minlength = function (value) {
    this.resetIfRequired();
    if (this.v_minlength == null || this.v_minlength == undefined) {
      this.v_minlength = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.v_minlength.setSetter(true);
    this.v_minlength.setValue(value);
    this.orderSet++;
    this.v_minlength.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_maxlength = function (value) {
    this.resetIfRequired();
    if (this.v_maxlength == null || this.v_maxlength == undefined) {
      this.v_maxlength = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.v_maxlength.setSetter(true);
    this.v_maxlength.setValue(value);
    this.orderSet++;
    this.v_maxlength.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_min = function (value) {
    this.resetIfRequired();
    if (this.v_min == null || this.v_min == undefined) {
      this.v_min = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.v_min.setSetter(true);
    this.v_min.setValue(value);
    this.orderSet++;
    this.v_min.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_max = function (value) {
    this.resetIfRequired();
    if (this.v_max == null || this.v_max == undefined) {
      this.v_max = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.v_max.setSetter(true);
    this.v_max.setValue(value);
    this.orderSet++;
    this.v_max.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_pattern = function (value) {
    this.resetIfRequired();
    if (this.v_pattern == null || this.v_pattern == undefined) {
      this.v_pattern = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.v_pattern.setSetter(true);
    this.v_pattern.setValue(value);
    this.orderSet++;
    this.v_pattern.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_type = function (value) {
    this.resetIfRequired();
    if (this.v_type == null || this.v_type == undefined) {
      this.v_type = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.v_type.setSetter(true);
    this.v_type.setValue(value);
    this.orderSet++;
    this.v_type.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setValidationErrorDisplayType = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.validationErrorDisplayType == null || this.validationErrorDisplayType == undefined) {
      this.validationErrorDisplayType = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.validationErrorDisplayType.setSetter(true);
    this.validationErrorDisplayType.setValue(value);
    this.orderSet++;
    this.validationErrorDisplayType.setOrderSet(this.orderSet);
    this.validationErrorDisplayType.setTransformer('validationErrorDisplay');
    return this.thisPointer;
  };
  ViewImpl.prototype.setCustomErrorMessageValues = function (value) {
    this.resetIfRequired();
    if (this.customErrorMessageValues == null || this.customErrorMessageValues == undefined) {
      this.customErrorMessageValues = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.customErrorMessageValues.setSetter(true);
    this.customErrorMessageValues.setValue(value);
    this.orderSet++;
    this.customErrorMessageValues.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setCustomErrorMessageKeys = function (value) {
    this.resetIfRequired();
    if (this.customErrorMessageKeys == null || this.customErrorMessageKeys == undefined) {
      this.customErrorMessageKeys = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.customErrorMessageKeys.setSetter(true);
    this.customErrorMessageKeys.setValue(value);
    this.orderSet++;
    this.customErrorMessageKeys.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setInvalidateOnFrameChange = function (value) {
    this.resetIfRequired();
    if (this.invalidateOnFrameChange == null || this.invalidateOnFrameChange == undefined) {
      this.invalidateOnFrameChange = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.invalidateOnFrameChange.setSetter(true);
    this.invalidateOnFrameChange.setValue(value);
    this.orderSet++;
    this.invalidateOnFrameChange.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnSwiped = function (value) {
    this.resetIfRequired();
    if (this.onSwiped == null || this.onSwiped == undefined) {
      this.onSwiped = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onSwiped.setSetter(true);
    this.onSwiped.setValue(value);
    this.orderSet++;
    this.onSwiped.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.animatorXml = function (value) {
    this.resetIfRequired();
    if (this.animatorXml_ == null || this.animatorXml_ == undefined) {
      this.animatorXml_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.animatorXml_.setSetter(true);
    this.animatorXml_.setValue(value);
    this.orderSet++;
    this.animatorXml_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.startAnimator = function () {
    this.resetIfRequired();
    if (this.startAnimator_ == null || this.startAnimator_ == undefined) {
      this.startAnimator_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.startAnimator_.setSetter(true);
    this.orderSet++;
    this.startAnimator_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.endAnimator = function () {
    this.resetIfRequired();
    if (this.endAnimator_ == null || this.endAnimator_ == undefined) {
      this.endAnimator_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.endAnimator_.setSetter(true);
    this.orderSet++;
    this.endAnimator_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnAnimationStart = function (value) {
    this.resetIfRequired();
    if (this.onAnimationStart == null || this.onAnimationStart == undefined) {
      this.onAnimationStart = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onAnimationStart.setSetter(true);
    this.onAnimationStart.setValue(value);
    this.orderSet++;
    this.onAnimationStart.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnAnimationEnd = function (value) {
    this.resetIfRequired();
    if (this.onAnimationEnd == null || this.onAnimationEnd == undefined) {
      this.onAnimationEnd = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onAnimationEnd.setSetter(true);
    this.onAnimationEnd.setValue(value);
    this.orderSet++;
    this.onAnimationEnd.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnAnimationCancel = function (value) {
    this.resetIfRequired();
    if (this.onAnimationCancel == null || this.onAnimationCancel == undefined) {
      this.onAnimationCancel = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onAnimationCancel.setSetter(true);
    this.onAnimationCancel.setValue(value);
    this.orderSet++;
    this.onAnimationCancel.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnAnimationRepeat = function (value) {
    this.resetIfRequired();
    if (this.onAnimationRepeat == null || this.onAnimationRepeat == undefined) {
      this.onAnimationRepeat = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.onAnimationRepeat.setSetter(true);
    this.onAnimationRepeat.setValue(value);
    this.orderSet++;
    this.onAnimationRepeat.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetLeft = function () {
    this.resetIfRequired();
    if (this.left == null || this.left == undefined) {
      this.left = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.left.setGetter(true);
    this.orderGet++;
    this.left.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getLeft = function () {
    if (this.left == null || this.left == undefined) {
      this.left = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.left.getCommandReturnValue();
  };
  ViewImpl.prototype.setLeft = function (value) {
    this.resetIfRequired();
    if (this.left == null || this.left == undefined) {
      this.left = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.left.setSetter(true);
    this.left.setValue(value);
    this.orderSet++;
    this.left.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetRight = function () {
    this.resetIfRequired();
    if (this.right == null || this.right == undefined) {
      this.right = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.right.setGetter(true);
    this.orderGet++;
    this.right.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getRight = function () {
    if (this.right == null || this.right == undefined) {
      this.right = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.right.getCommandReturnValue();
  };
  ViewImpl.prototype.setRight = function (value) {
    this.resetIfRequired();
    if (this.right == null || this.right == undefined) {
      this.right = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.right.setSetter(true);
    this.right.setValue(value);
    this.orderSet++;
    this.right.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTop = function () {
    this.resetIfRequired();
    if (this.top == null || this.top == undefined) {
      this.top = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.top.setGetter(true);
    this.orderGet++;
    this.top.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTop = function () {
    if (this.top == null || this.top == undefined) {
      this.top = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.top.getCommandReturnValue();
  };
  ViewImpl.prototype.setTop = function (value) {
    this.resetIfRequired();
    if (this.top == null || this.top == undefined) {
      this.top = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.top.setSetter(true);
    this.top.setValue(value);
    this.orderSet++;
    this.top.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetBottom = function () {
    this.resetIfRequired();
    if (this.bottom == null || this.bottom == undefined) {
      this.bottom = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.bottom.setGetter(true);
    this.orderGet++;
    this.bottom.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getBottom = function () {
    if (this.bottom == null || this.bottom == undefined) {
      this.bottom = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    return this.bottom.getCommandReturnValue();
  };
  ViewImpl.prototype.setBottom = function (value) {
    this.resetIfRequired();
    if (this.bottom == null || this.bottom == undefined) {
      this.bottom = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.bottom.setSetter(true);
    this.bottom.setValue(value);
    this.orderSet++;
    this.bottom.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOutlineAmbientShadowColor = function (value) {
    this.resetIfRequired();
    if (this.outlineAmbientShadowColor == null || this.outlineAmbientShadowColor == undefined) {
      this.outlineAmbientShadowColor = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.outlineAmbientShadowColor.setSetter(true);
    this.outlineAmbientShadowColor.setValue(value);
    this.orderSet++;
    this.outlineAmbientShadowColor.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOutlineSpotShadowColor = function (value) {
    this.resetIfRequired();
    if (this.outlineSpotShadowColor == null || this.outlineSpotShadowColor == undefined) {
      this.outlineSpotShadowColor = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.outlineSpotShadowColor.setSetter(true);
    this.outlineSpotShadowColor.setValue(value);
    this.orderSet++;
    this.outlineSpotShadowColor.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setCornerRadius = function (value) {
    this.resetIfRequired();
    if (this.cornerRadius == null || this.cornerRadius == undefined) {
      this.cornerRadius = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.cornerRadius.setSetter(true);
    this.cornerRadius.setValue(value);
    this.orderSet++;
    this.cornerRadius.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "accessibilityHeading"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "accessibilityHeading", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "accessibilityLiveRegion"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "accessibilityLiveRegion", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "accessibilityPaneTitle"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "accessibilityPaneTitle", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "accessibilityTraversalAfter"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "accessibilityTraversalAfter", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "accessibilityTraversalBefore"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "accessibilityTraversalBefore", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "alpha"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "alpha", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "autofillHints"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "autofillHints", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "backgroundTint"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "backgroundTint", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "backgroundTintMode"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "backgroundTintMode", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "clickable"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "clickable", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "contentDescription"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "contentDescription", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "contextClickable"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "contextClickable", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "defaultFocusHighlightEnabled"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "defaultFocusHighlightEnabled", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "duplicateParentState"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "duplicateParentState", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "elevation"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "elevation", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "fadeScrollbars"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "fadeScrollbars", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "fadingEdgeLength"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "fadingEdgeLength", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "filterTouchesWhenObscured"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "filterTouchesWhenObscured", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "fitsSystemWindows"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "fitsSystemWindows", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "focusableInTouchMode"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "focusableInTouchMode", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "focusedByDefault"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "focusedByDefault", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "forceHasOverlappingRendering"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "forceHasOverlappingRendering", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "foregroundTint"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "foregroundTint", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "foregroundTintMode"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "foregroundTintMode", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "hapticFeedbackEnabled"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "hapticFeedbackEnabled", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "importantForAccessibility"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "importantForAccessibility", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "importantForAutofill"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "importantForAutofill", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "isScrollContainer"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "isScrollContainer", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "keepScreenOn"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "keepScreenOn", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "keyboardNavigationCluster"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "keyboardNavigationCluster", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layoutDirection"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "layoutDirection", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "longClickable"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "longClickable", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "minHeight"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "minHeight", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "minWidth"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "minWidth", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "nextClusterForward"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "nextClusterForward", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "nextFocusDown"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "nextFocusDown", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "nextFocusForward"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "nextFocusForward", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "nextFocusLeft"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "nextFocusLeft", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "nextFocusRight"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "nextFocusRight", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "nextFocusUp"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "nextFocusUp", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "rotation"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "rotation", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "rotationX"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "rotationX", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "rotationY"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "rotationY", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "saveEnabled"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "saveEnabled", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "scaleX"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "scaleX", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "scaleY"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "scaleY", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "screenReaderFocusable"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "screenReaderFocusable", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "scrollIndicators"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "scrollIndicators", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "scrollbarDefaultDelayBeforeFade"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "scrollbarDefaultDelayBeforeFade", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "scrollbarFadeDuration"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "scrollbarFadeDuration", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "scrollbarSize"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "scrollbarSize", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "scrollbarStyle"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "scrollbarStyle", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "soundEffectsEnabled"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "soundEffectsEnabled", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "textAlignment"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "textAlignment", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "textDirection"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "textDirection", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "tooltipText"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "tooltipText", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "transformPivotX"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "transformPivotX", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "transformPivotY"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "transformPivotY", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "transitionName"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "transitionName", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "translationX"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "translationX", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "translationY"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "translationY", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "translationZ"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "translationZ", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "visibility"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "visibility", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onApplyWindowInsets"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onApplyWindowInsets", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onCapturedPointer"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onCapturedPointer", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onClick"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onClick", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onContextClick"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onContextClick", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onCreateContextMenu"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onCreateContextMenu", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onDrag"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onDrag", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onFocusChange"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onFocusChange", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onGenericMotion"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onGenericMotion", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onHover"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onHover", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onKey"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onKey", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onLongClick"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onLongClick", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onScrollChange"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onScrollChange", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onSystemUiVisibilityChange"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onSystemUiVisibilityChange", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onTouch"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onTouch", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "padding"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "padding", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "paddingTop"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "paddingTop", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "paddingBottom"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "paddingBottom", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "paddingLeft"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "paddingLeft", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "paddingRight"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "paddingRight", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "paddingStart"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "paddingStart", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "paddingEnd"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "paddingEnd", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "paddingHorizontal"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "paddingHorizontal", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "paddingVertical"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "paddingVertical", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layerType"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "layerType", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "requiresFadingEdge"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "requiresFadingEdge", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "background"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "background", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "foreground"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "foreground", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "backgroundRepeat"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "backgroundRepeat", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "modelSyncEvents"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "modelSyncEvents", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "updateModelData"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "updateModelData_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "notifyDataSetChanged"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "notifyDataSetChanged_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "modelParam"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "modelParam", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "modelPojoToUi"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "modelPojoToUi", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "modelUiToPojo"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "modelUiToPojo", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "modelPojoToUiParams"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "modelPojoToUiParams", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "refreshUiFromModel"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "refreshUiFromModel_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "modelUiToPojoEventIds"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "modelUiToPojoEventIds", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "foregroundRepeat"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "foregroundRepeat", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "foregroundGravity"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "foregroundGravity", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "performHapticFeedback"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "performHapticFeedback_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "performHapticFeedbackWithFlags"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "performHapticFeedbackWithFlags_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "attributeUnderTest"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "attributeUnderTest", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "selected"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "selected", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "enabled"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "enabled", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "focusable"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "focusable", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "scrollX"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "scrollX", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "scrollY"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "scrollY", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "invalidate"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "invalidate_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "requestLayout"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "requestLayout_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "asDragSource"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "asDragSource", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "zIndex"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "zIndex", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "maxWidth"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "maxWidth", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "maxHeight"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "maxHeight", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "style"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "style", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "errorStyle"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "errorStyle", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "validateForm"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "validateForm_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "validation"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "validation", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "v_required"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "v_required", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "v_minlength"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "v_minlength", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "v_maxlength"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "v_maxlength", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "v_min"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "v_min", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "v_max"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "v_max", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "v_pattern"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "v_pattern", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "v_type"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "v_type", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "validationErrorDisplayType"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "validationErrorDisplayType", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "customErrorMessageValues"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "customErrorMessageValues", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "customErrorMessageKeys"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "customErrorMessageKeys", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "invalidateOnFrameChange"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "invalidateOnFrameChange", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onSwiped"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onSwiped", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "animatorXml"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "animatorXml_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "startAnimator"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "startAnimator_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "endAnimator"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "endAnimator_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onAnimationStart"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onAnimationStart", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onAnimationEnd"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onAnimationEnd", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onAnimationCancel"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onAnimationCancel", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "onAnimationRepeat"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "onAnimationRepeat", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "left"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "left", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "right"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "right", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "top"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "top", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "bottom"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "bottom", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "outlineAmbientShadowColor"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "outlineAmbientShadowColor", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "outlineSpotShadowColor"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "outlineSpotShadowColor", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_4__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "cornerRadius"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "cornerRadius", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_1__.Exclude)()), __metadata("design:type", Object)], ViewImpl.prototype, "thisPointer", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_1__.Exclude)()), __metadata("design:type", Number)], ViewImpl.prototype, "orderGet", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_1__.Exclude)()), __metadata("design:type", Number)], ViewImpl.prototype, "orderSet", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_7__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layoutParams"
  })), __metadata("design:type", Object)], ViewImpl.prototype, "layoutParams", void 0);
  return ViewImpl;
}();

//start - staticinit
var View = /** @class */function (_super) {
  __extends(View, _super);
  function View(id, path, event) {
    return _super.call(this, id, path, event) || this;
  }
  View.prototype.getThisPointer = function () {
    return this;
  };
  View.prototype.getClass = function () {
    return View;
  };
  return View;
}(ViewImpl);

ViewImpl.initialize();
//end - staticinit

/***/ }),

/***/ "./src/android/widget/fragmentImpl.ts":
/*!********************************************!*\
  !*** ./src/android/widget/fragmentImpl.ts ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fragment: function() { return /* binding */ fragment; },
/* harmony export */   fragmentImpl: function() { return /* binding */ fragmentImpl; },
/* harmony export */   fragmentImpl_navigate: function() { return /* binding */ fragmentImpl_navigate; },
/* harmony export */   fragmentImpl_navigateAsTop: function() { return /* binding */ fragmentImpl_navigateAsTop; },
/* harmony export */   fragmentImpl_navigateWithPopBackStack: function() { return /* binding */ fragmentImpl_navigateWithPopBackStack; },
/* harmony export */   fragmentImpl_navigateWithPopBackStackTo: function() { return /* binding */ fragmentImpl_navigateWithPopBackStackTo; },
/* harmony export */   fragmentImpl_popBackStackTo: function() { return /* binding */ fragmentImpl_popBackStackTo; }
/* harmony export */ });
/* harmony import */ var _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../widget/CommandAttr */ "./src/widget/CommandAttr.ts");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/exclude.decorator.js");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/expose.decorator.js");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/type.decorator.js");
/* harmony import */ var ts_mixer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ts-mixer */ "./node_modules/ts-mixer/dist/esm/index.js");
/* harmony import */ var _ViewGroupImpl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ViewGroupImpl */ "./src/android/widget/ViewGroupImpl.ts");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
// start - imports
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var fragmentImpl_navigate = /** @class */function () {
  function fragmentImpl_navigate() {}
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "actionId"
  })), __metadata("design:type", String)], fragmentImpl_navigate.prototype, "actionId", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "scopeObjects"
  })), __metadata("design:type", Object)], fragmentImpl_navigate.prototype, "scopeObjects", void 0);
  return fragmentImpl_navigate;
}();

var fragmentImpl_navigateWithPopBackStack = /** @class */function () {
  function fragmentImpl_navigateWithPopBackStack() {}
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "actionId"
  })), __metadata("design:type", String)], fragmentImpl_navigateWithPopBackStack.prototype, "actionId", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "scopeObjects"
  })), __metadata("design:type", Object)], fragmentImpl_navigateWithPopBackStack.prototype, "scopeObjects", void 0);
  return fragmentImpl_navigateWithPopBackStack;
}();

var fragmentImpl_navigateAsTop = /** @class */function () {
  function fragmentImpl_navigateAsTop() {}
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "actionId"
  })), __metadata("design:type", String)], fragmentImpl_navigateAsTop.prototype, "actionId", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "scopeObjects"
  })), __metadata("design:type", Object)], fragmentImpl_navigateAsTop.prototype, "scopeObjects", void 0);
  return fragmentImpl_navigateAsTop;
}();

var fragmentImpl_navigateWithPopBackStackTo = /** @class */function () {
  function fragmentImpl_navigateWithPopBackStackTo() {}
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "actionId"
  })), __metadata("design:type", String)], fragmentImpl_navigateWithPopBackStackTo.prototype, "actionId", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "destinationId"
  })), __metadata("design:type", String)], fragmentImpl_navigateWithPopBackStackTo.prototype, "destinationId", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "inclusive"
  })), __metadata("design:type", Boolean)], fragmentImpl_navigateWithPopBackStackTo.prototype, "inclusive", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "scopeObjects"
  })), __metadata("design:type", Object)], fragmentImpl_navigateWithPopBackStackTo.prototype, "scopeObjects", void 0);
  return fragmentImpl_navigateWithPopBackStackTo;
}();

var fragmentImpl_popBackStackTo = /** @class */function () {
  function fragmentImpl_popBackStackTo() {}
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "destinationId"
  })), __metadata("design:type", String)], fragmentImpl_popBackStackTo.prototype, "destinationId", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "inclusive"
  })), __metadata("design:type", Boolean)], fragmentImpl_popBackStackTo.prototype, "inclusive", void 0);
  return fragmentImpl_popBackStackTo;
}();

// end - imports

var fragmentImpl = /** @class */function (_super) {
  __extends(fragmentImpl, _super);
  function fragmentImpl(id, path, event) {
    var _this = _super.call(this, id, path, event) || this;
    _this.thisPointer = _this.getThisPointer();
    return _this;
  }
  //start - body
  fragmentImpl.initialize = function () {};
  fragmentImpl.prototype.reset = function () {
    _super.prototype.reset.call(this);
    this.name = undefined;
    this.layout = undefined;
    this.navGraph = undefined;
    this.tag = undefined;
    this.replace_ = undefined;
    this.navigate_ = undefined;
    this.popBackStack_ = undefined;
    this.navigateWithPopBackStack_ = undefined;
    this.navigateAsTop_ = undefined;
    this.navigateWithPopBackStackTo_ = undefined;
    this.popBackStackTo_ = undefined;
    this.closeDialog_ = undefined;
    this.rootDirectory = undefined;
    this.namespace = undefined;
    return this.thisPointer;
  };
  fragmentImpl.prototype.setName = function (value) {
    this.resetIfRequired();
    if (this.name == null || this.name == undefined) {
      this.name = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.name.setSetter(true);
    this.name.setValue(value);
    this.orderSet++;
    this.name.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.setLayout = function (value) {
    this.resetIfRequired();
    if (this.layout == null || this.layout == undefined) {
      this.layout = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.layout.setSetter(true);
    this.layout.setValue(value);
    this.orderSet++;
    this.layout.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.setNavGraph = function (value) {
    this.resetIfRequired();
    if (this.navGraph == null || this.navGraph == undefined) {
      this.navGraph = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.navGraph.setSetter(true);
    this.navGraph.setValue(value);
    this.orderSet++;
    this.navGraph.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.setTag = function (value) {
    this.resetIfRequired();
    if (this.tag == null || this.tag == undefined) {
      this.tag = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.tag.setSetter(true);
    this.tag.setValue(value);
    this.orderSet++;
    this.tag.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.replace = function (value) {
    this.resetIfRequired();
    if (this.replace_ == null || this.replace_ == undefined) {
      this.replace_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.replace_.setSetter(true);
    this.replace_.setValue(value);
    this.orderSet++;
    this.replace_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.navigate = function (actionId, scopeObjects) {
    this.resetIfRequired();
    if (this.navigate_ == null || this.navigate_ == undefined) {
      this.navigate_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    var wrapper = new fragmentImpl_navigate();
    wrapper.actionId = actionId;
    wrapper.scopeObjects = scopeObjects;
    this.navigate_.setSetter(true);
    this.navigate_.setValue(wrapper);
    this.orderSet++;
    this.navigate_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.popBackStack = function () {
    this.resetIfRequired();
    if (this.popBackStack_ == null || this.popBackStack_ == undefined) {
      this.popBackStack_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.popBackStack_.setSetter(true);
    this.orderSet++;
    this.popBackStack_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.navigateWithPopBackStack = function (actionId, scopeObjects) {
    this.resetIfRequired();
    if (this.navigateWithPopBackStack_ == null || this.navigateWithPopBackStack_ == undefined) {
      this.navigateWithPopBackStack_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    var wrapper = new fragmentImpl_navigateWithPopBackStack();
    wrapper.actionId = actionId;
    wrapper.scopeObjects = scopeObjects;
    this.navigateWithPopBackStack_.setSetter(true);
    this.navigateWithPopBackStack_.setValue(wrapper);
    this.orderSet++;
    this.navigateWithPopBackStack_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.navigateAsTop = function (actionId, scopeObjects) {
    this.resetIfRequired();
    if (this.navigateAsTop_ == null || this.navigateAsTop_ == undefined) {
      this.navigateAsTop_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    var wrapper = new fragmentImpl_navigateAsTop();
    wrapper.actionId = actionId;
    wrapper.scopeObjects = scopeObjects;
    this.navigateAsTop_.setSetter(true);
    this.navigateAsTop_.setValue(wrapper);
    this.orderSet++;
    this.navigateAsTop_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.navigateWithPopBackStackTo = function (actionId, destinationId, inclusive, scopeObjects) {
    this.resetIfRequired();
    if (this.navigateWithPopBackStackTo_ == null || this.navigateWithPopBackStackTo_ == undefined) {
      this.navigateWithPopBackStackTo_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    var wrapper = new fragmentImpl_navigateWithPopBackStackTo();
    wrapper.actionId = actionId;
    wrapper.destinationId = destinationId;
    wrapper.inclusive = inclusive;
    wrapper.scopeObjects = scopeObjects;
    this.navigateWithPopBackStackTo_.setSetter(true);
    this.navigateWithPopBackStackTo_.setValue(wrapper);
    this.orderSet++;
    this.navigateWithPopBackStackTo_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.popBackStackTo = function (destinationId, inclusive) {
    this.resetIfRequired();
    if (this.popBackStackTo_ == null || this.popBackStackTo_ == undefined) {
      this.popBackStackTo_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    var wrapper = new fragmentImpl_popBackStackTo();
    wrapper.destinationId = destinationId;
    wrapper.inclusive = inclusive;
    this.popBackStackTo_.setSetter(true);
    this.popBackStackTo_.setValue(wrapper);
    this.orderSet++;
    this.popBackStackTo_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.closeDialog = function (value) {
    this.resetIfRequired();
    if (this.closeDialog_ == null || this.closeDialog_ == undefined) {
      this.closeDialog_ = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.closeDialog_.setSetter(true);
    this.closeDialog_.setValue(value);
    this.orderSet++;
    this.closeDialog_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.setRootDirectory = function (value) {
    this.resetIfRequired();
    if (this.rootDirectory == null || this.rootDirectory == undefined) {
      this.rootDirectory = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.rootDirectory.setSetter(true);
    this.rootDirectory.setValue(value);
    this.orderSet++;
    this.rootDirectory.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.setNamespace = function (value) {
    this.resetIfRequired();
    if (this.namespace == null || this.namespace == undefined) {
      this.namespace = new _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"]();
    }
    this.namespace.setSetter(true);
    this.namespace.setValue(value);
    this.orderSet++;
    this.namespace.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "name"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "name", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "layout"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "layout", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "navGraph"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "navGraph", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "tag"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "tag", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "replace"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "replace_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "navigate"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "navigate_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "popBackStack"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "popBackStack_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "navigateWithPopBackStack"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "navigateWithPopBackStack_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "navigateAsTop"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "navigateAsTop_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "navigateWithPopBackStackTo"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "navigateWithPopBackStackTo_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "popBackStackTo"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "popBackStackTo_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "closeDialog"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "closeDialog_", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "rootDirectory"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "rootDirectory", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_3__.Type)(function () {
    return _widget_CommandAttr__WEBPACK_IMPORTED_MODULE_0__["default"];
  })), (0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_2__.Expose)({
    name: "namespace"
  })), __metadata("design:type", Object)], fragmentImpl.prototype, "namespace", void 0);
  __decorate([(0,ts_mixer__WEBPACK_IMPORTED_MODULE_4__.decorate)((0,class_transformer__WEBPACK_IMPORTED_MODULE_1__.Exclude)()), __metadata("design:type", Object)], fragmentImpl.prototype, "thisPointer", void 0);
  return fragmentImpl;
}(_ViewGroupImpl__WEBPACK_IMPORTED_MODULE_5__.ViewGroupImpl);

//start - staticinit
var fragment = /** @class */function (_super) {
  __extends(fragment, _super);
  function fragment(id, path, event) {
    return _super.call(this, id, path, event) || this;
  }
  fragment.prototype.getThisPointer = function () {
    return this;
  };
  fragment.prototype.getClass = function () {
    return fragment;
  };
  return fragment;
}(fragmentImpl);

fragmentImpl.initialize();
//end - staticinit

/***/ }),

/***/ "./src/app/Fragment.ts":
/*!*****************************!*\
  !*** ./src/app/Fragment.ts ***!
  \*****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Fragment: function() { return /* binding */ Fragment; },
/* harmony export */   Inject: function() { return /* binding */ Inject; }
/* harmony export */ });
/* harmony import */ var reflect_metadata__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! reflect-metadata */ "./node_modules/reflect-metadata/Reflect.js");
/* harmony import */ var reflect_metadata__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(reflect_metadata__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/index.js");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};


var Fragment = /** @class */function () {
  function Fragment() {
    var _this = this;
    this.validateForm = function (form, viewCommand) {
      return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
          switch (_a.label) {
            case 0:
              viewCommand.validateForm(form).tryGetValidateForm();
              return [4 /*yield*/, this.executeCommand(viewCommand)];
            case 1:
              _a.sent();
              return [2 /*return*/, viewCommand.getValidateForm()];
          }
        });
      });
    };
    this.executeCommand = function () {
      var commands = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        commands[_i] = arguments[_i];
      }
      return __awaiter(_this, void 0, void 0, function () {
        var commandArray, resultCommands, i, resultCommand, i, command;
        return __generator(this, function (_a) {
          switch (_a.label) {
            case 0:
              return [4 /*yield*/, this.executeInternalCommand(commands)];
            case 1:
              commandArray = _a.sent();
              resultCommands = JSON.parse(commandArray);
              for (i = 0; i < resultCommands.length; i++) {
                resultCommand = resultCommands[i];
                this.updateCommandReturnValue(resultCommand, commands[i]);
              }
              for (i = 0; i < commands.length; i++) {
                command = commands[i];
                command.markForReset();
              }
              return [2 /*return*/];
          }
        });
      });
    };
    this.startActivity = function (fileName, varExpression, data) {
      return __awaiter(_this, void 0, void 0, function () {
        var result;
        return __generator(this, function (_a) {
          switch (_a.label) {
            case 0:
              return [4 /*yield*/, this.executeStartActivity(fileName, varExpression, data)];
            case 1:
              result = _a.sent();
              return [2 /*return*/, JSON.parse(result)];
          }
        });
      });
    };
  }
  Fragment.prototype.findViewById = function (id, type) {
    return new type(id, undefined, undefined);
  };
  Fragment.prototype.onCreateView = function (obj) {};
  Fragment.prototype.onAttach = function (obj) {};
  Fragment.prototype.onCreate = function (obj) {};
  Fragment.prototype.onResume = function (obj) {};
  Fragment.prototype.onError = function (obj) {};
  Fragment.prototype.onPause = function (obj) {};
  Fragment.prototype.onDestroy = function (obj) {};
  Fragment.prototype.onDetach = function (obj) {};
  Fragment.prototype.onCloseDialog = function (obj) {};
  Fragment.prototype.findViewByPath = function (path, type) {
    return new type(undefined, path, undefined);
  };
  Fragment.prototype.fireEventToWidget = function (event, type) {
    return new type(undefined, undefined, event);
  };
  Fragment.prototype.updateCommandReturnValue = function (obj, source) {
    var _this = this;
    Object.keys(obj).forEach(function (key) {
      if (key == 'layoutParams') {
        _this.updateCommandReturnValue(obj[key], source["layoutParams"]);
      }
      if (key != 'id' && _typeof(obj[key]) == 'object') {
        var sourceKey = key;
        if (typeof source[key] == 'function') {
          sourceKey = sourceKey + "_";
        }
        source[sourceKey]["commandReturnValue"] = obj[key]["commandReturnValue"];
      }
    });
  };
  Fragment.prototype.executeStartActivity = function (fileName, varExpression, data) {
    return new Promise(function (resolve, reject) {
      navigationManager.startActivity(fileName, varExpression, data, function (result) {
        resolve(result);
      });
    });
  };
  Fragment.prototype.executeInternalCommand = function (commands) {
    return new Promise(function (resolve, reject) {
      coreManager.executeCommand((0,class_transformer__WEBPACK_IMPORTED_MODULE_1__.serialize)(commands), function (result) {
        resolve(result);
      });
    });
  };
  Fragment.prototype.getOs = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        return [2 /*return*/, new Promise(function (resolve, reject) {
          coreManager.getOs(function (result) {
            resolve(result);
          });
        })];
      });
    });
  };
  Fragment.prototype.readCdvDataAsString = function (cdvUri) {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        return [2 /*return*/, new Promise(function (resolve, reject) {
          coreManager.executeSimpleCommand([["readCdvDataAsString", cdvUri]], function (result) {
            resolve(window.atob(result));
          });
        })];
      });
    });
  };
  return Fragment;
}();

function Inject(arg) {
  return function recordInjection(target, decoratedPropertyName) {
    var t = Reflect.getMetadata("design:type", target, decoratedPropertyName);
    if (arg.id) {
      target[decoratedPropertyName] = target.findViewById(arg.id, t);
    } else if (arg.path) {
      target[decoratedPropertyName] = target.findViewByPath(arg.path, t);
    } else if (arg.event) {
      target[decoratedPropertyName] = target.fireEventToWidget(arg.event, t);
    }
  };
}

/***/ }),

/***/ "./src/app/LocaleManager.ts":
/*!**********************************!*\
  !*** ./src/app/LocaleManager.ts ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Constants */ "./src/Constants.ts");

var LocaleManager = /** @class */function () {
  function LocaleManager() {
    this.keys = _Constants__WEBPACK_IMPORTED_MODULE_0__.LOCALE_MANAGER_KEYS;
  }
  LocaleManager.getInstance = function () {
    return LocaleManager.localeManager;
  };
  LocaleManager.prototype.init = function (callBack, rootDirectory) {
    coreManager.executeSimpleCommand([["loadLocale", this.keys, rootDirectory]], function (obj) {
      LocaleManager.localeMap = JSON.parse(obj)["loadLocale"];
      if (callBack) {
        callBack();
      }
    });
  };
  LocaleManager.prototype.translate = function (key) {
    if (LocaleManager.localeMap && LocaleManager.localeMap[key]) {
      return LocaleManager.localeMap[key];
    }
    return key;
  };
  LocaleManager.localeManager = new LocaleManager();
  return LocaleManager;
}();
/* harmony default export */ __webpack_exports__["default"] = (LocaleManager);

/***/ }),

/***/ "./src/app/ScopedObject.ts":
/*!*********************************!*\
  !*** ./src/app/ScopedObject.ts ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ScopedObject: function() { return /* binding */ ScopedObject; }
/* harmony export */ });
var ScopedObject = /** @class */function () {
  function ScopedObject(expression, payload) {
    this.expression = expression;
    this.payload = payload;
  }
  return ScopedObject;
}();


/***/ }),

/***/ "./src/navigation/NavController.ts":
/*!*****************************************!*\
  !*** ./src/navigation/NavController.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InjectController: function() { return /* binding */ InjectController; },
/* harmony export */   NavController: function() { return /* binding */ NavController; }
/* harmony export */ });
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/index.js");
/* harmony import */ var _app_ScopedObject__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../app/ScopedObject */ "./src/app/ScopedObject.ts");
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};
var __spreadArray = undefined && undefined.__spreadArray || function (to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};


var NavController = /** @class */function () {
  function NavController() {
    var _this = this;
    this.executeCommand = function () {
      return __awaiter(_this, void 0, void 0, function () {
        var result;
        return __generator(this, function (_a) {
          switch (_a.label) {
            case 0:
              return [4 /*yield*/, this.getExecuteCommandPromise()];
            case 1:
              result = _a.sent();
              return [2 /*return*/, JSON.parse(result)];
          }
        });
      });
    };
    this.commands = [];
  }
  NavController.prototype.reset = function () {
    this.commands = [];
    return this;
  };
  NavController.prototype.popBackStack = function () {
    this.commands.push(["popBackStack"]);
    return this;
  };
  NavController.prototype.popBackStackTo = function (destinationId, inclusive) {
    this.commands.push(["popBackStackTo", destinationId, inclusive]);
    return this;
  };
  NavController.prototype.closeDialog = function () {
    this.commands.push(["closeDialog"]);
    return this;
  };
  NavController.prototype.navigate = function (actionId, varExpression, data) {
    this.navigateTo(actionId, new _app_ScopedObject__WEBPACK_IMPORTED_MODULE_1__.ScopedObject(varExpression, data));
    return this;
  };
  NavController.prototype.navigateWithPopBackStack = function (actionId) {
    var scopedObjects = [];
    for (var _i = 1; _i < arguments.length; _i++) {
      scopedObjects[_i - 1] = arguments[_i];
    }
    this.commands.push(["navigateWithPopBackStack", actionId, (0,class_transformer__WEBPACK_IMPORTED_MODULE_0__.classToPlain)(scopedObjects)]);
    return this;
  };
  NavController.prototype.navigateAsTop = function (actionId) {
    var scopedObjects = [];
    for (var _i = 1; _i < arguments.length; _i++) {
      scopedObjects[_i - 1] = arguments[_i];
    }
    this.commands.push(["navigateAsTop", actionId, (0,class_transformer__WEBPACK_IMPORTED_MODULE_0__.classToPlain)(scopedObjects)]);
    return this;
  };
  NavController.prototype.navigateWithPopBackStackTo = function (actionId, destinationId, inclusive) {
    var scopedObjects = [];
    for (var _i = 3; _i < arguments.length; _i++) {
      scopedObjects[_i - 3] = arguments[_i];
    }
    this.commands.push(["navigateWithPopBackStackTo", actionId, destinationId, inclusive, (0,class_transformer__WEBPACK_IMPORTED_MODULE_0__.classToPlain)(scopedObjects)]);
    return this;
  };
  NavController.prototype.navigateTo = function (actionId) {
    var scopedObjects = [];
    for (var _i = 1; _i < arguments.length; _i++) {
      scopedObjects[_i - 1] = arguments[_i];
    }
    this.commands.push(["navigate", actionId, (0,class_transformer__WEBPACK_IMPORTED_MODULE_0__.classToPlain)(scopedObjects)]);
    return this;
  };
  NavController.prototype.getExecuteCommandPromise = function () {
    var _this = this;
    return new Promise(function (resolve, reject) {
      var commands = __spreadArray([], _this.commands, true);
      _this.reset();
      coreManager.navigateCommand(commands, function (result) {
        resolve(result);
      });
    });
  };
  return NavController;
}();

function InjectController(arg) {
  return function recordInjection(target, decoratedPropertyName) {
    var t = Reflect.getMetadata("design:type", target, decoratedPropertyName);
    target[decoratedPropertyName] = new NavController();
  };
}

/***/ }),

/***/ "./src/widget/CommandAttr.ts":
/*!***********************************!*\
  !*** ./src/widget/CommandAttr.ts ***!
  \***********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! class-transformer */ "./node_modules/class-transformer/esm5/decorators/transform.decorator.js");
/* harmony import */ var _TransformerFactory__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TransformerFactory */ "./src/widget/TransformerFactory.ts");
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : _typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var CommandAttr = /** @class */function () {
  function CommandAttr() {
    this.setter = false;
    this.getter = false;
    this.type = "attribute";
    this.orderGet = 0;
    this.orderSet = 0;
  }
  CommandAttr.prototype.getChildPath = function () {
    return this.childPath;
  };
  CommandAttr.prototype.setChildPath = function (value) {
    this.childPath = value;
  };
  CommandAttr.prototype.getOrderSet = function () {
    return this.orderGet;
  };
  CommandAttr.prototype.setOrderSet = function (value) {
    this.orderSet = value;
  };
  CommandAttr.prototype.getOrderGet = function () {
    return this.orderGet;
  };
  CommandAttr.prototype.setOrderGet = function (value) {
    this.orderGet = value;
  };
  CommandAttr.prototype.getTransformer = function () {
    return this.transformer;
  };
  CommandAttr.prototype.setTransformer = function (value) {
    this.transformer = value;
  };
  /**
   * Getter value
   * @return {T}
   */
  CommandAttr.prototype.getCommandReturnValue = function () {
    return this.commandReturnValue;
  };
  /**
   * Setter value
   * @param {T} value
   */
  CommandAttr.prototype.setCommandReturnValue = function (value) {
    this.commandReturnValue = value;
  };
  /**
   * Getter value
   * @return {T}
   */
  CommandAttr.prototype.getValue = function () {
    return this.value;
  };
  /**
   * Getter set
   * @return {boolean}
   */
  CommandAttr.prototype.getSetter = function () {
    return this.setter;
  };
  /**
   * Getter get
   * @return {boolean}
   */
  CommandAttr.prototype.getGetter = function () {
    return this.getter;
  };
  /**
   * Setter value
   * @param {T} value
   */
  CommandAttr.prototype.setValue = function (value) {
    this.value = value;
  };
  /**
   * Setter set
   * @param {boolean} value
   */
  CommandAttr.prototype.setSetter = function (value) {
    this.setter = value;
  };
  /**
   * Setter get
   * @param {boolean} value
   */
  CommandAttr.prototype.setGetter = function (value) {
    this.getter = value;
  };
  __decorate([(0,class_transformer__WEBPACK_IMPORTED_MODULE_0__.Transform)(function (_a) {
    var value = _a.value,
      obj = _a.obj,
      type = _a.type;
    return _TransformerFactory__WEBPACK_IMPORTED_MODULE_1__.TransformerFactory.getInstance().transform(value, obj, type, obj.transformer);
  }), __metadata("design:type", Object)], CommandAttr.prototype, "value", void 0);
  return CommandAttr;
}();
/* harmony default export */ __webpack_exports__["default"] = (CommandAttr);

/***/ }),

/***/ "./src/widget/Transformer.ts":
/*!***********************************!*\
  !*** ./src/widget/Transformer.ts ***!
  \***********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Transformer: function() { return /* binding */ Transformer; }
/* harmony export */ });
var Transformer = /** @class */function () {
  function Transformer() {}
  Transformer.registerDefaultTransformers = function (regMap) {
    regMap.set('gravity', new GravityTransformer());
  };
  return Transformer;
}();

var GravityTransformer = /** @class */function () {
  function GravityTransformer() {}
  GravityTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var gravityArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "top":
            gravityArr.push("top" /* Gravity.top */);
            break;
          case "bottom":
            gravityArr.push("bottom" /* Gravity.bottom */);
            break;
          case "start":
            gravityArr.push("start" /* Gravity.start */);
            break;
          case "end":
            gravityArr.push("end" /* Gravity.end */);
            break;
          case "right":
            gravityArr.push("right" /* Gravity.right */);
            break;
          case "left":
            gravityArr.push("left" /* Gravity.left */);
            break;
          case "center_horizontal":
            gravityArr.push("center_horizontal" /* Gravity.center_horizontal */);
            break;
          case "center_vertical":
            gravityArr.push("center_vertical" /* Gravity.center_vertical */);
            break;
          case "center":
            gravityArr.push("center" /* Gravity.center */);
            break;
          case "clip_vertical":
            gravityArr.push("clip_vertical" /* Gravity.clip_vertical */);
            break;
          case "center_horizontal":
            gravityArr.push("center_horizontal" /* Gravity.center_horizontal */);
            break;
        }
      }
      return gravityArr;
    }
  };
  return GravityTransformer;
}();

/***/ }),

/***/ "./src/widget/TransformerFactory.ts":
/*!******************************************!*\
  !*** ./src/widget/TransformerFactory.ts ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TransformerFactory: function() { return /* binding */ TransformerFactory; }
/* harmony export */ });
/* harmony import */ var _Transformer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Transformer */ "./src/widget/Transformer.ts");

var TransformerFactory = /** @class */function () {
  function TransformerFactory() {
    _Transformer__WEBPACK_IMPORTED_MODULE_0__.Transformer.registerDefaultTransformers(TransformerFactory.registrationMap);
  }
  TransformerFactory.getInstance = function () {
    return TransformerFactory.transformerFactory;
  };
  TransformerFactory.prototype.register = function (key, transform) {
    TransformerFactory.registrationMap.set(key, transform);
  };
  TransformerFactory.prototype.transform = function (value, obj, type, transformer) {
    var key = transformer;
    if (key != null) {
      var transformer_1 = TransformerFactory.registrationMap.get(key);
      return transformer_1.transform(value, obj, type);
    }
    return value;
  };
  TransformerFactory.registrationMap = new Map();
  TransformerFactory.transformerFactory = new TransformerFactory();
  return TransformerFactory;
}();


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	!function() {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	!function() {
/******/ 		__webpack_require__.nmd = function(module) {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
!function() {
"use strict";
/*!********************!*\
  !*** ./src/app.ts ***!
  \********************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var babel_polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! babel-polyfill */ "./node_modules/babel-polyfill/lib/index.js");
/* harmony import */ var babel_polyfill__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_polyfill__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ErrorFragment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ErrorFragment */ "./src/ErrorFragment.ts");
/* harmony import */ var _FragmentFactory__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./FragmentFactory */ "./src/FragmentFactory.ts");
/* harmony import */ var _app_LocaleManager__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/LocaleManager */ "./src/app/LocaleManager.ts");




var App = /** @class */function () {
  function App() {
    this.currentViewMap = new Map();
    this.errorFragment = new _ErrorFragment__WEBPACK_IMPORTED_MODULE_1__["default"]();
    this.fragmentFactory = new _FragmentFactory__WEBPACK_IMPORTED_MODULE_2__["default"]();
    this.localManager = _app_LocaleManager__WEBPACK_IMPORTED_MODULE_3__["default"].getInstance();
  }
  // Application Constructor
  App.prototype.initialize = function () {
    document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
  };
  // deviceready Event Handler
  //
  // Bind any cordova events here. Common events are:
  // 'pause', 'resume', etc.
  App.prototype.onDeviceReady = function () {
    document.addEventListener("action", this.onAction.bind(this), false);
    document.addEventListener("nativeevent", this.nativeEvent.bind(this), false);
    this.localManager.init(function () {
      coreManager.onDeviceReady();
    });
  };
  App.prototype.onAction = function (obj) {
    this.logEvent(obj);
    if (obj.event == 'onError') {
      this.errorFragment.display(obj.data);
    } else {
      var currentView = this.getCurrentView(obj);
      currentView[obj.event](obj);
    }
  };
  App.prototype.getCurrentView = function (obj) {
    var currentView = this.currentViewMap.get(obj.fragmentId);
    if (!currentView) {
      currentView = this.fragmentFactory.createNewInstance(obj.actionUrl, obj.namespace);
      this.currentViewMap.set(obj.fragmentId, currentView);
    }
    return currentView;
  };
  App.prototype.nativeEvent = function (obj) {
    this.logEvent(obj);
    var currentView = this.getCurrentView(obj);
    if (currentView[obj.event]) {
      currentView[obj.event](obj);
    }
    if (obj.event == 'onDetach') {
      this.currentViewMap.delete(obj.fragmentId);
    }
    if (obj.javascript) {
      eval(obj.javascript);
    }
  };
  App.prototype.logEvent = function (obj) {
    console.log(obj.event + " " + obj.actionUrl + " " + obj.fragmentId + " " + obj.namespace);
  };
  return App;
}();
var app = new App();
app.initialize();
}();
/******/ })()
;
//# sourceMappingURL=index.js.map