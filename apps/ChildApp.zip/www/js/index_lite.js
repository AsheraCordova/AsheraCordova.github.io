/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 754:
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
/*! *****************************************************************************
Copyright (C) Microsoft. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
var Reflect;
(function (Reflect) {
  // Metadata Proposal
  // https://rbuckton.github.io/reflect-metadata/
  (function (factory) {
    var root = (typeof __webpack_require__.g === "undefined" ? "undefined" : _typeof(__webpack_require__.g)) === "object" ? __webpack_require__.g : (typeof self === "undefined" ? "undefined" : _typeof(self)) === "object" ? self : _typeof(this) === "object" ? this : Function("return this;")();
    var exporter = makeExporter(Reflect);
    if (typeof root.Reflect === "undefined") {
      root.Reflect = Reflect;
    } else {
      exporter = makeExporter(root.Reflect, exporter);
    }
    factory(exporter);
    function makeExporter(target, previous) {
      return function (key, value) {
        if (typeof target[key] !== "function") {
          Object.defineProperty(target, key, {
            configurable: true,
            writable: true,
            value: value
          });
        }
        if (previous) previous(key, value);
      };
    }
  })(function (exporter) {
    var hasOwn = Object.prototype.hasOwnProperty;
    // feature test for Symbol support
    var supportsSymbol = typeof Symbol === "function";
    var toPrimitiveSymbol = supportsSymbol && typeof Symbol.toPrimitive !== "undefined" ? Symbol.toPrimitive : "@@toPrimitive";
    var iteratorSymbol = supportsSymbol && typeof Symbol.iterator !== "undefined" ? Symbol.iterator : "@@iterator";
    var supportsCreate = typeof Object.create === "function"; // feature test for Object.create support
    var supportsProto = {
      __proto__: []
    } instanceof Array; // feature test for __proto__ support
    var downLevel = !supportsCreate && !supportsProto;
    var HashMap = {
      // create an object in dictionary mode (a.k.a. "slow" mode in v8)
      create: supportsCreate ? function () {
        return MakeDictionary(Object.create(null));
      } : supportsProto ? function () {
        return MakeDictionary({
          __proto__: null
        });
      } : function () {
        return MakeDictionary({});
      },
      has: downLevel ? function (map, key) {
        return hasOwn.call(map, key);
      } : function (map, key) {
        return key in map;
      },
      get: downLevel ? function (map, key) {
        return hasOwn.call(map, key) ? map[key] : undefined;
      } : function (map, key) {
        return map[key];
      }
    };
    // Load global or shim versions of Map, Set, and WeakMap
    var functionPrototype = Object.getPrototypeOf(Function);
    var usePolyfill = (typeof process === "undefined" ? "undefined" : _typeof(process)) === "object" && process["env" + ""] && process["env" + ""]["REFLECT_METADATA_USE_MAP_POLYFILL"] === "true";
    var _Map = !usePolyfill && typeof Map === "function" && typeof Map.prototype.entries === "function" ? Map : CreateMapPolyfill();
    var _Set = !usePolyfill && typeof Set === "function" && typeof Set.prototype.entries === "function" ? Set : CreateSetPolyfill();
    var _WeakMap = !usePolyfill && typeof WeakMap === "function" ? WeakMap : CreateWeakMapPolyfill();
    // [[Metadata]] internal slot
    // https://rbuckton.github.io/reflect-metadata/#ordinary-object-internal-methods-and-internal-slots
    var Metadata = new _WeakMap();
    /**
     * Applies a set of decorators to a property of a target object.
     * @param decorators An array of decorators.
     * @param target The target object.
     * @param propertyKey (Optional) The property key to decorate.
     * @param attributes (Optional) The property descriptor for the target key.
     * @remarks Decorators are applied in reverse order.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     Example = Reflect.decorate(decoratorsArray, Example);
     *
     *     // property (on constructor)
     *     Reflect.decorate(decoratorsArray, Example, "staticProperty");
     *
     *     // property (on prototype)
     *     Reflect.decorate(decoratorsArray, Example.prototype, "property");
     *
     *     // method (on constructor)
     *     Object.defineProperty(Example, "staticMethod",
     *         Reflect.decorate(decoratorsArray, Example, "staticMethod",
     *             Object.getOwnPropertyDescriptor(Example, "staticMethod")));
     *
     *     // method (on prototype)
     *     Object.defineProperty(Example.prototype, "method",
     *         Reflect.decorate(decoratorsArray, Example.prototype, "method",
     *             Object.getOwnPropertyDescriptor(Example.prototype, "method")));
     *
     */
    function decorate(decorators, target, propertyKey, attributes) {
      if (!IsUndefined(propertyKey)) {
        if (!IsArray(decorators)) throw new TypeError();
        if (!IsObject(target)) throw new TypeError();
        if (!IsObject(attributes) && !IsUndefined(attributes) && !IsNull(attributes)) throw new TypeError();
        if (IsNull(attributes)) attributes = undefined;
        propertyKey = ToPropertyKey(propertyKey);
        return DecorateProperty(decorators, target, propertyKey, attributes);
      } else {
        if (!IsArray(decorators)) throw new TypeError();
        if (!IsConstructor(target)) throw new TypeError();
        return DecorateConstructor(decorators, target);
      }
    }
    exporter("decorate", decorate);
    // 4.1.2 Reflect.metadata(metadataKey, metadataValue)
    // https://rbuckton.github.io/reflect-metadata/#reflect.metadata
    /**
     * A default metadata decorator factory that can be used on a class, class member, or parameter.
     * @param metadataKey The key for the metadata entry.
     * @param metadataValue The value for the metadata entry.
     * @returns A decorator function.
     * @remarks
     * If `metadataKey` is already defined for the target and target key, the
     * metadataValue for that key will be overwritten.
     * @example
     *
     *     // constructor
     *     @Reflect.metadata(key, value)
     *     class Example {
     *     }
     *
     *     // property (on constructor, TypeScript only)
     *     class Example {
     *         @Reflect.metadata(key, value)
     *         static staticProperty;
     *     }
     *
     *     // property (on prototype, TypeScript only)
     *     class Example {
     *         @Reflect.metadata(key, value)
     *         property;
     *     }
     *
     *     // method (on constructor)
     *     class Example {
     *         @Reflect.metadata(key, value)
     *         static staticMethod() { }
     *     }
     *
     *     // method (on prototype)
     *     class Example {
     *         @Reflect.metadata(key, value)
     *         method() { }
     *     }
     *
     */
    function metadata(metadataKey, metadataValue) {
      function decorator(target, propertyKey) {
        if (!IsObject(target)) throw new TypeError();
        if (!IsUndefined(propertyKey) && !IsPropertyKey(propertyKey)) throw new TypeError();
        OrdinaryDefineOwnMetadata(metadataKey, metadataValue, target, propertyKey);
      }
      return decorator;
    }
    exporter("metadata", metadata);
    /**
     * Define a unique metadata entry on the target.
     * @param metadataKey A key used to store and retrieve metadata.
     * @param metadataValue A value that contains attached metadata.
     * @param target The target object on which to define metadata.
     * @param propertyKey (Optional) The property key for the target.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     Reflect.defineMetadata("custom:annotation", options, Example);
     *
     *     // property (on constructor)
     *     Reflect.defineMetadata("custom:annotation", options, Example, "staticProperty");
     *
     *     // property (on prototype)
     *     Reflect.defineMetadata("custom:annotation", options, Example.prototype, "property");
     *
     *     // method (on constructor)
     *     Reflect.defineMetadata("custom:annotation", options, Example, "staticMethod");
     *
     *     // method (on prototype)
     *     Reflect.defineMetadata("custom:annotation", options, Example.prototype, "method");
     *
     *     // decorator factory as metadata-producing annotation.
     *     function MyAnnotation(options): Decorator {
     *         return (target, key?) => Reflect.defineMetadata("custom:annotation", options, target, key);
     *     }
     *
     */
    function defineMetadata(metadataKey, metadataValue, target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryDefineOwnMetadata(metadataKey, metadataValue, target, propertyKey);
    }
    exporter("defineMetadata", defineMetadata);
    /**
     * Gets a value indicating whether the target object or its prototype chain has the provided metadata key defined.
     * @param metadataKey A key used to store and retrieve metadata.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns `true` if the metadata key was defined on the target object or its prototype chain; otherwise, `false`.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.hasMetadata("custom:annotation", Example);
     *
     *     // property (on constructor)
     *     result = Reflect.hasMetadata("custom:annotation", Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.hasMetadata("custom:annotation", Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.hasMetadata("custom:annotation", Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.hasMetadata("custom:annotation", Example.prototype, "method");
     *
     */
    function hasMetadata(metadataKey, target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryHasMetadata(metadataKey, target, propertyKey);
    }
    exporter("hasMetadata", hasMetadata);
    /**
     * Gets a value indicating whether the target object has the provided metadata key defined.
     * @param metadataKey A key used to store and retrieve metadata.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns `true` if the metadata key was defined on the target object; otherwise, `false`.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.hasOwnMetadata("custom:annotation", Example);
     *
     *     // property (on constructor)
     *     result = Reflect.hasOwnMetadata("custom:annotation", Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.hasOwnMetadata("custom:annotation", Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.hasOwnMetadata("custom:annotation", Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.hasOwnMetadata("custom:annotation", Example.prototype, "method");
     *
     */
    function hasOwnMetadata(metadataKey, target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryHasOwnMetadata(metadataKey, target, propertyKey);
    }
    exporter("hasOwnMetadata", hasOwnMetadata);
    /**
     * Gets the metadata value for the provided metadata key on the target object or its prototype chain.
     * @param metadataKey A key used to store and retrieve metadata.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns The metadata value for the metadata key if found; otherwise, `undefined`.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.getMetadata("custom:annotation", Example);
     *
     *     // property (on constructor)
     *     result = Reflect.getMetadata("custom:annotation", Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.getMetadata("custom:annotation", Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.getMetadata("custom:annotation", Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.getMetadata("custom:annotation", Example.prototype, "method");
     *
     */
    function getMetadata(metadataKey, target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryGetMetadata(metadataKey, target, propertyKey);
    }
    exporter("getMetadata", getMetadata);
    /**
     * Gets the metadata value for the provided metadata key on the target object.
     * @param metadataKey A key used to store and retrieve metadata.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns The metadata value for the metadata key if found; otherwise, `undefined`.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.getOwnMetadata("custom:annotation", Example);
     *
     *     // property (on constructor)
     *     result = Reflect.getOwnMetadata("custom:annotation", Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.getOwnMetadata("custom:annotation", Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.getOwnMetadata("custom:annotation", Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.getOwnMetadata("custom:annotation", Example.prototype, "method");
     *
     */
    function getOwnMetadata(metadataKey, target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryGetOwnMetadata(metadataKey, target, propertyKey);
    }
    exporter("getOwnMetadata", getOwnMetadata);
    /**
     * Gets the metadata keys defined on the target object or its prototype chain.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns An array of unique metadata keys.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.getMetadataKeys(Example);
     *
     *     // property (on constructor)
     *     result = Reflect.getMetadataKeys(Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.getMetadataKeys(Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.getMetadataKeys(Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.getMetadataKeys(Example.prototype, "method");
     *
     */
    function getMetadataKeys(target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryMetadataKeys(target, propertyKey);
    }
    exporter("getMetadataKeys", getMetadataKeys);
    /**
     * Gets the unique metadata keys defined on the target object.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns An array of unique metadata keys.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.getOwnMetadataKeys(Example);
     *
     *     // property (on constructor)
     *     result = Reflect.getOwnMetadataKeys(Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.getOwnMetadataKeys(Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.getOwnMetadataKeys(Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.getOwnMetadataKeys(Example.prototype, "method");
     *
     */
    function getOwnMetadataKeys(target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      return OrdinaryOwnMetadataKeys(target, propertyKey);
    }
    exporter("getOwnMetadataKeys", getOwnMetadataKeys);
    /**
     * Deletes the metadata entry from the target object with the provided key.
     * @param metadataKey A key used to store and retrieve metadata.
     * @param target The target object on which the metadata is defined.
     * @param propertyKey (Optional) The property key for the target.
     * @returns `true` if the metadata entry was found and deleted; otherwise, false.
     * @example
     *
     *     class Example {
     *         // property declarations are not part of ES6, though they are valid in TypeScript:
     *         // static staticProperty;
     *         // property;
     *
     *         constructor(p) { }
     *         static staticMethod(p) { }
     *         method(p) { }
     *     }
     *
     *     // constructor
     *     result = Reflect.deleteMetadata("custom:annotation", Example);
     *
     *     // property (on constructor)
     *     result = Reflect.deleteMetadata("custom:annotation", Example, "staticProperty");
     *
     *     // property (on prototype)
     *     result = Reflect.deleteMetadata("custom:annotation", Example.prototype, "property");
     *
     *     // method (on constructor)
     *     result = Reflect.deleteMetadata("custom:annotation", Example, "staticMethod");
     *
     *     // method (on prototype)
     *     result = Reflect.deleteMetadata("custom:annotation", Example.prototype, "method");
     *
     */
    function deleteMetadata(metadataKey, target, propertyKey) {
      if (!IsObject(target)) throw new TypeError();
      if (!IsUndefined(propertyKey)) propertyKey = ToPropertyKey(propertyKey);
      var metadataMap = GetOrCreateMetadataMap(target, propertyKey, /*Create*/false);
      if (IsUndefined(metadataMap)) return false;
      if (!metadataMap.delete(metadataKey)) return false;
      if (metadataMap.size > 0) return true;
      var targetMetadata = Metadata.get(target);
      targetMetadata.delete(propertyKey);
      if (targetMetadata.size > 0) return true;
      Metadata.delete(target);
      return true;
    }
    exporter("deleteMetadata", deleteMetadata);
    function DecorateConstructor(decorators, target) {
      for (var i = decorators.length - 1; i >= 0; --i) {
        var decorator = decorators[i];
        var decorated = decorator(target);
        if (!IsUndefined(decorated) && !IsNull(decorated)) {
          if (!IsConstructor(decorated)) throw new TypeError();
          target = decorated;
        }
      }
      return target;
    }
    function DecorateProperty(decorators, target, propertyKey, descriptor) {
      for (var i = decorators.length - 1; i >= 0; --i) {
        var decorator = decorators[i];
        var decorated = decorator(target, propertyKey, descriptor);
        if (!IsUndefined(decorated) && !IsNull(decorated)) {
          if (!IsObject(decorated)) throw new TypeError();
          descriptor = decorated;
        }
      }
      return descriptor;
    }
    function GetOrCreateMetadataMap(O, P, Create) {
      var targetMetadata = Metadata.get(O);
      if (IsUndefined(targetMetadata)) {
        if (!Create) return undefined;
        targetMetadata = new _Map();
        Metadata.set(O, targetMetadata);
      }
      var metadataMap = targetMetadata.get(P);
      if (IsUndefined(metadataMap)) {
        if (!Create) return undefined;
        metadataMap = new _Map();
        targetMetadata.set(P, metadataMap);
      }
      return metadataMap;
    }
    // 3.1.1.1 OrdinaryHasMetadata(MetadataKey, O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinaryhasmetadata
    function OrdinaryHasMetadata(MetadataKey, O, P) {
      var hasOwn = OrdinaryHasOwnMetadata(MetadataKey, O, P);
      if (hasOwn) return true;
      var parent = OrdinaryGetPrototypeOf(O);
      if (!IsNull(parent)) return OrdinaryHasMetadata(MetadataKey, parent, P);
      return false;
    }
    // 3.1.2.1 OrdinaryHasOwnMetadata(MetadataKey, O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinaryhasownmetadata
    function OrdinaryHasOwnMetadata(MetadataKey, O, P) {
      var metadataMap = GetOrCreateMetadataMap(O, P, /*Create*/false);
      if (IsUndefined(metadataMap)) return false;
      return ToBoolean(metadataMap.has(MetadataKey));
    }
    // 3.1.3.1 OrdinaryGetMetadata(MetadataKey, O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinarygetmetadata
    function OrdinaryGetMetadata(MetadataKey, O, P) {
      var hasOwn = OrdinaryHasOwnMetadata(MetadataKey, O, P);
      if (hasOwn) return OrdinaryGetOwnMetadata(MetadataKey, O, P);
      var parent = OrdinaryGetPrototypeOf(O);
      if (!IsNull(parent)) return OrdinaryGetMetadata(MetadataKey, parent, P);
      return undefined;
    }
    // 3.1.4.1 OrdinaryGetOwnMetadata(MetadataKey, O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinarygetownmetadata
    function OrdinaryGetOwnMetadata(MetadataKey, O, P) {
      var metadataMap = GetOrCreateMetadataMap(O, P, /*Create*/false);
      if (IsUndefined(metadataMap)) return undefined;
      return metadataMap.get(MetadataKey);
    }
    // 3.1.5.1 OrdinaryDefineOwnMetadata(MetadataKey, MetadataValue, O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinarydefineownmetadata
    function OrdinaryDefineOwnMetadata(MetadataKey, MetadataValue, O, P) {
      var metadataMap = GetOrCreateMetadataMap(O, P, /*Create*/true);
      metadataMap.set(MetadataKey, MetadataValue);
    }
    // 3.1.6.1 OrdinaryMetadataKeys(O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinarymetadatakeys
    function OrdinaryMetadataKeys(O, P) {
      var ownKeys = OrdinaryOwnMetadataKeys(O, P);
      var parent = OrdinaryGetPrototypeOf(O);
      if (parent === null) return ownKeys;
      var parentKeys = OrdinaryMetadataKeys(parent, P);
      if (parentKeys.length <= 0) return ownKeys;
      if (ownKeys.length <= 0) return parentKeys;
      var set = new _Set();
      var keys = [];
      for (var _i = 0, ownKeys_1 = ownKeys; _i < ownKeys_1.length; _i++) {
        var key = ownKeys_1[_i];
        var hasKey = set.has(key);
        if (!hasKey) {
          set.add(key);
          keys.push(key);
        }
      }
      for (var _a = 0, parentKeys_1 = parentKeys; _a < parentKeys_1.length; _a++) {
        var key = parentKeys_1[_a];
        var hasKey = set.has(key);
        if (!hasKey) {
          set.add(key);
          keys.push(key);
        }
      }
      return keys;
    }
    // 3.1.7.1 OrdinaryOwnMetadataKeys(O, P)
    // https://rbuckton.github.io/reflect-metadata/#ordinaryownmetadatakeys
    function OrdinaryOwnMetadataKeys(O, P) {
      var keys = [];
      var metadataMap = GetOrCreateMetadataMap(O, P, /*Create*/false);
      if (IsUndefined(metadataMap)) return keys;
      var keysObj = metadataMap.keys();
      var iterator = GetIterator(keysObj);
      var k = 0;
      while (true) {
        var next = IteratorStep(iterator);
        if (!next) {
          keys.length = k;
          return keys;
        }
        var nextValue = IteratorValue(next);
        try {
          keys[k] = nextValue;
        } catch (e) {
          try {
            IteratorClose(iterator);
          } finally {
            throw e;
          }
        }
        k++;
      }
    }
    // 6 ECMAScript Data Typ0es and Values
    // https://tc39.github.io/ecma262/#sec-ecmascript-data-types-and-values
    function Type(x) {
      if (x === null) return 1 /* Null */;
      switch (_typeof(x)) {
        case "undefined":
          return 0 /* Undefined */;
        case "boolean":
          return 2 /* Boolean */;
        case "string":
          return 3 /* String */;
        case "symbol":
          return 4 /* Symbol */;
        case "number":
          return 5 /* Number */;
        case "object":
          return x === null ? 1 /* Null */ : 6 /* Object */;
        default:
          return 6 /* Object */;
      }
    }
    // 6.1.1 The Undefined Type
    // https://tc39.github.io/ecma262/#sec-ecmascript-language-types-undefined-type
    function IsUndefined(x) {
      return x === undefined;
    }
    // 6.1.2 The Null Type
    // https://tc39.github.io/ecma262/#sec-ecmascript-language-types-null-type
    function IsNull(x) {
      return x === null;
    }
    // 6.1.5 The Symbol Type
    // https://tc39.github.io/ecma262/#sec-ecmascript-language-types-symbol-type
    function IsSymbol(x) {
      return _typeof(x) === "symbol";
    }
    // 6.1.7 The Object Type
    // https://tc39.github.io/ecma262/#sec-object-type
    function IsObject(x) {
      return _typeof(x) === "object" ? x !== null : typeof x === "function";
    }
    // 7.1 Type Conversion
    // https://tc39.github.io/ecma262/#sec-type-conversion
    // 7.1.1 ToPrimitive(input [, PreferredType])
    // https://tc39.github.io/ecma262/#sec-toprimitive
    function ToPrimitive(input, PreferredType) {
      switch (Type(input)) {
        case 0 /* Undefined */:
          return input;
        case 1 /* Null */:
          return input;
        case 2 /* Boolean */:
          return input;
        case 3 /* String */:
          return input;
        case 4 /* Symbol */:
          return input;
        case 5 /* Number */:
          return input;
      }
      var hint = PreferredType === 3 /* String */ ? "string" : PreferredType === 5 /* Number */ ? "number" : "default";
      var exoticToPrim = GetMethod(input, toPrimitiveSymbol);
      if (exoticToPrim !== undefined) {
        var result = exoticToPrim.call(input, hint);
        if (IsObject(result)) throw new TypeError();
        return result;
      }
      return OrdinaryToPrimitive(input, hint === "default" ? "number" : hint);
    }
    // 7.1.1.1 OrdinaryToPrimitive(O, hint)
    // https://tc39.github.io/ecma262/#sec-ordinarytoprimitive
    function OrdinaryToPrimitive(O, hint) {
      if (hint === "string") {
        var toString_1 = O.toString;
        if (IsCallable(toString_1)) {
          var result = toString_1.call(O);
          if (!IsObject(result)) return result;
        }
        var valueOf = O.valueOf;
        if (IsCallable(valueOf)) {
          var result = valueOf.call(O);
          if (!IsObject(result)) return result;
        }
      } else {
        var valueOf = O.valueOf;
        if (IsCallable(valueOf)) {
          var result = valueOf.call(O);
          if (!IsObject(result)) return result;
        }
        var toString_2 = O.toString;
        if (IsCallable(toString_2)) {
          var result = toString_2.call(O);
          if (!IsObject(result)) return result;
        }
      }
      throw new TypeError();
    }
    // 7.1.2 ToBoolean(argument)
    // https://tc39.github.io/ecma262/2016/#sec-toboolean
    function ToBoolean(argument) {
      return !!argument;
    }
    // 7.1.12 ToString(argument)
    // https://tc39.github.io/ecma262/#sec-tostring
    function ToString(argument) {
      return "" + argument;
    }
    // 7.1.14 ToPropertyKey(argument)
    // https://tc39.github.io/ecma262/#sec-topropertykey
    function ToPropertyKey(argument) {
      var key = ToPrimitive(argument, 3 /* String */);
      if (IsSymbol(key)) return key;
      return ToString(key);
    }
    // 7.2 Testing and Comparison Operations
    // https://tc39.github.io/ecma262/#sec-testing-and-comparison-operations
    // 7.2.2 IsArray(argument)
    // https://tc39.github.io/ecma262/#sec-isarray
    function IsArray(argument) {
      return Array.isArray ? Array.isArray(argument) : argument instanceof Object ? argument instanceof Array : Object.prototype.toString.call(argument) === "[object Array]";
    }
    // 7.2.3 IsCallable(argument)
    // https://tc39.github.io/ecma262/#sec-iscallable
    function IsCallable(argument) {
      // NOTE: This is an approximation as we cannot check for [[Call]] internal method.
      return typeof argument === "function";
    }
    // 7.2.4 IsConstructor(argument)
    // https://tc39.github.io/ecma262/#sec-isconstructor
    function IsConstructor(argument) {
      // NOTE: This is an approximation as we cannot check for [[Construct]] internal method.
      return typeof argument === "function";
    }
    // 7.2.7 IsPropertyKey(argument)
    // https://tc39.github.io/ecma262/#sec-ispropertykey
    function IsPropertyKey(argument) {
      switch (Type(argument)) {
        case 3 /* String */:
          return true;
        case 4 /* Symbol */:
          return true;
        default:
          return false;
      }
    }
    // 7.3 Operations on Objects
    // https://tc39.github.io/ecma262/#sec-operations-on-objects
    // 7.3.9 GetMethod(V, P)
    // https://tc39.github.io/ecma262/#sec-getmethod
    function GetMethod(V, P) {
      var func = V[P];
      if (func === undefined || func === null) return undefined;
      if (!IsCallable(func)) throw new TypeError();
      return func;
    }
    // 7.4 Operations on Iterator Objects
    // https://tc39.github.io/ecma262/#sec-operations-on-iterator-objects
    function GetIterator(obj) {
      var method = GetMethod(obj, iteratorSymbol);
      if (!IsCallable(method)) throw new TypeError(); // from Call
      var iterator = method.call(obj);
      if (!IsObject(iterator)) throw new TypeError();
      return iterator;
    }
    // 7.4.4 IteratorValue(iterResult)
    // https://tc39.github.io/ecma262/2016/#sec-iteratorvalue
    function IteratorValue(iterResult) {
      return iterResult.value;
    }
    // 7.4.5 IteratorStep(iterator)
    // https://tc39.github.io/ecma262/#sec-iteratorstep
    function IteratorStep(iterator) {
      var result = iterator.next();
      return result.done ? false : result;
    }
    // 7.4.6 IteratorClose(iterator, completion)
    // https://tc39.github.io/ecma262/#sec-iteratorclose
    function IteratorClose(iterator) {
      var f = iterator["return"];
      if (f) f.call(iterator);
    }
    // 9.1 Ordinary Object Internal Methods and Internal Slots
    // https://tc39.github.io/ecma262/#sec-ordinary-object-internal-methods-and-internal-slots
    // 9.1.1.1 OrdinaryGetPrototypeOf(O)
    // https://tc39.github.io/ecma262/#sec-ordinarygetprototypeof
    function OrdinaryGetPrototypeOf(O) {
      var proto = Object.getPrototypeOf(O);
      if (typeof O !== "function" || O === functionPrototype) return proto;
      // TypeScript doesn't set __proto__ in ES5, as it's non-standard.
      // Try to determine the superclass constructor. Compatible implementations
      // must either set __proto__ on a subclass constructor to the superclass constructor,
      // or ensure each class has a valid `constructor` property on its prototype that
      // points back to the constructor.
      // If this is not the same as Function.[[Prototype]], then this is definately inherited.
      // This is the case when in ES6 or when using __proto__ in a compatible browser.
      if (proto !== functionPrototype) return proto;
      // If the super prototype is Object.prototype, null, or undefined, then we cannot determine the heritage.
      var prototype = O.prototype;
      var prototypeProto = prototype && Object.getPrototypeOf(prototype);
      if (prototypeProto == null || prototypeProto === Object.prototype) return proto;
      // If the constructor was not a function, then we cannot determine the heritage.
      var constructor = prototypeProto.constructor;
      if (typeof constructor !== "function") return proto;
      // If we have some kind of self-reference, then we cannot determine the heritage.
      if (constructor === O) return proto;
      // we have a pretty good guess at the heritage.
      return constructor;
    }
    // naive Map shim
    function CreateMapPolyfill() {
      var cacheSentinel = {};
      var arraySentinel = [];
      var MapIterator = /** @class */function () {
        function MapIterator(keys, values, selector) {
          this._index = 0;
          this._keys = keys;
          this._values = values;
          this._selector = selector;
        }
        MapIterator.prototype["@@iterator"] = function () {
          return this;
        };
        MapIterator.prototype[iteratorSymbol] = function () {
          return this;
        };
        MapIterator.prototype.next = function () {
          var index = this._index;
          if (index >= 0 && index < this._keys.length) {
            var result = this._selector(this._keys[index], this._values[index]);
            if (index + 1 >= this._keys.length) {
              this._index = -1;
              this._keys = arraySentinel;
              this._values = arraySentinel;
            } else {
              this._index++;
            }
            return {
              value: result,
              done: false
            };
          }
          return {
            value: undefined,
            done: true
          };
        };
        MapIterator.prototype.throw = function (error) {
          if (this._index >= 0) {
            this._index = -1;
            this._keys = arraySentinel;
            this._values = arraySentinel;
          }
          throw error;
        };
        MapIterator.prototype.return = function (value) {
          if (this._index >= 0) {
            this._index = -1;
            this._keys = arraySentinel;
            this._values = arraySentinel;
          }
          return {
            value: value,
            done: true
          };
        };
        return MapIterator;
      }();
      return /** @class */function () {
        function Map() {
          this._keys = [];
          this._values = [];
          this._cacheKey = cacheSentinel;
          this._cacheIndex = -2;
        }
        Object.defineProperty(Map.prototype, "size", {
          get: function get() {
            return this._keys.length;
          },
          enumerable: true,
          configurable: true
        });
        Map.prototype.has = function (key) {
          return this._find(key, /*insert*/false) >= 0;
        };
        Map.prototype.get = function (key) {
          var index = this._find(key, /*insert*/false);
          return index >= 0 ? this._values[index] : undefined;
        };
        Map.prototype.set = function (key, value) {
          var index = this._find(key, /*insert*/true);
          this._values[index] = value;
          return this;
        };
        Map.prototype.delete = function (key) {
          var index = this._find(key, /*insert*/false);
          if (index >= 0) {
            var size = this._keys.length;
            for (var i = index + 1; i < size; i++) {
              this._keys[i - 1] = this._keys[i];
              this._values[i - 1] = this._values[i];
            }
            this._keys.length--;
            this._values.length--;
            if (key === this._cacheKey) {
              this._cacheKey = cacheSentinel;
              this._cacheIndex = -2;
            }
            return true;
          }
          return false;
        };
        Map.prototype.clear = function () {
          this._keys.length = 0;
          this._values.length = 0;
          this._cacheKey = cacheSentinel;
          this._cacheIndex = -2;
        };
        Map.prototype.keys = function () {
          return new MapIterator(this._keys, this._values, getKey);
        };
        Map.prototype.values = function () {
          return new MapIterator(this._keys, this._values, getValue);
        };
        Map.prototype.entries = function () {
          return new MapIterator(this._keys, this._values, getEntry);
        };
        Map.prototype["@@iterator"] = function () {
          return this.entries();
        };
        Map.prototype[iteratorSymbol] = function () {
          return this.entries();
        };
        Map.prototype._find = function (key, insert) {
          if (this._cacheKey !== key) {
            this._cacheIndex = this._keys.indexOf(this._cacheKey = key);
          }
          if (this._cacheIndex < 0 && insert) {
            this._cacheIndex = this._keys.length;
            this._keys.push(key);
            this._values.push(undefined);
          }
          return this._cacheIndex;
        };
        return Map;
      }();
      function getKey(key, _) {
        return key;
      }
      function getValue(_, value) {
        return value;
      }
      function getEntry(key, value) {
        return [key, value];
      }
    }
    // naive Set shim
    function CreateSetPolyfill() {
      return /** @class */function () {
        function Set() {
          this._map = new _Map();
        }
        Object.defineProperty(Set.prototype, "size", {
          get: function get() {
            return this._map.size;
          },
          enumerable: true,
          configurable: true
        });
        Set.prototype.has = function (value) {
          return this._map.has(value);
        };
        Set.prototype.add = function (value) {
          return this._map.set(value, value), this;
        };
        Set.prototype.delete = function (value) {
          return this._map.delete(value);
        };
        Set.prototype.clear = function () {
          this._map.clear();
        };
        Set.prototype.keys = function () {
          return this._map.keys();
        };
        Set.prototype.values = function () {
          return this._map.values();
        };
        Set.prototype.entries = function () {
          return this._map.entries();
        };
        Set.prototype["@@iterator"] = function () {
          return this.keys();
        };
        Set.prototype[iteratorSymbol] = function () {
          return this.keys();
        };
        return Set;
      }();
    }
    // naive WeakMap shim
    function CreateWeakMapPolyfill() {
      var UUID_SIZE = 16;
      var keys = HashMap.create();
      var rootKey = CreateUniqueKey();
      return /** @class */function () {
        function WeakMap() {
          this._key = CreateUniqueKey();
        }
        WeakMap.prototype.has = function (target) {
          var table = GetOrCreateWeakMapTable(target, /*create*/false);
          return table !== undefined ? HashMap.has(table, this._key) : false;
        };
        WeakMap.prototype.get = function (target) {
          var table = GetOrCreateWeakMapTable(target, /*create*/false);
          return table !== undefined ? HashMap.get(table, this._key) : undefined;
        };
        WeakMap.prototype.set = function (target, value) {
          var table = GetOrCreateWeakMapTable(target, /*create*/true);
          table[this._key] = value;
          return this;
        };
        WeakMap.prototype.delete = function (target) {
          var table = GetOrCreateWeakMapTable(target, /*create*/false);
          return table !== undefined ? delete table[this._key] : false;
        };
        WeakMap.prototype.clear = function () {
          // NOTE: not a real clear, just makes the previous data unreachable
          this._key = CreateUniqueKey();
        };
        return WeakMap;
      }();
      function CreateUniqueKey() {
        var key;
        do key = "@@WeakMap@@" + CreateUUID(); while (HashMap.has(keys, key));
        keys[key] = true;
        return key;
      }
      function GetOrCreateWeakMapTable(target, create) {
        if (!hasOwn.call(target, rootKey)) {
          if (!create) return undefined;
          Object.defineProperty(target, rootKey, {
            value: HashMap.create()
          });
        }
        return target[rootKey];
      }
      function FillRandomBytes(buffer, size) {
        for (var i = 0; i < size; ++i) buffer[i] = Math.random() * 0xff | 0;
        return buffer;
      }
      function GenRandomBytes(size) {
        if (typeof Uint8Array === "function") {
          if (typeof crypto !== "undefined") return crypto.getRandomValues(new Uint8Array(size));
          if (typeof msCrypto !== "undefined") return msCrypto.getRandomValues(new Uint8Array(size));
          return FillRandomBytes(new Uint8Array(size), size);
        }
        return FillRandomBytes(new Array(size), size);
      }
      function CreateUUID() {
        var data = GenRandomBytes(UUID_SIZE);
        // mark as random - RFC 4122 § 4.4
        data[6] = data[6] & 0x4f | 0x40;
        data[8] = data[8] & 0xbf | 0x80;
        var result = "";
        for (var offset = 0; offset < UUID_SIZE; ++offset) {
          var byte = data[offset];
          if (offset === 4 || offset === 6 || offset === 8) result += "-";
          if (byte < 16) result += "0";
          result += byte.toString(16).toLowerCase();
        }
        return result;
      }
    }
    // uses a heuristic used by v8 and chakra to force an object into dictionary mode.
    function MakeDictionary(obj) {
      obj.__ = undefined;
      delete obj.__;
      return obj;
    }
  });
})(Reflect || (Reflect = {}));

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/global */
/******/ 	!function() {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	}();
/******/ 	
/************************************************************************/
// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
!function() {
"use strict";

// UNUSED EXPORTS: AppLoader, fragmentMapper

;// ./src/Constants.ts
var LOCALE_MANAGER_KEYS = [];
;// ./src/app/LocaleManager.ts

var LocaleManager = /** @class */function () {
  function LocaleManager() {
    this.keys = LOCALE_MANAGER_KEYS;
  }
  LocaleManager.getInstance = function () {
    return LocaleManager.localeManager;
  };
  LocaleManager.prototype.init = function (callBack, rootDirectory) {
    coreManager.executeSimpleCommand([["loadLocale", this.keys, rootDirectory]], function (obj) {
      LocaleManager.localeMap = JSON.parse(obj)["loadLocale"];
      if (callBack) {
        callBack();
      }
    });
  };
  LocaleManager.prototype.translate = function (key) {
    if (LocaleManager.localeMap && LocaleManager.localeMap[key]) {
      return LocaleManager.localeMap[key];
    }
    return key;
  };
  LocaleManager.localeManager = new LocaleManager();
  return LocaleManager;
}();
/* harmony default export */ var app_LocaleManager = (LocaleManager);
// EXTERNAL MODULE: ./node_modules/reflect-metadata/Reflect.js
var reflect_metadata_Reflect = __webpack_require__(754);
;// ./node_modules/class-transformer/esm5/enums/transformation-type.enum.js
var TransformationType;
(function (TransformationType) {
  TransformationType[TransformationType["PLAIN_TO_CLASS"] = 0] = "PLAIN_TO_CLASS";
  TransformationType[TransformationType["CLASS_TO_PLAIN"] = 1] = "CLASS_TO_PLAIN";
  TransformationType[TransformationType["CLASS_TO_CLASS"] = 2] = "CLASS_TO_CLASS";
})(TransformationType || (TransformationType = {}));
;// ./node_modules/class-transformer/esm5/MetadataStorage.js

/**
 * Storage all library metadata.
 */
var MetadataStorage = /** @class */function () {
  function MetadataStorage() {
    // -------------------------------------------------------------------------
    // Properties
    // -------------------------------------------------------------------------
    this._typeMetadatas = new Map();
    this._transformMetadatas = new Map();
    this._exposeMetadatas = new Map();
    this._excludeMetadatas = new Map();
    this._ancestorsMap = new Map();
  }
  // -------------------------------------------------------------------------
  // Adder Methods
  // -------------------------------------------------------------------------
  MetadataStorage.prototype.addTypeMetadata = function (metadata) {
    if (!this._typeMetadatas.has(metadata.target)) {
      this._typeMetadatas.set(metadata.target, new Map());
    }
    this._typeMetadatas.get(metadata.target).set(metadata.propertyName, metadata);
  };
  MetadataStorage.prototype.addTransformMetadata = function (metadata) {
    if (!this._transformMetadatas.has(metadata.target)) {
      this._transformMetadatas.set(metadata.target, new Map());
    }
    if (!this._transformMetadatas.get(metadata.target).has(metadata.propertyName)) {
      this._transformMetadatas.get(metadata.target).set(metadata.propertyName, []);
    }
    this._transformMetadatas.get(metadata.target).get(metadata.propertyName).push(metadata);
  };
  MetadataStorage.prototype.addExposeMetadata = function (metadata) {
    if (!this._exposeMetadatas.has(metadata.target)) {
      this._exposeMetadatas.set(metadata.target, new Map());
    }
    this._exposeMetadatas.get(metadata.target).set(metadata.propertyName, metadata);
  };
  MetadataStorage.prototype.addExcludeMetadata = function (metadata) {
    if (!this._excludeMetadatas.has(metadata.target)) {
      this._excludeMetadatas.set(metadata.target, new Map());
    }
    this._excludeMetadatas.get(metadata.target).set(metadata.propertyName, metadata);
  };
  // -------------------------------------------------------------------------
  // Public Methods
  // -------------------------------------------------------------------------
  MetadataStorage.prototype.findTransformMetadatas = function (target, propertyName, transformationType) {
    return this.findMetadatas(this._transformMetadatas, target, propertyName).filter(function (metadata) {
      if (!metadata.options) return true;
      if (metadata.options.toClassOnly === true && metadata.options.toPlainOnly === true) return true;
      if (metadata.options.toClassOnly === true) {
        return transformationType === TransformationType.CLASS_TO_CLASS || transformationType === TransformationType.PLAIN_TO_CLASS;
      }
      if (metadata.options.toPlainOnly === true) {
        return transformationType === TransformationType.CLASS_TO_PLAIN;
      }
      return true;
    });
  };
  MetadataStorage.prototype.findExcludeMetadata = function (target, propertyName) {
    return this.findMetadata(this._excludeMetadatas, target, propertyName);
  };
  MetadataStorage.prototype.findExposeMetadata = function (target, propertyName) {
    return this.findMetadata(this._exposeMetadatas, target, propertyName);
  };
  MetadataStorage.prototype.findExposeMetadataByCustomName = function (target, name) {
    return this.getExposedMetadatas(target).find(function (metadata) {
      return metadata.options && metadata.options.name === name;
    });
  };
  MetadataStorage.prototype.findTypeMetadata = function (target, propertyName) {
    return this.findMetadata(this._typeMetadatas, target, propertyName);
  };
  MetadataStorage.prototype.getStrategy = function (target) {
    var excludeMap = this._excludeMetadatas.get(target);
    var exclude = excludeMap && excludeMap.get(undefined);
    var exposeMap = this._exposeMetadatas.get(target);
    var expose = exposeMap && exposeMap.get(undefined);
    if (exclude && expose || !exclude && !expose) return 'none';
    return exclude ? 'excludeAll' : 'exposeAll';
  };
  MetadataStorage.prototype.getExposedMetadatas = function (target) {
    return this.getMetadata(this._exposeMetadatas, target);
  };
  MetadataStorage.prototype.getExcludedMetadatas = function (target) {
    return this.getMetadata(this._excludeMetadatas, target);
  };
  MetadataStorage.prototype.getExposedProperties = function (target, transformationType) {
    return this.getExposedMetadatas(target).filter(function (metadata) {
      if (!metadata.options) return true;
      if (metadata.options.toClassOnly === true && metadata.options.toPlainOnly === true) return true;
      if (metadata.options.toClassOnly === true) {
        return transformationType === TransformationType.CLASS_TO_CLASS || transformationType === TransformationType.PLAIN_TO_CLASS;
      }
      if (metadata.options.toPlainOnly === true) {
        return transformationType === TransformationType.CLASS_TO_PLAIN;
      }
      return true;
    }).map(function (metadata) {
      return metadata.propertyName;
    });
  };
  MetadataStorage.prototype.getExcludedProperties = function (target, transformationType) {
    return this.getExcludedMetadatas(target).filter(function (metadata) {
      if (!metadata.options) return true;
      if (metadata.options.toClassOnly === true && metadata.options.toPlainOnly === true) return true;
      if (metadata.options.toClassOnly === true) {
        return transformationType === TransformationType.CLASS_TO_CLASS || transformationType === TransformationType.PLAIN_TO_CLASS;
      }
      if (metadata.options.toPlainOnly === true) {
        return transformationType === TransformationType.CLASS_TO_PLAIN;
      }
      return true;
    }).map(function (metadata) {
      return metadata.propertyName;
    });
  };
  MetadataStorage.prototype.clear = function () {
    this._typeMetadatas.clear();
    this._exposeMetadatas.clear();
    this._excludeMetadatas.clear();
    this._ancestorsMap.clear();
  };
  // -------------------------------------------------------------------------
  // Private Methods
  // -------------------------------------------------------------------------
  MetadataStorage.prototype.getMetadata = function (metadatas, target) {
    var metadataFromTargetMap = metadatas.get(target);
    var metadataFromTarget;
    if (metadataFromTargetMap) {
      metadataFromTarget = Array.from(metadataFromTargetMap.values()).filter(function (meta) {
        return meta.propertyName !== undefined;
      });
    }
    var metadataFromAncestors = [];
    for (var _i = 0, _a = this.getAncestors(target); _i < _a.length; _i++) {
      var ancestor = _a[_i];
      var ancestorMetadataMap = metadatas.get(ancestor);
      if (ancestorMetadataMap) {
        var metadataFromAncestor = Array.from(ancestorMetadataMap.values()).filter(function (meta) {
          return meta.propertyName !== undefined;
        });
        metadataFromAncestors.push.apply(metadataFromAncestors, metadataFromAncestor);
      }
    }
    return metadataFromAncestors.concat(metadataFromTarget || []);
  };
  MetadataStorage.prototype.findMetadata = function (metadatas, target, propertyName) {
    var metadataFromTargetMap = metadatas.get(target);
    if (metadataFromTargetMap) {
      var metadataFromTarget = metadataFromTargetMap.get(propertyName);
      if (metadataFromTarget) {
        return metadataFromTarget;
      }
    }
    for (var _i = 0, _a = this.getAncestors(target); _i < _a.length; _i++) {
      var ancestor = _a[_i];
      var ancestorMetadataMap = metadatas.get(ancestor);
      if (ancestorMetadataMap) {
        var ancestorResult = ancestorMetadataMap.get(propertyName);
        if (ancestorResult) {
          return ancestorResult;
        }
      }
    }
    return undefined;
  };
  MetadataStorage.prototype.findMetadatas = function (metadatas, target, propertyName) {
    var metadataFromTargetMap = metadatas.get(target);
    var metadataFromTarget;
    if (metadataFromTargetMap) {
      metadataFromTarget = metadataFromTargetMap.get(propertyName);
    }
    var metadataFromAncestorsTarget = [];
    for (var _i = 0, _a = this.getAncestors(target); _i < _a.length; _i++) {
      var ancestor = _a[_i];
      var ancestorMetadataMap = metadatas.get(ancestor);
      if (ancestorMetadataMap) {
        if (ancestorMetadataMap.has(propertyName)) {
          metadataFromAncestorsTarget.push.apply(metadataFromAncestorsTarget, ancestorMetadataMap.get(propertyName));
        }
      }
    }
    return metadataFromAncestorsTarget.slice().reverse().concat((metadataFromTarget || []).slice().reverse());
  };
  MetadataStorage.prototype.getAncestors = function (target) {
    if (!target) return [];
    if (!this._ancestorsMap.has(target)) {
      var ancestors = [];
      for (var baseClass = Object.getPrototypeOf(target.prototype.constructor); typeof baseClass.prototype !== 'undefined'; baseClass = Object.getPrototypeOf(baseClass.prototype.constructor)) {
        ancestors.push(baseClass);
      }
      this._ancestorsMap.set(target, ancestors);
    }
    return this._ancestorsMap.get(target);
  };
  return MetadataStorage;
}();

;// ./node_modules/class-transformer/esm5/storage.js

/**
 * Default metadata storage is used as singleton and can be used to storage all metadatas.
 */
var defaultMetadataStorage = new MetadataStorage();
;// ./node_modules/class-transformer/esm5/utils/get-global.util.js
/**
 * This function returns the global object across Node and browsers.
 *
 * Note: `globalThis` is the standardized approach however it has been added to
 * Node.js in version 12. We need to include this snippet until Node 12 EOL.
 */
function getGlobal() {
  if (typeof globalThis !== 'undefined') {
    return globalThis;
  }
  if (typeof __webpack_require__.g !== 'undefined') {
    return __webpack_require__.g;
  }
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore: Cannot find name 'window'.
  if (typeof window !== 'undefined') {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore: Cannot find name 'window'.
    return window;
  }
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore: Cannot find name 'self'.
  if (typeof self !== 'undefined') {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore: Cannot find name 'self'.
    return self;
  }
}
;// ./node_modules/class-transformer/esm5/utils/is-promise.util.js
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function isPromise(p) {
  return p !== null && _typeof(p) === 'object' && typeof p.then === 'function';
}
;// ./node_modules/class-transformer/esm5/TransformOperationExecutor.js
function TransformOperationExecutor_typeof(o) { "@babel/helpers - typeof"; return TransformOperationExecutor_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, TransformOperationExecutor_typeof(o); }
var __spreadArray = undefined && undefined.__spreadArray || function (to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};



function instantiateArrayType(arrayType) {
  var array = new arrayType();
  if (!(array instanceof Set) && !('push' in array)) {
    return [];
  }
  return array;
}
var TransformOperationExecutor = /** @class */function () {
  // -------------------------------------------------------------------------
  // Constructor
  // -------------------------------------------------------------------------
  function TransformOperationExecutor(transformationType, options) {
    this.transformationType = transformationType;
    this.options = options;
    // -------------------------------------------------------------------------
    // Private Properties
    // -------------------------------------------------------------------------
    this.recursionStack = new Set();
  }
  // -------------------------------------------------------------------------
  // Public Methods
  // -------------------------------------------------------------------------
  TransformOperationExecutor.prototype.transform = function (source, value, targetType, arrayType, isMap, level) {
    var _this = this;
    if (level === void 0) {
      level = 0;
    }
    if (Array.isArray(value) || value instanceof Set) {
      var newValue_1 = arrayType && this.transformationType === TransformationType.PLAIN_TO_CLASS ? instantiateArrayType(arrayType) : [];
      value.forEach(function (subValue, index) {
        var subSource = source ? source[index] : undefined;
        if (!_this.options.enableCircularCheck || !_this.isCircular(subValue)) {
          var realTargetType = void 0;
          if (typeof targetType !== 'function' && targetType && targetType.options && targetType.options.discriminator && targetType.options.discriminator.property && targetType.options.discriminator.subTypes) {
            if (_this.transformationType === TransformationType.PLAIN_TO_CLASS) {
              realTargetType = targetType.options.discriminator.subTypes.find(function (subType) {
                return subType.name === subValue[targetType.options.discriminator.property];
              });
              var options = {
                newObject: newValue_1,
                object: subValue,
                property: undefined
              };
              var newType = targetType.typeFunction(options);
              realTargetType === undefined ? realTargetType = newType : realTargetType = realTargetType.value;
              if (!targetType.options.keepDiscriminatorProperty) delete subValue[targetType.options.discriminator.property];
            }
            if (_this.transformationType === TransformationType.CLASS_TO_CLASS) {
              realTargetType = subValue.constructor;
            }
            if (_this.transformationType === TransformationType.CLASS_TO_PLAIN) {
              subValue[targetType.options.discriminator.property] = targetType.options.discriminator.subTypes.find(function (subType) {
                return subType.value === subValue.constructor;
              }).name;
            }
          } else {
            realTargetType = targetType;
          }
          var value_1 = _this.transform(subSource, subValue, realTargetType, undefined, subValue instanceof Map, level + 1);
          if (newValue_1 instanceof Set) {
            newValue_1.add(value_1);
          } else {
            newValue_1.push(value_1);
          }
        } else if (_this.transformationType === TransformationType.CLASS_TO_CLASS) {
          if (newValue_1 instanceof Set) {
            newValue_1.add(subValue);
          } else {
            newValue_1.push(subValue);
          }
        }
      });
      return newValue_1;
    } else if (targetType === String && !isMap) {
      if (value === null || value === undefined) return value;
      return String(value);
    } else if (targetType === Number && !isMap) {
      if (value === null || value === undefined) return value;
      return Number(value);
    } else if (targetType === Boolean && !isMap) {
      if (value === null || value === undefined) return value;
      return Boolean(value);
    } else if ((targetType === Date || value instanceof Date) && !isMap) {
      if (value instanceof Date) {
        return new Date(value.valueOf());
      }
      if (value === null || value === undefined) return value;
      return new Date(value);
    } else if (!!getGlobal().Buffer && (targetType === Buffer || value instanceof Buffer) && !isMap) {
      if (value === null || value === undefined) return value;
      return Buffer.from(value);
    } else if (isPromise(value) && !isMap) {
      return new Promise(function (resolve, reject) {
        value.then(function (data) {
          return resolve(_this.transform(undefined, data, targetType, undefined, undefined, level + 1));
        }, reject);
      });
    } else if (!isMap && value !== null && TransformOperationExecutor_typeof(value) === 'object' && typeof value.then === 'function') {
      // Note: We should not enter this, as promise has been handled above
      // This option simply returns the Promise preventing a JS error from happening and should be an inaccessible path.
      return value; // skip promise transformation
    } else if (TransformOperationExecutor_typeof(value) === 'object' && value !== null) {
      // try to guess the type
      if (!targetType && value.constructor !== Object /* && TransformationType === TransformationType.CLASS_TO_PLAIN*/) if (!Array.isArray(value) && value.constructor === Array) {
        // Somebody attempts to convert special Array like object to Array, eg:
        // const evilObject = { '100000000': '100000000', __proto__: [] };
        // This could be used to cause Denial-of-service attack so we don't allow it.
        // See prevent-array-bomb.spec.ts for more details.
      } else {
        // We are good we can use the built-in constructor
        targetType = value.constructor;
      }
      if (!targetType && source) targetType = source.constructor;
      if (this.options.enableCircularCheck) {
        // add transformed type to prevent circular references
        this.recursionStack.add(value);
      }
      var keys = this.getKeys(targetType, value, isMap);
      var newValue = source ? source : {};
      if (!source && (this.transformationType === TransformationType.PLAIN_TO_CLASS || this.transformationType === TransformationType.CLASS_TO_CLASS)) {
        if (isMap) {
          newValue = new Map();
        } else if (targetType) {
          newValue = new targetType();
        } else {
          newValue = {};
        }
      }
      var _loop_1 = function _loop_1(key) {
        if (key === '__proto__' || key === 'constructor') {
          return "continue";
        }
        var valueKey = key;
        var newValueKey = key,
          propertyName = key;
        if (!this_1.options.ignoreDecorators && targetType) {
          if (this_1.transformationType === TransformationType.PLAIN_TO_CLASS) {
            var exposeMetadata = defaultMetadataStorage.findExposeMetadataByCustomName(targetType, key);
            if (exposeMetadata) {
              propertyName = exposeMetadata.propertyName;
              newValueKey = exposeMetadata.propertyName;
            }
          } else if (this_1.transformationType === TransformationType.CLASS_TO_PLAIN || this_1.transformationType === TransformationType.CLASS_TO_CLASS) {
            var exposeMetadata = defaultMetadataStorage.findExposeMetadata(targetType, key);
            if (exposeMetadata && exposeMetadata.options && exposeMetadata.options.name) {
              newValueKey = exposeMetadata.options.name;
            }
          }
        }
        // get a subvalue
        var subValue = undefined;
        if (this_1.transformationType === TransformationType.PLAIN_TO_CLASS) {
          /**
           * This section is added for the following report:
           * https://github.com/typestack/class-transformer/issues/596
           *
           * We should not call functions or constructors when transforming to class.
           */
          subValue = value[valueKey];
        } else {
          if (value instanceof Map) {
            subValue = value.get(valueKey);
          } else if (value[valueKey] instanceof Function) {
            subValue = value[valueKey]();
          } else {
            subValue = value[valueKey];
          }
        }
        // determine a type
        var type = undefined,
          isSubValueMap = subValue instanceof Map;
        if (targetType && isMap) {
          type = targetType;
        } else if (targetType) {
          var metadata_1 = defaultMetadataStorage.findTypeMetadata(targetType, propertyName);
          if (metadata_1) {
            var options = {
              newObject: newValue,
              object: value,
              property: propertyName
            };
            var newType = metadata_1.typeFunction ? metadata_1.typeFunction(options) : metadata_1.reflectedType;
            if (metadata_1.options && metadata_1.options.discriminator && metadata_1.options.discriminator.property && metadata_1.options.discriminator.subTypes) {
              if (!(value[valueKey] instanceof Array)) {
                if (this_1.transformationType === TransformationType.PLAIN_TO_CLASS) {
                  type = metadata_1.options.discriminator.subTypes.find(function (subType) {
                    if (subValue && subValue instanceof Object && metadata_1.options.discriminator.property in subValue) {
                      return subType.name === subValue[metadata_1.options.discriminator.property];
                    }
                  });
                  type === undefined ? type = newType : type = type.value;
                  if (!metadata_1.options.keepDiscriminatorProperty) {
                    if (subValue && subValue instanceof Object && metadata_1.options.discriminator.property in subValue) {
                      delete subValue[metadata_1.options.discriminator.property];
                    }
                  }
                }
                if (this_1.transformationType === TransformationType.CLASS_TO_CLASS) {
                  type = subValue.constructor;
                }
                if (this_1.transformationType === TransformationType.CLASS_TO_PLAIN) {
                  if (subValue) {
                    subValue[metadata_1.options.discriminator.property] = metadata_1.options.discriminator.subTypes.find(function (subType) {
                      return subType.value === subValue.constructor;
                    }).name;
                  }
                }
              } else {
                type = metadata_1;
              }
            } else {
              type = newType;
            }
            isSubValueMap = isSubValueMap || metadata_1.reflectedType === Map;
          } else if (this_1.options.targetMaps) {
            // try to find a type in target maps
            this_1.options.targetMaps.filter(function (map) {
              return map.target === targetType && !!map.properties[propertyName];
            }).forEach(function (map) {
              return type = map.properties[propertyName];
            });
          } else if (this_1.options.enableImplicitConversion && this_1.transformationType === TransformationType.PLAIN_TO_CLASS) {
            // if we have no registererd type via the @Type() decorator then we check if we have any
            // type declarations in reflect-metadata (type declaration is emited only if some decorator is added to the property.)
            var reflectedType = Reflect.getMetadata('design:type', targetType.prototype, propertyName);
            if (reflectedType) {
              type = reflectedType;
            }
          }
        }
        // if value is an array try to get its custom array type
        var arrayType_1 = Array.isArray(value[valueKey]) ? this_1.getReflectedType(targetType, propertyName) : undefined;
        // const subValueKey = TransformationType === TransformationType.PLAIN_TO_CLASS && newKeyName ? newKeyName : key;
        var subSource = source ? source[valueKey] : undefined;
        // if its deserialization then type if required
        // if we uncomment this types like string[] will not work
        // if (this.transformationType === TransformationType.PLAIN_TO_CLASS && !type && subValue instanceof Object && !(subValue instanceof Date))
        //     throw new Error(`Cannot determine type for ${(targetType as any).name }.${propertyName}, did you forget to specify a @Type?`);
        // if newValue is a source object that has method that match newKeyName then skip it
        if (newValue.constructor.prototype) {
          var descriptor = Object.getOwnPropertyDescriptor(newValue.constructor.prototype, newValueKey);
          if ((this_1.transformationType === TransformationType.PLAIN_TO_CLASS || this_1.transformationType === TransformationType.CLASS_TO_CLASS) && (
          // eslint-disable-next-line @typescript-eslint/unbound-method
          descriptor && !descriptor.set || newValue[newValueKey] instanceof Function)) return "continue";
        }
        if (!this_1.options.enableCircularCheck || !this_1.isCircular(subValue)) {
          var transformKey = this_1.transformationType === TransformationType.PLAIN_TO_CLASS ? newValueKey : key;
          var finalValue = void 0;
          if (this_1.transformationType === TransformationType.CLASS_TO_PLAIN) {
            // Get original value
            finalValue = value[transformKey];
            // Apply custom transformation
            finalValue = this_1.applyCustomTransformations(finalValue, targetType, transformKey, value, this_1.transformationType);
            // If nothing change, it means no custom transformation was applied, so use the subValue.
            finalValue = value[transformKey] === finalValue ? subValue : finalValue;
            // Apply the default transformation
            finalValue = this_1.transform(subSource, finalValue, type, arrayType_1, isSubValueMap, level + 1);
          } else {
            if (subValue === undefined && this_1.options.exposeDefaultValues) {
              // Set default value if nothing provided
              finalValue = newValue[newValueKey];
            } else {
              finalValue = this_1.transform(subSource, subValue, type, arrayType_1, isSubValueMap, level + 1);
              finalValue = this_1.applyCustomTransformations(finalValue, targetType, transformKey, value, this_1.transformationType);
            }
          }
          if (finalValue !== undefined || this_1.options.exposeUnsetFields) {
            if (newValue instanceof Map) {
              newValue.set(newValueKey, finalValue);
            } else {
              newValue[newValueKey] = finalValue;
            }
          }
        } else if (this_1.transformationType === TransformationType.CLASS_TO_CLASS) {
          var finalValue = subValue;
          finalValue = this_1.applyCustomTransformations(finalValue, targetType, key, value, this_1.transformationType);
          if (finalValue !== undefined || this_1.options.exposeUnsetFields) {
            if (newValue instanceof Map) {
              newValue.set(newValueKey, finalValue);
            } else {
              newValue[newValueKey] = finalValue;
            }
          }
        }
      };
      var this_1 = this;
      // traverse over keys
      for (var _i = 0, keys_1 = keys; _i < keys_1.length; _i++) {
        var key = keys_1[_i];
        _loop_1(key);
      }
      if (this.options.enableCircularCheck) {
        this.recursionStack.delete(value);
      }
      return newValue;
    } else {
      return value;
    }
  };
  TransformOperationExecutor.prototype.applyCustomTransformations = function (value, target, key, obj, transformationType) {
    var _this = this;
    var metadatas = defaultMetadataStorage.findTransformMetadatas(target, key, this.transformationType);
    // apply versioning options
    if (this.options.version !== undefined) {
      metadatas = metadatas.filter(function (metadata) {
        if (!metadata.options) return true;
        return _this.checkVersion(metadata.options.since, metadata.options.until);
      });
    }
    // apply grouping options
    if (this.options.groups && this.options.groups.length) {
      metadatas = metadatas.filter(function (metadata) {
        if (!metadata.options) return true;
        return _this.checkGroups(metadata.options.groups);
      });
    } else {
      metadatas = metadatas.filter(function (metadata) {
        return !metadata.options || !metadata.options.groups || !metadata.options.groups.length;
      });
    }
    metadatas.forEach(function (metadata) {
      value = metadata.transformFn({
        value: value,
        key: key,
        obj: obj,
        type: transformationType,
        options: _this.options
      });
    });
    return value;
  };
  // preventing circular references
  TransformOperationExecutor.prototype.isCircular = function (object) {
    return this.recursionStack.has(object);
  };
  TransformOperationExecutor.prototype.getReflectedType = function (target, propertyName) {
    if (!target) return undefined;
    var meta = defaultMetadataStorage.findTypeMetadata(target, propertyName);
    return meta ? meta.reflectedType : undefined;
  };
  TransformOperationExecutor.prototype.getKeys = function (target, object, isMap) {
    var _this = this;
    // determine exclusion strategy
    var strategy = defaultMetadataStorage.getStrategy(target);
    if (strategy === 'none') strategy = this.options.strategy || 'exposeAll'; // exposeAll is default strategy
    // get all keys that need to expose
    var keys = [];
    if (strategy === 'exposeAll' || isMap) {
      if (object instanceof Map) {
        keys = Array.from(object.keys());
      } else {
        keys = Object.keys(object);
      }
    }
    if (isMap) {
      // expose & exclude do not apply for map keys only to fields
      return keys;
    }
    /**
     * If decorators are ignored but we don't want the extraneous values, then we use the
     * metadata to decide which property is needed, but doesn't apply the decorator effect.
     */
    if (this.options.ignoreDecorators && this.options.excludeExtraneousValues && target) {
      var exposedProperties = defaultMetadataStorage.getExposedProperties(target, this.transformationType);
      var excludedProperties = defaultMetadataStorage.getExcludedProperties(target, this.transformationType);
      keys = __spreadArray(__spreadArray([], exposedProperties, true), excludedProperties, true);
    }
    if (!this.options.ignoreDecorators && target) {
      // add all exposed to list of keys
      var exposedProperties = defaultMetadataStorage.getExposedProperties(target, this.transformationType);
      if (this.transformationType === TransformationType.PLAIN_TO_CLASS) {
        exposedProperties = exposedProperties.map(function (key) {
          var exposeMetadata = defaultMetadataStorage.findExposeMetadata(target, key);
          if (exposeMetadata && exposeMetadata.options && exposeMetadata.options.name) {
            return exposeMetadata.options.name;
          }
          return key;
        });
      }
      if (this.options.excludeExtraneousValues) {
        keys = exposedProperties;
      } else {
        keys = keys.concat(exposedProperties);
      }
      // exclude excluded properties
      var excludedProperties_1 = defaultMetadataStorage.getExcludedProperties(target, this.transformationType);
      if (excludedProperties_1.length > 0) {
        keys = keys.filter(function (key) {
          return !excludedProperties_1.includes(key);
        });
      }
      // apply versioning options
      if (this.options.version !== undefined) {
        keys = keys.filter(function (key) {
          var exposeMetadata = defaultMetadataStorage.findExposeMetadata(target, key);
          if (!exposeMetadata || !exposeMetadata.options) return true;
          return _this.checkVersion(exposeMetadata.options.since, exposeMetadata.options.until);
        });
      }
      // apply grouping options
      if (this.options.groups && this.options.groups.length) {
        keys = keys.filter(function (key) {
          var exposeMetadata = defaultMetadataStorage.findExposeMetadata(target, key);
          if (!exposeMetadata || !exposeMetadata.options) return true;
          return _this.checkGroups(exposeMetadata.options.groups);
        });
      } else {
        keys = keys.filter(function (key) {
          var exposeMetadata = defaultMetadataStorage.findExposeMetadata(target, key);
          return !exposeMetadata || !exposeMetadata.options || !exposeMetadata.options.groups || !exposeMetadata.options.groups.length;
        });
      }
    }
    // exclude prefixed properties
    if (this.options.excludePrefixes && this.options.excludePrefixes.length) {
      keys = keys.filter(function (key) {
        return _this.options.excludePrefixes.every(function (prefix) {
          return key.substr(0, prefix.length) !== prefix;
        });
      });
    }
    // make sure we have unique keys
    keys = keys.filter(function (key, index, self) {
      return self.indexOf(key) === index;
    });
    return keys;
  };
  TransformOperationExecutor.prototype.checkVersion = function (since, until) {
    var decision = true;
    if (decision && since) decision = this.options.version >= since;
    if (decision && until) decision = this.options.version < until;
    return decision;
  };
  TransformOperationExecutor.prototype.checkGroups = function (groups) {
    if (!groups) return true;
    return this.options.groups.some(function (optionGroup) {
      return groups.includes(optionGroup);
    });
  };
  return TransformOperationExecutor;
}();

;// ./node_modules/class-transformer/esm5/constants/default-options.constant.js
/**
 * These are the default options used by any transformation operation.
 */
var defaultOptions = {
  enableCircularCheck: false,
  enableImplicitConversion: false,
  excludeExtraneousValues: false,
  excludePrefixes: undefined,
  exposeDefaultValues: false,
  exposeUnsetFields: true,
  groups: undefined,
  ignoreDecorators: false,
  strategy: undefined,
  targetMaps: undefined,
  version: undefined
};
;// ./node_modules/class-transformer/esm5/ClassTransformer.js
var __assign = undefined && undefined.__assign || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};



var ClassTransformer = /** @class */function () {
  function ClassTransformer() {}
  ClassTransformer.prototype.instanceToPlain = function (object, options) {
    var executor = new TransformOperationExecutor(TransformationType.CLASS_TO_PLAIN, __assign(__assign({}, defaultOptions), options));
    return executor.transform(undefined, object, undefined, undefined, undefined, undefined);
  };
  ClassTransformer.prototype.classToPlainFromExist = function (object, plainObject, options) {
    var executor = new TransformOperationExecutor(TransformationType.CLASS_TO_PLAIN, __assign(__assign({}, defaultOptions), options));
    return executor.transform(plainObject, object, undefined, undefined, undefined, undefined);
  };
  ClassTransformer.prototype.plainToInstance = function (cls, plain, options) {
    var executor = new TransformOperationExecutor(TransformationType.PLAIN_TO_CLASS, __assign(__assign({}, defaultOptions), options));
    return executor.transform(undefined, plain, cls, undefined, undefined, undefined);
  };
  ClassTransformer.prototype.plainToClassFromExist = function (clsObject, plain, options) {
    var executor = new TransformOperationExecutor(TransformationType.PLAIN_TO_CLASS, __assign(__assign({}, defaultOptions), options));
    return executor.transform(clsObject, plain, undefined, undefined, undefined, undefined);
  };
  ClassTransformer.prototype.instanceToInstance = function (object, options) {
    var executor = new TransformOperationExecutor(TransformationType.CLASS_TO_CLASS, __assign(__assign({}, defaultOptions), options));
    return executor.transform(undefined, object, undefined, undefined, undefined, undefined);
  };
  ClassTransformer.prototype.classToClassFromExist = function (object, fromObject, options) {
    var executor = new TransformOperationExecutor(TransformationType.CLASS_TO_CLASS, __assign(__assign({}, defaultOptions), options));
    return executor.transform(fromObject, object, undefined, undefined, undefined, undefined);
  };
  ClassTransformer.prototype.serialize = function (object, options) {
    return JSON.stringify(this.instanceToPlain(object, options));
  };
  /**
   * Deserializes given JSON string to a object of the given class.
   */
  ClassTransformer.prototype.deserialize = function (cls, json, options) {
    var jsonObject = JSON.parse(json);
    return this.plainToInstance(cls, jsonObject, options);
  };
  /**
   * Deserializes given JSON string to an array of objects of the given class.
   */
  ClassTransformer.prototype.deserializeArray = function (cls, json, options) {
    var jsonObject = JSON.parse(json);
    return this.plainToInstance(cls, jsonObject, options);
  };
  return ClassTransformer;
}();

;// ./node_modules/class-transformer/esm5/index.js





var classTransformer = new ClassTransformer();
function classToPlain(object, options) {
  return classTransformer.instanceToPlain(object, options);
}
function instanceToPlain(object, options) {
  return classTransformer.instanceToPlain(object, options);
}
function classToPlainFromExist(object, plainObject, options) {
  return classTransformer.classToPlainFromExist(object, plainObject, options);
}
function plainToClass(cls, plain, options) {
  return classTransformer.plainToInstance(cls, plain, options);
}
function plainToInstance(cls, plain, options) {
  return classTransformer.plainToInstance(cls, plain, options);
}
function plainToClassFromExist(clsObject, plain, options) {
  return classTransformer.plainToClassFromExist(clsObject, plain, options);
}
function instanceToInstance(object, options) {
  return classTransformer.instanceToInstance(object, options);
}
function classToClassFromExist(object, fromObject, options) {
  return classTransformer.classToClassFromExist(object, fromObject, options);
}
function serialize(object, options) {
  return classTransformer.serialize(object, options);
}
/**
 * Deserializes given JSON string to a object of the given class.
 *
 * @deprecated This function is being removed. Please use the following instead:
 * ```
 * instanceToClass(cls, JSON.parse(json), options)
 * ```
 */
function deserialize(cls, json, options) {
  return classTransformer.deserialize(cls, json, options);
}
/**
 * Deserializes given JSON string to an array of objects of the given class.
 *
 * @deprecated This function is being removed. Please use the following instead:
 * ```
 * JSON.parse(json).map(value => instanceToClass(cls, value, options))
 * ```
 *
 */
function deserializeArray(cls, json, options) {
  return classTransformer.deserializeArray(cls, json, options);
}
;// ./src/app/Fragment.ts
function Fragment_typeof(o) { "@babel/helpers - typeof"; return Fragment_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, Fragment_typeof(o); }
var __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};


var Fragment = /** @class */function () {
  function Fragment() {
    var _this = this;
    this.validateForm = function (form, viewCommand) {
      return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
          switch (_a.label) {
            case 0:
              viewCommand.validateForm(form).tryGetValidateForm();
              return [4 /*yield*/, this.executeCommand(viewCommand)];
            case 1:
              _a.sent();
              return [2 /*return*/, viewCommand.getValidateForm()];
          }
        });
      });
    };
    this.executeCommand = function () {
      var commands = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        commands[_i] = arguments[_i];
      }
      return __awaiter(_this, void 0, void 0, function () {
        var commandArray, resultCommands, i, resultCommand, i, command;
        return __generator(this, function (_a) {
          switch (_a.label) {
            case 0:
              return [4 /*yield*/, this.executeInternalCommand(commands)];
            case 1:
              commandArray = _a.sent();
              resultCommands = JSON.parse(commandArray);
              for (i = 0; i < resultCommands.length; i++) {
                resultCommand = resultCommands[i];
                this.updateCommandReturnValue(resultCommand, commands[i]);
              }
              for (i = 0; i < commands.length; i++) {
                command = commands[i];
                command.markForReset();
              }
              return [2 /*return*/];
          }
        });
      });
    };
    this.startActivity = function (fileName, varExpression, data) {
      return __awaiter(_this, void 0, void 0, function () {
        var result;
        return __generator(this, function (_a) {
          switch (_a.label) {
            case 0:
              return [4 /*yield*/, this.executeStartActivity(fileName, varExpression, data)];
            case 1:
              result = _a.sent();
              return [2 /*return*/, JSON.parse(result)];
          }
        });
      });
    };
  }
  Fragment.prototype.findViewById = function (id, type) {
    return new type(id, undefined, undefined);
  };
  Fragment.prototype.onCreateView = function (obj) {};
  Fragment.prototype.onAttach = function (obj) {};
  Fragment.prototype.onCreate = function (obj) {};
  Fragment.prototype.onResume = function (obj) {};
  Fragment.prototype.onError = function (obj) {};
  Fragment.prototype.onPause = function (obj) {};
  Fragment.prototype.onDestroy = function (obj) {};
  Fragment.prototype.onDetach = function (obj) {};
  Fragment.prototype.onCloseDialog = function (obj) {};
  Fragment.prototype.findViewByPath = function (path, type) {
    return new type(undefined, path, undefined);
  };
  Fragment.prototype.fireEventToWidget = function (event, type) {
    return new type(undefined, undefined, event);
  };
  Fragment.prototype.updateCommandReturnValue = function (obj, source) {
    var _this = this;
    Object.keys(obj).forEach(function (key) {
      if (key == 'layoutParams') {
        _this.updateCommandReturnValue(obj[key], source["layoutParams"]);
      }
      if (key != 'id' && Fragment_typeof(obj[key]) == 'object') {
        var sourceKey = key;
        if (typeof source[key] == 'function') {
          sourceKey = sourceKey + "_";
        }
        source[sourceKey]["commandReturnValue"] = obj[key]["commandReturnValue"];
      }
    });
  };
  Fragment.prototype.executeStartActivity = function (fileName, varExpression, data) {
    return new Promise(function (resolve, reject) {
      navigationManager.startActivity(fileName, varExpression, data, function (result) {
        resolve(result);
      });
    });
  };
  Fragment.prototype.executeInternalCommand = function (commands) {
    return new Promise(function (resolve, reject) {
      coreManager.executeCommand(serialize(commands), function (result) {
        resolve(result);
      });
    });
  };
  Fragment.prototype.getOs = function () {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        return [2 /*return*/, new Promise(function (resolve, reject) {
          coreManager.getOs(function (result) {
            resolve(result);
          });
        })];
      });
    });
  };
  Fragment.prototype.readCdvDataAsString = function (cdvUri) {
    return __awaiter(this, void 0, void 0, function () {
      return __generator(this, function (_a) {
        return [2 /*return*/, new Promise(function (resolve, reject) {
          coreManager.executeSimpleCommand([["readCdvDataAsString", cdvUri]], function (result) {
            resolve(window.atob(result));
          });
        })];
      });
    });
  };
  return Fragment;
}();

function Inject(arg) {
  return function recordInjection(target, decoratedPropertyName) {
    var t = Reflect.getMetadata("design:type", target, decoratedPropertyName);
    if (arg.id) {
      target[decoratedPropertyName] = target.findViewById(arg.id, t);
    } else if (arg.path) {
      target[decoratedPropertyName] = target.findViewByPath(arg.path, t);
    } else if (arg.event) {
      target[decoratedPropertyName] = target.fireEventToWidget(arg.event, t);
    }
  };
}
;// ./src/app/ScopedObject.ts
var ScopedObject = /** @class */function () {
  function ScopedObject(expression, payload) {
    this.expression = expression;
    this.payload = payload;
  }
  return ScopedObject;
}();

;// ./src/navigation/NavController.ts
var NavController_awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var NavController_generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};
var NavController_spreadArray = undefined && undefined.__spreadArray || function (to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};


var NavController = /** @class */function () {
  function NavController() {
    var _this = this;
    this.executeCommand = function () {
      return NavController_awaiter(_this, void 0, void 0, function () {
        var result;
        return NavController_generator(this, function (_a) {
          switch (_a.label) {
            case 0:
              return [4 /*yield*/, this.getExecuteCommandPromise()];
            case 1:
              result = _a.sent();
              return [2 /*return*/, JSON.parse(result)];
          }
        });
      });
    };
    this.commands = [];
  }
  NavController.prototype.reset = function () {
    this.commands = [];
    return this;
  };
  NavController.prototype.popBackStack = function () {
    this.commands.push(["popBackStack"]);
    return this;
  };
  NavController.prototype.popBackStackTo = function (destinationId, inclusive) {
    this.commands.push(["popBackStackTo", destinationId, inclusive]);
    return this;
  };
  NavController.prototype.closeDialog = function () {
    this.commands.push(["closeDialog"]);
    return this;
  };
  NavController.prototype.navigate = function (actionId, varExpression, data) {
    this.navigateTo(actionId, new ScopedObject(varExpression, data));
    return this;
  };
  NavController.prototype.navigateWithPopBackStack = function (actionId) {
    var scopedObjects = [];
    for (var _i = 1; _i < arguments.length; _i++) {
      scopedObjects[_i - 1] = arguments[_i];
    }
    this.commands.push(["navigateWithPopBackStack", actionId, classToPlain(scopedObjects)]);
    return this;
  };
  NavController.prototype.navigateAsTop = function (actionId) {
    var scopedObjects = [];
    for (var _i = 1; _i < arguments.length; _i++) {
      scopedObjects[_i - 1] = arguments[_i];
    }
    this.commands.push(["navigateAsTop", actionId, classToPlain(scopedObjects)]);
    return this;
  };
  NavController.prototype.navigateWithPopBackStackTo = function (actionId, destinationId, inclusive) {
    var scopedObjects = [];
    for (var _i = 3; _i < arguments.length; _i++) {
      scopedObjects[_i - 3] = arguments[_i];
    }
    this.commands.push(["navigateWithPopBackStackTo", actionId, destinationId, inclusive, classToPlain(scopedObjects)]);
    return this;
  };
  NavController.prototype.navigateTo = function (actionId) {
    var scopedObjects = [];
    for (var _i = 1; _i < arguments.length; _i++) {
      scopedObjects[_i - 1] = arguments[_i];
    }
    this.commands.push(["navigate", actionId, classToPlain(scopedObjects)]);
    return this;
  };
  NavController.prototype.getExecuteCommandPromise = function () {
    var _this = this;
    return new Promise(function (resolve, reject) {
      var commands = NavController_spreadArray([], _this.commands, true);
      _this.reset();
      coreManager.navigateCommand(commands, function (result) {
        resolve(result);
      });
    });
  };
  return NavController;
}();

function InjectController(arg) {
  return function recordInjection(target, decoratedPropertyName) {
    var t = Reflect.getMetadata("design:type", target, decoratedPropertyName);
    target[decoratedPropertyName] = new NavController();
  };
}
;// ./src/R/NavGraph.ts
var action_error_to_error_detail = 'action_error_to_error_detail#@layout/error_detail';
var index = 'fragment#index#layout/index.xml';
var error = 'fragment#error#layout/error.xml';
var error_detail = 'fragment#error_detail#layout/error_detail.xml';
;// ./src/ErrorFragment.ts
function ErrorFragment_typeof(o) { "@babel/helpers - typeof"; return ErrorFragment_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, ErrorFragment_typeof(o); }
var __extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : ErrorFragment_typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : ErrorFragment_typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ErrorFragment_awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var ErrorFragment_generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};



var ErrorFragment = /** @class */function (_super) {
  __extends(ErrorFragment, _super);
  function ErrorFragment() {
    var _this = _super.call(this) || this;
    _this.display = function (errorData) {
      return ErrorFragment_awaiter(_this, void 0, void 0, function () {
        return ErrorFragment_generator(this, function (_a) {
          this.navController.navigate(error, "errors->view as list", errorData.errors).executeCommand();
          return [2 /*return*/];
        });
      });
    };
    _this.gotoErrorDetails = function (obj) {
      return ErrorFragment_awaiter(_this, void 0, void 0, function () {
        return ErrorFragment_generator(this, function (_a) {
          switch (_a.label) {
            case 0:
              return [4 /*yield*/, this.navController.navigate(error_detail, "error->view as map", obj.error).executeCommand()];
            case 1:
              _a.sent();
              return [2 /*return*/];
          }
        });
      });
    };
    return _this;
  }
  __decorate([InjectController({}), __metadata("design:type", NavController)], ErrorFragment.prototype, "navController", void 0);
  return ErrorFragment;
}(Fragment);
/* harmony default export */ var src_ErrorFragment = (ErrorFragment);
;// ./src/ErrorDetailFragment.ts
var ErrorDetailFragment_extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();

var ErrorDetailFragment = /** @class */function (_super) {
  ErrorDetailFragment_extends(ErrorDetailFragment, _super);
  function ErrorDetailFragment() {
    return _super.call(this) || this;
  }
  return ErrorDetailFragment;
}(Fragment);
/* harmony default export */ var src_ErrorDetailFragment = (ErrorDetailFragment);
;// ./node_modules/class-transformer/esm5/decorators/transform.decorator.js

/**
 * Defines a custom logic for value transformation.
 *
 * Can be applied to properties only.
 */
function Transform(transformFn, options) {
  if (options === void 0) {
    options = {};
  }
  return function (target, propertyName) {
    defaultMetadataStorage.addTransformMetadata({
      target: target.constructor,
      propertyName: propertyName,
      transformFn: transformFn,
      options: options
    });
  };
}
;// ./src/widget/Transformer.ts
var Transformer = /** @class */function () {
  function Transformer() {}
  Transformer.registerDefaultTransformers = function (regMap) {
    regMap.set('gravity', new GravityTransformer());
  };
  return Transformer;
}();

var GravityTransformer = /** @class */function () {
  function GravityTransformer() {}
  GravityTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var gravityArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "top":
            gravityArr.push("top" /* Gravity.top */);
            break;
          case "bottom":
            gravityArr.push("bottom" /* Gravity.bottom */);
            break;
          case "start":
            gravityArr.push("start" /* Gravity.start */);
            break;
          case "end":
            gravityArr.push("end" /* Gravity.end */);
            break;
          case "right":
            gravityArr.push("right" /* Gravity.right */);
            break;
          case "left":
            gravityArr.push("left" /* Gravity.left */);
            break;
          case "center_horizontal":
            gravityArr.push("center_horizontal" /* Gravity.center_horizontal */);
            break;
          case "center_vertical":
            gravityArr.push("center_vertical" /* Gravity.center_vertical */);
            break;
          case "center":
            gravityArr.push("center" /* Gravity.center */);
            break;
          case "clip_vertical":
            gravityArr.push("clip_vertical" /* Gravity.clip_vertical */);
            break;
          case "center_horizontal":
            gravityArr.push("center_horizontal" /* Gravity.center_horizontal */);
            break;
        }
      }
      return gravityArr;
    }
  };
  return GravityTransformer;
}();
;// ./src/widget/TransformerFactory.ts

var TransformerFactory = /** @class */function () {
  function TransformerFactory() {
    Transformer.registerDefaultTransformers(TransformerFactory.registrationMap);
  }
  TransformerFactory.getInstance = function () {
    return TransformerFactory.transformerFactory;
  };
  TransformerFactory.prototype.register = function (key, transform) {
    TransformerFactory.registrationMap.set(key, transform);
  };
  TransformerFactory.prototype.transform = function (value, obj, type, transformer) {
    var key = transformer;
    if (key != null) {
      var transformer_1 = TransformerFactory.registrationMap.get(key);
      return transformer_1.transform(value, obj, type);
    }
    return value;
  };
  TransformerFactory.registrationMap = new Map();
  TransformerFactory.transformerFactory = new TransformerFactory();
  return TransformerFactory;
}();

;// ./src/widget/CommandAttr.ts
function CommandAttr_typeof(o) { "@babel/helpers - typeof"; return CommandAttr_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, CommandAttr_typeof(o); }
var CommandAttr_decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : CommandAttr_typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var CommandAttr_metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : CommandAttr_typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var CommandAttr = /** @class */function () {
  function CommandAttr() {
    this.setter = false;
    this.getter = false;
    this.type = "attribute";
    this.orderGet = 0;
    this.orderSet = 0;
  }
  CommandAttr.prototype.getChildPath = function () {
    return this.childPath;
  };
  CommandAttr.prototype.setChildPath = function (value) {
    this.childPath = value;
  };
  CommandAttr.prototype.getOrderSet = function () {
    return this.orderGet;
  };
  CommandAttr.prototype.setOrderSet = function (value) {
    this.orderSet = value;
  };
  CommandAttr.prototype.getOrderGet = function () {
    return this.orderGet;
  };
  CommandAttr.prototype.setOrderGet = function (value) {
    this.orderGet = value;
  };
  CommandAttr.prototype.getTransformer = function () {
    return this.transformer;
  };
  CommandAttr.prototype.setTransformer = function (value) {
    this.transformer = value;
  };
  /**
   * Getter value
   * @return {T}
   */
  CommandAttr.prototype.getCommandReturnValue = function () {
    return this.commandReturnValue;
  };
  /**
   * Setter value
   * @param {T} value
   */
  CommandAttr.prototype.setCommandReturnValue = function (value) {
    this.commandReturnValue = value;
  };
  /**
   * Getter value
   * @return {T}
   */
  CommandAttr.prototype.getValue = function () {
    return this.value;
  };
  /**
   * Getter set
   * @return {boolean}
   */
  CommandAttr.prototype.getSetter = function () {
    return this.setter;
  };
  /**
   * Getter get
   * @return {boolean}
   */
  CommandAttr.prototype.getGetter = function () {
    return this.getter;
  };
  /**
   * Setter value
   * @param {T} value
   */
  CommandAttr.prototype.setValue = function (value) {
    this.value = value;
  };
  /**
   * Setter set
   * @param {boolean} value
   */
  CommandAttr.prototype.setSetter = function (value) {
    this.setter = value;
  };
  /**
   * Setter get
   * @param {boolean} value
   */
  CommandAttr.prototype.setGetter = function (value) {
    this.getter = value;
  };
  CommandAttr_decorate([Transform(function (_a) {
    var value = _a.value,
      obj = _a.obj,
      type = _a.type;
    return TransformerFactory.getInstance().transform(value, obj, type, obj.transformer);
  }), CommandAttr_metadata("design:type", Object)], CommandAttr.prototype, "value", void 0);
  return CommandAttr;
}();
/* harmony default export */ var widget_CommandAttr = (CommandAttr);
;// ./node_modules/class-transformer/esm5/decorators/expose.decorator.js

/**
 * Marks the given class or property as included. By default the property is included in both
 * constructorToPlain and plainToConstructor transformations. It can be limited to only one direction
 * via using the `toPlainOnly` or `toClassOnly` option.
 *
 * Can be applied to class definitions and properties.
 */
function Expose(options) {
  if (options === void 0) {
    options = {};
  }
  /**
   * NOTE: The `propertyName` property must be marked as optional because
   * this decorator used both as a class and a property decorator and the
   * Typescript compiler will freak out if we make it mandatory as a class
   * decorator only receives one parameter.
   */
  return function (object, propertyName) {
    defaultMetadataStorage.addExposeMetadata({
      target: object instanceof Function ? object : object.constructor,
      propertyName: propertyName,
      options: options
    });
  };
}
;// ./node_modules/class-transformer/esm5/decorators/type.decorator.js

/**
 * Specifies a type of the property.
 * The given TypeFunction can return a constructor. A discriminator can be given in the options.
 *
 * Can be applied to properties only.
 */
function Type(typeFunction, options) {
  if (options === void 0) {
    options = {};
  }
  return function (target, propertyName) {
    var reflectedType = Reflect.getMetadata('design:type', target, propertyName);
    defaultMetadataStorage.addTypeMetadata({
      target: target.constructor,
      propertyName: propertyName,
      reflectedType: reflectedType,
      typeFunction: typeFunction,
      options: options
    });
  };
}
;// ./node_modules/class-transformer/esm5/decorators/exclude.decorator.js

/**
 * Marks the given class or property as excluded. By default the property is excluded in both
 * constructorToPlain and plainToConstructor transformations. It can be limited to only one direction
 * via using the `toPlainOnly` or `toClassOnly` option.
 *
 * Can be applied to class definitions and properties.
 */
function Exclude(options) {
  if (options === void 0) {
    options = {};
  }
  /**
   * NOTE: The `propertyName` property must be marked as optional because
   * this decorator used both as a class and a property decorator and the
   * Typescript compiler will freak out if we make it mandatory as a class
   * decorator only receives one parameter.
   */
  return function (object, propertyName) {
    defaultMetadataStorage.addExcludeMetadata({
      target: object instanceof Function ? object : object.constructor,
      propertyName: propertyName,
      options: options
    });
  };
}
;// ./node_modules/ts-mixer/dist/esm/index.js
function esm_typeof(o) { "@babel/helpers - typeof"; return esm_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, esm_typeof(o); }
function _construct(t, e, r) { if (_isNativeReflectConstruct()) return Reflect.construct.apply(null, arguments); var o = [null]; o.push.apply(o, e); var p = new (t.bind.apply(t, o))(); return r && _setPrototypeOf(p, r.prototype), p; }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == esm_typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != esm_typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != esm_typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _toConsumableArray(r) { return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArray(r) { if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r); }
function _arrayWithoutHoles(r) { if (Array.isArray(r)) return _arrayLikeToArray(r); }
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
/**
 * Utility function that works like `Object.apply`, but copies getters and setters properly as well.  Additionally gives
 * the option to exclude properties by name.
 */
var copyProps = function copyProps(dest, src) {
  var exclude = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
  var props = Object.getOwnPropertyDescriptors(src);
  var _iterator = _createForOfIteratorHelper(exclude),
    _step;
  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var prop = _step.value;
      delete props[prop];
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  Object.defineProperties(dest, props);
};
/**
 * Returns the full chain of prototypes up until Object.prototype given a starting object.  The order of prototypes will
 * be closest to farthest in the chain.
 */
var _protoChain = function protoChain(obj) {
  var currentChain = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [obj];
  var proto = Object.getPrototypeOf(obj);
  if (proto === null) return currentChain;
  return _protoChain(proto, [].concat(_toConsumableArray(currentChain), [proto]));
};
/**
 * Identifies the nearest ancestor common to all the given objects in their prototype chains.  For most unrelated
 * objects, this function should return Object.prototype.
 */
var nearestCommonProto = function nearestCommonProto() {
  for (var _len = arguments.length, objs = new Array(_len), _key = 0; _key < _len; _key++) {
    objs[_key] = arguments[_key];
  }
  if (objs.length === 0) return undefined;
  var commonProto = undefined;
  var protoChains = objs.map(function (obj) {
    return _protoChain(obj);
  });
  var _loop = function _loop() {
    var protos = protoChains.map(function (protoChain) {
      return protoChain.pop();
    });
    var potentialCommonProto = protos[0];
    if (protos.every(function (proto) {
      return proto === potentialCommonProto;
    })) commonProto = potentialCommonProto;else return 1; // break
  };
  while (protoChains.every(function (protoChain) {
    return protoChain.length > 0;
  })) {
    if (_loop()) break;
  }
  return commonProto;
};
/**
 * Creates a new prototype object that is a mixture of the given prototypes.  The mixing is achieved by first
 * identifying the nearest common ancestor and using it as the prototype for a new object.  Then all properties/methods
 * downstream of this prototype (ONLY downstream) are copied into the new object.
 *
 * The resulting prototype is more performant than softMixProtos(...), as well as ES5 compatible.  However, it's not as
 * flexible as updates to the source prototypes aren't captured by the mixed result.  See softMixProtos for why you may
 * want to use that instead.
 */
var hardMixProtos = function hardMixProtos(ingredients, constructor) {
  var exclude = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
  var _a;
  var base = (_a = nearestCommonProto.apply(void 0, _toConsumableArray(ingredients))) !== null && _a !== void 0 ? _a : Object.prototype;
  var mixedProto = Object.create(base);
  // Keeps track of prototypes we've already visited to avoid copying the same properties multiple times.  We init the
  // list with the proto chain below the nearest common ancestor because we don't want any of those methods mixed in
  // when they will already be accessible via prototype access.
  var visitedProtos = _protoChain(base);
  var _iterator2 = _createForOfIteratorHelper(ingredients),
    _step2;
  try {
    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
      var prototype = _step2.value;
      var protos = _protoChain(prototype);
      // Apply the prototype chain in reverse order so that old methods don't override newer ones.
      for (var i = protos.length - 1; i >= 0; i--) {
        var newProto = protos[i];
        if (visitedProtos.indexOf(newProto) === -1) {
          copyProps(mixedProto, newProto, ['constructor'].concat(_toConsumableArray(exclude)));
          visitedProtos.push(newProto);
        }
      }
    }
  } catch (err) {
    _iterator2.e(err);
  } finally {
    _iterator2.f();
  }
  mixedProto.constructor = constructor;
  return mixedProto;
};
var unique = function unique(arr) {
  return arr.filter(function (e, i) {
    return arr.indexOf(e) == i;
  });
};

/**
 * Finds the ingredient with the given prop, searching in reverse order and breadth-first if searching ingredient
 * prototypes is required.
 */
var getIngredientWithProp = function getIngredientWithProp(prop, ingredients) {
  var protoChains = ingredients.map(function (ingredient) {
    return _protoChain(ingredient);
  });
  // since we search breadth-first, we need to keep track of our depth in the prototype chains
  var protoDepth = 0;
  // not all prototype chains are the same depth, so this remains true as long as at least one of the ingredients'
  // prototype chains has an object at this depth
  var protosAreLeftToSearch = true;
  while (protosAreLeftToSearch) {
    // with the start of each horizontal slice, we assume this is the one that's deeper than any of the proto chains
    protosAreLeftToSearch = false;
    // scan through the ingredients right to left
    for (var i = ingredients.length - 1; i >= 0; i--) {
      var searchTarget = protoChains[i][protoDepth];
      if (searchTarget !== undefined && searchTarget !== null) {
        // if we find something, this is proof that this horizontal slice potentially more objects to search
        protosAreLeftToSearch = true;
        // eureka, we found it
        if (Object.getOwnPropertyDescriptor(searchTarget, prop) != undefined) {
          return protoChains[i][0];
        }
      }
    }
    protoDepth++;
  }
  return undefined;
};
/**
 * "Mixes" ingredients by wrapping them in a Proxy.  The optional prototype argument allows the mixed object to sit
 * downstream of an existing prototype chain.  Note that "properties" cannot be added, deleted, or modified.
 */
var proxyMix = function proxyMix(ingredients) {
  var prototype = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : Object.prototype;
  return new Proxy({}, {
    getPrototypeOf: function getPrototypeOf() {
      return prototype;
    },
    setPrototypeOf: function setPrototypeOf() {
      throw Error('Cannot set prototype of Proxies created by ts-mixer');
    },
    getOwnPropertyDescriptor: function getOwnPropertyDescriptor(_, prop) {
      return Object.getOwnPropertyDescriptor(getIngredientWithProp(prop, ingredients) || {}, prop);
    },
    defineProperty: function defineProperty() {
      throw new Error('Cannot define new properties on Proxies created by ts-mixer');
    },
    has: function has(_, prop) {
      return getIngredientWithProp(prop, ingredients) !== undefined || prototype[prop] !== undefined;
    },
    get: function get(_, prop) {
      return (getIngredientWithProp(prop, ingredients) || prototype)[prop];
    },
    set: function set(_, prop, val) {
      var ingredientWithProp = getIngredientWithProp(prop, ingredients);
      if (ingredientWithProp === undefined) throw new Error('Cannot set new properties on Proxies created by ts-mixer');
      ingredientWithProp[prop] = val;
      return true;
    },
    deleteProperty: function deleteProperty() {
      throw new Error('Cannot delete properties on Proxies created by ts-mixer');
    },
    ownKeys: function ownKeys() {
      return ingredients.map(Object.getOwnPropertyNames).reduce(function (prev, curr) {
        return curr.concat(prev.filter(function (key) {
          return curr.indexOf(key) < 0;
        }));
      });
    }
  });
};
/**
 * Creates a new proxy-prototype object that is a "soft" mixture of the given prototypes.  The mixing is achieved by
 * proxying all property access to the ingredients.  This is not ES5 compatible and less performant.  However, any
 * changes made to the source prototypes will be reflected in the proxy-prototype, which may be desirable.
 */
var softMixProtos = function softMixProtos(ingredients, constructor) {
  return proxyMix([].concat(_toConsumableArray(ingredients), [{
    constructor: constructor
  }]));
};
var settings = {
  initFunction: null,
  staticsStrategy: 'copy',
  prototypeStrategy: 'copy',
  decoratorInheritance: 'deep'
};

// Keeps track of constituent classes for every mixin class created by ts-mixer.
var mixins = new Map();
var getMixinsForClass = function getMixinsForClass(clazz) {
  return mixins.get(clazz);
};
var registerMixins = function registerMixins(mixedClass, constituents) {
  return mixins.set(mixedClass, constituents);
};
var hasMixin = function hasMixin(instance, mixin) {
  if (instance instanceof mixin) return true;
  var constructor = instance.constructor;
  var visited = new Set();
  var frontier = new Set();
  frontier.add(constructor);
  var _loop2 = function _loop2() {
      // check if the frontier has the mixin we're looking for.  if not, we can say we visited every item in the frontier
      if (frontier.has(mixin)) return {
        v: true
      };
      frontier.forEach(function (item) {
        return visited.add(item);
      });
      // build a new frontier based on the associated mixin classes and prototype chains of each frontier item
      var newFrontier = new Set();
      frontier.forEach(function (item) {
        var _a;
        var itemConstituents = (_a = mixins.get(item)) !== null && _a !== void 0 ? _a : _protoChain(item.prototype).map(function (proto) {
          return proto.constructor;
        }).filter(function (item) {
          return item !== null;
        });
        if (itemConstituents) itemConstituents.forEach(function (constituent) {
          if (!visited.has(constituent) && !frontier.has(constituent)) newFrontier.add(constituent);
        });
      });
      // we have a new frontier, now search again
      frontier = newFrontier;
    },
    _ret;
  while (frontier.size > 0) {
    _ret = _loop2();
    if (_ret) return _ret.v;
  }
  // if we get here, we couldn't find the mixin anywhere in the prototype chain or associated mixin classes
  return false;
};
var mergeObjectsOfDecorators = function mergeObjectsOfDecorators(o1, o2) {
  var _a, _b;
  var allKeys = unique([].concat(_toConsumableArray(Object.getOwnPropertyNames(o1)), _toConsumableArray(Object.getOwnPropertyNames(o2))));
  var mergedObject = {};
  var _iterator3 = _createForOfIteratorHelper(allKeys),
    _step3;
  try {
    for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
      var key = _step3.value;
      mergedObject[key] = unique([].concat(_toConsumableArray((_a = o1 === null || o1 === void 0 ? void 0 : o1[key]) !== null && _a !== void 0 ? _a : []), _toConsumableArray((_b = o2 === null || o2 === void 0 ? void 0 : o2[key]) !== null && _b !== void 0 ? _b : [])));
    }
  } catch (err) {
    _iterator3.e(err);
  } finally {
    _iterator3.f();
  }
  return mergedObject;
};
var mergePropertyAndMethodDecorators = function mergePropertyAndMethodDecorators(d1, d2) {
  var _a, _b, _c, _d;
  return {
    property: mergeObjectsOfDecorators((_a = d1 === null || d1 === void 0 ? void 0 : d1.property) !== null && _a !== void 0 ? _a : {}, (_b = d2 === null || d2 === void 0 ? void 0 : d2.property) !== null && _b !== void 0 ? _b : {}),
    method: mergeObjectsOfDecorators((_c = d1 === null || d1 === void 0 ? void 0 : d1.method) !== null && _c !== void 0 ? _c : {}, (_d = d2 === null || d2 === void 0 ? void 0 : d2.method) !== null && _d !== void 0 ? _d : {})
  };
};
var mergeDecorators = function mergeDecorators(d1, d2) {
  var _a, _b, _c, _d, _e, _f;
  return {
    class: unique([].concat(_toConsumableArray((_a = d1 === null || d1 === void 0 ? void 0 : d1.class) !== null && _a !== void 0 ? _a : []), _toConsumableArray((_b = d2 === null || d2 === void 0 ? void 0 : d2.class) !== null && _b !== void 0 ? _b : []))),
    static: mergePropertyAndMethodDecorators((_c = d1 === null || d1 === void 0 ? void 0 : d1.static) !== null && _c !== void 0 ? _c : {}, (_d = d2 === null || d2 === void 0 ? void 0 : d2.static) !== null && _d !== void 0 ? _d : {}),
    instance: mergePropertyAndMethodDecorators((_e = d1 === null || d1 === void 0 ? void 0 : d1.instance) !== null && _e !== void 0 ? _e : {}, (_f = d2 === null || d2 === void 0 ? void 0 : d2.instance) !== null && _f !== void 0 ? _f : {})
  };
};
var decorators = new Map();
var findAllConstituentClasses = function findAllConstituentClasses() {
  var _a;
  var allClasses = new Set();
  for (var _len2 = arguments.length, classes = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    classes[_key2] = arguments[_key2];
  }
  var frontier = new Set([].concat(classes));
  while (frontier.size > 0) {
    var _iterator4 = _createForOfIteratorHelper(frontier),
      _step4;
    try {
      for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
        var clazz = _step4.value;
        var protoChainClasses = _protoChain(clazz.prototype).map(function (proto) {
          return proto.constructor;
        });
        var mixinClasses = (_a = getMixinsForClass(clazz)) !== null && _a !== void 0 ? _a : [];
        var potentiallyNewClasses = [].concat(_toConsumableArray(protoChainClasses), _toConsumableArray(mixinClasses));
        var newClasses = potentiallyNewClasses.filter(function (c) {
          return !allClasses.has(c);
        });
        var _iterator5 = _createForOfIteratorHelper(newClasses),
          _step5;
        try {
          for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
            var newClass = _step5.value;
            frontier.add(newClass);
          }
        } catch (err) {
          _iterator5.e(err);
        } finally {
          _iterator5.f();
        }
        allClasses.add(clazz);
        frontier.delete(clazz);
      }
    } catch (err) {
      _iterator4.e(err);
    } finally {
      _iterator4.f();
    }
  }
  return _toConsumableArray(allClasses);
};
var deepDecoratorSearch = function deepDecoratorSearch() {
  var decoratorsForClassChain = findAllConstituentClasses.apply(void 0, arguments).map(function (clazz) {
    return decorators.get(clazz);
  }).filter(function (decorators) {
    return !!decorators;
  });
  if (decoratorsForClassChain.length == 0) return {};
  if (decoratorsForClassChain.length == 1) return decoratorsForClassChain[0];
  return decoratorsForClassChain.reduce(function (d1, d2) {
    return mergeDecorators(d1, d2);
  });
};
var directDecoratorSearch = function directDecoratorSearch() {
  for (var _len3 = arguments.length, classes = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
    classes[_key3] = arguments[_key3];
  }
  var classDecorators = classes.map(function (clazz) {
    return getDecoratorsForClass(clazz);
  });
  if (classDecorators.length === 0) return {};
  if (classDecorators.length === 1) return classDecorators[1];
  return classDecorators.reduce(function (d1, d2) {
    return mergeDecorators(d1, d2);
  });
};
var getDecoratorsForClass = function getDecoratorsForClass(clazz) {
  var decoratorsForClass = decorators.get(clazz);
  if (!decoratorsForClass) {
    decoratorsForClass = {};
    decorators.set(clazz, decoratorsForClass);
  }
  return decoratorsForClass;
};
var decorateClass = function decorateClass(decorator) {
  return function (clazz) {
    var decoratorsForClass = getDecoratorsForClass(clazz);
    var classDecorators = decoratorsForClass.class;
    if (!classDecorators) {
      classDecorators = [];
      decoratorsForClass.class = classDecorators;
    }
    classDecorators.push(decorator);
    return decorator(clazz);
  };
};
var decorateMember = function decorateMember(decorator) {
  return function (object, key) {
    var decoratorTargetType = typeof object === 'function' ? 'static' : 'instance';
    var decoratorType = typeof object[key] === 'function' ? 'method' : 'property';
    var clazz = decoratorTargetType === 'static' ? object : object.constructor;
    var decoratorsForClass = getDecoratorsForClass(clazz);
    var decoratorsForTargetType = decoratorsForClass === null || decoratorsForClass === void 0 ? void 0 : decoratorsForClass[decoratorTargetType];
    if (!decoratorsForTargetType) {
      decoratorsForTargetType = {};
      decoratorsForClass[decoratorTargetType] = decoratorsForTargetType;
    }
    var decoratorsForType = decoratorsForTargetType === null || decoratorsForTargetType === void 0 ? void 0 : decoratorsForTargetType[decoratorType];
    if (!decoratorsForType) {
      decoratorsForType = {};
      decoratorsForTargetType[decoratorType] = decoratorsForType;
    }
    var decoratorsForKey = decoratorsForType === null || decoratorsForType === void 0 ? void 0 : decoratorsForType[key];
    if (!decoratorsForKey) {
      decoratorsForKey = [];
      decoratorsForType[key] = decoratorsForKey;
    }
    decoratorsForKey.push(decorator);
    // @ts-ignore
    for (var _len4 = arguments.length, otherArgs = new Array(_len4 > 2 ? _len4 - 2 : 0), _key4 = 2; _key4 < _len4; _key4++) {
      otherArgs[_key4 - 2] = arguments[_key4];
    }
    return decorator.apply(void 0, [object, key].concat(otherArgs));
  };
};
var decorate = function decorate(decorator) {
  return function () {
    if (arguments.length === 1) return decorateClass(decorator)(arguments.length <= 0 ? undefined : arguments[0]);
    return decorateMember(decorator).apply(void 0, arguments);
  };
};
function Mixin() {
  for (var _len5 = arguments.length, constructors = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
    constructors[_key5] = arguments[_key5];
  }
  var _a, _b, _c;
  var prototypes = constructors.map(function (constructor) {
    return constructor.prototype;
  });
  // Here we gather up the init functions of the ingredient prototypes, combine them into one init function, and
  // attach it to the mixed class prototype.  The reason we do this is because we want the init functions to mix
  // similarly to constructors -- not methods, which simply override each other.
  var initFunctionName = settings.initFunction;
  if (initFunctionName !== null) {
    var initFunctions = prototypes.map(function (proto) {
      return proto[initFunctionName];
    }).filter(function (func) {
      return typeof func === 'function';
    });
    var combinedInitFunction = function combinedInitFunction() {
      for (var _len6 = arguments.length, args = new Array(_len6), _key6 = 0; _key6 < _len6; _key6++) {
        args[_key6] = arguments[_key6];
      }
      var _iterator6 = _createForOfIteratorHelper(initFunctions),
        _step6;
      try {
        for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
          var initFunction = _step6.value;
          initFunction.apply(this, args);
        }
      } catch (err) {
        _iterator6.e(err);
      } finally {
        _iterator6.f();
      }
    };
    var extraProto = _defineProperty({}, initFunctionName, combinedInitFunction);
    prototypes.push(extraProto);
  }
  function MixedClass() {
    for (var _len7 = arguments.length, args = new Array(_len7), _key7 = 0; _key7 < _len7; _key7++) {
      args[_key7] = arguments[_key7];
    }
    var _iterator7 = _createForOfIteratorHelper(constructors),
      _step7;
    try {
      for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
        var constructor = _step7.value;
        copyProps(this, _construct(constructor, args));
      }
    } catch (err) {
      _iterator7.e(err);
    } finally {
      _iterator7.f();
    }
    if (initFunctionName !== null && typeof this[initFunctionName] === 'function') this[initFunctionName].apply(this, args);
  }
  MixedClass.prototype = settings.prototypeStrategy === 'copy' ? hardMixProtos(prototypes, MixedClass) : softMixProtos(prototypes, MixedClass);
  Object.setPrototypeOf(MixedClass, settings.staticsStrategy === 'copy' ? hardMixProtos(constructors, null, ['prototype']) : proxyMix(constructors, Function.prototype));
  var DecoratedMixedClass = MixedClass;
  if (settings.decoratorInheritance !== 'none') {
    var classDecorators = settings.decoratorInheritance === 'deep' ? deepDecoratorSearch.apply(void 0, constructors) : directDecoratorSearch.apply(void 0, constructors);
    var _iterator8 = _createForOfIteratorHelper((_a = classDecorators === null || classDecorators === void 0 ? void 0 : classDecorators.class) !== null && _a !== void 0 ? _a : []),
      _step8;
    try {
      for (_iterator8.s(); !(_step8 = _iterator8.n()).done;) {
        var decorator = _step8.value;
        DecoratedMixedClass = decorator(DecoratedMixedClass);
      }
    } catch (err) {
      _iterator8.e(err);
    } finally {
      _iterator8.f();
    }
    applyPropAndMethodDecorators((_b = classDecorators === null || classDecorators === void 0 ? void 0 : classDecorators.static) !== null && _b !== void 0 ? _b : {}, DecoratedMixedClass);
    applyPropAndMethodDecorators((_c = classDecorators === null || classDecorators === void 0 ? void 0 : classDecorators.instance) !== null && _c !== void 0 ? _c : {}, DecoratedMixedClass.prototype);
  }
  registerMixins(DecoratedMixedClass, constructors);
  return DecoratedMixedClass;
}
var applyPropAndMethodDecorators = function applyPropAndMethodDecorators(propAndMethodDecorators, target) {
  var propDecorators = propAndMethodDecorators.property;
  var methodDecorators = propAndMethodDecorators.method;
  if (propDecorators) for (var key in propDecorators) {
    var _iterator9 = _createForOfIteratorHelper(propDecorators[key]),
      _step9;
    try {
      for (_iterator9.s(); !(_step9 = _iterator9.n()).done;) {
        var decorator = _step9.value;
        decorator(target, key);
      }
    } catch (err) {
      _iterator9.e(err);
    } finally {
      _iterator9.f();
    }
  }
  if (methodDecorators) for (var _key8 in methodDecorators) {
    var _iterator0 = _createForOfIteratorHelper(methodDecorators[_key8]),
      _step0;
    try {
      for (_iterator0.s(); !(_step0 = _iterator0.n()).done;) {
        var _decorator = _step0.value;
        _decorator(target, _key8, Object.getOwnPropertyDescriptor(target, _key8));
      }
    } catch (err) {
      _iterator0.e(err);
    } finally {
      _iterator0.f();
    }
  }
};
/**
 * A decorator version of the `Mixin` function.  You'll want to use this instead of `Mixin` for mixing generic classes.
 */
var mix = function mix() {
  for (var _len8 = arguments.length, ingredients = new Array(_len8), _key9 = 0; _key9 < _len8; _key9++) {
    ingredients[_key9] = arguments[_key9];
  }
  return function (decoratedClass) {
    // @ts-ignore
    var mixedClass = Mixin.apply(void 0, _toConsumableArray(ingredients.concat([decoratedClass])));
    Object.defineProperty(mixedClass, 'name', {
      value: decoratedClass.name,
      writable: false
    });
    return mixedClass;
  };
};

;// ./src/android/widget/ViewImpl.ts
function ViewImpl_typeof(o) { "@babel/helpers - typeof"; return ViewImpl_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, ViewImpl_typeof(o); }
// start - imports
var ViewImpl_extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var ViewImpl_decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : ViewImpl_typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ViewImpl_metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : ViewImpl_typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var ImportantForAutofillTransformer = /** @class */function () {
  function ImportantForAutofillTransformer() {}
  ImportantForAutofillTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "auto":
            valueArr.push("auto" /* ImportantForAutofill.auto */);
            break;
          case "no":
            valueArr.push("no" /* ImportantForAutofill.no */);
            break;
          case "noExcludeDescendants":
            valueArr.push("noExcludeDescendants" /* ImportantForAutofill.noExcludeDescendants */);
            break;
          case "yes":
            valueArr.push("yes" /* ImportantForAutofill.yes */);
            break;
          case "yesExcludeDescendants":
            valueArr.push("yesExcludeDescendants" /* ImportantForAutofill.yesExcludeDescendants */);
            break;
        }
      }
      return valueArr;
    }
  };
  return ImportantForAutofillTransformer;
}();

var ScrollIndicatorsTransformer = /** @class */function () {
  function ScrollIndicatorsTransformer() {}
  ScrollIndicatorsTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "bottom":
            valueArr.push("bottom" /* ScrollIndicators.bottom */);
            break;
          case "end":
            valueArr.push("end" /* ScrollIndicators.end */);
            break;
          case "left":
            valueArr.push("left" /* ScrollIndicators.left */);
            break;
          case "none":
            valueArr.push("none" /* ScrollIndicators.none */);
            break;
          case "right":
            valueArr.push("right" /* ScrollIndicators.right */);
            break;
          case "start":
            valueArr.push("start" /* ScrollIndicators.start */);
            break;
          case "top":
            valueArr.push("top" /* ScrollIndicators.top */);
            break;
        }
      }
      return valueArr;
    }
  };
  return ScrollIndicatorsTransformer;
}();

var RequiresFadingEdgeTransformer = /** @class */function () {
  function RequiresFadingEdgeTransformer() {}
  RequiresFadingEdgeTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "horizontal":
            valueArr.push("horizontal" /* RequiresFadingEdge.horizontal */);
            break;
          case "none":
            valueArr.push("none" /* RequiresFadingEdge.none */);
            break;
          case "vertical":
            valueArr.push("vertical" /* RequiresFadingEdge.vertical */);
            break;
        }
      }
      return valueArr;
    }
  };
  return RequiresFadingEdgeTransformer;
}();

var ViewImpl_performHapticFeedbackWithFlags = /** @class */function () {
  function ViewImpl_performHapticFeedbackWithFlags() {}
  ViewImpl_decorate([decorate(Expose({
    name: "value"
  })), ViewImpl_metadata("design:type", String)], ViewImpl_performHapticFeedbackWithFlags.prototype, "value", void 0);
  ViewImpl_decorate([decorate(Expose({
    name: "flags"
  })), decorate(Transform(function (_a) {
    var value = _a.value,
      obj = _a.obj,
      type = _a.type;
    return TransformerFactory.getInstance().transform(value, obj, type, "HapticFeedbackConstantsFlag");
  })), ViewImpl_metadata("design:type", Array)], ViewImpl_performHapticFeedbackWithFlags.prototype, "flags", void 0);
  return ViewImpl_performHapticFeedbackWithFlags;
}();

var HapticFeedbackConstantsFlagTransformer = /** @class */function () {
  function HapticFeedbackConstantsFlagTransformer() {}
  HapticFeedbackConstantsFlagTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "FLAG_IGNORE_VIEW_SETTING":
            valueArr.push("FLAG_IGNORE_VIEW_SETTING" /* HapticFeedbackConstantsFlag.FLAG_IGNORE_VIEW_SETTING */);
            break;
          case "FLAG_IGNORE_GLOBAL_SETTING":
            valueArr.push("FLAG_IGNORE_GLOBAL_SETTING" /* HapticFeedbackConstantsFlag.FLAG_IGNORE_GLOBAL_SETTING */);
            break;
        }
      }
      return valueArr;
    }
  };
  return HapticFeedbackConstantsFlagTransformer;
}();

var ValidationErrorDisplayTransformer = /** @class */function () {
  function ValidationErrorDisplayTransformer() {}
  ValidationErrorDisplayTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "popup":
            valueArr.push("popup" /* ValidationErrorDisplay.popup */);
            break;
          case "label":
            valueArr.push("label" /* ValidationErrorDisplay.label */);
            break;
          case "style":
            valueArr.push("style" /* ValidationErrorDisplay.style */);
            break;
        }
      }
      return valueArr;
    }
  };
  return ValidationErrorDisplayTransformer;
}();

// end - imports
var ViewImpl = /** @class */function () {
  function ViewImpl(id, paths, event) {
    this.orderGet = 0;
    this.orderSet = 0;
    this.flush = false;
    this.id = id;
    this.paths = paths;
    this.event = event;
    this.thisPointer = this.getThisPointer();
    this.layoutParams = undefined;
  }
  //start - body
  ViewImpl.initialize = function () {
    TransformerFactory.getInstance().register("importantForAutofill", new ImportantForAutofillTransformer());
    TransformerFactory.getInstance().register("scrollIndicators", new ScrollIndicatorsTransformer());
    TransformerFactory.getInstance().register("requiresFadingEdge", new RequiresFadingEdgeTransformer());
    TransformerFactory.getInstance().register("HapticFeedbackConstantsFlag", new HapticFeedbackConstantsFlagTransformer());
    TransformerFactory.getInstance().register("validationErrorDisplay", new ValidationErrorDisplayTransformer());
  };
  ViewImpl.prototype.markForReset = function () {
    this.flush = true;
  };
  ViewImpl.prototype.resetIfRequired = function () {
    if (this.flush) {
      this.reset();
    }
  };
  ViewImpl.prototype.reset = function () {
    this.accessibilityHeading = undefined;
    this.accessibilityLiveRegion = undefined;
    this.accessibilityPaneTitle = undefined;
    this.accessibilityTraversalAfter = undefined;
    this.accessibilityTraversalBefore = undefined;
    this.alpha = undefined;
    this.autofillHints = undefined;
    this.backgroundTint = undefined;
    this.backgroundTintMode = undefined;
    this.clickable = undefined;
    this.contentDescription = undefined;
    this.contextClickable = undefined;
    this.defaultFocusHighlightEnabled = undefined;
    this.duplicateParentState = undefined;
    this.elevation = undefined;
    this.fadeScrollbars = undefined;
    this.fadingEdgeLength = undefined;
    this.filterTouchesWhenObscured = undefined;
    this.fitsSystemWindows = undefined;
    this.focusableInTouchMode = undefined;
    this.focusedByDefault = undefined;
    this.forceHasOverlappingRendering = undefined;
    this.foregroundTint = undefined;
    this.foregroundTintMode = undefined;
    this.hapticFeedbackEnabled = undefined;
    this.importantForAccessibility = undefined;
    this.importantForAutofill = undefined;
    this.isScrollContainer = undefined;
    this.keepScreenOn = undefined;
    this.keyboardNavigationCluster = undefined;
    this.layoutDirection = undefined;
    this.longClickable = undefined;
    this.minHeight = undefined;
    this.minWidth = undefined;
    this.nextClusterForward = undefined;
    this.nextFocusDown = undefined;
    this.nextFocusForward = undefined;
    this.nextFocusLeft = undefined;
    this.nextFocusRight = undefined;
    this.nextFocusUp = undefined;
    this.rotation = undefined;
    this.rotationX = undefined;
    this.rotationY = undefined;
    this.saveEnabled = undefined;
    this.scaleX = undefined;
    this.scaleY = undefined;
    this.screenReaderFocusable = undefined;
    this.scrollIndicators = undefined;
    this.scrollbarDefaultDelayBeforeFade = undefined;
    this.scrollbarFadeDuration = undefined;
    this.scrollbarSize = undefined;
    this.scrollbarStyle = undefined;
    this.soundEffectsEnabled = undefined;
    this.textAlignment = undefined;
    this.textDirection = undefined;
    this.tooltipText = undefined;
    this.transformPivotX = undefined;
    this.transformPivotY = undefined;
    this.transitionName = undefined;
    this.translationX = undefined;
    this.translationY = undefined;
    this.translationZ = undefined;
    this.visibility = undefined;
    this.onApplyWindowInsets = undefined;
    this.onCapturedPointer = undefined;
    this.onClick = undefined;
    this.onContextClick = undefined;
    this.onCreateContextMenu = undefined;
    this.onDrag = undefined;
    this.onFocusChange = undefined;
    this.onGenericMotion = undefined;
    this.onHover = undefined;
    this.onKey = undefined;
    this.onLongClick = undefined;
    this.onScrollChange = undefined;
    this.onSystemUiVisibilityChange = undefined;
    this.onTouch = undefined;
    this.padding = undefined;
    this.paddingTop = undefined;
    this.paddingBottom = undefined;
    this.paddingLeft = undefined;
    this.paddingRight = undefined;
    this.paddingStart = undefined;
    this.paddingEnd = undefined;
    this.paddingHorizontal = undefined;
    this.paddingVertical = undefined;
    this.layerType = undefined;
    this.requiresFadingEdge = undefined;
    this.background = undefined;
    this.foreground = undefined;
    this.backgroundRepeat = undefined;
    this.modelSyncEvents = undefined;
    this.updateModelData_ = undefined;
    this.notifyDataSetChanged_ = undefined;
    this.modelParam = undefined;
    this.modelPojoToUi = undefined;
    this.modelUiToPojo = undefined;
    this.modelPojoToUiParams = undefined;
    this.refreshUiFromModel_ = undefined;
    this.modelUiToPojoEventIds = undefined;
    this.foregroundRepeat = undefined;
    this.foregroundGravity = undefined;
    this.performHapticFeedback_ = undefined;
    this.performHapticFeedbackWithFlags_ = undefined;
    this.attributeUnderTest = undefined;
    this.selected = undefined;
    this.enabled = undefined;
    this.focusable = undefined;
    this.scrollX = undefined;
    this.scrollY = undefined;
    this.invalidate_ = undefined;
    this.requestLayout_ = undefined;
    this.asDragSource = undefined;
    this.zIndex = undefined;
    this.maxWidth = undefined;
    this.maxHeight = undefined;
    this.style = undefined;
    this.errorStyle = undefined;
    this.validateForm_ = undefined;
    this.validation = undefined;
    this.v_required = undefined;
    this.v_minlength = undefined;
    this.v_maxlength = undefined;
    this.v_min = undefined;
    this.v_max = undefined;
    this.v_pattern = undefined;
    this.v_type = undefined;
    this.validationErrorDisplayType = undefined;
    this.customErrorMessageValues = undefined;
    this.customErrorMessageKeys = undefined;
    this.invalidateOnFrameChange = undefined;
    this.onSwiped = undefined;
    this.animatorXml_ = undefined;
    this.startAnimator_ = undefined;
    this.endAnimator_ = undefined;
    this.onAnimationStart = undefined;
    this.onAnimationEnd = undefined;
    this.onAnimationCancel = undefined;
    this.onAnimationRepeat = undefined;
    this.left = undefined;
    this.right = undefined;
    this.top = undefined;
    this.bottom = undefined;
    this.outlineAmbientShadowColor = undefined;
    this.outlineSpotShadowColor = undefined;
    this.cornerRadius = undefined;
    this.orderGet = 0;
    this.orderSet = 0;
    this.flush = false;
    return this.thisPointer;
  };
  ViewImpl.prototype.setLayoutParams = function (layoutParams) {
    this.resetIfRequired();
    this.layoutParams = layoutParams;
  };
  ViewImpl.prototype.getLayoutParams = function () {
    return this.layoutParams;
  };
  ViewImpl.prototype.tryGetAccessibilityHeading = function () {
    this.resetIfRequired();
    if (this.accessibilityHeading == null || this.accessibilityHeading == undefined) {
      this.accessibilityHeading = new widget_CommandAttr();
    }
    this.accessibilityHeading.setGetter(true);
    this.orderGet++;
    this.accessibilityHeading.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isAccessibilityHeading = function () {
    if (this.accessibilityHeading == null || this.accessibilityHeading == undefined) {
      this.accessibilityHeading = new widget_CommandAttr();
    }
    return this.accessibilityHeading.getCommandReturnValue();
  };
  ViewImpl.prototype.setAccessibilityHeading = function (value) {
    this.resetIfRequired();
    if (this.accessibilityHeading == null || this.accessibilityHeading == undefined) {
      this.accessibilityHeading = new widget_CommandAttr();
    }
    this.accessibilityHeading.setSetter(true);
    this.accessibilityHeading.setValue(value);
    this.orderSet++;
    this.accessibilityHeading.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetAccessibilityLiveRegion = function () {
    this.resetIfRequired();
    if (this.accessibilityLiveRegion == null || this.accessibilityLiveRegion == undefined) {
      this.accessibilityLiveRegion = new widget_CommandAttr();
    }
    this.accessibilityLiveRegion.setGetter(true);
    this.orderGet++;
    this.accessibilityLiveRegion.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getAccessibilityLiveRegion = function () {
    if (this.accessibilityLiveRegion == null || this.accessibilityLiveRegion == undefined) {
      this.accessibilityLiveRegion = new widget_CommandAttr();
    }
    return this.accessibilityLiveRegion.getCommandReturnValue();
  };
  ViewImpl.prototype.setAccessibilityLiveRegion = function (value) {
    this.resetIfRequired();
    if (this.accessibilityLiveRegion == null || this.accessibilityLiveRegion == undefined) {
      this.accessibilityLiveRegion = new widget_CommandAttr();
    }
    this.accessibilityLiveRegion.setSetter(true);
    this.accessibilityLiveRegion.setValue(value);
    this.orderSet++;
    this.accessibilityLiveRegion.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetAccessibilityPaneTitle = function () {
    this.resetIfRequired();
    if (this.accessibilityPaneTitle == null || this.accessibilityPaneTitle == undefined) {
      this.accessibilityPaneTitle = new widget_CommandAttr();
    }
    this.accessibilityPaneTitle.setGetter(true);
    this.orderGet++;
    this.accessibilityPaneTitle.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getAccessibilityPaneTitle = function () {
    if (this.accessibilityPaneTitle == null || this.accessibilityPaneTitle == undefined) {
      this.accessibilityPaneTitle = new widget_CommandAttr();
    }
    return this.accessibilityPaneTitle.getCommandReturnValue();
  };
  ViewImpl.prototype.setAccessibilityPaneTitle = function (value) {
    this.resetIfRequired();
    if (this.accessibilityPaneTitle == null || this.accessibilityPaneTitle == undefined) {
      this.accessibilityPaneTitle = new widget_CommandAttr();
    }
    this.accessibilityPaneTitle.setSetter(true);
    this.accessibilityPaneTitle.setValue(value);
    this.orderSet++;
    this.accessibilityPaneTitle.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetAccessibilityTraversalAfter = function () {
    this.resetIfRequired();
    if (this.accessibilityTraversalAfter == null || this.accessibilityTraversalAfter == undefined) {
      this.accessibilityTraversalAfter = new widget_CommandAttr();
    }
    this.accessibilityTraversalAfter.setGetter(true);
    this.orderGet++;
    this.accessibilityTraversalAfter.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getAccessibilityTraversalAfter = function () {
    if (this.accessibilityTraversalAfter == null || this.accessibilityTraversalAfter == undefined) {
      this.accessibilityTraversalAfter = new widget_CommandAttr();
    }
    return this.accessibilityTraversalAfter.getCommandReturnValue();
  };
  ViewImpl.prototype.setAccessibilityTraversalAfter = function (value) {
    this.resetIfRequired();
    if (this.accessibilityTraversalAfter == null || this.accessibilityTraversalAfter == undefined) {
      this.accessibilityTraversalAfter = new widget_CommandAttr();
    }
    this.accessibilityTraversalAfter.setSetter(true);
    this.accessibilityTraversalAfter.setValue(value);
    this.orderSet++;
    this.accessibilityTraversalAfter.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetAccessibilityTraversalBefore = function () {
    this.resetIfRequired();
    if (this.accessibilityTraversalBefore == null || this.accessibilityTraversalBefore == undefined) {
      this.accessibilityTraversalBefore = new widget_CommandAttr();
    }
    this.accessibilityTraversalBefore.setGetter(true);
    this.orderGet++;
    this.accessibilityTraversalBefore.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getAccessibilityTraversalBefore = function () {
    if (this.accessibilityTraversalBefore == null || this.accessibilityTraversalBefore == undefined) {
      this.accessibilityTraversalBefore = new widget_CommandAttr();
    }
    return this.accessibilityTraversalBefore.getCommandReturnValue();
  };
  ViewImpl.prototype.setAccessibilityTraversalBefore = function (value) {
    this.resetIfRequired();
    if (this.accessibilityTraversalBefore == null || this.accessibilityTraversalBefore == undefined) {
      this.accessibilityTraversalBefore = new widget_CommandAttr();
    }
    this.accessibilityTraversalBefore.setSetter(true);
    this.accessibilityTraversalBefore.setValue(value);
    this.orderSet++;
    this.accessibilityTraversalBefore.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetAlpha = function () {
    this.resetIfRequired();
    if (this.alpha == null || this.alpha == undefined) {
      this.alpha = new widget_CommandAttr();
    }
    this.alpha.setGetter(true);
    this.orderGet++;
    this.alpha.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getAlpha = function () {
    if (this.alpha == null || this.alpha == undefined) {
      this.alpha = new widget_CommandAttr();
    }
    return this.alpha.getCommandReturnValue();
  };
  ViewImpl.prototype.setAlpha = function (value) {
    this.resetIfRequired();
    if (this.alpha == null || this.alpha == undefined) {
      this.alpha = new widget_CommandAttr();
    }
    this.alpha.setSetter(true);
    this.alpha.setValue(value);
    this.orderSet++;
    this.alpha.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetAutofillHints = function () {
    this.resetIfRequired();
    if (this.autofillHints == null || this.autofillHints == undefined) {
      this.autofillHints = new widget_CommandAttr();
    }
    this.autofillHints.setGetter(true);
    this.orderGet++;
    this.autofillHints.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getAutofillHints = function () {
    if (this.autofillHints == null || this.autofillHints == undefined) {
      this.autofillHints = new widget_CommandAttr();
    }
    return this.autofillHints.getCommandReturnValue();
  };
  ViewImpl.prototype.setAutofillHints = function (value) {
    this.resetIfRequired();
    if (this.autofillHints == null || this.autofillHints == undefined) {
      this.autofillHints = new widget_CommandAttr();
    }
    this.autofillHints.setSetter(true);
    this.autofillHints.setValue(value);
    this.orderSet++;
    this.autofillHints.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetBackgroundTint = function () {
    this.resetIfRequired();
    if (this.backgroundTint == null || this.backgroundTint == undefined) {
      this.backgroundTint = new widget_CommandAttr();
    }
    this.backgroundTint.setGetter(true);
    this.orderGet++;
    this.backgroundTint.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getBackgroundTint = function () {
    if (this.backgroundTint == null || this.backgroundTint == undefined) {
      this.backgroundTint = new widget_CommandAttr();
    }
    return this.backgroundTint.getCommandReturnValue();
  };
  ViewImpl.prototype.setBackgroundTint = function (value) {
    this.resetIfRequired();
    if (this.backgroundTint == null || this.backgroundTint == undefined) {
      this.backgroundTint = new widget_CommandAttr();
    }
    this.backgroundTint.setSetter(true);
    this.backgroundTint.setValue(value);
    this.orderSet++;
    this.backgroundTint.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetBackgroundTintMode = function () {
    this.resetIfRequired();
    if (this.backgroundTintMode == null || this.backgroundTintMode == undefined) {
      this.backgroundTintMode = new widget_CommandAttr();
    }
    this.backgroundTintMode.setGetter(true);
    this.orderGet++;
    this.backgroundTintMode.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getBackgroundTintMode = function () {
    if (this.backgroundTintMode == null || this.backgroundTintMode == undefined) {
      this.backgroundTintMode = new widget_CommandAttr();
    }
    return this.backgroundTintMode.getCommandReturnValue();
  };
  ViewImpl.prototype.setBackgroundTintMode = function (value) {
    this.resetIfRequired();
    if (this.backgroundTintMode == null || this.backgroundTintMode == undefined) {
      this.backgroundTintMode = new widget_CommandAttr();
    }
    this.backgroundTintMode.setSetter(true);
    this.backgroundTintMode.setValue(value);
    this.orderSet++;
    this.backgroundTintMode.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetClickable = function () {
    this.resetIfRequired();
    if (this.clickable == null || this.clickable == undefined) {
      this.clickable = new widget_CommandAttr();
    }
    this.clickable.setGetter(true);
    this.orderGet++;
    this.clickable.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isClickable = function () {
    if (this.clickable == null || this.clickable == undefined) {
      this.clickable = new widget_CommandAttr();
    }
    return this.clickable.getCommandReturnValue();
  };
  ViewImpl.prototype.setClickable = function (value) {
    this.resetIfRequired();
    if (this.clickable == null || this.clickable == undefined) {
      this.clickable = new widget_CommandAttr();
    }
    this.clickable.setSetter(true);
    this.clickable.setValue(value);
    this.orderSet++;
    this.clickable.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetContentDescription = function () {
    this.resetIfRequired();
    if (this.contentDescription == null || this.contentDescription == undefined) {
      this.contentDescription = new widget_CommandAttr();
    }
    this.contentDescription.setGetter(true);
    this.orderGet++;
    this.contentDescription.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getContentDescription = function () {
    if (this.contentDescription == null || this.contentDescription == undefined) {
      this.contentDescription = new widget_CommandAttr();
    }
    return this.contentDescription.getCommandReturnValue();
  };
  ViewImpl.prototype.setContentDescription = function (value) {
    this.resetIfRequired();
    if (this.contentDescription == null || this.contentDescription == undefined) {
      this.contentDescription = new widget_CommandAttr();
    }
    this.contentDescription.setSetter(true);
    this.contentDescription.setValue(value);
    this.orderSet++;
    this.contentDescription.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetContextClickable = function () {
    this.resetIfRequired();
    if (this.contextClickable == null || this.contextClickable == undefined) {
      this.contextClickable = new widget_CommandAttr();
    }
    this.contextClickable.setGetter(true);
    this.orderGet++;
    this.contextClickable.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isContextClickable = function () {
    if (this.contextClickable == null || this.contextClickable == undefined) {
      this.contextClickable = new widget_CommandAttr();
    }
    return this.contextClickable.getCommandReturnValue();
  };
  ViewImpl.prototype.setContextClickable = function (value) {
    this.resetIfRequired();
    if (this.contextClickable == null || this.contextClickable == undefined) {
      this.contextClickable = new widget_CommandAttr();
    }
    this.contextClickable.setSetter(true);
    this.contextClickable.setValue(value);
    this.orderSet++;
    this.contextClickable.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetDefaultFocusHighlightEnabled = function () {
    this.resetIfRequired();
    if (this.defaultFocusHighlightEnabled == null || this.defaultFocusHighlightEnabled == undefined) {
      this.defaultFocusHighlightEnabled = new widget_CommandAttr();
    }
    this.defaultFocusHighlightEnabled.setGetter(true);
    this.orderGet++;
    this.defaultFocusHighlightEnabled.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isDefaultFocusHighlightEnabled = function () {
    if (this.defaultFocusHighlightEnabled == null || this.defaultFocusHighlightEnabled == undefined) {
      this.defaultFocusHighlightEnabled = new widget_CommandAttr();
    }
    return this.defaultFocusHighlightEnabled.getCommandReturnValue();
  };
  ViewImpl.prototype.setDefaultFocusHighlightEnabled = function (value) {
    this.resetIfRequired();
    if (this.defaultFocusHighlightEnabled == null || this.defaultFocusHighlightEnabled == undefined) {
      this.defaultFocusHighlightEnabled = new widget_CommandAttr();
    }
    this.defaultFocusHighlightEnabled.setSetter(true);
    this.defaultFocusHighlightEnabled.setValue(value);
    this.orderSet++;
    this.defaultFocusHighlightEnabled.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetDuplicateParentState = function () {
    this.resetIfRequired();
    if (this.duplicateParentState == null || this.duplicateParentState == undefined) {
      this.duplicateParentState = new widget_CommandAttr();
    }
    this.duplicateParentState.setGetter(true);
    this.orderGet++;
    this.duplicateParentState.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isDuplicateParentState = function () {
    if (this.duplicateParentState == null || this.duplicateParentState == undefined) {
      this.duplicateParentState = new widget_CommandAttr();
    }
    return this.duplicateParentState.getCommandReturnValue();
  };
  ViewImpl.prototype.setDuplicateParentState = function (value) {
    this.resetIfRequired();
    if (this.duplicateParentState == null || this.duplicateParentState == undefined) {
      this.duplicateParentState = new widget_CommandAttr();
    }
    this.duplicateParentState.setSetter(true);
    this.duplicateParentState.setValue(value);
    this.orderSet++;
    this.duplicateParentState.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetElevation = function () {
    this.resetIfRequired();
    if (this.elevation == null || this.elevation == undefined) {
      this.elevation = new widget_CommandAttr();
    }
    this.elevation.setGetter(true);
    this.orderGet++;
    this.elevation.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getElevation = function () {
    if (this.elevation == null || this.elevation == undefined) {
      this.elevation = new widget_CommandAttr();
    }
    return this.elevation.getCommandReturnValue();
  };
  ViewImpl.prototype.setElevation = function (value) {
    this.resetIfRequired();
    if (this.elevation == null || this.elevation == undefined) {
      this.elevation = new widget_CommandAttr();
    }
    this.elevation.setSetter(true);
    this.elevation.setValue(value);
    this.orderSet++;
    this.elevation.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetFadeScrollbars = function () {
    this.resetIfRequired();
    if (this.fadeScrollbars == null || this.fadeScrollbars == undefined) {
      this.fadeScrollbars = new widget_CommandAttr();
    }
    this.fadeScrollbars.setGetter(true);
    this.orderGet++;
    this.fadeScrollbars.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isFadeScrollbars = function () {
    if (this.fadeScrollbars == null || this.fadeScrollbars == undefined) {
      this.fadeScrollbars = new widget_CommandAttr();
    }
    return this.fadeScrollbars.getCommandReturnValue();
  };
  ViewImpl.prototype.setFadeScrollbars = function (value) {
    this.resetIfRequired();
    if (this.fadeScrollbars == null || this.fadeScrollbars == undefined) {
      this.fadeScrollbars = new widget_CommandAttr();
    }
    this.fadeScrollbars.setSetter(true);
    this.fadeScrollbars.setValue(value);
    this.orderSet++;
    this.fadeScrollbars.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setFadingEdgeLength = function (value) {
    this.resetIfRequired();
    if (this.fadingEdgeLength == null || this.fadingEdgeLength == undefined) {
      this.fadingEdgeLength = new widget_CommandAttr();
    }
    this.fadingEdgeLength.setSetter(true);
    this.fadingEdgeLength.setValue(value);
    this.orderSet++;
    this.fadingEdgeLength.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetFilterTouchesWhenObscured = function () {
    this.resetIfRequired();
    if (this.filterTouchesWhenObscured == null || this.filterTouchesWhenObscured == undefined) {
      this.filterTouchesWhenObscured = new widget_CommandAttr();
    }
    this.filterTouchesWhenObscured.setGetter(true);
    this.orderGet++;
    this.filterTouchesWhenObscured.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isFilterTouchesWhenObscured = function () {
    if (this.filterTouchesWhenObscured == null || this.filterTouchesWhenObscured == undefined) {
      this.filterTouchesWhenObscured = new widget_CommandAttr();
    }
    return this.filterTouchesWhenObscured.getCommandReturnValue();
  };
  ViewImpl.prototype.setFilterTouchesWhenObscured = function (value) {
    this.resetIfRequired();
    if (this.filterTouchesWhenObscured == null || this.filterTouchesWhenObscured == undefined) {
      this.filterTouchesWhenObscured = new widget_CommandAttr();
    }
    this.filterTouchesWhenObscured.setSetter(true);
    this.filterTouchesWhenObscured.setValue(value);
    this.orderSet++;
    this.filterTouchesWhenObscured.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetFitsSystemWindows = function () {
    this.resetIfRequired();
    if (this.fitsSystemWindows == null || this.fitsSystemWindows == undefined) {
      this.fitsSystemWindows = new widget_CommandAttr();
    }
    this.fitsSystemWindows.setGetter(true);
    this.orderGet++;
    this.fitsSystemWindows.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isFitsSystemWindows = function () {
    if (this.fitsSystemWindows == null || this.fitsSystemWindows == undefined) {
      this.fitsSystemWindows = new widget_CommandAttr();
    }
    return this.fitsSystemWindows.getCommandReturnValue();
  };
  ViewImpl.prototype.setFitsSystemWindows = function (value) {
    this.resetIfRequired();
    if (this.fitsSystemWindows == null || this.fitsSystemWindows == undefined) {
      this.fitsSystemWindows = new widget_CommandAttr();
    }
    this.fitsSystemWindows.setSetter(true);
    this.fitsSystemWindows.setValue(value);
    this.orderSet++;
    this.fitsSystemWindows.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetFocusableInTouchMode = function () {
    this.resetIfRequired();
    if (this.focusableInTouchMode == null || this.focusableInTouchMode == undefined) {
      this.focusableInTouchMode = new widget_CommandAttr();
    }
    this.focusableInTouchMode.setGetter(true);
    this.orderGet++;
    this.focusableInTouchMode.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isFocusableInTouchMode = function () {
    if (this.focusableInTouchMode == null || this.focusableInTouchMode == undefined) {
      this.focusableInTouchMode = new widget_CommandAttr();
    }
    return this.focusableInTouchMode.getCommandReturnValue();
  };
  ViewImpl.prototype.setFocusableInTouchMode = function (value) {
    this.resetIfRequired();
    if (this.focusableInTouchMode == null || this.focusableInTouchMode == undefined) {
      this.focusableInTouchMode = new widget_CommandAttr();
    }
    this.focusableInTouchMode.setSetter(true);
    this.focusableInTouchMode.setValue(value);
    this.orderSet++;
    this.focusableInTouchMode.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetFocusedByDefault = function () {
    this.resetIfRequired();
    if (this.focusedByDefault == null || this.focusedByDefault == undefined) {
      this.focusedByDefault = new widget_CommandAttr();
    }
    this.focusedByDefault.setGetter(true);
    this.orderGet++;
    this.focusedByDefault.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isFocusedByDefault = function () {
    if (this.focusedByDefault == null || this.focusedByDefault == undefined) {
      this.focusedByDefault = new widget_CommandAttr();
    }
    return this.focusedByDefault.getCommandReturnValue();
  };
  ViewImpl.prototype.setFocusedByDefault = function (value) {
    this.resetIfRequired();
    if (this.focusedByDefault == null || this.focusedByDefault == undefined) {
      this.focusedByDefault = new widget_CommandAttr();
    }
    this.focusedByDefault.setSetter(true);
    this.focusedByDefault.setValue(value);
    this.orderSet++;
    this.focusedByDefault.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setForceHasOverlappingRendering = function (value) {
    this.resetIfRequired();
    if (this.forceHasOverlappingRendering == null || this.forceHasOverlappingRendering == undefined) {
      this.forceHasOverlappingRendering = new widget_CommandAttr();
    }
    this.forceHasOverlappingRendering.setSetter(true);
    this.forceHasOverlappingRendering.setValue(value);
    this.orderSet++;
    this.forceHasOverlappingRendering.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetForegroundTint = function () {
    this.resetIfRequired();
    if (this.foregroundTint == null || this.foregroundTint == undefined) {
      this.foregroundTint = new widget_CommandAttr();
    }
    this.foregroundTint.setGetter(true);
    this.orderGet++;
    this.foregroundTint.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getForegroundTint = function () {
    if (this.foregroundTint == null || this.foregroundTint == undefined) {
      this.foregroundTint = new widget_CommandAttr();
    }
    return this.foregroundTint.getCommandReturnValue();
  };
  ViewImpl.prototype.setForegroundTint = function (value) {
    this.resetIfRequired();
    if (this.foregroundTint == null || this.foregroundTint == undefined) {
      this.foregroundTint = new widget_CommandAttr();
    }
    this.foregroundTint.setSetter(true);
    this.foregroundTint.setValue(value);
    this.orderSet++;
    this.foregroundTint.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetForegroundTintMode = function () {
    this.resetIfRequired();
    if (this.foregroundTintMode == null || this.foregroundTintMode == undefined) {
      this.foregroundTintMode = new widget_CommandAttr();
    }
    this.foregroundTintMode.setGetter(true);
    this.orderGet++;
    this.foregroundTintMode.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getForegroundTintMode = function () {
    if (this.foregroundTintMode == null || this.foregroundTintMode == undefined) {
      this.foregroundTintMode = new widget_CommandAttr();
    }
    return this.foregroundTintMode.getCommandReturnValue();
  };
  ViewImpl.prototype.setForegroundTintMode = function (value) {
    this.resetIfRequired();
    if (this.foregroundTintMode == null || this.foregroundTintMode == undefined) {
      this.foregroundTintMode = new widget_CommandAttr();
    }
    this.foregroundTintMode.setSetter(true);
    this.foregroundTintMode.setValue(value);
    this.orderSet++;
    this.foregroundTintMode.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetHapticFeedbackEnabled = function () {
    this.resetIfRequired();
    if (this.hapticFeedbackEnabled == null || this.hapticFeedbackEnabled == undefined) {
      this.hapticFeedbackEnabled = new widget_CommandAttr();
    }
    this.hapticFeedbackEnabled.setGetter(true);
    this.orderGet++;
    this.hapticFeedbackEnabled.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isHapticFeedbackEnabled = function () {
    if (this.hapticFeedbackEnabled == null || this.hapticFeedbackEnabled == undefined) {
      this.hapticFeedbackEnabled = new widget_CommandAttr();
    }
    return this.hapticFeedbackEnabled.getCommandReturnValue();
  };
  ViewImpl.prototype.setHapticFeedbackEnabled = function (value) {
    this.resetIfRequired();
    if (this.hapticFeedbackEnabled == null || this.hapticFeedbackEnabled == undefined) {
      this.hapticFeedbackEnabled = new widget_CommandAttr();
    }
    this.hapticFeedbackEnabled.setSetter(true);
    this.hapticFeedbackEnabled.setValue(value);
    this.orderSet++;
    this.hapticFeedbackEnabled.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetImportantForAccessibility = function () {
    this.resetIfRequired();
    if (this.importantForAccessibility == null || this.importantForAccessibility == undefined) {
      this.importantForAccessibility = new widget_CommandAttr();
    }
    this.importantForAccessibility.setGetter(true);
    this.orderGet++;
    this.importantForAccessibility.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getImportantForAccessibility = function () {
    if (this.importantForAccessibility == null || this.importantForAccessibility == undefined) {
      this.importantForAccessibility = new widget_CommandAttr();
    }
    return this.importantForAccessibility.getCommandReturnValue();
  };
  ViewImpl.prototype.setImportantForAccessibility = function (value) {
    this.resetIfRequired();
    if (this.importantForAccessibility == null || this.importantForAccessibility == undefined) {
      this.importantForAccessibility = new widget_CommandAttr();
    }
    this.importantForAccessibility.setSetter(true);
    this.importantForAccessibility.setValue(value);
    this.orderSet++;
    this.importantForAccessibility.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetImportantForAutofill = function () {
    this.resetIfRequired();
    if (this.importantForAutofill == null || this.importantForAutofill == undefined) {
      this.importantForAutofill = new widget_CommandAttr();
    }
    this.importantForAutofill.setGetter(true);
    this.orderGet++;
    this.importantForAutofill.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getImportantForAutofill = function () {
    if (this.importantForAutofill == null || this.importantForAutofill == undefined) {
      this.importantForAutofill = new widget_CommandAttr();
    }
    this.importantForAutofill.setTransformer('importantForAutofill');
    return this.importantForAutofill.getCommandReturnValue();
  };
  ViewImpl.prototype.setImportantForAutofill = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.importantForAutofill == null || this.importantForAutofill == undefined) {
      this.importantForAutofill = new widget_CommandAttr();
    }
    this.importantForAutofill.setSetter(true);
    this.importantForAutofill.setValue(value);
    this.orderSet++;
    this.importantForAutofill.setOrderSet(this.orderSet);
    this.importantForAutofill.setTransformer('importantForAutofill');
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetIsScrollContainer = function () {
    this.resetIfRequired();
    if (this.isScrollContainer == null || this.isScrollContainer == undefined) {
      this.isScrollContainer = new widget_CommandAttr();
    }
    this.isScrollContainer.setGetter(true);
    this.orderGet++;
    this.isScrollContainer.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isIsScrollContainer = function () {
    if (this.isScrollContainer == null || this.isScrollContainer == undefined) {
      this.isScrollContainer = new widget_CommandAttr();
    }
    return this.isScrollContainer.getCommandReturnValue();
  };
  ViewImpl.prototype.setIsScrollContainer = function (value) {
    this.resetIfRequired();
    if (this.isScrollContainer == null || this.isScrollContainer == undefined) {
      this.isScrollContainer = new widget_CommandAttr();
    }
    this.isScrollContainer.setSetter(true);
    this.isScrollContainer.setValue(value);
    this.orderSet++;
    this.isScrollContainer.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetKeepScreenOn = function () {
    this.resetIfRequired();
    if (this.keepScreenOn == null || this.keepScreenOn == undefined) {
      this.keepScreenOn = new widget_CommandAttr();
    }
    this.keepScreenOn.setGetter(true);
    this.orderGet++;
    this.keepScreenOn.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isKeepScreenOn = function () {
    if (this.keepScreenOn == null || this.keepScreenOn == undefined) {
      this.keepScreenOn = new widget_CommandAttr();
    }
    return this.keepScreenOn.getCommandReturnValue();
  };
  ViewImpl.prototype.setKeepScreenOn = function (value) {
    this.resetIfRequired();
    if (this.keepScreenOn == null || this.keepScreenOn == undefined) {
      this.keepScreenOn = new widget_CommandAttr();
    }
    this.keepScreenOn.setSetter(true);
    this.keepScreenOn.setValue(value);
    this.orderSet++;
    this.keepScreenOn.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetKeyboardNavigationCluster = function () {
    this.resetIfRequired();
    if (this.keyboardNavigationCluster == null || this.keyboardNavigationCluster == undefined) {
      this.keyboardNavigationCluster = new widget_CommandAttr();
    }
    this.keyboardNavigationCluster.setGetter(true);
    this.orderGet++;
    this.keyboardNavigationCluster.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isKeyboardNavigationCluster = function () {
    if (this.keyboardNavigationCluster == null || this.keyboardNavigationCluster == undefined) {
      this.keyboardNavigationCluster = new widget_CommandAttr();
    }
    return this.keyboardNavigationCluster.getCommandReturnValue();
  };
  ViewImpl.prototype.setKeyboardNavigationCluster = function (value) {
    this.resetIfRequired();
    if (this.keyboardNavigationCluster == null || this.keyboardNavigationCluster == undefined) {
      this.keyboardNavigationCluster = new widget_CommandAttr();
    }
    this.keyboardNavigationCluster.setSetter(true);
    this.keyboardNavigationCluster.setValue(value);
    this.orderSet++;
    this.keyboardNavigationCluster.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetLayoutDirection = function () {
    this.resetIfRequired();
    if (this.layoutDirection == null || this.layoutDirection == undefined) {
      this.layoutDirection = new widget_CommandAttr();
    }
    this.layoutDirection.setGetter(true);
    this.orderGet++;
    this.layoutDirection.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getLayoutDirection = function () {
    if (this.layoutDirection == null || this.layoutDirection == undefined) {
      this.layoutDirection = new widget_CommandAttr();
    }
    return this.layoutDirection.getCommandReturnValue();
  };
  ViewImpl.prototype.setLayoutDirection = function (value) {
    this.resetIfRequired();
    if (this.layoutDirection == null || this.layoutDirection == undefined) {
      this.layoutDirection = new widget_CommandAttr();
    }
    this.layoutDirection.setSetter(true);
    this.layoutDirection.setValue(value);
    this.orderSet++;
    this.layoutDirection.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetLongClickable = function () {
    this.resetIfRequired();
    if (this.longClickable == null || this.longClickable == undefined) {
      this.longClickable = new widget_CommandAttr();
    }
    this.longClickable.setGetter(true);
    this.orderGet++;
    this.longClickable.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isLongClickable = function () {
    if (this.longClickable == null || this.longClickable == undefined) {
      this.longClickable = new widget_CommandAttr();
    }
    return this.longClickable.getCommandReturnValue();
  };
  ViewImpl.prototype.setLongClickable = function (value) {
    this.resetIfRequired();
    if (this.longClickable == null || this.longClickable == undefined) {
      this.longClickable = new widget_CommandAttr();
    }
    this.longClickable.setSetter(true);
    this.longClickable.setValue(value);
    this.orderSet++;
    this.longClickable.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetMinHeight = function () {
    this.resetIfRequired();
    if (this.minHeight == null || this.minHeight == undefined) {
      this.minHeight = new widget_CommandAttr();
    }
    this.minHeight.setGetter(true);
    this.orderGet++;
    this.minHeight.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getMinHeight = function () {
    if (this.minHeight == null || this.minHeight == undefined) {
      this.minHeight = new widget_CommandAttr();
    }
    return this.minHeight.getCommandReturnValue();
  };
  ViewImpl.prototype.setMinHeight = function (value) {
    this.resetIfRequired();
    if (this.minHeight == null || this.minHeight == undefined) {
      this.minHeight = new widget_CommandAttr();
    }
    this.minHeight.setSetter(true);
    this.minHeight.setValue(value);
    this.orderSet++;
    this.minHeight.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetMinWidth = function () {
    this.resetIfRequired();
    if (this.minWidth == null || this.minWidth == undefined) {
      this.minWidth = new widget_CommandAttr();
    }
    this.minWidth.setGetter(true);
    this.orderGet++;
    this.minWidth.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getMinWidth = function () {
    if (this.minWidth == null || this.minWidth == undefined) {
      this.minWidth = new widget_CommandAttr();
    }
    return this.minWidth.getCommandReturnValue();
  };
  ViewImpl.prototype.setMinWidth = function (value) {
    this.resetIfRequired();
    if (this.minWidth == null || this.minWidth == undefined) {
      this.minWidth = new widget_CommandAttr();
    }
    this.minWidth.setSetter(true);
    this.minWidth.setValue(value);
    this.orderSet++;
    this.minWidth.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetNextClusterForward = function () {
    this.resetIfRequired();
    if (this.nextClusterForward == null || this.nextClusterForward == undefined) {
      this.nextClusterForward = new widget_CommandAttr();
    }
    this.nextClusterForward.setGetter(true);
    this.orderGet++;
    this.nextClusterForward.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getNextClusterForward = function () {
    if (this.nextClusterForward == null || this.nextClusterForward == undefined) {
      this.nextClusterForward = new widget_CommandAttr();
    }
    return this.nextClusterForward.getCommandReturnValue();
  };
  ViewImpl.prototype.setNextClusterForward = function (value) {
    this.resetIfRequired();
    if (this.nextClusterForward == null || this.nextClusterForward == undefined) {
      this.nextClusterForward = new widget_CommandAttr();
    }
    this.nextClusterForward.setSetter(true);
    this.nextClusterForward.setValue(value);
    this.orderSet++;
    this.nextClusterForward.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetNextFocusDown = function () {
    this.resetIfRequired();
    if (this.nextFocusDown == null || this.nextFocusDown == undefined) {
      this.nextFocusDown = new widget_CommandAttr();
    }
    this.nextFocusDown.setGetter(true);
    this.orderGet++;
    this.nextFocusDown.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getNextFocusDown = function () {
    if (this.nextFocusDown == null || this.nextFocusDown == undefined) {
      this.nextFocusDown = new widget_CommandAttr();
    }
    return this.nextFocusDown.getCommandReturnValue();
  };
  ViewImpl.prototype.setNextFocusDown = function (value) {
    this.resetIfRequired();
    if (this.nextFocusDown == null || this.nextFocusDown == undefined) {
      this.nextFocusDown = new widget_CommandAttr();
    }
    this.nextFocusDown.setSetter(true);
    this.nextFocusDown.setValue(value);
    this.orderSet++;
    this.nextFocusDown.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetNextFocusForward = function () {
    this.resetIfRequired();
    if (this.nextFocusForward == null || this.nextFocusForward == undefined) {
      this.nextFocusForward = new widget_CommandAttr();
    }
    this.nextFocusForward.setGetter(true);
    this.orderGet++;
    this.nextFocusForward.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getNextFocusForward = function () {
    if (this.nextFocusForward == null || this.nextFocusForward == undefined) {
      this.nextFocusForward = new widget_CommandAttr();
    }
    return this.nextFocusForward.getCommandReturnValue();
  };
  ViewImpl.prototype.setNextFocusForward = function (value) {
    this.resetIfRequired();
    if (this.nextFocusForward == null || this.nextFocusForward == undefined) {
      this.nextFocusForward = new widget_CommandAttr();
    }
    this.nextFocusForward.setSetter(true);
    this.nextFocusForward.setValue(value);
    this.orderSet++;
    this.nextFocusForward.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetNextFocusLeft = function () {
    this.resetIfRequired();
    if (this.nextFocusLeft == null || this.nextFocusLeft == undefined) {
      this.nextFocusLeft = new widget_CommandAttr();
    }
    this.nextFocusLeft.setGetter(true);
    this.orderGet++;
    this.nextFocusLeft.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getNextFocusLeft = function () {
    if (this.nextFocusLeft == null || this.nextFocusLeft == undefined) {
      this.nextFocusLeft = new widget_CommandAttr();
    }
    return this.nextFocusLeft.getCommandReturnValue();
  };
  ViewImpl.prototype.setNextFocusLeft = function (value) {
    this.resetIfRequired();
    if (this.nextFocusLeft == null || this.nextFocusLeft == undefined) {
      this.nextFocusLeft = new widget_CommandAttr();
    }
    this.nextFocusLeft.setSetter(true);
    this.nextFocusLeft.setValue(value);
    this.orderSet++;
    this.nextFocusLeft.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetNextFocusRight = function () {
    this.resetIfRequired();
    if (this.nextFocusRight == null || this.nextFocusRight == undefined) {
      this.nextFocusRight = new widget_CommandAttr();
    }
    this.nextFocusRight.setGetter(true);
    this.orderGet++;
    this.nextFocusRight.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getNextFocusRight = function () {
    if (this.nextFocusRight == null || this.nextFocusRight == undefined) {
      this.nextFocusRight = new widget_CommandAttr();
    }
    return this.nextFocusRight.getCommandReturnValue();
  };
  ViewImpl.prototype.setNextFocusRight = function (value) {
    this.resetIfRequired();
    if (this.nextFocusRight == null || this.nextFocusRight == undefined) {
      this.nextFocusRight = new widget_CommandAttr();
    }
    this.nextFocusRight.setSetter(true);
    this.nextFocusRight.setValue(value);
    this.orderSet++;
    this.nextFocusRight.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetNextFocusUp = function () {
    this.resetIfRequired();
    if (this.nextFocusUp == null || this.nextFocusUp == undefined) {
      this.nextFocusUp = new widget_CommandAttr();
    }
    this.nextFocusUp.setGetter(true);
    this.orderGet++;
    this.nextFocusUp.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getNextFocusUp = function () {
    if (this.nextFocusUp == null || this.nextFocusUp == undefined) {
      this.nextFocusUp = new widget_CommandAttr();
    }
    return this.nextFocusUp.getCommandReturnValue();
  };
  ViewImpl.prototype.setNextFocusUp = function (value) {
    this.resetIfRequired();
    if (this.nextFocusUp == null || this.nextFocusUp == undefined) {
      this.nextFocusUp = new widget_CommandAttr();
    }
    this.nextFocusUp.setSetter(true);
    this.nextFocusUp.setValue(value);
    this.orderSet++;
    this.nextFocusUp.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetRotation = function () {
    this.resetIfRequired();
    if (this.rotation == null || this.rotation == undefined) {
      this.rotation = new widget_CommandAttr();
    }
    this.rotation.setGetter(true);
    this.orderGet++;
    this.rotation.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getRotation = function () {
    if (this.rotation == null || this.rotation == undefined) {
      this.rotation = new widget_CommandAttr();
    }
    return this.rotation.getCommandReturnValue();
  };
  ViewImpl.prototype.setRotation = function (value) {
    this.resetIfRequired();
    if (this.rotation == null || this.rotation == undefined) {
      this.rotation = new widget_CommandAttr();
    }
    this.rotation.setSetter(true);
    this.rotation.setValue(value);
    this.orderSet++;
    this.rotation.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetRotationX = function () {
    this.resetIfRequired();
    if (this.rotationX == null || this.rotationX == undefined) {
      this.rotationX = new widget_CommandAttr();
    }
    this.rotationX.setGetter(true);
    this.orderGet++;
    this.rotationX.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getRotationX = function () {
    if (this.rotationX == null || this.rotationX == undefined) {
      this.rotationX = new widget_CommandAttr();
    }
    return this.rotationX.getCommandReturnValue();
  };
  ViewImpl.prototype.setRotationX = function (value) {
    this.resetIfRequired();
    if (this.rotationX == null || this.rotationX == undefined) {
      this.rotationX = new widget_CommandAttr();
    }
    this.rotationX.setSetter(true);
    this.rotationX.setValue(value);
    this.orderSet++;
    this.rotationX.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetRotationY = function () {
    this.resetIfRequired();
    if (this.rotationY == null || this.rotationY == undefined) {
      this.rotationY = new widget_CommandAttr();
    }
    this.rotationY.setGetter(true);
    this.orderGet++;
    this.rotationY.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getRotationY = function () {
    if (this.rotationY == null || this.rotationY == undefined) {
      this.rotationY = new widget_CommandAttr();
    }
    return this.rotationY.getCommandReturnValue();
  };
  ViewImpl.prototype.setRotationY = function (value) {
    this.resetIfRequired();
    if (this.rotationY == null || this.rotationY == undefined) {
      this.rotationY = new widget_CommandAttr();
    }
    this.rotationY.setSetter(true);
    this.rotationY.setValue(value);
    this.orderSet++;
    this.rotationY.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetSaveEnabled = function () {
    this.resetIfRequired();
    if (this.saveEnabled == null || this.saveEnabled == undefined) {
      this.saveEnabled = new widget_CommandAttr();
    }
    this.saveEnabled.setGetter(true);
    this.orderGet++;
    this.saveEnabled.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isSaveEnabled = function () {
    if (this.saveEnabled == null || this.saveEnabled == undefined) {
      this.saveEnabled = new widget_CommandAttr();
    }
    return this.saveEnabled.getCommandReturnValue();
  };
  ViewImpl.prototype.setSaveEnabled = function (value) {
    this.resetIfRequired();
    if (this.saveEnabled == null || this.saveEnabled == undefined) {
      this.saveEnabled = new widget_CommandAttr();
    }
    this.saveEnabled.setSetter(true);
    this.saveEnabled.setValue(value);
    this.orderSet++;
    this.saveEnabled.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScaleX = function () {
    this.resetIfRequired();
    if (this.scaleX == null || this.scaleX == undefined) {
      this.scaleX = new widget_CommandAttr();
    }
    this.scaleX.setGetter(true);
    this.orderGet++;
    this.scaleX.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScaleX = function () {
    if (this.scaleX == null || this.scaleX == undefined) {
      this.scaleX = new widget_CommandAttr();
    }
    return this.scaleX.getCommandReturnValue();
  };
  ViewImpl.prototype.setScaleX = function (value) {
    this.resetIfRequired();
    if (this.scaleX == null || this.scaleX == undefined) {
      this.scaleX = new widget_CommandAttr();
    }
    this.scaleX.setSetter(true);
    this.scaleX.setValue(value);
    this.orderSet++;
    this.scaleX.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScaleY = function () {
    this.resetIfRequired();
    if (this.scaleY == null || this.scaleY == undefined) {
      this.scaleY = new widget_CommandAttr();
    }
    this.scaleY.setGetter(true);
    this.orderGet++;
    this.scaleY.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScaleY = function () {
    if (this.scaleY == null || this.scaleY == undefined) {
      this.scaleY = new widget_CommandAttr();
    }
    return this.scaleY.getCommandReturnValue();
  };
  ViewImpl.prototype.setScaleY = function (value) {
    this.resetIfRequired();
    if (this.scaleY == null || this.scaleY == undefined) {
      this.scaleY = new widget_CommandAttr();
    }
    this.scaleY.setSetter(true);
    this.scaleY.setValue(value);
    this.orderSet++;
    this.scaleY.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScreenReaderFocusable = function () {
    this.resetIfRequired();
    if (this.screenReaderFocusable == null || this.screenReaderFocusable == undefined) {
      this.screenReaderFocusable = new widget_CommandAttr();
    }
    this.screenReaderFocusable.setGetter(true);
    this.orderGet++;
    this.screenReaderFocusable.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isScreenReaderFocusable = function () {
    if (this.screenReaderFocusable == null || this.screenReaderFocusable == undefined) {
      this.screenReaderFocusable = new widget_CommandAttr();
    }
    return this.screenReaderFocusable.getCommandReturnValue();
  };
  ViewImpl.prototype.setScreenReaderFocusable = function (value) {
    this.resetIfRequired();
    if (this.screenReaderFocusable == null || this.screenReaderFocusable == undefined) {
      this.screenReaderFocusable = new widget_CommandAttr();
    }
    this.screenReaderFocusable.setSetter(true);
    this.screenReaderFocusable.setValue(value);
    this.orderSet++;
    this.screenReaderFocusable.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollIndicators = function () {
    this.resetIfRequired();
    if (this.scrollIndicators == null || this.scrollIndicators == undefined) {
      this.scrollIndicators = new widget_CommandAttr();
    }
    this.scrollIndicators.setGetter(true);
    this.orderGet++;
    this.scrollIndicators.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollIndicators = function () {
    if (this.scrollIndicators == null || this.scrollIndicators == undefined) {
      this.scrollIndicators = new widget_CommandAttr();
    }
    this.scrollIndicators.setTransformer('scrollIndicators');
    return this.scrollIndicators.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollIndicators = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.scrollIndicators == null || this.scrollIndicators == undefined) {
      this.scrollIndicators = new widget_CommandAttr();
    }
    this.scrollIndicators.setSetter(true);
    this.scrollIndicators.setValue(value);
    this.orderSet++;
    this.scrollIndicators.setOrderSet(this.orderSet);
    this.scrollIndicators.setTransformer('scrollIndicators');
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollbarDefaultDelayBeforeFade = function () {
    this.resetIfRequired();
    if (this.scrollbarDefaultDelayBeforeFade == null || this.scrollbarDefaultDelayBeforeFade == undefined) {
      this.scrollbarDefaultDelayBeforeFade = new widget_CommandAttr();
    }
    this.scrollbarDefaultDelayBeforeFade.setGetter(true);
    this.orderGet++;
    this.scrollbarDefaultDelayBeforeFade.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollbarDefaultDelayBeforeFade = function () {
    if (this.scrollbarDefaultDelayBeforeFade == null || this.scrollbarDefaultDelayBeforeFade == undefined) {
      this.scrollbarDefaultDelayBeforeFade = new widget_CommandAttr();
    }
    return this.scrollbarDefaultDelayBeforeFade.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollbarDefaultDelayBeforeFade = function (value) {
    this.resetIfRequired();
    if (this.scrollbarDefaultDelayBeforeFade == null || this.scrollbarDefaultDelayBeforeFade == undefined) {
      this.scrollbarDefaultDelayBeforeFade = new widget_CommandAttr();
    }
    this.scrollbarDefaultDelayBeforeFade.setSetter(true);
    this.scrollbarDefaultDelayBeforeFade.setValue(value);
    this.orderSet++;
    this.scrollbarDefaultDelayBeforeFade.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollbarFadeDuration = function () {
    this.resetIfRequired();
    if (this.scrollbarFadeDuration == null || this.scrollbarFadeDuration == undefined) {
      this.scrollbarFadeDuration = new widget_CommandAttr();
    }
    this.scrollbarFadeDuration.setGetter(true);
    this.orderGet++;
    this.scrollbarFadeDuration.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollbarFadeDuration = function () {
    if (this.scrollbarFadeDuration == null || this.scrollbarFadeDuration == undefined) {
      this.scrollbarFadeDuration = new widget_CommandAttr();
    }
    return this.scrollbarFadeDuration.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollbarFadeDuration = function (value) {
    this.resetIfRequired();
    if (this.scrollbarFadeDuration == null || this.scrollbarFadeDuration == undefined) {
      this.scrollbarFadeDuration = new widget_CommandAttr();
    }
    this.scrollbarFadeDuration.setSetter(true);
    this.scrollbarFadeDuration.setValue(value);
    this.orderSet++;
    this.scrollbarFadeDuration.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollbarSize = function () {
    this.resetIfRequired();
    if (this.scrollbarSize == null || this.scrollbarSize == undefined) {
      this.scrollbarSize = new widget_CommandAttr();
    }
    this.scrollbarSize.setGetter(true);
    this.orderGet++;
    this.scrollbarSize.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollbarSize = function () {
    if (this.scrollbarSize == null || this.scrollbarSize == undefined) {
      this.scrollbarSize = new widget_CommandAttr();
    }
    return this.scrollbarSize.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollbarSize = function (value) {
    this.resetIfRequired();
    if (this.scrollbarSize == null || this.scrollbarSize == undefined) {
      this.scrollbarSize = new widget_CommandAttr();
    }
    this.scrollbarSize.setSetter(true);
    this.scrollbarSize.setValue(value);
    this.orderSet++;
    this.scrollbarSize.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollbarStyle = function () {
    this.resetIfRequired();
    if (this.scrollbarStyle == null || this.scrollbarStyle == undefined) {
      this.scrollbarStyle = new widget_CommandAttr();
    }
    this.scrollbarStyle.setGetter(true);
    this.orderGet++;
    this.scrollbarStyle.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollbarStyle = function () {
    if (this.scrollbarStyle == null || this.scrollbarStyle == undefined) {
      this.scrollbarStyle = new widget_CommandAttr();
    }
    return this.scrollbarStyle.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollbarStyle = function (value) {
    this.resetIfRequired();
    if (this.scrollbarStyle == null || this.scrollbarStyle == undefined) {
      this.scrollbarStyle = new widget_CommandAttr();
    }
    this.scrollbarStyle.setSetter(true);
    this.scrollbarStyle.setValue(value);
    this.orderSet++;
    this.scrollbarStyle.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetSoundEffectsEnabled = function () {
    this.resetIfRequired();
    if (this.soundEffectsEnabled == null || this.soundEffectsEnabled == undefined) {
      this.soundEffectsEnabled = new widget_CommandAttr();
    }
    this.soundEffectsEnabled.setGetter(true);
    this.orderGet++;
    this.soundEffectsEnabled.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isSoundEffectsEnabled = function () {
    if (this.soundEffectsEnabled == null || this.soundEffectsEnabled == undefined) {
      this.soundEffectsEnabled = new widget_CommandAttr();
    }
    return this.soundEffectsEnabled.getCommandReturnValue();
  };
  ViewImpl.prototype.setSoundEffectsEnabled = function (value) {
    this.resetIfRequired();
    if (this.soundEffectsEnabled == null || this.soundEffectsEnabled == undefined) {
      this.soundEffectsEnabled = new widget_CommandAttr();
    }
    this.soundEffectsEnabled.setSetter(true);
    this.soundEffectsEnabled.setValue(value);
    this.orderSet++;
    this.soundEffectsEnabled.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTextAlignment = function () {
    this.resetIfRequired();
    if (this.textAlignment == null || this.textAlignment == undefined) {
      this.textAlignment = new widget_CommandAttr();
    }
    this.textAlignment.setGetter(true);
    this.orderGet++;
    this.textAlignment.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTextAlignment = function () {
    if (this.textAlignment == null || this.textAlignment == undefined) {
      this.textAlignment = new widget_CommandAttr();
    }
    return this.textAlignment.getCommandReturnValue();
  };
  ViewImpl.prototype.setTextAlignment = function (value) {
    this.resetIfRequired();
    if (this.textAlignment == null || this.textAlignment == undefined) {
      this.textAlignment = new widget_CommandAttr();
    }
    this.textAlignment.setSetter(true);
    this.textAlignment.setValue(value);
    this.orderSet++;
    this.textAlignment.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTextDirection = function () {
    this.resetIfRequired();
    if (this.textDirection == null || this.textDirection == undefined) {
      this.textDirection = new widget_CommandAttr();
    }
    this.textDirection.setGetter(true);
    this.orderGet++;
    this.textDirection.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTextDirection = function () {
    if (this.textDirection == null || this.textDirection == undefined) {
      this.textDirection = new widget_CommandAttr();
    }
    return this.textDirection.getCommandReturnValue();
  };
  ViewImpl.prototype.setTextDirection = function (value) {
    this.resetIfRequired();
    if (this.textDirection == null || this.textDirection == undefined) {
      this.textDirection = new widget_CommandAttr();
    }
    this.textDirection.setSetter(true);
    this.textDirection.setValue(value);
    this.orderSet++;
    this.textDirection.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTooltipText = function () {
    this.resetIfRequired();
    if (this.tooltipText == null || this.tooltipText == undefined) {
      this.tooltipText = new widget_CommandAttr();
    }
    this.tooltipText.setGetter(true);
    this.orderGet++;
    this.tooltipText.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTooltipText = function () {
    if (this.tooltipText == null || this.tooltipText == undefined) {
      this.tooltipText = new widget_CommandAttr();
    }
    return this.tooltipText.getCommandReturnValue();
  };
  ViewImpl.prototype.setTooltipText = function (value) {
    this.resetIfRequired();
    if (this.tooltipText == null || this.tooltipText == undefined) {
      this.tooltipText = new widget_CommandAttr();
    }
    this.tooltipText.setSetter(true);
    this.tooltipText.setValue(value);
    this.orderSet++;
    this.tooltipText.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTransformPivotX = function () {
    this.resetIfRequired();
    if (this.transformPivotX == null || this.transformPivotX == undefined) {
      this.transformPivotX = new widget_CommandAttr();
    }
    this.transformPivotX.setGetter(true);
    this.orderGet++;
    this.transformPivotX.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTransformPivotX = function () {
    if (this.transformPivotX == null || this.transformPivotX == undefined) {
      this.transformPivotX = new widget_CommandAttr();
    }
    return this.transformPivotX.getCommandReturnValue();
  };
  ViewImpl.prototype.setTransformPivotX = function (value) {
    this.resetIfRequired();
    if (this.transformPivotX == null || this.transformPivotX == undefined) {
      this.transformPivotX = new widget_CommandAttr();
    }
    this.transformPivotX.setSetter(true);
    this.transformPivotX.setValue(value);
    this.orderSet++;
    this.transformPivotX.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTransformPivotY = function () {
    this.resetIfRequired();
    if (this.transformPivotY == null || this.transformPivotY == undefined) {
      this.transformPivotY = new widget_CommandAttr();
    }
    this.transformPivotY.setGetter(true);
    this.orderGet++;
    this.transformPivotY.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTransformPivotY = function () {
    if (this.transformPivotY == null || this.transformPivotY == undefined) {
      this.transformPivotY = new widget_CommandAttr();
    }
    return this.transformPivotY.getCommandReturnValue();
  };
  ViewImpl.prototype.setTransformPivotY = function (value) {
    this.resetIfRequired();
    if (this.transformPivotY == null || this.transformPivotY == undefined) {
      this.transformPivotY = new widget_CommandAttr();
    }
    this.transformPivotY.setSetter(true);
    this.transformPivotY.setValue(value);
    this.orderSet++;
    this.transformPivotY.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTransitionName = function () {
    this.resetIfRequired();
    if (this.transitionName == null || this.transitionName == undefined) {
      this.transitionName = new widget_CommandAttr();
    }
    this.transitionName.setGetter(true);
    this.orderGet++;
    this.transitionName.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTransitionName = function () {
    if (this.transitionName == null || this.transitionName == undefined) {
      this.transitionName = new widget_CommandAttr();
    }
    return this.transitionName.getCommandReturnValue();
  };
  ViewImpl.prototype.setTransitionName = function (value) {
    this.resetIfRequired();
    if (this.transitionName == null || this.transitionName == undefined) {
      this.transitionName = new widget_CommandAttr();
    }
    this.transitionName.setSetter(true);
    this.transitionName.setValue(value);
    this.orderSet++;
    this.transitionName.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTranslationX = function () {
    this.resetIfRequired();
    if (this.translationX == null || this.translationX == undefined) {
      this.translationX = new widget_CommandAttr();
    }
    this.translationX.setGetter(true);
    this.orderGet++;
    this.translationX.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTranslationX = function () {
    if (this.translationX == null || this.translationX == undefined) {
      this.translationX = new widget_CommandAttr();
    }
    return this.translationX.getCommandReturnValue();
  };
  ViewImpl.prototype.setTranslationX = function (value) {
    this.resetIfRequired();
    if (this.translationX == null || this.translationX == undefined) {
      this.translationX = new widget_CommandAttr();
    }
    this.translationX.setSetter(true);
    this.translationX.setValue(value);
    this.orderSet++;
    this.translationX.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTranslationY = function () {
    this.resetIfRequired();
    if (this.translationY == null || this.translationY == undefined) {
      this.translationY = new widget_CommandAttr();
    }
    this.translationY.setGetter(true);
    this.orderGet++;
    this.translationY.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTranslationY = function () {
    if (this.translationY == null || this.translationY == undefined) {
      this.translationY = new widget_CommandAttr();
    }
    return this.translationY.getCommandReturnValue();
  };
  ViewImpl.prototype.setTranslationY = function (value) {
    this.resetIfRequired();
    if (this.translationY == null || this.translationY == undefined) {
      this.translationY = new widget_CommandAttr();
    }
    this.translationY.setSetter(true);
    this.translationY.setValue(value);
    this.orderSet++;
    this.translationY.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTranslationZ = function () {
    this.resetIfRequired();
    if (this.translationZ == null || this.translationZ == undefined) {
      this.translationZ = new widget_CommandAttr();
    }
    this.translationZ.setGetter(true);
    this.orderGet++;
    this.translationZ.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTranslationZ = function () {
    if (this.translationZ == null || this.translationZ == undefined) {
      this.translationZ = new widget_CommandAttr();
    }
    return this.translationZ.getCommandReturnValue();
  };
  ViewImpl.prototype.setTranslationZ = function (value) {
    this.resetIfRequired();
    if (this.translationZ == null || this.translationZ == undefined) {
      this.translationZ = new widget_CommandAttr();
    }
    this.translationZ.setSetter(true);
    this.translationZ.setValue(value);
    this.orderSet++;
    this.translationZ.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetVisibility = function () {
    this.resetIfRequired();
    if (this.visibility == null || this.visibility == undefined) {
      this.visibility = new widget_CommandAttr();
    }
    this.visibility.setGetter(true);
    this.orderGet++;
    this.visibility.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getVisibility = function () {
    if (this.visibility == null || this.visibility == undefined) {
      this.visibility = new widget_CommandAttr();
    }
    return this.visibility.getCommandReturnValue();
  };
  ViewImpl.prototype.setVisibility = function (value) {
    this.resetIfRequired();
    if (this.visibility == null || this.visibility == undefined) {
      this.visibility = new widget_CommandAttr();
    }
    this.visibility.setSetter(true);
    this.visibility.setValue(value);
    this.orderSet++;
    this.visibility.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnApplyWindowInsets = function (value) {
    this.resetIfRequired();
    if (this.onApplyWindowInsets == null || this.onApplyWindowInsets == undefined) {
      this.onApplyWindowInsets = new widget_CommandAttr();
    }
    this.onApplyWindowInsets.setSetter(true);
    this.onApplyWindowInsets.setValue(value);
    this.orderSet++;
    this.onApplyWindowInsets.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnCapturedPointer = function (value) {
    this.resetIfRequired();
    if (this.onCapturedPointer == null || this.onCapturedPointer == undefined) {
      this.onCapturedPointer = new widget_CommandAttr();
    }
    this.onCapturedPointer.setSetter(true);
    this.onCapturedPointer.setValue(value);
    this.orderSet++;
    this.onCapturedPointer.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnClick = function (value) {
    this.resetIfRequired();
    if (this.onClick == null || this.onClick == undefined) {
      this.onClick = new widget_CommandAttr();
    }
    this.onClick.setSetter(true);
    this.onClick.setValue(value);
    this.orderSet++;
    this.onClick.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnContextClick = function (value) {
    this.resetIfRequired();
    if (this.onContextClick == null || this.onContextClick == undefined) {
      this.onContextClick = new widget_CommandAttr();
    }
    this.onContextClick.setSetter(true);
    this.onContextClick.setValue(value);
    this.orderSet++;
    this.onContextClick.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnCreateContextMenu = function (value) {
    this.resetIfRequired();
    if (this.onCreateContextMenu == null || this.onCreateContextMenu == undefined) {
      this.onCreateContextMenu = new widget_CommandAttr();
    }
    this.onCreateContextMenu.setSetter(true);
    this.onCreateContextMenu.setValue(value);
    this.orderSet++;
    this.onCreateContextMenu.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnDrag = function (value) {
    this.resetIfRequired();
    if (this.onDrag == null || this.onDrag == undefined) {
      this.onDrag = new widget_CommandAttr();
    }
    this.onDrag.setSetter(true);
    this.onDrag.setValue(value);
    this.orderSet++;
    this.onDrag.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnFocusChange = function (value) {
    this.resetIfRequired();
    if (this.onFocusChange == null || this.onFocusChange == undefined) {
      this.onFocusChange = new widget_CommandAttr();
    }
    this.onFocusChange.setSetter(true);
    this.onFocusChange.setValue(value);
    this.orderSet++;
    this.onFocusChange.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnGenericMotion = function (value) {
    this.resetIfRequired();
    if (this.onGenericMotion == null || this.onGenericMotion == undefined) {
      this.onGenericMotion = new widget_CommandAttr();
    }
    this.onGenericMotion.setSetter(true);
    this.onGenericMotion.setValue(value);
    this.orderSet++;
    this.onGenericMotion.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnHover = function (value) {
    this.resetIfRequired();
    if (this.onHover == null || this.onHover == undefined) {
      this.onHover = new widget_CommandAttr();
    }
    this.onHover.setSetter(true);
    this.onHover.setValue(value);
    this.orderSet++;
    this.onHover.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnKey = function (value) {
    this.resetIfRequired();
    if (this.onKey == null || this.onKey == undefined) {
      this.onKey = new widget_CommandAttr();
    }
    this.onKey.setSetter(true);
    this.onKey.setValue(value);
    this.orderSet++;
    this.onKey.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnLongClick = function (value) {
    this.resetIfRequired();
    if (this.onLongClick == null || this.onLongClick == undefined) {
      this.onLongClick = new widget_CommandAttr();
    }
    this.onLongClick.setSetter(true);
    this.onLongClick.setValue(value);
    this.orderSet++;
    this.onLongClick.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnScrollChange = function (value) {
    this.resetIfRequired();
    if (this.onScrollChange == null || this.onScrollChange == undefined) {
      this.onScrollChange = new widget_CommandAttr();
    }
    this.onScrollChange.setSetter(true);
    this.onScrollChange.setValue(value);
    this.orderSet++;
    this.onScrollChange.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnSystemUiVisibilityChange = function (value) {
    this.resetIfRequired();
    if (this.onSystemUiVisibilityChange == null || this.onSystemUiVisibilityChange == undefined) {
      this.onSystemUiVisibilityChange = new widget_CommandAttr();
    }
    this.onSystemUiVisibilityChange.setSetter(true);
    this.onSystemUiVisibilityChange.setValue(value);
    this.orderSet++;
    this.onSystemUiVisibilityChange.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnTouch = function (value) {
    this.resetIfRequired();
    if (this.onTouch == null || this.onTouch == undefined) {
      this.onTouch = new widget_CommandAttr();
    }
    this.onTouch.setSetter(true);
    this.onTouch.setValue(value);
    this.orderSet++;
    this.onTouch.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setPadding = function (value) {
    this.resetIfRequired();
    if (this.padding == null || this.padding == undefined) {
      this.padding = new widget_CommandAttr();
    }
    this.padding.setSetter(true);
    this.padding.setValue(value);
    this.orderSet++;
    this.padding.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetPaddingTop = function () {
    this.resetIfRequired();
    if (this.paddingTop == null || this.paddingTop == undefined) {
      this.paddingTop = new widget_CommandAttr();
    }
    this.paddingTop.setGetter(true);
    this.orderGet++;
    this.paddingTop.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getPaddingTop = function () {
    if (this.paddingTop == null || this.paddingTop == undefined) {
      this.paddingTop = new widget_CommandAttr();
    }
    return this.paddingTop.getCommandReturnValue();
  };
  ViewImpl.prototype.setPaddingTop = function (value) {
    this.resetIfRequired();
    if (this.paddingTop == null || this.paddingTop == undefined) {
      this.paddingTop = new widget_CommandAttr();
    }
    this.paddingTop.setSetter(true);
    this.paddingTop.setValue(value);
    this.orderSet++;
    this.paddingTop.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetPaddingBottom = function () {
    this.resetIfRequired();
    if (this.paddingBottom == null || this.paddingBottom == undefined) {
      this.paddingBottom = new widget_CommandAttr();
    }
    this.paddingBottom.setGetter(true);
    this.orderGet++;
    this.paddingBottom.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getPaddingBottom = function () {
    if (this.paddingBottom == null || this.paddingBottom == undefined) {
      this.paddingBottom = new widget_CommandAttr();
    }
    return this.paddingBottom.getCommandReturnValue();
  };
  ViewImpl.prototype.setPaddingBottom = function (value) {
    this.resetIfRequired();
    if (this.paddingBottom == null || this.paddingBottom == undefined) {
      this.paddingBottom = new widget_CommandAttr();
    }
    this.paddingBottom.setSetter(true);
    this.paddingBottom.setValue(value);
    this.orderSet++;
    this.paddingBottom.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetPaddingLeft = function () {
    this.resetIfRequired();
    if (this.paddingLeft == null || this.paddingLeft == undefined) {
      this.paddingLeft = new widget_CommandAttr();
    }
    this.paddingLeft.setGetter(true);
    this.orderGet++;
    this.paddingLeft.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getPaddingLeft = function () {
    if (this.paddingLeft == null || this.paddingLeft == undefined) {
      this.paddingLeft = new widget_CommandAttr();
    }
    return this.paddingLeft.getCommandReturnValue();
  };
  ViewImpl.prototype.setPaddingLeft = function (value) {
    this.resetIfRequired();
    if (this.paddingLeft == null || this.paddingLeft == undefined) {
      this.paddingLeft = new widget_CommandAttr();
    }
    this.paddingLeft.setSetter(true);
    this.paddingLeft.setValue(value);
    this.orderSet++;
    this.paddingLeft.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetPaddingRight = function () {
    this.resetIfRequired();
    if (this.paddingRight == null || this.paddingRight == undefined) {
      this.paddingRight = new widget_CommandAttr();
    }
    this.paddingRight.setGetter(true);
    this.orderGet++;
    this.paddingRight.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getPaddingRight = function () {
    if (this.paddingRight == null || this.paddingRight == undefined) {
      this.paddingRight = new widget_CommandAttr();
    }
    return this.paddingRight.getCommandReturnValue();
  };
  ViewImpl.prototype.setPaddingRight = function (value) {
    this.resetIfRequired();
    if (this.paddingRight == null || this.paddingRight == undefined) {
      this.paddingRight = new widget_CommandAttr();
    }
    this.paddingRight.setSetter(true);
    this.paddingRight.setValue(value);
    this.orderSet++;
    this.paddingRight.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetPaddingStart = function () {
    this.resetIfRequired();
    if (this.paddingStart == null || this.paddingStart == undefined) {
      this.paddingStart = new widget_CommandAttr();
    }
    this.paddingStart.setGetter(true);
    this.orderGet++;
    this.paddingStart.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getPaddingStart = function () {
    if (this.paddingStart == null || this.paddingStart == undefined) {
      this.paddingStart = new widget_CommandAttr();
    }
    return this.paddingStart.getCommandReturnValue();
  };
  ViewImpl.prototype.setPaddingStart = function (value) {
    this.resetIfRequired();
    if (this.paddingStart == null || this.paddingStart == undefined) {
      this.paddingStart = new widget_CommandAttr();
    }
    this.paddingStart.setSetter(true);
    this.paddingStart.setValue(value);
    this.orderSet++;
    this.paddingStart.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetPaddingEnd = function () {
    this.resetIfRequired();
    if (this.paddingEnd == null || this.paddingEnd == undefined) {
      this.paddingEnd = new widget_CommandAttr();
    }
    this.paddingEnd.setGetter(true);
    this.orderGet++;
    this.paddingEnd.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getPaddingEnd = function () {
    if (this.paddingEnd == null || this.paddingEnd == undefined) {
      this.paddingEnd = new widget_CommandAttr();
    }
    return this.paddingEnd.getCommandReturnValue();
  };
  ViewImpl.prototype.setPaddingEnd = function (value) {
    this.resetIfRequired();
    if (this.paddingEnd == null || this.paddingEnd == undefined) {
      this.paddingEnd = new widget_CommandAttr();
    }
    this.paddingEnd.setSetter(true);
    this.paddingEnd.setValue(value);
    this.orderSet++;
    this.paddingEnd.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setPaddingHorizontal = function (value) {
    this.resetIfRequired();
    if (this.paddingHorizontal == null || this.paddingHorizontal == undefined) {
      this.paddingHorizontal = new widget_CommandAttr();
    }
    this.paddingHorizontal.setSetter(true);
    this.paddingHorizontal.setValue(value);
    this.orderSet++;
    this.paddingHorizontal.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setPaddingVertical = function (value) {
    this.resetIfRequired();
    if (this.paddingVertical == null || this.paddingVertical == undefined) {
      this.paddingVertical = new widget_CommandAttr();
    }
    this.paddingVertical.setSetter(true);
    this.paddingVertical.setValue(value);
    this.orderSet++;
    this.paddingVertical.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setLayerType = function (value) {
    this.resetIfRequired();
    if (this.layerType == null || this.layerType == undefined) {
      this.layerType = new widget_CommandAttr();
    }
    this.layerType.setSetter(true);
    this.layerType.setValue(value);
    this.orderSet++;
    this.layerType.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetRequiresFadingEdge = function () {
    this.resetIfRequired();
    if (this.requiresFadingEdge == null || this.requiresFadingEdge == undefined) {
      this.requiresFadingEdge = new widget_CommandAttr();
    }
    this.requiresFadingEdge.setGetter(true);
    this.orderGet++;
    this.requiresFadingEdge.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getRequiresFadingEdge = function () {
    if (this.requiresFadingEdge == null || this.requiresFadingEdge == undefined) {
      this.requiresFadingEdge = new widget_CommandAttr();
    }
    this.requiresFadingEdge.setTransformer('requiresFadingEdge');
    return this.requiresFadingEdge.getCommandReturnValue();
  };
  ViewImpl.prototype.setRequiresFadingEdge = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.requiresFadingEdge == null || this.requiresFadingEdge == undefined) {
      this.requiresFadingEdge = new widget_CommandAttr();
    }
    this.requiresFadingEdge.setSetter(true);
    this.requiresFadingEdge.setValue(value);
    this.orderSet++;
    this.requiresFadingEdge.setOrderSet(this.orderSet);
    this.requiresFadingEdge.setTransformer('requiresFadingEdge');
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetBackground = function () {
    this.resetIfRequired();
    if (this.background == null || this.background == undefined) {
      this.background = new widget_CommandAttr();
    }
    this.background.setGetter(true);
    this.orderGet++;
    this.background.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getBackground = function () {
    if (this.background == null || this.background == undefined) {
      this.background = new widget_CommandAttr();
    }
    return this.background.getCommandReturnValue();
  };
  ViewImpl.prototype.setBackground = function (value) {
    this.resetIfRequired();
    if (this.background == null || this.background == undefined) {
      this.background = new widget_CommandAttr();
    }
    this.background.setSetter(true);
    this.background.setValue(value);
    this.orderSet++;
    this.background.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetForeground = function () {
    this.resetIfRequired();
    if (this.foreground == null || this.foreground == undefined) {
      this.foreground = new widget_CommandAttr();
    }
    this.foreground.setGetter(true);
    this.orderGet++;
    this.foreground.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getForeground = function () {
    if (this.foreground == null || this.foreground == undefined) {
      this.foreground = new widget_CommandAttr();
    }
    return this.foreground.getCommandReturnValue();
  };
  ViewImpl.prototype.setForeground = function (value) {
    this.resetIfRequired();
    if (this.foreground == null || this.foreground == undefined) {
      this.foreground = new widget_CommandAttr();
    }
    this.foreground.setSetter(true);
    this.foreground.setValue(value);
    this.orderSet++;
    this.foreground.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setBackgroundRepeat = function (value) {
    this.resetIfRequired();
    if (this.backgroundRepeat == null || this.backgroundRepeat == undefined) {
      this.backgroundRepeat = new widget_CommandAttr();
    }
    this.backgroundRepeat.setSetter(true);
    this.backgroundRepeat.setValue(value);
    this.orderSet++;
    this.backgroundRepeat.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetModelSyncEvents = function () {
    this.resetIfRequired();
    if (this.modelSyncEvents == null || this.modelSyncEvents == undefined) {
      this.modelSyncEvents = new widget_CommandAttr();
    }
    this.modelSyncEvents.setGetter(true);
    this.orderGet++;
    this.modelSyncEvents.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getModelSyncEvents = function () {
    if (this.modelSyncEvents == null || this.modelSyncEvents == undefined) {
      this.modelSyncEvents = new widget_CommandAttr();
    }
    return this.modelSyncEvents.getCommandReturnValue();
  };
  ViewImpl.prototype.setModelSyncEvents = function (value) {
    this.resetIfRequired();
    if (this.modelSyncEvents == null || this.modelSyncEvents == undefined) {
      this.modelSyncEvents = new widget_CommandAttr();
    }
    this.modelSyncEvents.setSetter(true);
    this.modelSyncEvents.setValue(value);
    this.orderSet++;
    this.modelSyncEvents.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.updateModelData = function (expression, payload) {
    this.resetIfRequired();
    if (this.updateModelData_ == null || this.updateModelData_ == undefined) {
      this.updateModelData_ = new widget_CommandAttr();
    }
    var wrapper = new ScopedObject();
    wrapper.expression = expression;
    wrapper.payload = payload;
    this.updateModelData_.setSetter(true);
    this.updateModelData_.setValue(wrapper);
    this.orderSet++;
    this.updateModelData_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.updateModelDataWithScopedObject = function () {
    var arr = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      arr[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.updateModelData_ == null || this.updateModelData_ == undefined) {
      this.updateModelData_ = new widget_CommandAttr();
    }
    this.updateModelData_.setSetter(true);
    this.updateModelData_.setValue(arr);
    this.orderSet++;
    this.updateModelData_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.notifyDataSetChanged = function (value) {
    this.resetIfRequired();
    if (this.notifyDataSetChanged_ == null || this.notifyDataSetChanged_ == undefined) {
      this.notifyDataSetChanged_ = new widget_CommandAttr();
    }
    this.notifyDataSetChanged_.setSetter(true);
    this.notifyDataSetChanged_.setValue(value);
    this.orderSet++;
    this.notifyDataSetChanged_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetModelParam = function () {
    this.resetIfRequired();
    if (this.modelParam == null || this.modelParam == undefined) {
      this.modelParam = new widget_CommandAttr();
    }
    this.modelParam.setGetter(true);
    this.orderGet++;
    this.modelParam.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getModelParam = function () {
    if (this.modelParam == null || this.modelParam == undefined) {
      this.modelParam = new widget_CommandAttr();
    }
    return this.modelParam.getCommandReturnValue();
  };
  ViewImpl.prototype.setModelParam = function (value) {
    this.resetIfRequired();
    if (this.modelParam == null || this.modelParam == undefined) {
      this.modelParam = new widget_CommandAttr();
    }
    this.modelParam.setSetter(true);
    this.modelParam.setValue(value);
    this.orderSet++;
    this.modelParam.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetModelPojoToUi = function () {
    this.resetIfRequired();
    if (this.modelPojoToUi == null || this.modelPojoToUi == undefined) {
      this.modelPojoToUi = new widget_CommandAttr();
    }
    this.modelPojoToUi.setGetter(true);
    this.orderGet++;
    this.modelPojoToUi.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getModelPojoToUi = function () {
    if (this.modelPojoToUi == null || this.modelPojoToUi == undefined) {
      this.modelPojoToUi = new widget_CommandAttr();
    }
    return this.modelPojoToUi.getCommandReturnValue();
  };
  ViewImpl.prototype.setModelPojoToUi = function (value) {
    this.resetIfRequired();
    if (this.modelPojoToUi == null || this.modelPojoToUi == undefined) {
      this.modelPojoToUi = new widget_CommandAttr();
    }
    this.modelPojoToUi.setSetter(true);
    this.modelPojoToUi.setValue(value);
    this.orderSet++;
    this.modelPojoToUi.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetModelUiToPojo = function () {
    this.resetIfRequired();
    if (this.modelUiToPojo == null || this.modelUiToPojo == undefined) {
      this.modelUiToPojo = new widget_CommandAttr();
    }
    this.modelUiToPojo.setGetter(true);
    this.orderGet++;
    this.modelUiToPojo.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getModelUiToPojo = function () {
    if (this.modelUiToPojo == null || this.modelUiToPojo == undefined) {
      this.modelUiToPojo = new widget_CommandAttr();
    }
    return this.modelUiToPojo.getCommandReturnValue();
  };
  ViewImpl.prototype.setModelUiToPojo = function (value) {
    this.resetIfRequired();
    if (this.modelUiToPojo == null || this.modelUiToPojo == undefined) {
      this.modelUiToPojo = new widget_CommandAttr();
    }
    this.modelUiToPojo.setSetter(true);
    this.modelUiToPojo.setValue(value);
    this.orderSet++;
    this.modelUiToPojo.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setModelPojoToUiParams = function (value) {
    this.resetIfRequired();
    if (this.modelPojoToUiParams == null || this.modelPojoToUiParams == undefined) {
      this.modelPojoToUiParams = new widget_CommandAttr();
    }
    this.modelPojoToUiParams.setSetter(true);
    this.modelPojoToUiParams.setValue(value);
    this.orderSet++;
    this.modelPojoToUiParams.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.refreshUiFromModel = function (value) {
    this.resetIfRequired();
    if (this.refreshUiFromModel_ == null || this.refreshUiFromModel_ == undefined) {
      this.refreshUiFromModel_ = new widget_CommandAttr();
    }
    this.refreshUiFromModel_.setSetter(true);
    this.refreshUiFromModel_.setValue(value);
    this.orderSet++;
    this.refreshUiFromModel_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setModelUiToPojoEventIds = function (value) {
    this.resetIfRequired();
    if (this.modelUiToPojoEventIds == null || this.modelUiToPojoEventIds == undefined) {
      this.modelUiToPojoEventIds = new widget_CommandAttr();
    }
    this.modelUiToPojoEventIds.setSetter(true);
    this.modelUiToPojoEventIds.setValue(value);
    this.orderSet++;
    this.modelUiToPojoEventIds.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setForegroundRepeat = function (value) {
    this.resetIfRequired();
    if (this.foregroundRepeat == null || this.foregroundRepeat == undefined) {
      this.foregroundRepeat = new widget_CommandAttr();
    }
    this.foregroundRepeat.setSetter(true);
    this.foregroundRepeat.setValue(value);
    this.orderSet++;
    this.foregroundRepeat.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetForegroundGravity = function () {
    this.resetIfRequired();
    if (this.foregroundGravity == null || this.foregroundGravity == undefined) {
      this.foregroundGravity = new widget_CommandAttr();
    }
    this.foregroundGravity.setGetter(true);
    this.orderGet++;
    this.foregroundGravity.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getForegroundGravity = function () {
    if (this.foregroundGravity == null || this.foregroundGravity == undefined) {
      this.foregroundGravity = new widget_CommandAttr();
    }
    this.foregroundGravity.setTransformer('gravity');
    return this.foregroundGravity.getCommandReturnValue();
  };
  ViewImpl.prototype.setForegroundGravity = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.foregroundGravity == null || this.foregroundGravity == undefined) {
      this.foregroundGravity = new widget_CommandAttr();
    }
    this.foregroundGravity.setSetter(true);
    this.foregroundGravity.setValue(value);
    this.orderSet++;
    this.foregroundGravity.setOrderSet(this.orderSet);
    this.foregroundGravity.setTransformer('gravity');
    return this.thisPointer;
  };
  ViewImpl.prototype.performHapticFeedback = function (value) {
    this.resetIfRequired();
    if (this.performHapticFeedback_ == null || this.performHapticFeedback_ == undefined) {
      this.performHapticFeedback_ = new widget_CommandAttr();
    }
    this.performHapticFeedback_.setSetter(true);
    this.performHapticFeedback_.setValue(value);
    this.orderSet++;
    this.performHapticFeedback_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.performHapticFeedbackWithFlags = function (value) {
    var flags = [];
    for (var _i = 1; _i < arguments.length; _i++) {
      flags[_i - 1] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.performHapticFeedbackWithFlags_ == null || this.performHapticFeedbackWithFlags_ == undefined) {
      this.performHapticFeedbackWithFlags_ = new widget_CommandAttr();
    }
    var wrapper = new ViewImpl_performHapticFeedbackWithFlags();
    wrapper.value = value;
    wrapper.flags = flags;
    this.performHapticFeedbackWithFlags_.setSetter(true);
    this.performHapticFeedbackWithFlags_.setValue(wrapper);
    this.orderSet++;
    this.performHapticFeedbackWithFlags_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setAttributeUnderTest = function (value) {
    this.resetIfRequired();
    if (this.attributeUnderTest == null || this.attributeUnderTest == undefined) {
      this.attributeUnderTest = new widget_CommandAttr();
    }
    this.attributeUnderTest.setSetter(true);
    this.attributeUnderTest.setValue(value);
    this.orderSet++;
    this.attributeUnderTest.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetSelected = function () {
    this.resetIfRequired();
    if (this.selected == null || this.selected == undefined) {
      this.selected = new widget_CommandAttr();
    }
    this.selected.setGetter(true);
    this.orderGet++;
    this.selected.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isSelected = function () {
    if (this.selected == null || this.selected == undefined) {
      this.selected = new widget_CommandAttr();
    }
    return this.selected.getCommandReturnValue();
  };
  ViewImpl.prototype.setSelected = function (value) {
    this.resetIfRequired();
    if (this.selected == null || this.selected == undefined) {
      this.selected = new widget_CommandAttr();
    }
    this.selected.setSetter(true);
    this.selected.setValue(value);
    this.orderSet++;
    this.selected.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetEnabled = function () {
    this.resetIfRequired();
    if (this.enabled == null || this.enabled == undefined) {
      this.enabled = new widget_CommandAttr();
    }
    this.enabled.setGetter(true);
    this.orderGet++;
    this.enabled.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isEnabled = function () {
    if (this.enabled == null || this.enabled == undefined) {
      this.enabled = new widget_CommandAttr();
    }
    return this.enabled.getCommandReturnValue();
  };
  ViewImpl.prototype.setEnabled = function (value) {
    this.resetIfRequired();
    if (this.enabled == null || this.enabled == undefined) {
      this.enabled = new widget_CommandAttr();
    }
    this.enabled.setSetter(true);
    this.enabled.setValue(value);
    this.orderSet++;
    this.enabled.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetFocusable = function () {
    this.resetIfRequired();
    if (this.focusable == null || this.focusable == undefined) {
      this.focusable = new widget_CommandAttr();
    }
    this.focusable.setGetter(true);
    this.orderGet++;
    this.focusable.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.isFocusable = function () {
    if (this.focusable == null || this.focusable == undefined) {
      this.focusable = new widget_CommandAttr();
    }
    return this.focusable.getCommandReturnValue();
  };
  ViewImpl.prototype.setFocusable = function (value) {
    this.resetIfRequired();
    if (this.focusable == null || this.focusable == undefined) {
      this.focusable = new widget_CommandAttr();
    }
    this.focusable.setSetter(true);
    this.focusable.setValue(value);
    this.orderSet++;
    this.focusable.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollX = function () {
    this.resetIfRequired();
    if (this.scrollX == null || this.scrollX == undefined) {
      this.scrollX = new widget_CommandAttr();
    }
    this.scrollX.setGetter(true);
    this.orderGet++;
    this.scrollX.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollX = function () {
    if (this.scrollX == null || this.scrollX == undefined) {
      this.scrollX = new widget_CommandAttr();
    }
    return this.scrollX.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollX = function (value) {
    this.resetIfRequired();
    if (this.scrollX == null || this.scrollX == undefined) {
      this.scrollX = new widget_CommandAttr();
    }
    this.scrollX.setSetter(true);
    this.scrollX.setValue(value);
    this.orderSet++;
    this.scrollX.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetScrollY = function () {
    this.resetIfRequired();
    if (this.scrollY == null || this.scrollY == undefined) {
      this.scrollY = new widget_CommandAttr();
    }
    this.scrollY.setGetter(true);
    this.orderGet++;
    this.scrollY.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getScrollY = function () {
    if (this.scrollY == null || this.scrollY == undefined) {
      this.scrollY = new widget_CommandAttr();
    }
    return this.scrollY.getCommandReturnValue();
  };
  ViewImpl.prototype.setScrollY = function (value) {
    this.resetIfRequired();
    if (this.scrollY == null || this.scrollY == undefined) {
      this.scrollY = new widget_CommandAttr();
    }
    this.scrollY.setSetter(true);
    this.scrollY.setValue(value);
    this.orderSet++;
    this.scrollY.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.invalidate = function () {
    this.resetIfRequired();
    if (this.invalidate_ == null || this.invalidate_ == undefined) {
      this.invalidate_ = new widget_CommandAttr();
    }
    this.invalidate_.setSetter(true);
    this.orderSet++;
    this.invalidate_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.requestLayout = function () {
    this.resetIfRequired();
    if (this.requestLayout_ == null || this.requestLayout_ == undefined) {
      this.requestLayout_ = new widget_CommandAttr();
    }
    this.requestLayout_.setSetter(true);
    this.orderSet++;
    this.requestLayout_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setAsDragSource = function (value) {
    this.resetIfRequired();
    if (this.asDragSource == null || this.asDragSource == undefined) {
      this.asDragSource = new widget_CommandAttr();
    }
    this.asDragSource.setSetter(true);
    this.asDragSource.setValue(value);
    this.orderSet++;
    this.asDragSource.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setZIndex = function (value) {
    this.resetIfRequired();
    if (this.zIndex == null || this.zIndex == undefined) {
      this.zIndex = new widget_CommandAttr();
    }
    this.zIndex.setSetter(true);
    this.zIndex.setValue(value);
    this.orderSet++;
    this.zIndex.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetMaxWidth = function () {
    this.resetIfRequired();
    if (this.maxWidth == null || this.maxWidth == undefined) {
      this.maxWidth = new widget_CommandAttr();
    }
    this.maxWidth.setGetter(true);
    this.orderGet++;
    this.maxWidth.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getMaxWidth = function () {
    if (this.maxWidth == null || this.maxWidth == undefined) {
      this.maxWidth = new widget_CommandAttr();
    }
    return this.maxWidth.getCommandReturnValue();
  };
  ViewImpl.prototype.setMaxWidth = function (value) {
    this.resetIfRequired();
    if (this.maxWidth == null || this.maxWidth == undefined) {
      this.maxWidth = new widget_CommandAttr();
    }
    this.maxWidth.setSetter(true);
    this.maxWidth.setValue(value);
    this.orderSet++;
    this.maxWidth.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetMaxHeight = function () {
    this.resetIfRequired();
    if (this.maxHeight == null || this.maxHeight == undefined) {
      this.maxHeight = new widget_CommandAttr();
    }
    this.maxHeight.setGetter(true);
    this.orderGet++;
    this.maxHeight.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getMaxHeight = function () {
    if (this.maxHeight == null || this.maxHeight == undefined) {
      this.maxHeight = new widget_CommandAttr();
    }
    return this.maxHeight.getCommandReturnValue();
  };
  ViewImpl.prototype.setMaxHeight = function (value) {
    this.resetIfRequired();
    if (this.maxHeight == null || this.maxHeight == undefined) {
      this.maxHeight = new widget_CommandAttr();
    }
    this.maxHeight.setSetter(true);
    this.maxHeight.setValue(value);
    this.orderSet++;
    this.maxHeight.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setStyle = function (value) {
    this.resetIfRequired();
    if (this.style == null || this.style == undefined) {
      this.style = new widget_CommandAttr();
    }
    this.style.setSetter(true);
    this.style.setValue(value);
    this.orderSet++;
    this.style.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setErrorStyle = function (value) {
    this.resetIfRequired();
    if (this.errorStyle == null || this.errorStyle == undefined) {
      this.errorStyle = new widget_CommandAttr();
    }
    this.errorStyle.setSetter(true);
    this.errorStyle.setValue(value);
    this.orderSet++;
    this.errorStyle.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetValidateForm = function () {
    this.resetIfRequired();
    if (this.validateForm_ == null || this.validateForm_ == undefined) {
      this.validateForm_ = new widget_CommandAttr();
    }
    this.validateForm_.setGetter(true);
    this.orderGet++;
    this.validateForm_.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getValidateForm = function () {
    if (this.validateForm_ == null || this.validateForm_ == undefined) {
      this.validateForm_ = new widget_CommandAttr();
    }
    return this.validateForm_.getCommandReturnValue();
  };
  ViewImpl.prototype.validateForm = function (value) {
    this.resetIfRequired();
    if (this.validateForm_ == null || this.validateForm_ == undefined) {
      this.validateForm_ = new widget_CommandAttr();
    }
    this.validateForm_.setSetter(true);
    this.validateForm_.setValue(value);
    this.orderSet++;
    this.validateForm_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setValidation = function (value) {
    this.resetIfRequired();
    if (this.validation == null || this.validation == undefined) {
      this.validation = new widget_CommandAttr();
    }
    this.validation.setSetter(true);
    this.validation.setValue(value);
    this.orderSet++;
    this.validation.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_required = function (value) {
    this.resetIfRequired();
    if (this.v_required == null || this.v_required == undefined) {
      this.v_required = new widget_CommandAttr();
    }
    this.v_required.setSetter(true);
    this.v_required.setValue(value);
    this.orderSet++;
    this.v_required.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_minlength = function (value) {
    this.resetIfRequired();
    if (this.v_minlength == null || this.v_minlength == undefined) {
      this.v_minlength = new widget_CommandAttr();
    }
    this.v_minlength.setSetter(true);
    this.v_minlength.setValue(value);
    this.orderSet++;
    this.v_minlength.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_maxlength = function (value) {
    this.resetIfRequired();
    if (this.v_maxlength == null || this.v_maxlength == undefined) {
      this.v_maxlength = new widget_CommandAttr();
    }
    this.v_maxlength.setSetter(true);
    this.v_maxlength.setValue(value);
    this.orderSet++;
    this.v_maxlength.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_min = function (value) {
    this.resetIfRequired();
    if (this.v_min == null || this.v_min == undefined) {
      this.v_min = new widget_CommandAttr();
    }
    this.v_min.setSetter(true);
    this.v_min.setValue(value);
    this.orderSet++;
    this.v_min.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_max = function (value) {
    this.resetIfRequired();
    if (this.v_max == null || this.v_max == undefined) {
      this.v_max = new widget_CommandAttr();
    }
    this.v_max.setSetter(true);
    this.v_max.setValue(value);
    this.orderSet++;
    this.v_max.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_pattern = function (value) {
    this.resetIfRequired();
    if (this.v_pattern == null || this.v_pattern == undefined) {
      this.v_pattern = new widget_CommandAttr();
    }
    this.v_pattern.setSetter(true);
    this.v_pattern.setValue(value);
    this.orderSet++;
    this.v_pattern.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setV_type = function (value) {
    this.resetIfRequired();
    if (this.v_type == null || this.v_type == undefined) {
      this.v_type = new widget_CommandAttr();
    }
    this.v_type.setSetter(true);
    this.v_type.setValue(value);
    this.orderSet++;
    this.v_type.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setValidationErrorDisplayType = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.validationErrorDisplayType == null || this.validationErrorDisplayType == undefined) {
      this.validationErrorDisplayType = new widget_CommandAttr();
    }
    this.validationErrorDisplayType.setSetter(true);
    this.validationErrorDisplayType.setValue(value);
    this.orderSet++;
    this.validationErrorDisplayType.setOrderSet(this.orderSet);
    this.validationErrorDisplayType.setTransformer('validationErrorDisplay');
    return this.thisPointer;
  };
  ViewImpl.prototype.setCustomErrorMessageValues = function (value) {
    this.resetIfRequired();
    if (this.customErrorMessageValues == null || this.customErrorMessageValues == undefined) {
      this.customErrorMessageValues = new widget_CommandAttr();
    }
    this.customErrorMessageValues.setSetter(true);
    this.customErrorMessageValues.setValue(value);
    this.orderSet++;
    this.customErrorMessageValues.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setCustomErrorMessageKeys = function (value) {
    this.resetIfRequired();
    if (this.customErrorMessageKeys == null || this.customErrorMessageKeys == undefined) {
      this.customErrorMessageKeys = new widget_CommandAttr();
    }
    this.customErrorMessageKeys.setSetter(true);
    this.customErrorMessageKeys.setValue(value);
    this.orderSet++;
    this.customErrorMessageKeys.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setInvalidateOnFrameChange = function (value) {
    this.resetIfRequired();
    if (this.invalidateOnFrameChange == null || this.invalidateOnFrameChange == undefined) {
      this.invalidateOnFrameChange = new widget_CommandAttr();
    }
    this.invalidateOnFrameChange.setSetter(true);
    this.invalidateOnFrameChange.setValue(value);
    this.orderSet++;
    this.invalidateOnFrameChange.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnSwiped = function (value) {
    this.resetIfRequired();
    if (this.onSwiped == null || this.onSwiped == undefined) {
      this.onSwiped = new widget_CommandAttr();
    }
    this.onSwiped.setSetter(true);
    this.onSwiped.setValue(value);
    this.orderSet++;
    this.onSwiped.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.animatorXml = function (value) {
    this.resetIfRequired();
    if (this.animatorXml_ == null || this.animatorXml_ == undefined) {
      this.animatorXml_ = new widget_CommandAttr();
    }
    this.animatorXml_.setSetter(true);
    this.animatorXml_.setValue(value);
    this.orderSet++;
    this.animatorXml_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.startAnimator = function () {
    this.resetIfRequired();
    if (this.startAnimator_ == null || this.startAnimator_ == undefined) {
      this.startAnimator_ = new widget_CommandAttr();
    }
    this.startAnimator_.setSetter(true);
    this.orderSet++;
    this.startAnimator_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.endAnimator = function () {
    this.resetIfRequired();
    if (this.endAnimator_ == null || this.endAnimator_ == undefined) {
      this.endAnimator_ = new widget_CommandAttr();
    }
    this.endAnimator_.setSetter(true);
    this.orderSet++;
    this.endAnimator_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnAnimationStart = function (value) {
    this.resetIfRequired();
    if (this.onAnimationStart == null || this.onAnimationStart == undefined) {
      this.onAnimationStart = new widget_CommandAttr();
    }
    this.onAnimationStart.setSetter(true);
    this.onAnimationStart.setValue(value);
    this.orderSet++;
    this.onAnimationStart.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnAnimationEnd = function (value) {
    this.resetIfRequired();
    if (this.onAnimationEnd == null || this.onAnimationEnd == undefined) {
      this.onAnimationEnd = new widget_CommandAttr();
    }
    this.onAnimationEnd.setSetter(true);
    this.onAnimationEnd.setValue(value);
    this.orderSet++;
    this.onAnimationEnd.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnAnimationCancel = function (value) {
    this.resetIfRequired();
    if (this.onAnimationCancel == null || this.onAnimationCancel == undefined) {
      this.onAnimationCancel = new widget_CommandAttr();
    }
    this.onAnimationCancel.setSetter(true);
    this.onAnimationCancel.setValue(value);
    this.orderSet++;
    this.onAnimationCancel.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOnAnimationRepeat = function (value) {
    this.resetIfRequired();
    if (this.onAnimationRepeat == null || this.onAnimationRepeat == undefined) {
      this.onAnimationRepeat = new widget_CommandAttr();
    }
    this.onAnimationRepeat.setSetter(true);
    this.onAnimationRepeat.setValue(value);
    this.orderSet++;
    this.onAnimationRepeat.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetLeft = function () {
    this.resetIfRequired();
    if (this.left == null || this.left == undefined) {
      this.left = new widget_CommandAttr();
    }
    this.left.setGetter(true);
    this.orderGet++;
    this.left.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getLeft = function () {
    if (this.left == null || this.left == undefined) {
      this.left = new widget_CommandAttr();
    }
    return this.left.getCommandReturnValue();
  };
  ViewImpl.prototype.setLeft = function (value) {
    this.resetIfRequired();
    if (this.left == null || this.left == undefined) {
      this.left = new widget_CommandAttr();
    }
    this.left.setSetter(true);
    this.left.setValue(value);
    this.orderSet++;
    this.left.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetRight = function () {
    this.resetIfRequired();
    if (this.right == null || this.right == undefined) {
      this.right = new widget_CommandAttr();
    }
    this.right.setGetter(true);
    this.orderGet++;
    this.right.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getRight = function () {
    if (this.right == null || this.right == undefined) {
      this.right = new widget_CommandAttr();
    }
    return this.right.getCommandReturnValue();
  };
  ViewImpl.prototype.setRight = function (value) {
    this.resetIfRequired();
    if (this.right == null || this.right == undefined) {
      this.right = new widget_CommandAttr();
    }
    this.right.setSetter(true);
    this.right.setValue(value);
    this.orderSet++;
    this.right.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetTop = function () {
    this.resetIfRequired();
    if (this.top == null || this.top == undefined) {
      this.top = new widget_CommandAttr();
    }
    this.top.setGetter(true);
    this.orderGet++;
    this.top.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getTop = function () {
    if (this.top == null || this.top == undefined) {
      this.top = new widget_CommandAttr();
    }
    return this.top.getCommandReturnValue();
  };
  ViewImpl.prototype.setTop = function (value) {
    this.resetIfRequired();
    if (this.top == null || this.top == undefined) {
      this.top = new widget_CommandAttr();
    }
    this.top.setSetter(true);
    this.top.setValue(value);
    this.orderSet++;
    this.top.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.tryGetBottom = function () {
    this.resetIfRequired();
    if (this.bottom == null || this.bottom == undefined) {
      this.bottom = new widget_CommandAttr();
    }
    this.bottom.setGetter(true);
    this.orderGet++;
    this.bottom.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewImpl.prototype.getBottom = function () {
    if (this.bottom == null || this.bottom == undefined) {
      this.bottom = new widget_CommandAttr();
    }
    return this.bottom.getCommandReturnValue();
  };
  ViewImpl.prototype.setBottom = function (value) {
    this.resetIfRequired();
    if (this.bottom == null || this.bottom == undefined) {
      this.bottom = new widget_CommandAttr();
    }
    this.bottom.setSetter(true);
    this.bottom.setValue(value);
    this.orderSet++;
    this.bottom.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOutlineAmbientShadowColor = function (value) {
    this.resetIfRequired();
    if (this.outlineAmbientShadowColor == null || this.outlineAmbientShadowColor == undefined) {
      this.outlineAmbientShadowColor = new widget_CommandAttr();
    }
    this.outlineAmbientShadowColor.setSetter(true);
    this.outlineAmbientShadowColor.setValue(value);
    this.orderSet++;
    this.outlineAmbientShadowColor.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setOutlineSpotShadowColor = function (value) {
    this.resetIfRequired();
    if (this.outlineSpotShadowColor == null || this.outlineSpotShadowColor == undefined) {
      this.outlineSpotShadowColor = new widget_CommandAttr();
    }
    this.outlineSpotShadowColor.setSetter(true);
    this.outlineSpotShadowColor.setValue(value);
    this.orderSet++;
    this.outlineSpotShadowColor.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl.prototype.setCornerRadius = function (value) {
    this.resetIfRequired();
    if (this.cornerRadius == null || this.cornerRadius == undefined) {
      this.cornerRadius = new widget_CommandAttr();
    }
    this.cornerRadius.setSetter(true);
    this.cornerRadius.setValue(value);
    this.orderSet++;
    this.cornerRadius.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "accessibilityHeading"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "accessibilityHeading", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "accessibilityLiveRegion"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "accessibilityLiveRegion", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "accessibilityPaneTitle"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "accessibilityPaneTitle", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "accessibilityTraversalAfter"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "accessibilityTraversalAfter", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "accessibilityTraversalBefore"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "accessibilityTraversalBefore", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "alpha"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "alpha", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "autofillHints"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "autofillHints", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "backgroundTint"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "backgroundTint", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "backgroundTintMode"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "backgroundTintMode", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "clickable"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "clickable", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "contentDescription"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "contentDescription", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "contextClickable"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "contextClickable", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "defaultFocusHighlightEnabled"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "defaultFocusHighlightEnabled", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "duplicateParentState"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "duplicateParentState", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "elevation"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "elevation", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "fadeScrollbars"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "fadeScrollbars", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "fadingEdgeLength"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "fadingEdgeLength", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "filterTouchesWhenObscured"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "filterTouchesWhenObscured", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "fitsSystemWindows"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "fitsSystemWindows", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "focusableInTouchMode"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "focusableInTouchMode", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "focusedByDefault"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "focusedByDefault", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "forceHasOverlappingRendering"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "forceHasOverlappingRendering", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "foregroundTint"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "foregroundTint", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "foregroundTintMode"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "foregroundTintMode", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "hapticFeedbackEnabled"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "hapticFeedbackEnabled", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "importantForAccessibility"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "importantForAccessibility", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "importantForAutofill"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "importantForAutofill", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "isScrollContainer"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "isScrollContainer", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "keepScreenOn"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "keepScreenOn", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "keyboardNavigationCluster"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "keyboardNavigationCluster", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layoutDirection"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "layoutDirection", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "longClickable"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "longClickable", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "minHeight"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "minHeight", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "minWidth"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "minWidth", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "nextClusterForward"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "nextClusterForward", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "nextFocusDown"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "nextFocusDown", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "nextFocusForward"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "nextFocusForward", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "nextFocusLeft"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "nextFocusLeft", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "nextFocusRight"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "nextFocusRight", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "nextFocusUp"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "nextFocusUp", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "rotation"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "rotation", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "rotationX"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "rotationX", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "rotationY"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "rotationY", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "saveEnabled"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "saveEnabled", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "scaleX"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "scaleX", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "scaleY"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "scaleY", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "screenReaderFocusable"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "screenReaderFocusable", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "scrollIndicators"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "scrollIndicators", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "scrollbarDefaultDelayBeforeFade"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "scrollbarDefaultDelayBeforeFade", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "scrollbarFadeDuration"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "scrollbarFadeDuration", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "scrollbarSize"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "scrollbarSize", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "scrollbarStyle"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "scrollbarStyle", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "soundEffectsEnabled"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "soundEffectsEnabled", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "textAlignment"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "textAlignment", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "textDirection"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "textDirection", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "tooltipText"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "tooltipText", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "transformPivotX"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "transformPivotX", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "transformPivotY"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "transformPivotY", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "transitionName"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "transitionName", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "translationX"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "translationX", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "translationY"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "translationY", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "translationZ"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "translationZ", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "visibility"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "visibility", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onApplyWindowInsets"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onApplyWindowInsets", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onCapturedPointer"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onCapturedPointer", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onClick"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onClick", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onContextClick"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onContextClick", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onCreateContextMenu"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onCreateContextMenu", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onDrag"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onDrag", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onFocusChange"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onFocusChange", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onGenericMotion"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onGenericMotion", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onHover"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onHover", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onKey"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onKey", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onLongClick"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onLongClick", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onScrollChange"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onScrollChange", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onSystemUiVisibilityChange"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onSystemUiVisibilityChange", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onTouch"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onTouch", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "padding"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "padding", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "paddingTop"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "paddingTop", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "paddingBottom"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "paddingBottom", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "paddingLeft"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "paddingLeft", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "paddingRight"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "paddingRight", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "paddingStart"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "paddingStart", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "paddingEnd"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "paddingEnd", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "paddingHorizontal"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "paddingHorizontal", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "paddingVertical"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "paddingVertical", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layerType"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "layerType", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "requiresFadingEdge"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "requiresFadingEdge", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "background"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "background", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "foreground"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "foreground", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "backgroundRepeat"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "backgroundRepeat", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "modelSyncEvents"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "modelSyncEvents", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "updateModelData"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "updateModelData_", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "notifyDataSetChanged"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "notifyDataSetChanged_", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "modelParam"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "modelParam", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "modelPojoToUi"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "modelPojoToUi", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "modelUiToPojo"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "modelUiToPojo", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "modelPojoToUiParams"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "modelPojoToUiParams", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "refreshUiFromModel"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "refreshUiFromModel_", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "modelUiToPojoEventIds"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "modelUiToPojoEventIds", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "foregroundRepeat"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "foregroundRepeat", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "foregroundGravity"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "foregroundGravity", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "performHapticFeedback"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "performHapticFeedback_", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "performHapticFeedbackWithFlags"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "performHapticFeedbackWithFlags_", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "attributeUnderTest"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "attributeUnderTest", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "selected"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "selected", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "enabled"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "enabled", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "focusable"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "focusable", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "scrollX"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "scrollX", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "scrollY"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "scrollY", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "invalidate"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "invalidate_", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "requestLayout"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "requestLayout_", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "asDragSource"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "asDragSource", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "zIndex"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "zIndex", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "maxWidth"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "maxWidth", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "maxHeight"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "maxHeight", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "style"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "style", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "errorStyle"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "errorStyle", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "validateForm"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "validateForm_", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "validation"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "validation", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "v_required"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "v_required", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "v_minlength"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "v_minlength", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "v_maxlength"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "v_maxlength", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "v_min"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "v_min", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "v_max"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "v_max", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "v_pattern"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "v_pattern", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "v_type"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "v_type", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "validationErrorDisplayType"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "validationErrorDisplayType", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "customErrorMessageValues"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "customErrorMessageValues", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "customErrorMessageKeys"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "customErrorMessageKeys", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "invalidateOnFrameChange"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "invalidateOnFrameChange", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onSwiped"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onSwiped", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "animatorXml"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "animatorXml_", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "startAnimator"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "startAnimator_", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "endAnimator"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "endAnimator_", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onAnimationStart"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onAnimationStart", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onAnimationEnd"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onAnimationEnd", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onAnimationCancel"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onAnimationCancel", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onAnimationRepeat"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "onAnimationRepeat", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "left"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "left", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "right"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "right", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "top"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "top", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "bottom"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "bottom", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "outlineAmbientShadowColor"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "outlineAmbientShadowColor", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "outlineSpotShadowColor"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "outlineSpotShadowColor", void 0);
  ViewImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "cornerRadius"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "cornerRadius", void 0);
  ViewImpl_decorate([decorate(Exclude()), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "thisPointer", void 0);
  ViewImpl_decorate([decorate(Exclude()), ViewImpl_metadata("design:type", Number)], ViewImpl.prototype, "orderGet", void 0);
  ViewImpl_decorate([decorate(Exclude()), ViewImpl_metadata("design:type", Number)], ViewImpl.prototype, "orderSet", void 0);
  ViewImpl_decorate([decorate(Expose({
    name: "layoutParams"
  })), ViewImpl_metadata("design:type", Object)], ViewImpl.prototype, "layoutParams", void 0);
  return ViewImpl;
}();

//start - staticinit
var View = /** @class */function (_super) {
  ViewImpl_extends(View, _super);
  function View(id, path, event) {
    return _super.call(this, id, path, event) || this;
  }
  View.prototype.getThisPointer = function () {
    return this;
  };
  View.prototype.getClass = function () {
    return View;
  };
  return View;
}(ViewImpl);

ViewImpl.initialize();
//end - staticinit
;// ./src/android/widget/ViewGroupModelImpl.ts
function ViewGroupModelImpl_typeof(o) { "@babel/helpers - typeof"; return ViewGroupModelImpl_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, ViewGroupModelImpl_typeof(o); }
// start - imports
var ViewGroupModelImpl_extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var ViewGroupModelImpl_decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : ViewGroupModelImpl_typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ViewGroupModelImpl_metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : ViewGroupModelImpl_typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



// end - imports

var ViewGroupModelImpl = /** @class */function (_super) {
  ViewGroupModelImpl_extends(ViewGroupModelImpl, _super);
  function ViewGroupModelImpl(id, path, event) {
    var _this = _super.call(this, id, path, event) || this;
    _this.thisPointer = _this.getThisPointer();
    return _this;
  }
  //start - body
  ViewGroupModelImpl.initialize = function () {};
  ViewGroupModelImpl.prototype.reset = function () {
    _super.prototype.reset.call(this);
    this.addModel_ = undefined;
    this.addAllModel_ = undefined;
    this.addModelByIndex_ = undefined;
    this.removeModelAtIndex_ = undefined;
    this.removeModelById_ = undefined;
    this.modelFor = undefined;
    this.modelIdPath = undefined;
    this.modelDescPath = undefined;
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.addModel = function (value) {
    this.resetIfRequired();
    if (this.addModel_ == null || this.addModel_ == undefined) {
      this.addModel_ = new widget_CommandAttr();
    }
    this.addModel_.setSetter(true);
    this.addModel_.setValue(value);
    this.orderSet++;
    this.addModel_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.addAllModel = function (value) {
    this.resetIfRequired();
    if (this.addAllModel_ == null || this.addAllModel_ == undefined) {
      this.addAllModel_ = new widget_CommandAttr();
    }
    this.addAllModel_.setSetter(true);
    this.addAllModel_.setValue(value);
    this.orderSet++;
    this.addAllModel_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.addModelByIndex = function (value, index) {
    this.resetIfRequired();
    if (this.addModelByIndex_ == null || this.addModelByIndex_ == undefined) {
      this.addModelByIndex_ = new widget_CommandAttr();
    }
    var wrapper = {};
    wrapper["index"] = index;
    wrapper["data"] = value;
    this.addModelByIndex_.setSetter(true);
    this.addModelByIndex_.setValue(wrapper);
    this.orderSet++;
    this.addModelByIndex_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.removeModelAtIndex = function (value) {
    this.resetIfRequired();
    if (this.removeModelAtIndex_ == null || this.removeModelAtIndex_ == undefined) {
      this.removeModelAtIndex_ = new widget_CommandAttr();
    }
    this.removeModelAtIndex_.setSetter(true);
    this.removeModelAtIndex_.setValue(value);
    this.orderSet++;
    this.removeModelAtIndex_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.removeModelById = function (value) {
    this.resetIfRequired();
    if (this.removeModelById_ == null || this.removeModelById_ == undefined) {
      this.removeModelById_ = new widget_CommandAttr();
    }
    this.removeModelById_.setSetter(true);
    this.removeModelById_.setValue(value);
    this.orderSet++;
    this.removeModelById_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.setModelFor = function (value) {
    this.resetIfRequired();
    if (this.modelFor == null || this.modelFor == undefined) {
      this.modelFor = new widget_CommandAttr();
    }
    this.modelFor.setSetter(true);
    this.modelFor.setValue(value);
    this.orderSet++;
    this.modelFor.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.tryGetModelIdPath = function () {
    this.resetIfRequired();
    if (this.modelIdPath == null || this.modelIdPath == undefined) {
      this.modelIdPath = new widget_CommandAttr();
    }
    this.modelIdPath.setGetter(true);
    this.orderGet++;
    this.modelIdPath.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.getModelIdPath = function () {
    if (this.modelIdPath == null || this.modelIdPath == undefined) {
      this.modelIdPath = new widget_CommandAttr();
    }
    return this.modelIdPath.getCommandReturnValue();
  };
  ViewGroupModelImpl.prototype.setModelIdPath = function (value) {
    this.resetIfRequired();
    if (this.modelIdPath == null || this.modelIdPath == undefined) {
      this.modelIdPath = new widget_CommandAttr();
    }
    this.modelIdPath.setSetter(true);
    this.modelIdPath.setValue(value);
    this.orderSet++;
    this.modelIdPath.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.tryGetModelDescPath = function () {
    this.resetIfRequired();
    if (this.modelDescPath == null || this.modelDescPath == undefined) {
      this.modelDescPath = new widget_CommandAttr();
    }
    this.modelDescPath.setGetter(true);
    this.orderGet++;
    this.modelDescPath.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupModelImpl.prototype.getModelDescPath = function () {
    if (this.modelDescPath == null || this.modelDescPath == undefined) {
      this.modelDescPath = new widget_CommandAttr();
    }
    return this.modelDescPath.getCommandReturnValue();
  };
  ViewGroupModelImpl.prototype.setModelDescPath = function (value) {
    this.resetIfRequired();
    if (this.modelDescPath == null || this.modelDescPath == undefined) {
      this.modelDescPath = new widget_CommandAttr();
    }
    this.modelDescPath.setSetter(true);
    this.modelDescPath.setValue(value);
    this.orderSet++;
    this.modelDescPath.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupModelImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "addModel"
  })), ViewGroupModelImpl_metadata("design:type", Object)], ViewGroupModelImpl.prototype, "addModel_", void 0);
  ViewGroupModelImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "addAllModel"
  })), ViewGroupModelImpl_metadata("design:type", Object)], ViewGroupModelImpl.prototype, "addAllModel_", void 0);
  ViewGroupModelImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "addModelByIndex"
  })), ViewGroupModelImpl_metadata("design:type", Object)], ViewGroupModelImpl.prototype, "addModelByIndex_", void 0);
  ViewGroupModelImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "removeModelAtIndex"
  })), ViewGroupModelImpl_metadata("design:type", Object)], ViewGroupModelImpl.prototype, "removeModelAtIndex_", void 0);
  ViewGroupModelImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "removeModelById"
  })), ViewGroupModelImpl_metadata("design:type", Object)], ViewGroupModelImpl.prototype, "removeModelById_", void 0);
  ViewGroupModelImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "modelFor"
  })), ViewGroupModelImpl_metadata("design:type", Object)], ViewGroupModelImpl.prototype, "modelFor", void 0);
  ViewGroupModelImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "modelIdPath"
  })), ViewGroupModelImpl_metadata("design:type", Object)], ViewGroupModelImpl.prototype, "modelIdPath", void 0);
  ViewGroupModelImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "modelDescPath"
  })), ViewGroupModelImpl_metadata("design:type", Object)], ViewGroupModelImpl.prototype, "modelDescPath", void 0);
  ViewGroupModelImpl_decorate([decorate(Exclude()), ViewGroupModelImpl_metadata("design:type", Object)], ViewGroupModelImpl.prototype, "thisPointer", void 0);
  return ViewGroupModelImpl;
}(ViewImpl);

//start - staticinit
var ViewGroupModel = /** @class */function (_super) {
  ViewGroupModelImpl_extends(ViewGroupModel, _super);
  function ViewGroupModel(id, path, event) {
    return _super.call(this, id, path, event) || this;
  }
  ViewGroupModel.prototype.getThisPointer = function () {
    return this;
  };
  ViewGroupModel.prototype.getClass = function () {
    return ViewGroupModel;
  };
  return ViewGroupModel;
}(ViewGroupModelImpl);

ViewGroupModelImpl.initialize();
//end - staticinit
;// ./src/android/widget/ViewGroupImpl.ts
function ViewGroupImpl_typeof(o) { "@babel/helpers - typeof"; return ViewGroupImpl_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, ViewGroupImpl_typeof(o); }
// start - imports
var ViewGroupImpl_extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var ViewGroupImpl_decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : ViewGroupImpl_typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ViewGroupImpl_metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : ViewGroupImpl_typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var PersistentDrawingCacheTransformer = /** @class */function () {
  function PersistentDrawingCacheTransformer() {}
  PersistentDrawingCacheTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "all":
            valueArr.push("all" /* PersistentDrawingCache.all */);
            break;
          case "animation":
            valueArr.push("animation" /* PersistentDrawingCache.animation */);
            break;
          case "none":
            valueArr.push("none" /* PersistentDrawingCache.none */);
            break;
          case "scrolling":
            valueArr.push("scrolling" /* PersistentDrawingCache.scrolling */);
            break;
        }
      }
      return valueArr;
    }
  };
  return PersistentDrawingCacheTransformer;
}();

var LayoutTransitionTransformer = /** @class */function () {
  function LayoutTransitionTransformer() {}
  LayoutTransitionTransformer.prototype.transform = function (value, obj, type) {
    if (type == 1) {
      return value.toString().replace(",", "|");
    } else {
      var strArray = value.toString().split("|");
      var valueArr = new Array();
      for (var i = 0; i < strArray.length; i++) {
        switch (strArray[i]) {
          case "change_appearing":
            valueArr.push("change_appearing" /* LayoutTransition.change_appearing */);
            break;
          case "change_disappearing":
            valueArr.push("change_disappearing" /* LayoutTransition.change_disappearing */);
            break;
          case "appearing":
            valueArr.push("appearing" /* LayoutTransition.appearing */);
            break;
          case "disappearing":
            valueArr.push("disappearing" /* LayoutTransition.disappearing */);
            break;
          case "changing":
            valueArr.push("changing" /* LayoutTransition.changing */);
            break;
        }
      }
      return valueArr;
    }
  };
  return LayoutTransitionTransformer;
}();

// end - imports

var ViewGroupImpl = /** @class */function (_super) {
  ViewGroupImpl_extends(ViewGroupImpl, _super);
  function ViewGroupImpl(id, path, event) {
    var _this = _super.call(this, id, path, event) || this;
    _this.thisPointer = _this.getThisPointer();
    return _this;
  }
  //start - body
  ViewGroupImpl.initialize = function () {
    TransformerFactory.getInstance().register("persistentDrawingCache", new PersistentDrawingCacheTransformer());
    TransformerFactory.getInstance().register("layoutTransition", new LayoutTransitionTransformer());
  };
  ViewGroupImpl.prototype.reset = function () {
    _super.prototype.reset.call(this);
    this.alwaysDrawnWithCache = undefined;
    this.animationCache = undefined;
    this.clipChildren = undefined;
    this.clipToPadding = undefined;
    this.descendantFocusability = undefined;
    this.layoutMode = undefined;
    this.persistentDrawingCache = undefined;
    this.splitMotionEvents = undefined;
    this.onChildViewAdded = undefined;
    this.onChildViewRemoved = undefined;
    this.animateLayoutChanges = undefined;
    this.layoutTransition = undefined;
    this.layoutTransitionDuration = undefined;
    this.animateParentHierarchy = undefined;
    this.listitem = undefined;
    this.addStatesFromChildren = undefined;
    this.childXml = undefined;
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetAlwaysDrawnWithCache = function () {
    this.resetIfRequired();
    if (this.alwaysDrawnWithCache == null || this.alwaysDrawnWithCache == undefined) {
      this.alwaysDrawnWithCache = new widget_CommandAttr();
    }
    this.alwaysDrawnWithCache.setGetter(true);
    this.orderGet++;
    this.alwaysDrawnWithCache.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.isAlwaysDrawnWithCache = function () {
    if (this.alwaysDrawnWithCache == null || this.alwaysDrawnWithCache == undefined) {
      this.alwaysDrawnWithCache = new widget_CommandAttr();
    }
    return this.alwaysDrawnWithCache.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setAlwaysDrawnWithCache = function (value) {
    this.resetIfRequired();
    if (this.alwaysDrawnWithCache == null || this.alwaysDrawnWithCache == undefined) {
      this.alwaysDrawnWithCache = new widget_CommandAttr();
    }
    this.alwaysDrawnWithCache.setSetter(true);
    this.alwaysDrawnWithCache.setValue(value);
    this.orderSet++;
    this.alwaysDrawnWithCache.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetAnimationCache = function () {
    this.resetIfRequired();
    if (this.animationCache == null || this.animationCache == undefined) {
      this.animationCache = new widget_CommandAttr();
    }
    this.animationCache.setGetter(true);
    this.orderGet++;
    this.animationCache.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.isAnimationCache = function () {
    if (this.animationCache == null || this.animationCache == undefined) {
      this.animationCache = new widget_CommandAttr();
    }
    return this.animationCache.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setAnimationCache = function (value) {
    this.resetIfRequired();
    if (this.animationCache == null || this.animationCache == undefined) {
      this.animationCache = new widget_CommandAttr();
    }
    this.animationCache.setSetter(true);
    this.animationCache.setValue(value);
    this.orderSet++;
    this.animationCache.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetClipChildren = function () {
    this.resetIfRequired();
    if (this.clipChildren == null || this.clipChildren == undefined) {
      this.clipChildren = new widget_CommandAttr();
    }
    this.clipChildren.setGetter(true);
    this.orderGet++;
    this.clipChildren.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.isClipChildren = function () {
    if (this.clipChildren == null || this.clipChildren == undefined) {
      this.clipChildren = new widget_CommandAttr();
    }
    return this.clipChildren.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setClipChildren = function (value) {
    this.resetIfRequired();
    if (this.clipChildren == null || this.clipChildren == undefined) {
      this.clipChildren = new widget_CommandAttr();
    }
    this.clipChildren.setSetter(true);
    this.clipChildren.setValue(value);
    this.orderSet++;
    this.clipChildren.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetClipToPadding = function () {
    this.resetIfRequired();
    if (this.clipToPadding == null || this.clipToPadding == undefined) {
      this.clipToPadding = new widget_CommandAttr();
    }
    this.clipToPadding.setGetter(true);
    this.orderGet++;
    this.clipToPadding.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.isClipToPadding = function () {
    if (this.clipToPadding == null || this.clipToPadding == undefined) {
      this.clipToPadding = new widget_CommandAttr();
    }
    return this.clipToPadding.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setClipToPadding = function (value) {
    this.resetIfRequired();
    if (this.clipToPadding == null || this.clipToPadding == undefined) {
      this.clipToPadding = new widget_CommandAttr();
    }
    this.clipToPadding.setSetter(true);
    this.clipToPadding.setValue(value);
    this.orderSet++;
    this.clipToPadding.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetDescendantFocusability = function () {
    this.resetIfRequired();
    if (this.descendantFocusability == null || this.descendantFocusability == undefined) {
      this.descendantFocusability = new widget_CommandAttr();
    }
    this.descendantFocusability.setGetter(true);
    this.orderGet++;
    this.descendantFocusability.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.getDescendantFocusability = function () {
    if (this.descendantFocusability == null || this.descendantFocusability == undefined) {
      this.descendantFocusability = new widget_CommandAttr();
    }
    return this.descendantFocusability.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setDescendantFocusability = function (value) {
    this.resetIfRequired();
    if (this.descendantFocusability == null || this.descendantFocusability == undefined) {
      this.descendantFocusability = new widget_CommandAttr();
    }
    this.descendantFocusability.setSetter(true);
    this.descendantFocusability.setValue(value);
    this.orderSet++;
    this.descendantFocusability.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetLayoutMode = function () {
    this.resetIfRequired();
    if (this.layoutMode == null || this.layoutMode == undefined) {
      this.layoutMode = new widget_CommandAttr();
    }
    this.layoutMode.setGetter(true);
    this.orderGet++;
    this.layoutMode.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.getLayoutMode = function () {
    if (this.layoutMode == null || this.layoutMode == undefined) {
      this.layoutMode = new widget_CommandAttr();
    }
    return this.layoutMode.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setLayoutMode = function (value) {
    this.resetIfRequired();
    if (this.layoutMode == null || this.layoutMode == undefined) {
      this.layoutMode = new widget_CommandAttr();
    }
    this.layoutMode.setSetter(true);
    this.layoutMode.setValue(value);
    this.orderSet++;
    this.layoutMode.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetPersistentDrawingCache = function () {
    this.resetIfRequired();
    if (this.persistentDrawingCache == null || this.persistentDrawingCache == undefined) {
      this.persistentDrawingCache = new widget_CommandAttr();
    }
    this.persistentDrawingCache.setGetter(true);
    this.orderGet++;
    this.persistentDrawingCache.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.getPersistentDrawingCache = function () {
    if (this.persistentDrawingCache == null || this.persistentDrawingCache == undefined) {
      this.persistentDrawingCache = new widget_CommandAttr();
    }
    this.persistentDrawingCache.setTransformer('persistentDrawingCache');
    return this.persistentDrawingCache.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setPersistentDrawingCache = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.persistentDrawingCache == null || this.persistentDrawingCache == undefined) {
      this.persistentDrawingCache = new widget_CommandAttr();
    }
    this.persistentDrawingCache.setSetter(true);
    this.persistentDrawingCache.setValue(value);
    this.orderSet++;
    this.persistentDrawingCache.setOrderSet(this.orderSet);
    this.persistentDrawingCache.setTransformer('persistentDrawingCache');
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetSplitMotionEvents = function () {
    this.resetIfRequired();
    if (this.splitMotionEvents == null || this.splitMotionEvents == undefined) {
      this.splitMotionEvents = new widget_CommandAttr();
    }
    this.splitMotionEvents.setGetter(true);
    this.orderGet++;
    this.splitMotionEvents.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.isSplitMotionEvents = function () {
    if (this.splitMotionEvents == null || this.splitMotionEvents == undefined) {
      this.splitMotionEvents = new widget_CommandAttr();
    }
    return this.splitMotionEvents.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setSplitMotionEvents = function (value) {
    this.resetIfRequired();
    if (this.splitMotionEvents == null || this.splitMotionEvents == undefined) {
      this.splitMotionEvents = new widget_CommandAttr();
    }
    this.splitMotionEvents.setSetter(true);
    this.splitMotionEvents.setValue(value);
    this.orderSet++;
    this.splitMotionEvents.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setOnChildViewAdded = function (value) {
    this.resetIfRequired();
    if (this.onChildViewAdded == null || this.onChildViewAdded == undefined) {
      this.onChildViewAdded = new widget_CommandAttr();
    }
    this.onChildViewAdded.setSetter(true);
    this.onChildViewAdded.setValue(value);
    this.orderSet++;
    this.onChildViewAdded.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setOnChildViewRemoved = function (value) {
    this.resetIfRequired();
    if (this.onChildViewRemoved == null || this.onChildViewRemoved == undefined) {
      this.onChildViewRemoved = new widget_CommandAttr();
    }
    this.onChildViewRemoved.setSetter(true);
    this.onChildViewRemoved.setValue(value);
    this.orderSet++;
    this.onChildViewRemoved.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setAnimateLayoutChanges = function (value) {
    this.resetIfRequired();
    if (this.animateLayoutChanges == null || this.animateLayoutChanges == undefined) {
      this.animateLayoutChanges = new widget_CommandAttr();
    }
    this.animateLayoutChanges.setSetter(true);
    this.animateLayoutChanges.setValue(value);
    this.orderSet++;
    this.animateLayoutChanges.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setLayoutTransition = function () {
    var value = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      value[_i] = arguments[_i];
    }
    this.resetIfRequired();
    if (this.layoutTransition == null || this.layoutTransition == undefined) {
      this.layoutTransition = new widget_CommandAttr();
    }
    this.layoutTransition.setSetter(true);
    this.layoutTransition.setValue(value);
    this.orderSet++;
    this.layoutTransition.setOrderSet(this.orderSet);
    this.layoutTransition.setTransformer('layoutTransition');
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setLayoutTransitionDuration = function (value) {
    this.resetIfRequired();
    if (this.layoutTransitionDuration == null || this.layoutTransitionDuration == undefined) {
      this.layoutTransitionDuration = new widget_CommandAttr();
    }
    this.layoutTransitionDuration.setSetter(true);
    this.layoutTransitionDuration.setValue(value);
    this.orderSet++;
    this.layoutTransitionDuration.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setAnimateParentHierarchy = function (value) {
    this.resetIfRequired();
    if (this.animateParentHierarchy == null || this.animateParentHierarchy == undefined) {
      this.animateParentHierarchy = new widget_CommandAttr();
    }
    this.animateParentHierarchy.setSetter(true);
    this.animateParentHierarchy.setValue(value);
    this.orderSet++;
    this.animateParentHierarchy.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setListitem = function (value) {
    this.resetIfRequired();
    if (this.listitem == null || this.listitem == undefined) {
      this.listitem = new widget_CommandAttr();
    }
    this.listitem.setSetter(true);
    this.listitem.setValue(value);
    this.orderSet++;
    this.listitem.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.tryGetAddStatesFromChildren = function () {
    this.resetIfRequired();
    if (this.addStatesFromChildren == null || this.addStatesFromChildren == undefined) {
      this.addStatesFromChildren = new widget_CommandAttr();
    }
    this.addStatesFromChildren.setGetter(true);
    this.orderGet++;
    this.addStatesFromChildren.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.isAddStatesFromChildren = function () {
    if (this.addStatesFromChildren == null || this.addStatesFromChildren == undefined) {
      this.addStatesFromChildren = new widget_CommandAttr();
    }
    return this.addStatesFromChildren.getCommandReturnValue();
  };
  ViewGroupImpl.prototype.setAddStatesFromChildren = function (value) {
    this.resetIfRequired();
    if (this.addStatesFromChildren == null || this.addStatesFromChildren == undefined) {
      this.addStatesFromChildren = new widget_CommandAttr();
    }
    this.addStatesFromChildren.setSetter(true);
    this.addStatesFromChildren.setValue(value);
    this.orderSet++;
    this.addStatesFromChildren.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl.prototype.setChildXml = function (value) {
    this.resetIfRequired();
    if (this.childXml == null || this.childXml == undefined) {
      this.childXml = new widget_CommandAttr();
    }
    this.childXml.setSetter(true);
    this.childXml.setValue(value);
    this.orderSet++;
    this.childXml.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "alwaysDrawnWithCache"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "alwaysDrawnWithCache", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "animationCache"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "animationCache", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "clipChildren"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "clipChildren", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "clipToPadding"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "clipToPadding", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "descendantFocusability"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "descendantFocusability", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layoutMode"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "layoutMode", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "persistentDrawingCache"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "persistentDrawingCache", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "splitMotionEvents"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "splitMotionEvents", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onChildViewAdded"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "onChildViewAdded", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "onChildViewRemoved"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "onChildViewRemoved", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "animateLayoutChanges"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "animateLayoutChanges", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layoutTransition"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "layoutTransition", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layoutTransitionDuration"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "layoutTransitionDuration", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "animateParentHierarchy"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "animateParentHierarchy", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "listitem"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "listitem", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "addStatesFromChildren"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "addStatesFromChildren", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "childXml"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "childXml", void 0);
  ViewGroupImpl_decorate([decorate(Exclude()), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl.prototype, "thisPointer", void 0);
  return ViewGroupImpl;
}(ViewGroupModelImpl);

//start - staticinit
var ViewGroupImpl_LayoutParams = /** @class */function () {
  function ViewGroupImpl_LayoutParams() {
    this.orderGet = 0;
    this.orderSet = 0;
    this.thisPointer = this.getThisPointer();
  }
  ViewGroupImpl_LayoutParams.prototype.reset = function () {
    this.layout_marginBottom = undefined;
    this.layout_marginTop = undefined;
    this.layout_marginStart = undefined;
    this.layout_marginEnd = undefined;
    this.layout_marginLeft = undefined;
    this.layout_marginRight = undefined;
    this.layout_margin = undefined;
    this.layout_marginHorizontal = undefined;
    this.layout_marginVertical = undefined;
    this.orderGet = 0;
    this.orderSet = 0;
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.tryGetLayoutMarginBottom = function () {
    if (this.layout_marginBottom == null || this.layout_marginBottom == undefined) {
      this.layout_marginBottom = new widget_CommandAttr();
    }
    this.layout_marginBottom.setGetter(true);
    this.orderGet++;
    this.layout_marginBottom.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.getLayoutMarginBottom = function () {
    if (this.layout_marginBottom == null || this.layout_marginBottom == undefined) {
      this.layout_marginBottom = new widget_CommandAttr();
    }
    return this.layout_marginBottom.getCommandReturnValue();
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginBottom = function (value) {
    if (this.layout_marginBottom == null || this.layout_marginBottom == undefined) {
      this.layout_marginBottom = new widget_CommandAttr();
    }
    this.layout_marginBottom.setSetter(true);
    this.layout_marginBottom.setValue(value);
    this.orderSet++;
    this.layout_marginBottom.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.tryGetLayoutMarginTop = function () {
    if (this.layout_marginTop == null || this.layout_marginTop == undefined) {
      this.layout_marginTop = new widget_CommandAttr();
    }
    this.layout_marginTop.setGetter(true);
    this.orderGet++;
    this.layout_marginTop.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.getLayoutMarginTop = function () {
    if (this.layout_marginTop == null || this.layout_marginTop == undefined) {
      this.layout_marginTop = new widget_CommandAttr();
    }
    return this.layout_marginTop.getCommandReturnValue();
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginTop = function (value) {
    if (this.layout_marginTop == null || this.layout_marginTop == undefined) {
      this.layout_marginTop = new widget_CommandAttr();
    }
    this.layout_marginTop.setSetter(true);
    this.layout_marginTop.setValue(value);
    this.orderSet++;
    this.layout_marginTop.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.tryGetLayoutMarginStart = function () {
    if (this.layout_marginStart == null || this.layout_marginStart == undefined) {
      this.layout_marginStart = new widget_CommandAttr();
    }
    this.layout_marginStart.setGetter(true);
    this.orderGet++;
    this.layout_marginStart.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.getLayoutMarginStart = function () {
    if (this.layout_marginStart == null || this.layout_marginStart == undefined) {
      this.layout_marginStart = new widget_CommandAttr();
    }
    return this.layout_marginStart.getCommandReturnValue();
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginStart = function (value) {
    if (this.layout_marginStart == null || this.layout_marginStart == undefined) {
      this.layout_marginStart = new widget_CommandAttr();
    }
    this.layout_marginStart.setSetter(true);
    this.layout_marginStart.setValue(value);
    this.orderSet++;
    this.layout_marginStart.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.tryGetLayoutMarginEnd = function () {
    if (this.layout_marginEnd == null || this.layout_marginEnd == undefined) {
      this.layout_marginEnd = new widget_CommandAttr();
    }
    this.layout_marginEnd.setGetter(true);
    this.orderGet++;
    this.layout_marginEnd.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.getLayoutMarginEnd = function () {
    if (this.layout_marginEnd == null || this.layout_marginEnd == undefined) {
      this.layout_marginEnd = new widget_CommandAttr();
    }
    return this.layout_marginEnd.getCommandReturnValue();
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginEnd = function (value) {
    if (this.layout_marginEnd == null || this.layout_marginEnd == undefined) {
      this.layout_marginEnd = new widget_CommandAttr();
    }
    this.layout_marginEnd.setSetter(true);
    this.layout_marginEnd.setValue(value);
    this.orderSet++;
    this.layout_marginEnd.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.tryGetLayoutMarginLeft = function () {
    if (this.layout_marginLeft == null || this.layout_marginLeft == undefined) {
      this.layout_marginLeft = new widget_CommandAttr();
    }
    this.layout_marginLeft.setGetter(true);
    this.orderGet++;
    this.layout_marginLeft.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.getLayoutMarginLeft = function () {
    if (this.layout_marginLeft == null || this.layout_marginLeft == undefined) {
      this.layout_marginLeft = new widget_CommandAttr();
    }
    return this.layout_marginLeft.getCommandReturnValue();
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginLeft = function (value) {
    if (this.layout_marginLeft == null || this.layout_marginLeft == undefined) {
      this.layout_marginLeft = new widget_CommandAttr();
    }
    this.layout_marginLeft.setSetter(true);
    this.layout_marginLeft.setValue(value);
    this.orderSet++;
    this.layout_marginLeft.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.tryGetLayoutMarginRight = function () {
    if (this.layout_marginRight == null || this.layout_marginRight == undefined) {
      this.layout_marginRight = new widget_CommandAttr();
    }
    this.layout_marginRight.setGetter(true);
    this.orderGet++;
    this.layout_marginRight.setOrderGet(this.orderGet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.getLayoutMarginRight = function () {
    if (this.layout_marginRight == null || this.layout_marginRight == undefined) {
      this.layout_marginRight = new widget_CommandAttr();
    }
    return this.layout_marginRight.getCommandReturnValue();
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginRight = function (value) {
    if (this.layout_marginRight == null || this.layout_marginRight == undefined) {
      this.layout_marginRight = new widget_CommandAttr();
    }
    this.layout_marginRight.setSetter(true);
    this.layout_marginRight.setValue(value);
    this.orderSet++;
    this.layout_marginRight.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMargin = function (value) {
    if (this.layout_margin == null || this.layout_margin == undefined) {
      this.layout_margin = new widget_CommandAttr();
    }
    this.layout_margin.setSetter(true);
    this.layout_margin.setValue(value);
    this.orderSet++;
    this.layout_margin.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginHorizontal = function (value) {
    if (this.layout_marginHorizontal == null || this.layout_marginHorizontal == undefined) {
      this.layout_marginHorizontal = new widget_CommandAttr();
    }
    this.layout_marginHorizontal.setSetter(true);
    this.layout_marginHorizontal.setValue(value);
    this.orderSet++;
    this.layout_marginHorizontal.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_LayoutParams.prototype.setLayoutMarginVertical = function (value) {
    if (this.layout_marginVertical == null || this.layout_marginVertical == undefined) {
      this.layout_marginVertical = new widget_CommandAttr();
    }
    this.layout_marginVertical.setSetter(true);
    this.layout_marginVertical.setValue(value);
    this.orderSet++;
    this.layout_marginVertical.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layout_marginBottom"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginBottom", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layout_marginTop"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginTop", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layout_marginStart"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginStart", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layout_marginEnd"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginEnd", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layout_marginLeft"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginLeft", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layout_marginRight"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginRight", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layout_margin"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_margin", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layout_marginHorizontal"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginHorizontal", void 0);
  ViewGroupImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layout_marginVertical"
  })), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "layout_marginVertical", void 0);
  ViewGroupImpl_decorate([decorate(Exclude()), ViewGroupImpl_metadata("design:type", Object)], ViewGroupImpl_LayoutParams.prototype, "thisPointer", void 0);
  ViewGroupImpl_decorate([decorate(Exclude()), ViewGroupImpl_metadata("design:type", Number)], ViewGroupImpl_LayoutParams.prototype, "orderGet", void 0);
  ViewGroupImpl_decorate([decorate(Exclude()), ViewGroupImpl_metadata("design:type", Number)], ViewGroupImpl_LayoutParams.prototype, "orderSet", void 0);
  return ViewGroupImpl_LayoutParams;
}();

var ViewGroup_LayoutParams = /** @class */function (_super) {
  ViewGroupImpl_extends(ViewGroup_LayoutParams, _super);
  function ViewGroup_LayoutParams() {
    return _super.call(this) || this;
  }
  ViewGroup_LayoutParams.prototype.getThisPointer = function () {
    return this;
  };
  return ViewGroup_LayoutParams;
}(ViewGroupImpl_LayoutParams);

var ViewGroup = /** @class */function (_super) {
  ViewGroupImpl_extends(ViewGroup, _super);
  function ViewGroup(id, path, event) {
    return _super.call(this, id, path, event) || this;
  }
  ViewGroup.prototype.getThisPointer = function () {
    return this;
  };
  ViewGroup.prototype.getClass = function () {
    return ViewGroup;
  };
  return ViewGroup;
}(ViewGroupImpl);

ViewGroupImpl.initialize();
//end - staticinit
;// ./src/android/widget/fragmentImpl.ts
function fragmentImpl_typeof(o) { "@babel/helpers - typeof"; return fragmentImpl_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, fragmentImpl_typeof(o); }
// start - imports
var fragmentImpl_extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var fragmentImpl_decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : fragmentImpl_typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var fragmentImpl_metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : fragmentImpl_typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var fragmentImpl_navigate = /** @class */function () {
  function fragmentImpl_navigate() {}
  fragmentImpl_decorate([decorate(Expose({
    name: "actionId"
  })), fragmentImpl_metadata("design:type", String)], fragmentImpl_navigate.prototype, "actionId", void 0);
  fragmentImpl_decorate([decorate(Expose({
    name: "scopeObjects"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl_navigate.prototype, "scopeObjects", void 0);
  return fragmentImpl_navigate;
}();

var fragmentImpl_navigateWithPopBackStack = /** @class */function () {
  function fragmentImpl_navigateWithPopBackStack() {}
  fragmentImpl_decorate([decorate(Expose({
    name: "actionId"
  })), fragmentImpl_metadata("design:type", String)], fragmentImpl_navigateWithPopBackStack.prototype, "actionId", void 0);
  fragmentImpl_decorate([decorate(Expose({
    name: "scopeObjects"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl_navigateWithPopBackStack.prototype, "scopeObjects", void 0);
  return fragmentImpl_navigateWithPopBackStack;
}();

var fragmentImpl_navigateAsTop = /** @class */function () {
  function fragmentImpl_navigateAsTop() {}
  fragmentImpl_decorate([decorate(Expose({
    name: "actionId"
  })), fragmentImpl_metadata("design:type", String)], fragmentImpl_navigateAsTop.prototype, "actionId", void 0);
  fragmentImpl_decorate([decorate(Expose({
    name: "scopeObjects"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl_navigateAsTop.prototype, "scopeObjects", void 0);
  return fragmentImpl_navigateAsTop;
}();

var fragmentImpl_navigateWithPopBackStackTo = /** @class */function () {
  function fragmentImpl_navigateWithPopBackStackTo() {}
  fragmentImpl_decorate([decorate(Expose({
    name: "actionId"
  })), fragmentImpl_metadata("design:type", String)], fragmentImpl_navigateWithPopBackStackTo.prototype, "actionId", void 0);
  fragmentImpl_decorate([decorate(Expose({
    name: "destinationId"
  })), fragmentImpl_metadata("design:type", String)], fragmentImpl_navigateWithPopBackStackTo.prototype, "destinationId", void 0);
  fragmentImpl_decorate([decorate(Expose({
    name: "inclusive"
  })), fragmentImpl_metadata("design:type", Boolean)], fragmentImpl_navigateWithPopBackStackTo.prototype, "inclusive", void 0);
  fragmentImpl_decorate([decorate(Expose({
    name: "scopeObjects"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl_navigateWithPopBackStackTo.prototype, "scopeObjects", void 0);
  return fragmentImpl_navigateWithPopBackStackTo;
}();

var fragmentImpl_popBackStackTo = /** @class */function () {
  function fragmentImpl_popBackStackTo() {}
  fragmentImpl_decorate([decorate(Expose({
    name: "destinationId"
  })), fragmentImpl_metadata("design:type", String)], fragmentImpl_popBackStackTo.prototype, "destinationId", void 0);
  fragmentImpl_decorate([decorate(Expose({
    name: "inclusive"
  })), fragmentImpl_metadata("design:type", Boolean)], fragmentImpl_popBackStackTo.prototype, "inclusive", void 0);
  return fragmentImpl_popBackStackTo;
}();

// end - imports

var fragmentImpl = /** @class */function (_super) {
  fragmentImpl_extends(fragmentImpl, _super);
  function fragmentImpl(id, path, event) {
    var _this = _super.call(this, id, path, event) || this;
    _this.thisPointer = _this.getThisPointer();
    return _this;
  }
  //start - body
  fragmentImpl.initialize = function () {};
  fragmentImpl.prototype.reset = function () {
    _super.prototype.reset.call(this);
    this.name = undefined;
    this.layout = undefined;
    this.navGraph = undefined;
    this.tag = undefined;
    this.replace_ = undefined;
    this.navigate_ = undefined;
    this.popBackStack_ = undefined;
    this.navigateWithPopBackStack_ = undefined;
    this.navigateAsTop_ = undefined;
    this.navigateWithPopBackStackTo_ = undefined;
    this.popBackStackTo_ = undefined;
    this.closeDialog_ = undefined;
    this.rootDirectory = undefined;
    this.namespace = undefined;
    return this.thisPointer;
  };
  fragmentImpl.prototype.setName = function (value) {
    this.resetIfRequired();
    if (this.name == null || this.name == undefined) {
      this.name = new widget_CommandAttr();
    }
    this.name.setSetter(true);
    this.name.setValue(value);
    this.orderSet++;
    this.name.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.setLayout = function (value) {
    this.resetIfRequired();
    if (this.layout == null || this.layout == undefined) {
      this.layout = new widget_CommandAttr();
    }
    this.layout.setSetter(true);
    this.layout.setValue(value);
    this.orderSet++;
    this.layout.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.setNavGraph = function (value) {
    this.resetIfRequired();
    if (this.navGraph == null || this.navGraph == undefined) {
      this.navGraph = new widget_CommandAttr();
    }
    this.navGraph.setSetter(true);
    this.navGraph.setValue(value);
    this.orderSet++;
    this.navGraph.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.setTag = function (value) {
    this.resetIfRequired();
    if (this.tag == null || this.tag == undefined) {
      this.tag = new widget_CommandAttr();
    }
    this.tag.setSetter(true);
    this.tag.setValue(value);
    this.orderSet++;
    this.tag.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.replace = function (value) {
    this.resetIfRequired();
    if (this.replace_ == null || this.replace_ == undefined) {
      this.replace_ = new widget_CommandAttr();
    }
    this.replace_.setSetter(true);
    this.replace_.setValue(value);
    this.orderSet++;
    this.replace_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.navigate = function (actionId, scopeObjects) {
    this.resetIfRequired();
    if (this.navigate_ == null || this.navigate_ == undefined) {
      this.navigate_ = new widget_CommandAttr();
    }
    var wrapper = new fragmentImpl_navigate();
    wrapper.actionId = actionId;
    wrapper.scopeObjects = scopeObjects;
    this.navigate_.setSetter(true);
    this.navigate_.setValue(wrapper);
    this.orderSet++;
    this.navigate_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.popBackStack = function () {
    this.resetIfRequired();
    if (this.popBackStack_ == null || this.popBackStack_ == undefined) {
      this.popBackStack_ = new widget_CommandAttr();
    }
    this.popBackStack_.setSetter(true);
    this.orderSet++;
    this.popBackStack_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.navigateWithPopBackStack = function (actionId, scopeObjects) {
    this.resetIfRequired();
    if (this.navigateWithPopBackStack_ == null || this.navigateWithPopBackStack_ == undefined) {
      this.navigateWithPopBackStack_ = new widget_CommandAttr();
    }
    var wrapper = new fragmentImpl_navigateWithPopBackStack();
    wrapper.actionId = actionId;
    wrapper.scopeObjects = scopeObjects;
    this.navigateWithPopBackStack_.setSetter(true);
    this.navigateWithPopBackStack_.setValue(wrapper);
    this.orderSet++;
    this.navigateWithPopBackStack_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.navigateAsTop = function (actionId, scopeObjects) {
    this.resetIfRequired();
    if (this.navigateAsTop_ == null || this.navigateAsTop_ == undefined) {
      this.navigateAsTop_ = new widget_CommandAttr();
    }
    var wrapper = new fragmentImpl_navigateAsTop();
    wrapper.actionId = actionId;
    wrapper.scopeObjects = scopeObjects;
    this.navigateAsTop_.setSetter(true);
    this.navigateAsTop_.setValue(wrapper);
    this.orderSet++;
    this.navigateAsTop_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.navigateWithPopBackStackTo = function (actionId, destinationId, inclusive, scopeObjects) {
    this.resetIfRequired();
    if (this.navigateWithPopBackStackTo_ == null || this.navigateWithPopBackStackTo_ == undefined) {
      this.navigateWithPopBackStackTo_ = new widget_CommandAttr();
    }
    var wrapper = new fragmentImpl_navigateWithPopBackStackTo();
    wrapper.actionId = actionId;
    wrapper.destinationId = destinationId;
    wrapper.inclusive = inclusive;
    wrapper.scopeObjects = scopeObjects;
    this.navigateWithPopBackStackTo_.setSetter(true);
    this.navigateWithPopBackStackTo_.setValue(wrapper);
    this.orderSet++;
    this.navigateWithPopBackStackTo_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.popBackStackTo = function (destinationId, inclusive) {
    this.resetIfRequired();
    if (this.popBackStackTo_ == null || this.popBackStackTo_ == undefined) {
      this.popBackStackTo_ = new widget_CommandAttr();
    }
    var wrapper = new fragmentImpl_popBackStackTo();
    wrapper.destinationId = destinationId;
    wrapper.inclusive = inclusive;
    this.popBackStackTo_.setSetter(true);
    this.popBackStackTo_.setValue(wrapper);
    this.orderSet++;
    this.popBackStackTo_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.closeDialog = function (value) {
    this.resetIfRequired();
    if (this.closeDialog_ == null || this.closeDialog_ == undefined) {
      this.closeDialog_ = new widget_CommandAttr();
    }
    this.closeDialog_.setSetter(true);
    this.closeDialog_.setValue(value);
    this.orderSet++;
    this.closeDialog_.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.setRootDirectory = function (value) {
    this.resetIfRequired();
    if (this.rootDirectory == null || this.rootDirectory == undefined) {
      this.rootDirectory = new widget_CommandAttr();
    }
    this.rootDirectory.setSetter(true);
    this.rootDirectory.setValue(value);
    this.orderSet++;
    this.rootDirectory.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl.prototype.setNamespace = function (value) {
    this.resetIfRequired();
    if (this.namespace == null || this.namespace == undefined) {
      this.namespace = new widget_CommandAttr();
    }
    this.namespace.setSetter(true);
    this.namespace.setValue(value);
    this.orderSet++;
    this.namespace.setOrderSet(this.orderSet);
    return this.thisPointer;
  };
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "name"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "name", void 0);
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "layout"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "layout", void 0);
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "navGraph"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "navGraph", void 0);
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "tag"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "tag", void 0);
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "replace"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "replace_", void 0);
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "navigate"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "navigate_", void 0);
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "popBackStack"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "popBackStack_", void 0);
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "navigateWithPopBackStack"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "navigateWithPopBackStack_", void 0);
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "navigateAsTop"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "navigateAsTop_", void 0);
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "navigateWithPopBackStackTo"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "navigateWithPopBackStackTo_", void 0);
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "popBackStackTo"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "popBackStackTo_", void 0);
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "closeDialog"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "closeDialog_", void 0);
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "rootDirectory"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "rootDirectory", void 0);
  fragmentImpl_decorate([decorate(Type(function () {
    return widget_CommandAttr;
  })), decorate(Expose({
    name: "namespace"
  })), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "namespace", void 0);
  fragmentImpl_decorate([decorate(Exclude()), fragmentImpl_metadata("design:type", Object)], fragmentImpl.prototype, "thisPointer", void 0);
  return fragmentImpl;
}(ViewGroupImpl);

//start - staticinit
var fragment = /** @class */function (_super) {
  fragmentImpl_extends(fragment, _super);
  function fragment(id, path, event) {
    return _super.call(this, id, path, event) || this;
  }
  fragment.prototype.getThisPointer = function () {
    return this;
  };
  fragment.prototype.getClass = function () {
    return fragment;
  };
  return fragment;
}(fragmentImpl);

fragmentImpl.initialize();
//end - staticinit
;// ./src/Dashboard.ts
function Dashboard_typeof(o) { "@babel/helpers - typeof"; return Dashboard_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, Dashboard_typeof(o); }
//start - import
var Dashboard_extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var Dashboard_decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : Dashboard_typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var Dashboard_metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : Dashboard_typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var Dashboard_awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var Dashboard_generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};
//end - import



//start - className
var Dashboard = /** @class */function (_super) {
  Dashboard_extends(Dashboard, _super);
  function Dashboard() {
    return _super !== null && _super.apply(this, arguments) || this;
  }
  Dashboard.createInstance = function () {
    return new Dashboard();
  };
  Dashboard.prototype.goToPreviousScreen = function () {
    return Dashboard_awaiter(this, void 0, void 0, function () {
      return Dashboard_generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4 /*yield*/, this.navController.reset().popBackStack().executeCommand()];
          case 1:
            _a.sent();
            return [2 /*return*/];
        }
      });
    });
  };
  Dashboard.prototype.goBack = function () {
    return Dashboard_awaiter(this, void 0, void 0, function () {
      return Dashboard_generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4 /*yield*/, this.nav_host_fragment_container.popBackStack()];
          case 1:
            _a.sent();
            this.executeCommand(this.nav_host_fragment_container);
            return [2 /*return*/];
        }
      });
    });
  };
  Dashboard_decorate([InjectController({}), Dashboard_metadata("design:type", NavController)], Dashboard.prototype, "navController", void 0);
  Dashboard_decorate([Inject({
    id: "@+id/nav_host_fragment_container"
  }), Dashboard_metadata("design:type", fragment)], Dashboard.prototype, "nav_host_fragment_container", void 0);
  return Dashboard;
}(Fragment
//end - className
);
/* harmony default export */ var src_Dashboard = (Dashboard);
;// ./src/R/NavGraphChild.ts
var NavGraphChild_action_error_to_error_detail = 'action_error_to_error_detail#@layout/error_detail';
var NavGraphChild_index = 'fragment#index#layout/home.xml';
var dashboard = 'fragment#dashboard#layout/dashboard.xml';
var NavGraphChild_error = 'fragment#error#layout/error.xml';
var NavGraphChild_error_detail = 'fragment#error_detail#layout/error_detail.xml';
;// ./src/Home.ts
function Home_typeof(o) { "@babel/helpers - typeof"; return Home_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, Home_typeof(o); }
//start - import
var Home_extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var Home_decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : Home_typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var Home_metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : Home_typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var Home_awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var Home_generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};
//end - import




//start - className
var Home = /** @class */function (_super) {
  Home_extends(Home, _super);
  function Home() {
    return _super !== null && _super.apply(this, arguments) || this;
  }
  Home.createInstance = function () {
    return new Home();
  };
  Home.prototype.goToPreviousScreen = function () {
    return Home_awaiter(this, void 0, void 0, function () {
      return Home_generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4 /*yield*/, this.navController.reset().popBackStack().executeCommand()];
          case 1:
            _a.sent();
            return [2 /*return*/];
        }
      });
    });
  };
  Home.prototype.gotToDashBoard = function () {
    this.nav_host_fragment_container.navigate(dashboard, []);
    this.executeCommand(this.nav_host_fragment_container);
  };
  Home_decorate([InjectController({}), Home_metadata("design:type", NavController)], Home.prototype, "navController", void 0);
  Home_decorate([Inject({
    id: "@+id/nav_host_fragment_container"
  }), Home_metadata("design:type", fragment)], Home.prototype, "nav_host_fragment_container", void 0);
  return Home;
}(Fragment
//end - className
);
/* harmony default export */ var src_Home = (Home);
;// ./src/Index.ts
function Index_typeof(o) { "@babel/helpers - typeof"; return Index_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, Index_typeof(o); }
//start - import
var Index_extends = undefined && undefined.__extends || function () {
  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return _extendStatics(d, b);
  };
  return function (d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    _extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var Index_decorate = undefined && undefined.__decorate || function (decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if ((typeof Reflect === "undefined" ? "undefined" : Index_typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var Index_metadata = undefined && undefined.__metadata || function (k, v) {
  if ((typeof Reflect === "undefined" ? "undefined" : Index_typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var Index_awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var Index_generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};

//end - import


var Index = /** @class */function (_super) {
  Index_extends(Index, _super);
  //end - body
  function Index() {
    return _super.call(this) || this;
  }
  Index.createInstance = function () {
    return new Index();
  };
  Index.prototype.goToPreviousScreen = function () {
    return Index_awaiter(this, void 0, void 0, function () {
      return Index_generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4 /*yield*/, this.navController.reset().popBackStack().executeCommand()];
          case 1:
            _a.sent();
            return [2 /*return*/];
        }
      });
    });
  };
  Index.prototype.onCreate = function (obj) {
    //alert("If you receive this  alert, you are good to write your first program");
  };
  Index_decorate([InjectController({}), Index_metadata("design:type", NavController)], Index.prototype, "navController", void 0);
  Index_decorate([Inject({
    id: "@+id/nav_host_fragment_container"
  }), Index_metadata("design:type", fragment)], Index.prototype, "nav_host_fragment_container", void 0);
  return Index;
}(Fragment);
/* harmony default export */ var src_Index = (Index);
;// ./src/FragmentMapper.ts


//start - import



//end - import
var fragmentMapper = {
  'layout/error.xml': src_ErrorFragment,
  'layout/error_detail.xml': src_ErrorDetailFragment,
  //start - body
  'layout/dashboard.xml': src_Dashboard,
  'layout/home.xml': src_Home,
  'layout/index.xml': src_Index
  //end - body
};
;// ./src/ChildApp.ts
var ChildApp_awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var ChildApp_generator = undefined && undefined.__generator || function (thisArg, body) {
  var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
};


var AppLoaderWrapper = /** @class */function () {
  function AppLoaderWrapper() {}
  AppLoaderWrapper.prototype.loadApp = function (rootDirectory) {
    return ChildApp_awaiter(this, void 0, void 0, function () {
      return ChildApp_generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [4 /*yield*/, this.initLocale(rootDirectory)];
          case 1:
            _a.sent();
            return [2 /*return*/];
        }
      });
    });
  };
  AppLoaderWrapper.prototype.initLocale = function (rootDirectory) {
    return new Promise(function (resolve) {
      app_LocaleManager.getInstance().init(function () {
        resolve();
      }, rootDirectory);
    });
  };
  return AppLoaderWrapper;
}();
window.__DYNAMIC_MODULE__ = {
  fragmentMapper: fragmentMapper,
  AppLoader: AppLoaderWrapper
};
var ChildApp_fragmentMapper = (/* unused pure expression or super */ null && (mapper));
var AppLoader = (/* unused pure expression or super */ null && (AppLoaderWrapper));
}();
/******/ })()
;
//# sourceMappingURL=index_lite.js.map
export const fragmentMapper = window.__DYNAMIC_MODULE__.fragmentMapper;
export const AppLoader = window.__DYNAMIC_MODULE__.AppLoader;
